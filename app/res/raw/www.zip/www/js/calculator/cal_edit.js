
window.currentDemo = {};
window.calculatorList = [];
window.flagFrom = "";
window.Demo = {
    kSize: 0,
    qSize: 0,//填空个数
    calculator: null,
    currentEnterIndex: 0,//当前enter的个数
    hasNext: true,//填空是否拥有下一个文字
    onNeedEnter: true,//是否需要响应enter
    onEnterCallBack: function (i) {
        Demo.currentEnterIndex++;
        if (Demo.currentEnterIndex == Demo.qSize) {
            Demo.onNeedEnter = false;
            //oplatex();
        }
    },
    canTouch: true
};

window.jsComplete = function(templateIndex, subTemplateIndex, latexList, flag) {
    flagFrom = flag;
    var dom = $('div[data-template-index="' + templateIndex + '"][data-sub-template-index="' + subTemplateIndex + '"]')[0];
    var calculator = Desmos.Calculator(dom, {"keypad": true, "graphpaper": false, "solutions": true, "lockViewport": true});
    calculatorList.push(calculator);
    latexList = latexList || [{id: "1", expression: " "}];
    $.each(latexList, function (index, latex) {
        calculator.setExpression({id: $.trim(latex.key ? latex.key + index : index), latex: latex.value ? latex.value : (latex || " ")});
        //calculator.setExpression({id: "", latex: " "});
        if (!flag) {
            var close = '<span class="exercises-close delete-textentry-choice" data-template-index="' + templateIndex + '" data-sub-template-index="' + subTemplateIndex + '" data-choice-index="' + index + '"></span>';
            if (index >= 1) {
                $($(dom).find(".dcg-expressionitem")[index]).prepend($(close));
            }
        }
    });
    Desmos.$("#latex_content").hide();
    Demo.qSize = Desmos.$(".latex_splite").size() - 1;
    addLine(Demo.qSize, 0);
    if (Demo.qSize == 0) {
        Demo.onNeedEnter = false;
        //oplatex();
    }
}

window.jsCompleteForBasic = function(dom, latex, flag) {
    flagFrom = flag;
    var calculator = Desmos.Calculator(dom, {"keypad": true, "graphpaper": false, "solutions": true, "lockViewport": true});
    calculatorList.push(calculator);
    calculator.setExpression({id: dom.id, latex: latex || " "});
    Desmos.$("#latex_content").hide();
    Demo.qSize = Desmos.$(".latex_splite").size() - 1;
    addLine(Demo.qSize, 0);
    if (Demo.qSize == 0) {
        Demo.onNeedEnter = false;
    }
}

function fillRect() {
    var $fill = Desmos.$(".dcg-template-expressioneach .dcg-expressionitem");
    var fillCount = $fill.size();
    if (fillCount > 0) {
        var offsetStr = "";
        for (var i = 0; i < fillCount; i++) {
            var $fillItem = $fill.eq(i);
            var l, r, t, b;
            l = $fillItem.offset().left;
            t = $fillItem.offset().top;
            r = l + $fillItem.width();
            b = t + $fillItem.height();
            offsetStr += l + "," + t + "," + r + "," + b + ";";
        }
    }
};


/*
 * 填入指定位置
 */
function writeLatex(i, str) {
    var edit_main = Desmos.$(".dcg-template-expressioneach .dcg-expressionitem").eq(i).find('.mathquill-editable');
    edit_main.mathquill('latex', "");
    edit_main.trigger('render');
    clickHandler("add", str, 0, i);

}

/**
 * 清除填空
 */
function clearLatex(i) {
    var edit_main = Desmos.$(".dcg-template-expressioneach .dcg-expressionitem").eq(i).find('.mathquill-editable');
    edit_main.mathquill('latex', "");
    edit_main.trigger('render');
    getResult();
}


/**
 * 清除所有填空内容
 */
function clearLatexAll() {
    var edit_main = Desmos.$(".dcg-template-expressioneach .dcg-expressionitem").find('.mathquill-editable');
    edit_main.mathquill('latex', "");
    edit_main.trigger('render');
    getResult();
}

/**
 * 隐藏填空光标
 */
function hideCursor() {
    Demo.canTouch = false;
    Desmos.$(".mq-line").hide();
}

/**
 * 显示填空光标
 */
function showCursor() {
    Demo.canTouch = true;
    Desmos.$(".mq-line").show();
}


function oplatex() {
    console.log("oplatex_start:" + new Date().getSeconds() + ":" + new Date().getMilliseconds());
    var dd = Desmos.$("#latex_content").html().split('<span class="latex_splite"></span>');
    var length = Desmos.$("#latex_content").attr("length").split(',');

    Demo.kSize = dd.length;
    for (var i = 0; i < Demo.kSize; i++) {
        var editlength = length[i];
        var widthPerc = (5 * editlength > 50) ? 50 : 5 * editlength;
        var html = dd[i];
        if (i == (Demo.kSize - 1)) {
            Desmos.$(".dcg-template-expressioneach .dcg-expressionitem").eq(i - 1).after(html);
        } else {
            var $exp = Desmos.$(".dcg-template-expressioneach .dcg-expressionitem").eq(i)
            $exp.before(html);
            $exp.css("width", widthPerc + "%");
            $exp.find(".mathquill-root-block").css("width", parseInt($exp.css("width")) - 10);
        }
    }

    setTimeout(fillRect, 300);
    setTimeout(getFeedBackLocation, 400);
}

// 获取赋值后的方程式表达式
window.getResult = function() {
    var state = currentDemo.getState();
    if (flagFrom == "student") {
        var parentBox = currentDemo._calc.expressions.$exppanel.parents(".answerbox");
        var templateIndex = parentBox.data().templateIndex;
        var subTemplateIndex = parentBox.data().subTemplateIndex;
        var template = window.student.getTemplates();
        var subTemplate = template[templateIndex].sub_template_details[subTemplateIndex];

        $.each(state.expressions.list, function (index, expression) {
            window.student.setAnswer(subTemplate, expression.latex, index);
        });
    } else if (flagFrom == "basic") {
        $.each(state.expressions.list, function (index, expression) {
            var calIndex = calculatorList.indexOf(currentDemo);
            window.basic.setAnswer(calIndex, expression.latex)
        });
    } else {
        var parentBox = currentDemo._calc.expressions.$exppanel.parents(".answer-input-box");
        var templateIndex = parentBox.data().templateIndex;
        var subTemplateIndex = parentBox.data().subTemplateIndex;
        var template = window.templates;
        var subTemplate = template[templateIndex].sub_template_detail_list[subTemplateIndex];
        var question_choice = [];
        $.each(state.expressions.list, function (index, expression) {
            var choice = {key: expression.id, value: expression.latex || " "};
            question_choice.push(choice);
        });
        subTemplate.question_choice = question_choice;
    }
}


function addOnKey(word) {
    var edit_main = Desmos.$('.dcg-selected').find('.mathquill-editable');
    edit_main.mathquill('onKey', word);
    edit_main.trigger('render');
    getResult();
}


/*
 * 回退
 */
function backSpace() {
    addOnKey("Backspace");
}

function addLine(count, h) {
    for (var i = 0; i < count; i++) {
        addOnKey("Enter");
    }
}

/*
 * 新增字符串
 */
function addCmd(word) {
    var edit_main = Desmos.$('.dcg-selected').find('.mathquill-editable');
    edit_main.mathquill('cmd', word);
    edit_main.trigger('render');
    getResult();
}

// onkey backspace

// render

function buttonClicked(act, key, index) {
    if (currentDemo) {
        key = key.replace("\\int", '\\intt');
        var edit_main;
        var calIndex = calculatorList.indexOf(currentDemo);
        // edit_main = Desmos.$($('.dcg-container')[calIndex]).find('.dcg-selected').find('.mathquill-editable');
        if (typeof index == "undefined") {
            //edit_main = Desmos.$('.dcg-selected').find('.mathquill-editable');
            edit_main = Desmos.$($('.dcg-container')[0]).find('.dcg-selected').find('.mathquill-editable');
        } else {
            edit_main = Desmos.$(".dcg-template-expressioneach .dcg-expressionitem").eq(index).find('.mathquill-editable');
        }
        if (act == "render") {
            edit_main.trigger(act);
        }
        else {
            edit_main.mathquill(act, key);
        }
        edit_main.find(".mathquill-root-block").scrollLeft(10000);
    }
}

window.clickHandler = function(act, key, args, index, keyboard) {
    if(keyboard) {
        window.symbolKeyboard = true
    } else {
        window.symbolKeyboard = false
    }

    if (act == "key") {
        buttonClicked("onKey", key, index);
    } else if (act == "cmd") {
        buttonClicked("cmd", key, index);
    } else if (act == "func") {
        var suffix = '\\left( \\right)';
        if ((args || 0) === 2) {
            suffix = '\\left({},{}\\right)';
        }
        buttonClicked('write', key + suffix, index);
        buttonClicked('onKey', 'Left', index);
        if ((args || 0) === 2) {
            buttonClicked('onKey', 'Left', index);
        }

    } else if (act == "custom") {
        switch (key) {
            case 'loga':

                buttonClicked('write', 'log_{}\\left( \\right)', index);
                buttonClicked('onKey', 'Left', index);
                buttonClicked('onKey', 'Left', index);
                buttonClicked('onKey', 'Left', index);
                break;
            case 'cuberoot':
                buttonClicked('write', '\\sqrt[3]{}', index);
                buttonClicked('onKey', 'Left', index);
                break;
            case 'squared':
                buttonClicked('cmd', '^', index);
                buttonClicked('cmd', '2', index);
                buttonClicked('onKey', 'Right', index);
                break;
            case 'cubed':
                buttonClicked('write', '^{3}', index);
                break;
            case 'd/dx':
                buttonClicked('write', '\\frac{d}{dx}', index);
                break;
        }
    } else if (act == "add") {
        buttonClicked('write', key, index);
        if (args) {
            for (var i = 0; i < args; i++) {
                buttonClicked('onKey', 'Left', index);
            }
        }
    }
    //光标向右两次，再回来，将光标定位在可视图
    //Demo.hasNext = true;
    //buttonClicked('onKey', "Right", index);
    //if (Demo.hasNext) {
    //    buttonClicked('onKey', "Left", index);
    //}
    buttonClicked('render', "", index);
    getResult();
}

/*
 * 新增字符串
 */
function write(word) {
    var edit_main = Desmos.$('.dcg-selected ').find('.mathquill-editable');
    //下来的word要将\转义；如传入"\\sqrt",而不是"\sqrt"
    edit_main.mathquill('write', word);
    edit_main.trigger('render');
    getResult();
}

function getFeedBackLocation() {
    var optionlist = document.getElementsByClassName("feedbackspan");
    if (optionlist.length > 0) {
        var offsetStr = "";
        var l, r, t, b;
        var option = optionlist[1];
        l = option.offsetLeft;
        t = option.offsetTop;
        r = l + option.offsetWidth;
        b = t + option.offsetHeight;
        offsetStr = l + "," + t + "," + r + "," + b;

    }
}

Desmos.$(".dcg-exppanel").bind("scroll", function () {
})
