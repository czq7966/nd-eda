var Desmos = window.Desmos || {};
if (!Desmos.config) {
    Desmos.config = {}
}
(function () {
    var requirejs, require, define;
    (function (undef) {
        var main, req, makeMap, handlers, defined = {}, waiting = {}, config = {}, defining = {}, hasOwn = Object.prototype.hasOwnProperty, aps = [].slice;

        function hasProp(obj, prop) {
            return hasOwn.call(obj, prop)
        }

        function normalize(name, baseName) {
            var nameParts, nameSegment, mapValue, foundMap, foundI, foundStarMap, starI, i, j, part, baseParts = baseName && baseName.split("/"), map = config.map, starMap = (map && map["*"]) || {};
            if (name && name.charAt(0) === ".") {
                if (baseName) {
                    baseParts = baseParts.slice(0, baseParts.length - 1);
                    name = baseParts.concat(name.split("/"));
                    for (i = 0; i < name.length; i += 1) {
                        part = name[i];
                        if (part === ".") {
                            name.splice(i, 1);
                            i -= 1
                        } else {
                            if (part === "..") {
                                if (i === 1 && (name[2] === ".." || name[0] === "..")) {
                                    break
                                } else {
                                    if (i > 0) {
                                        name.splice(i - 1, 2);
                                        i -= 2
                                    }
                                }
                            }
                        }
                    }
                    name = name.join("/")
                } else {
                    if (name.indexOf("./") === 0) {
                        name = name.substring(2)
                    }
                }
            }
            if ((baseParts || starMap) && map) {
                nameParts = name.split("/");
                for (i = nameParts.length; i > 0; i -= 1) {
                    nameSegment = nameParts.slice(0, i).join("/");
                    if (baseParts) {
                        for (j = baseParts.length; j > 0; j -= 1) {
                            mapValue = map[baseParts.slice(0, j).join("/")];
                            if (mapValue) {
                                mapValue = mapValue[nameSegment];
                                if (mapValue) {
                                    foundMap = mapValue;
                                    foundI = i;
                                    break
                                }
                            }
                        }
                    }
                    if (foundMap) {
                        break
                    }
                    if (!foundStarMap && starMap && starMap[nameSegment]) {
                        foundStarMap = starMap[nameSegment];
                        starI = i
                    }
                }
                if (!foundMap && foundStarMap) {
                    foundMap = foundStarMap;
                    foundI = starI
                }
                if (foundMap) {
                    nameParts.splice(0, foundI, foundMap);
                    name = nameParts.join("/")
                }
            }
            return name
        }

        function makeRequire(relName, forceSync) {
            return function () {
                return req.apply(undef, aps.call(arguments, 0).concat([relName, forceSync]))
            }
        }

        function makeNormalize(relName) {
            return function (name) {
                return normalize(name, relName)
            }
        }

        function makeLoad(depName) {
            return function (value) {
                defined[depName] = value
            }
        }

        function callDep(name) {
            if (hasProp(waiting, name)) {
                var args = waiting[name];
                delete waiting[name];
                defining[name] = true;
                main.apply(undef, args)
            }
            if (!hasProp(defined, name) && !hasProp(defining, name)) {
                throw new Error("No " + name)
            }
            return defined[name]
        }

        function splitPrefix(name) {
            var prefix, index = name ? name.indexOf("!") : -1;
            if (index > -1) {
                prefix = name.substring(0, index);
                name = name.substring(index + 1, name.length)
            }
            return [prefix, name]
        }

        makeMap = function (name, relName) {
            var plugin, parts = splitPrefix(name), prefix = parts[0];
            name = parts[1];
            if (prefix) {
                prefix = normalize(prefix, relName);
                plugin = callDep(prefix)
            }
            if (prefix) {
                if (plugin && plugin.normalize) {
                    name = plugin.normalize(name, makeNormalize(relName))
                } else {
                    name = normalize(name, relName)
                }
            } else {
                name = normalize(name, relName);
                parts = splitPrefix(name);
                prefix = parts[0];
                name = parts[1];
                if (prefix) {
                    plugin = callDep(prefix)
                }
            }
            return {f: prefix ? prefix + "!" + name : name, n: name, pr: prefix, p: plugin}
        };
        function makeConfig(name) {
            return function () {
                return (config && config.config && config.config[name]) || {}
            }
        }

        handlers = {
            require: function (name) {
                return makeRequire(name)
            }, exports: function (name) {
                var e = defined[name];
                if (typeof e !== "undefined") {
                    return e
                } else {
                    return (defined[name] = {})
                }
            }, module: function (name) {
                return {id: name, uri: "", exports: defined[name], config: makeConfig(name)}
            }
        };
        main = function (name, deps, callback, relName) {
            var cjsModule, depName, ret, map, i, args = [], usingExports;
            relName = relName || name;
            if (typeof callback === "function") {
                deps = !deps.length && callback.length ? ["require", "exports", "module"] : deps;
                for (i = 0; i < deps.length; i += 1) {
                    map = makeMap(deps[i], relName);
                    depName = map.f;
                    if (depName === "require") {
                        args[i] = handlers.require(name)
                    } else {
                        if (depName === "exports") {
                            args[i] = handlers.exports(name);
                            usingExports = true
                        } else {
                            if (depName === "module") {
                                cjsModule = args[i] = handlers.module(name)
                            } else {
                                if (hasProp(defined, depName) || hasProp(waiting, depName) || hasProp(defining, depName)) {
                                    args[i] = callDep(depName)
                                } else {
                                    if (map.p) {
                                        map.p.load(map.n, makeRequire(relName, true), makeLoad(depName), {});
                                        args[i] = defined[depName]
                                    } else {
                                        throw new Error(name + " missing " + depName)
                                    }
                                }
                            }
                        }
                    }
                }
                ret = callback.apply(defined[name], args);
                if (name) {
                    if (cjsModule && cjsModule.exports !== undef && cjsModule.exports !== defined[name]) {
                        defined[name] = cjsModule.exports
                    } else {
                        if (ret !== undef || !usingExports) {
                            defined[name] = ret
                        }
                    }
                }
            } else {
                if (name) {
                    defined[name] = callback
                }
            }
        };
        requirejs = require = req = function (deps, callback, relName, forceSync, alt) {
            if (typeof deps === "string") {
                if (handlers[deps]) {
                    return handlers[deps](callback)
                }
                return callDep(makeMap(deps, callback).f)
            } else {
                if (!deps.splice) {
                    config = deps;
                    if (callback.splice) {
                        deps = callback;
                        callback = relName;
                        relName = null
                    } else {
                        deps = undef
                    }
                }
            }
            callback = callback || function () {
            };
            if (typeof relName === "function") {
                relName = forceSync;
                forceSync = alt
            }
            if (forceSync) {
                main(undef, deps, callback, relName)
            } else {
                setTimeout(function () {
                    main(undef, deps, callback, relName)
                }, 4)
            }
            return req
        };
        req.config = function (cfg) {
            config = cfg;
            if (config.deps) {
                req(config.deps, config.callback)
            }
            return req
        };
        define = function (name, deps, callback) {
            if (!deps.splice) {
                callback = deps;
                deps = []
            }
            if (!hasProp(defined, name) && !hasProp(waiting, name)) {
                waiting[name] = [name, deps, callback]
            }
        };
        define.amd = {jQuery: true}
    }());
    define("vendor/almond", function () {
    });
    define("pjs", [], function () {
        var P = (function (prototype, ownProperty, undefined) {
            function isObject(o) {
                return typeof o === "object"
            }

            function isFunction(f) {
                return typeof f === "function"
            }

            function SuperclassBare() {
            }

            function P(_superclass, definition) {
                if (definition === undefined) {
                    definition = _superclass;
                    _superclass = Object
                }
                function C() {
                    var self = new Bare;
                    if (isFunction(self.init)) {
                        self.init.apply(self, arguments)
                    }
                    return self
                }

                function Bare() {
                }

                C.Bare = Bare;
                var _super = SuperclassBare[prototype] = _superclass[prototype];
                var proto = Bare[prototype] = C[prototype] = new SuperclassBare;
                var extensions;
                proto.constructor = C;
                C.mixin = function (def) {
                    Bare[prototype] = C[prototype] = P(C, def)[prototype];
                    return C
                };
                return (C.open = function (def) {
                    extensions = {};
                    if (isFunction(def)) {
                        extensions = def.call(C, proto, _super, C, _superclass)
                    } else {
                        if (isObject(def)) {
                            extensions = def
                        }
                    }
                    if (isObject(extensions)) {
                        for (var ext in extensions) {
                            if (ownProperty.call(extensions, ext)) {
                                proto[ext] = extensions[ext]
                            }
                        }
                    }
                    if (!isFunction(proto.init)) {
                        proto.init = _superclass
                    }
                    return C
                })(definition)
            }

            return P
        })("prototype", ({}).hasOwnProperty);
        return P
    });
    (function () {
        var root = this;
        var previousUnderscore = root._;
        var breaker = {};
        var ArrayProto = Array.prototype, ObjProto = Object.prototype, FuncProto = Function.prototype;
        var slice = ArrayProto.slice, unshift = ArrayProto.unshift, toString = ObjProto.toString, hasOwnProperty = ObjProto.hasOwnProperty;
        var nativeForEach = ArrayProto.forEach, nativeMap = ArrayProto.map, nativeReduce = ArrayProto.reduce, nativeReduceRight = ArrayProto.reduceRight, nativeFilter = ArrayProto.filter, nativeEvery = ArrayProto.every, nativeSome = ArrayProto.some, nativeIndexOf = ArrayProto.indexOf, nativeLastIndexOf = ArrayProto.lastIndexOf, nativeIsArray = Array.isArray, nativeKeys = Object.keys, nativeBind = FuncProto.bind;
        var _ = function (obj) {
            return new wrapper(obj)
        };
        if (typeof exports !== "undefined") {
            if (typeof module !== "undefined" && module.exports) {
                exports = module.exports = _
            }
            exports._ = _
        } else {
            root._ = _
        }
        _.VERSION = "1.3.3";
        var each = _.each = _.forEach = function (obj, iterator, context) {
            if (obj == null) {
                return
            }
            if (nativeForEach && obj.forEach === nativeForEach) {
                obj.forEach(iterator, context)
            } else {
                if (obj.length === +obj.length) {
                    for (var i = 0, l = obj.length; i < l; i++) {
                        if (i in obj && iterator.call(context, obj[i], i, obj) === breaker) {
                            return
                        }
                    }
                } else {
                    for (var key in obj) {
                        if (_.has(obj, key)) {
                            if (iterator.call(context, obj[key], key, obj) === breaker) {
                                return
                            }
                        }
                    }
                }
            }
        };
        _.map = _.collect = function (obj, iterator, context) {
            var results = [];
            if (obj == null) {
                return results
            }
            if (nativeMap && obj.map === nativeMap) {
                return obj.map(iterator, context)
            }
            each(obj, function (value, index, list) {
                results[results.length] = iterator.call(context, value, index, list)
            });
            if (obj.length === +obj.length) {
                results.length = obj.length
            }
            return results
        };
        _.reduce = _.foldl = _.inject = function (obj, iterator, memo, context) {
            var initial = arguments.length > 2;
            if (obj == null) {
                obj = []
            }
            if (nativeReduce && obj.reduce === nativeReduce) {
                if (context) {
                    iterator = _.bind(iterator, context)
                }
                return initial ? obj.reduce(iterator, memo) : obj.reduce(iterator)
            }
            each(obj, function (value, index, list) {
                if (!initial) {
                    memo = value;
                    initial = true
                } else {
                    memo = iterator.call(context, memo, value, index, list)
                }
            });
            if (!initial) {
                throw new TypeError("Reduce of empty array with no initial value")
            }
            return memo
        };
        _.reduceRight = _.foldr = function (obj, iterator, memo, context) {
            var initial = arguments.length > 2;
            if (obj == null) {
                obj = []
            }
            if (nativeReduceRight && obj.reduceRight === nativeReduceRight) {
                if (context) {
                    iterator = _.bind(iterator, context)
                }
                return initial ? obj.reduceRight(iterator, memo) : obj.reduceRight(iterator)
            }
            var reversed = _.toArray(obj).reverse();
            if (context && !initial) {
                iterator = _.bind(iterator, context)
            }
            return initial ? _.reduce(reversed, iterator, memo, context) : _.reduce(reversed, iterator)
        };
        _.find = _.detect = function (obj, iterator, context) {
            var result;
            any(obj, function (value, index, list) {
                if (iterator.call(context, value, index, list)) {
                    result = value;
                    return true
                }
            });
            return result
        };
        _.filter = _.select = function (obj, iterator, context) {
            var results = [];
            if (obj == null) {
                return results
            }
            if (nativeFilter && obj.filter === nativeFilter) {
                return obj.filter(iterator, context)
            }
            each(obj, function (value, index, list) {
                if (iterator.call(context, value, index, list)) {
                    results[results.length] = value
                }
            });
            return results
        };
        _.reject = function (obj, iterator, context) {
            var results = [];
            if (obj == null) {
                return results
            }
            each(obj, function (value, index, list) {
                if (!iterator.call(context, value, index, list)) {
                    results[results.length] = value
                }
            });
            return results
        };
        _.every = _.all = function (obj, iterator, context) {
            var result = true;
            if (obj == null) {
                return result
            }
            if (nativeEvery && obj.every === nativeEvery) {
                return obj.every(iterator, context)
            }
            each(obj, function (value, index, list) {
                if (!(result = result && iterator.call(context, value, index, list))) {
                    return breaker
                }
            });
            return !!result
        };
        var any = _.some = _.any = function (obj, iterator, context) {
            iterator || (iterator = _.identity);
            var result = false;
            if (obj == null) {
                return result
            }
            if (nativeSome && obj.some === nativeSome) {
                return obj.some(iterator, context)
            }
            each(obj, function (value, index, list) {
                if (result || (result = iterator.call(context, value, index, list))) {
                    return breaker
                }
            });
            return !!result
        };
        _.include = _.contains = function (obj, target) {
            var found = false;
            if (obj == null) {
                return found
            }
            if (nativeIndexOf && obj.indexOf === nativeIndexOf) {
                return obj.indexOf(target) != -1
            }
            found = any(obj, function (value) {
                return value === target
            });
            return found
        };
        _.invoke = function (obj, method) {
            var args = slice.call(arguments, 2);
            return _.map(obj, function (value) {
                return (_.isFunction(method) ? method || value : value[method]).apply(value, args)
            })
        };
        _.pluck = function (obj, key) {
            return _.map(obj, function (value) {
                return value[key]
            })
        };
        _.max = function (obj, iterator, context) {
            if (!iterator && _.isArray(obj) && obj[0] === +obj[0]) {
                return Math.max.apply(Math, obj)
            }
            if (!iterator && _.isEmpty(obj)) {
                return -Infinity
            }
            var result = {computed: -Infinity};
            each(obj, function (value, index, list) {
                var computed = iterator ? iterator.call(context, value, index, list) : value;
                computed >= result.computed && (result = {value: value, computed: computed})
            });
            return result.value
        };
        _.min = function (obj, iterator, context) {
            if (!iterator && _.isArray(obj) && obj[0] === +obj[0]) {
                return Math.min.apply(Math, obj)
            }
            if (!iterator && _.isEmpty(obj)) {
                return Infinity
            }
            var result = {computed: Infinity};
            each(obj, function (value, index, list) {
                var computed = iterator ? iterator.call(context, value, index, list) : value;
                computed < result.computed && (result = {value: value, computed: computed})
            });
            return result.value
        };
        _.shuffle = function (obj) {
            var shuffled = [], rand;
            each(obj, function (value, index, list) {
                rand = Math.floor(Math.random() * (index + 1));
                shuffled[index] = shuffled[rand];
                shuffled[rand] = value
            });
            return shuffled
        };
        _.sortBy = function (obj, val, context) {
            var iterator = _.isFunction(val) ? val : function (obj) {
                return obj[val]
            };
            return _.pluck(_.map(obj, function (value, index, list) {
                return {value: value, criteria: iterator.call(context, value, index, list)}
            }).sort(function (left, right) {
                var a = left.criteria, b = right.criteria;
                if (a === void 0) {
                    return 1
                }
                if (b === void 0) {
                    return -1
                }
                return a < b ? -1 : a > b ? 1 : 0
            }), "value")
        };
        _.groupBy = function (obj, val) {
            var result = {};
            var iterator = _.isFunction(val) ? val : function (obj) {
                return obj[val]
            };
            each(obj, function (value, index) {
                var key = iterator(value, index);
                (result[key] || (result[key] = [])).push(value)
            });
            return result
        };
        _.sortedIndex = function (array, obj, iterator) {
            iterator || (iterator = _.identity);
            var low = 0, high = array.length;
            while (low < high) {
                var mid = (low + high) >> 1;
                iterator(array[mid]) < iterator(obj) ? low = mid + 1 : high = mid
            }
            return low
        };
        _.toArray = function (obj) {
            if (!obj) {
                return []
            }
            if (_.isArray(obj)) {
                return slice.call(obj)
            }
            if (_.isArguments(obj)) {
                return slice.call(obj)
            }
            if (obj.toArray && _.isFunction(obj.toArray)) {
                return obj.toArray()
            }
            return _.values(obj)
        };
        _.size = function (obj) {
            return _.isArray(obj) ? obj.length : _.keys(obj).length
        };
        _.first = _.head = _.take = function (array, n, guard) {
            return (n != null) && !guard ? slice.call(array, 0, n) : array[0]
        };
        _.initial = function (array, n, guard) {
            return slice.call(array, 0, array.length - ((n == null) || guard ? 1 : n))
        };
        _.last = function (array, n, guard) {
            if ((n != null) && !guard) {
                return slice.call(array, Math.max(array.length - n, 0))
            } else {
                return array[array.length - 1]
            }
        };
        _.rest = _.tail = function (array, index, guard) {
            return slice.call(array, (index == null) || guard ? 1 : index)
        };
        _.compact = function (array) {
            return _.filter(array, function (value) {
                return !!value
            })
        };
        _.flatten = function (array, shallow) {
            return _.reduce(array, function (memo, value) {
                if (_.isArray(value)) {
                    return memo.concat(shallow ? value : _.flatten(value))
                }
                memo[memo.length] = value;
                return memo
            }, [])
        };
        _.without = function (array) {
            return _.difference(array, slice.call(arguments, 1))
        };
        _.uniq = _.unique = function (array, isSorted, iterator) {
            var initial = iterator ? _.map(array, iterator) : array;
            var results = [];
            if (array.length < 3) {
                isSorted = true
            }
            _.reduce(initial, function (memo, value, index) {
                if (isSorted ? _.last(memo) !== value || !memo.length : !_.include(memo, value)) {
                    memo.push(value);
                    results.push(array[index])
                }
                return memo
            }, []);
            return results
        };
        _.union = function () {
            return _.uniq(_.flatten(arguments, true))
        };
        _.intersection = _.intersect = function (array) {
            var rest = slice.call(arguments, 1);
            return _.filter(_.uniq(array), function (item) {
                return _.every(rest, function (other) {
                    return _.indexOf(other, item) >= 0
                })
            })
        };
        _.difference = function (array) {
            var rest = _.flatten(slice.call(arguments, 1), true);
            return _.filter(array, function (value) {
                return !_.include(rest, value)
            })
        };
        _.zip = function () {
            var args = slice.call(arguments);
            var length = _.max(_.pluck(args, "length"));
            var results = new Array(length);
            for (var i = 0; i < length; i++) {
                results[i] = _.pluck(args, "" + i)
            }
            return results
        };
        _.indexOf = function (array, item, isSorted) {
            if (array == null) {
                return -1
            }
            var i, l;
            if (isSorted) {
                i = _.sortedIndex(array, item);
                return array[i] === item ? i : -1
            }
            if (nativeIndexOf && array.indexOf === nativeIndexOf) {
                return array.indexOf(item)
            }
            for (i = 0, l = array.length; i < l; i++) {
                if (i in array && array[i] === item) {
                    return i
                }
            }
            return -1
        };
        _.lastIndexOf = function (array, item) {
            if (array == null) {
                return -1
            }
            if (nativeLastIndexOf && array.lastIndexOf === nativeLastIndexOf) {
                return array.lastIndexOf(item)
            }
            var i = array.length;
            while (i--) {
                if (i in array && array[i] === item) {
                    return i
                }
            }
            return -1
        };
        _.range = function (start, stop, step) {
            if (arguments.length <= 1) {
                stop = start || 0;
                start = 0
            }
            step = arguments[2] || 1;
            var len = Math.max(Math.ceil((stop - start) / step), 0);
            var idx = 0;
            var range = new Array(len);
            while (idx < len) {
                range[idx++] = start;
                start += step
            }
            return range
        };
        var ctor = function () {
        };
        _.bind = function bind(func, context) {
            var bound, args;
            if (func.bind === nativeBind && nativeBind) {
                return nativeBind.apply(func, slice.call(arguments, 1))
            }
            if (!_.isFunction(func)) {
                throw new TypeError
            }
            args = slice.call(arguments, 2);
            return bound = function () {
                if (!(this instanceof bound)) {
                    return func.apply(context, args.concat(slice.call(arguments)))
                }
                ctor.prototype = func.prototype;
                var self = new ctor;
                var result = func.apply(self, args.concat(slice.call(arguments)));
                if (Object(result) === result) {
                    return result
                }
                return self
            }
        };
        _.bindAll = function (obj) {
            var funcs = slice.call(arguments, 1);
            if (funcs.length == 0) {
                funcs = _.functions(obj)
            }
            each(funcs, function (f) {
                obj[f] = _.bind(obj[f], obj)
            });
            return obj
        };
        _.memoize = function (func, hasher) {
            var memo = {};
            hasher || (hasher = _.identity);
            return function () {
                var key = hasher.apply(this, arguments);
                return _.has(memo, key) ? memo[key] : (memo[key] = func.apply(this, arguments))
            }
        };
        _.delay = function (func, wait) {
            var args = slice.call(arguments, 2);
            return setTimeout(function () {
                return func.apply(null, args)
            }, wait)
        };
        _.defer = function (func) {
            return _.delay.apply(_, [func, 1].concat(slice.call(arguments, 1)))
        };
        _.throttle = function (func, wait) {
            var context, args, timeout, throttling, more, result;
            var whenDone = _.debounce(function () {
                more = throttling = false
            }, wait);
            return function () {
                context = this;
                args = arguments;
                var later = function () {
                    timeout = null;
                    if (more) {
                        func.apply(context, args)
                    }
                    whenDone()
                };
                if (!timeout) {
                    timeout = setTimeout(later, wait)
                }
                if (throttling) {
                    more = true
                } else {
                    result = func.apply(context, args)
                }
                whenDone();
                throttling = true;
                return result
            }
        };
        _.debounce = function (func, wait, immediate) {
            var timeout;
            return function () {
                var context = this, args = arguments;
                var later = function () {
                    timeout = null;
                    if (!immediate) {
                        func.apply(context, args)
                    }
                };
                if (immediate && !timeout) {
                    func.apply(context, args)
                }
                clearTimeout(timeout);
                timeout = setTimeout(later, wait)
            }
        };
        _.once = function (func) {
            var ran = false, memo;
            return function () {
                if (ran) {
                    return memo
                }
                ran = true;
                return memo = func.apply(this, arguments)
            }
        };
        _.wrap = function (func, wrapper) {
            return function () {
                var args = [func].concat(slice.call(arguments, 0));
                return wrapper.apply(this, args)
            }
        };
        _.compose = function () {
            var funcs = arguments;
            return function () {
                var args = arguments;
                for (var i = funcs.length - 1; i >= 0; i--) {
                    args = [funcs[i].apply(this, args)]
                }
                return args[0]
            }
        };
        _.after = function (times, func) {
            if (times <= 0) {
                return func()
            }
            return function () {
                if (--times < 1) {
                    return func.apply(this, arguments)
                }
            }
        };
        _.keys = nativeKeys || function (obj) {
            if (obj !== Object(obj)) {
                throw new TypeError("Invalid object")
            }
            var keys = [];
            for (var key in obj) {
                if (_.has(obj, key)) {
                    keys[keys.length] = key
                }
            }
            return keys
        };
        _.values = function (obj) {
            return _.map(obj, _.identity)
        };
        _.functions = _.methods = function (obj) {
            var names = [];
            for (var key in obj) {
                if (_.isFunction(obj[key])) {
                    names.push(key)
                }
            }
            return names.sort()
        };
        _.extend = function (obj) {
            each(slice.call(arguments, 1), function (source) {
                for (var prop in source) {
                    obj[prop] = source[prop]
                }
            });
            return obj
        };
        _.pick = function (obj) {
            var result = {};
            each(_.flatten(slice.call(arguments, 1)), function (key) {
                if (key in obj) {
                    result[key] = obj[key]
                }
            });
            return result
        };
        _.defaults = function (obj) {
            each(slice.call(arguments, 1), function (source) {
                for (var prop in source) {
                    if (obj[prop] == null) {
                        obj[prop] = source[prop]
                    }
                }
            });
            return obj
        };
        _.clone = function (obj) {
            if (!_.isObject(obj)) {
                return obj
            }
            return _.isArray(obj) ? obj.slice() : _.extend({}, obj)
        };
        _.tap = function (obj, interceptor) {
            interceptor(obj);
            return obj
        };
        function eq(a, b, stack) {
            if (a === b) {
                return a !== 0 || 1 / a == 1 / b
            }
            if (a == null || b == null) {
                return a === b
            }
            if (a._chain) {
                a = a._wrapped
            }
            if (b._chain) {
                b = b._wrapped
            }
            if (a.isEqual && _.isFunction(a.isEqual)) {
                return a.isEqual(b)
            }
            if (b.isEqual && _.isFunction(b.isEqual)) {
                return b.isEqual(a)
            }
            var className = toString.call(a);
            if (className != toString.call(b)) {
                return false
            }
            switch (className) {
                case"[object String]":
                    return a == String(b);
                case"[object Number]":
                    return a != +a ? b != +b : (a == 0 ? 1 / a == 1 / b : a == +b);
                case"[object Date]":
                case"[object Boolean]":
                    return +a == +b;
                case"[object RegExp]":
                    return a.source == b.source && a.global == b.global && a.multiline == b.multiline && a.ignoreCase == b.ignoreCase
            }
            if (typeof a != "object" || typeof b != "object") {
                return false
            }
            var length = stack.length;
            while (length--) {
                if (stack[length] == a) {
                    return true
                }
            }
            stack.push(a);
            var size = 0, result = true;
            if (className == "[object Array]") {
                size = a.length;
                result = size == b.length;
                if (result) {
                    while (size--) {
                        if (!(result = size in a == size in b && eq(a[size], b[size], stack))) {
                            break
                        }
                    }
                }
            } else {
                if ("constructor" in a != "constructor" in b || a.constructor != b.constructor) {
                    return false
                }
                for (var key in a) {
                    if (_.has(a, key)) {
                        size++;
                        if (!(result = _.has(b, key) && eq(a[key], b[key], stack))) {
                            break
                        }
                    }
                }
                if (result) {
                    for (key in b) {
                        if (_.has(b, key) && !(size--)) {
                            break
                        }
                    }
                    result = !size
                }
            }
            stack.pop();
            return result
        }

        _.isEqual = function (a, b) {
            return eq(a, b, [])
        };
        _.isEmpty = function (obj) {
            if (obj == null) {
                return true
            }
            if (_.isArray(obj) || _.isString(obj)) {
                return obj.length === 0
            }
            for (var key in obj) {
                if (_.has(obj, key)) {
                    return false
                }
            }
            return true
        };
        _.isElement = function (obj) {
            return !!(obj && obj.nodeType == 1)
        };
        _.isArray = nativeIsArray || function (obj) {
            return toString.call(obj) == "[object Array]"
        };
        _.isObject = function (obj) {
            return obj === Object(obj)
        };
        _.isArguments = function (obj) {
            return toString.call(obj) == "[object Arguments]"
        };
        if (!_.isArguments(arguments)) {
            _.isArguments = function (obj) {
                return !!(obj && _.has(obj, "callee"))
            }
        }
        _.isFunction = function (obj) {
            return toString.call(obj) == "[object Function]"
        };
        _.isString = function (obj) {
            return toString.call(obj) == "[object String]"
        };
        _.isNumber = function (obj) {
            return toString.call(obj) == "[object Number]"
        };
        _.isFinite = function (obj) {
            return _.isNumber(obj) && isFinite(obj)
        };
        _.isNaN = function (obj) {
            return obj !== obj
        };
        _.isBoolean = function (obj) {
            return obj === true || obj === false || toString.call(obj) == "[object Boolean]"
        };
        _.isDate = function (obj) {
            return toString.call(obj) == "[object Date]"
        };
        _.isRegExp = function (obj) {
            return toString.call(obj) == "[object RegExp]"
        };
        _.isNull = function (obj) {
            return obj === null
        };
        _.isUndefined = function (obj) {
            return obj === void 0
        };
        _.has = function (obj, key) {
            return hasOwnProperty.call(obj, key)
        };
        _.noConflict = function () {
            root._ = previousUnderscore;
            return this
        };
        _.identity = function (value) {
            return value
        };
        _.times = function (n, iterator, context) {
            for (var i = 0; i < n; i++) {
                iterator.call(context, i)
            }
        };
        _.escape = function (string) {
            return ("" + string).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;").replace(/\//g, "&#x2F;")
        };
        _.result = function (object, property) {
            if (object == null) {
                return null
            }
            var value = object[property];
            return _.isFunction(value) ? value.call(object) : value
        };
        _.mixin = function (obj) {
            each(_.functions(obj), function (name) {
                addToWrapper(name, _[name] = obj[name])
            })
        };
        var idCounter = 0;
        _.uniqueId = function (prefix) {
            var id = idCounter++;
            return prefix ? prefix + id : id
        };
        _.templateSettings = {evaluate: /<%([\s\S]+?)%>/g, interpolate: /<%=([\s\S]+?)%>/g, escape: /<%-([\s\S]+?)%>/g};
        var noMatch = /.^/;
        var escapes = {"\\": "\\", "'": "'", r: "\r", n: "\n", t: "\t", u2028: "\u2028", u2029: "\u2029"};
        for (var p in escapes) {
            escapes[escapes[p]] = p
        }
        var escaper = /\\|'|\r|\n|\t|\u2028|\u2029/g;
        var unescaper = /\\(\\|'|r|n|t|u2028|u2029)/g;
        var unescape = function (code) {
            return code.replace(unescaper, function (match, escape) {
                return escapes[escape]
            })
        };
        _.template = function (text, data, settings) {
            settings = _.defaults(settings || {}, _.templateSettings);
            var source = "__p+='" + text.replace(escaper, function (match) {
                    return "\\" + escapes[match]
                }).replace(settings.escape || noMatch, function (match, code) {
                    return "'+\n_.escape(" + unescape(code) + ")+\n'"
                }).replace(settings.interpolate || noMatch, function (match, code) {
                    return "'+\n(" + unescape(code) + ")+\n'"
                }).replace(settings.evaluate || noMatch, function (match, code) {
                    return "';\n" + unescape(code) + "\n;__p+='"
                }) + "';\n";
            if (!settings.variable) {
                source = "with(obj||{}){\n" + source + "}\n"
            }
            source = "var __p='';var print=function(){__p+=Array.prototype.join.call(arguments, '')};\n" + source + "return __p;\n";
            var render = new Function(settings.variable || "obj", "_", source);
            if (data) {
                return render(data, _)
            }
            var template = function (data) {
                return render.call(this, data, _)
            };
            template.source = "function(" + (settings.variable || "obj") + "){\n" + source + "}";
            return template
        };
        _.chain = function (obj) {
            return _(obj).chain()
        };
        var wrapper = function (obj) {
            this._wrapped = obj
        };
        _.prototype = wrapper.prototype;
        var result = function (obj, chain) {
            return chain ? _(obj).chain() : obj
        };
        var addToWrapper = function (name, func) {
            wrapper.prototype[name] = function () {
                var args = slice.call(arguments);
                unshift.call(args, this._wrapped);
                return result(func.apply(_, args), this._chain)
            }
        };
        _.mixin(_);
        each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function (name) {
            var method = ArrayProto[name];
            wrapper.prototype[name] = function () {
                var wrapped = this._wrapped;
                method.apply(wrapped, arguments);
                var length = wrapped.length;
                if ((name == "shift" || name == "splice") && length === 0) {
                    delete wrapped[0]
                }
                return result(wrapped, this._chain)
            }
        });
        each(["concat", "join", "slice"], function (name) {
            var method = ArrayProto[name];
            wrapper.prototype[name] = function () {
                return result(method.apply(this._wrapped, arguments), this._chain)
            }
        });
        wrapper.prototype.chain = function () {
            this._chain = true;
            return this
        };
        wrapper.prototype.value = function () {
            return this._wrapped
        }
    }).call(this);
    define("underscore", (function (global) {
        return function () {
            var ret, fn;
            return ret || global._
        }
    }(this)));
    /*!
     * jQuery JavaScript Library v1.8.3
     * http://jquery.com/
     *
     * Includes Sizzle.js
     * http://sizzlejs.com/
     *
     * Copyright 2012 jQuery Foundation and other contributors
     * Released under the MIT license
     * http://jquery.org/license
     *
     * Date: Tue Nov 13 2012 08:20:33 GMT-0500 (Eastern Standard Time)
     */
    (function (window, undefined) {
        var rootjQuery, readyList, document = window.document, location = window.location, navigator = window.navigator, _jQuery = window.jQuery, _$ = window.$, core_push = Array.prototype.push, core_slice = Array.prototype.slice, core_indexOf = Array.prototype.indexOf, core_toString = Object.prototype.toString, core_hasOwn = Object.prototype.hasOwnProperty, core_trim = String.prototype.trim, jQuery = function (selector, context) {
            return new jQuery.fn.init(selector, context, rootjQuery)
        }, core_pnum = /[\-+]?(?:\d*\.|)\d+(?:[eE][\-+]?\d+|)/.source, core_rnotwhite = /\S/, core_rspace = /\s+/, rtrim = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, rquickExpr = /^(?:[^#<]*(<[\w\W]+>)[^>]*$|#([\w\-]*)$)/, rsingleTag = /^<(\w+)\s*\/?>(?:<\/\1>|)$/, rvalidchars = /^[\],:{}\s]*$/, rvalidbraces = /(?:^|:|,)(?:\s*\[)+/g, rvalidescape = /\\(?:["\\\/bfnrt]|u[\da-fA-F]{4})/g, rvalidtokens = /"[^"\\\r\n]*"|true|false|null|-?(?:\d\d*\.|)\d+(?:[eE][\-+]?\d+|)/g, rmsPrefix = /^-ms-/, rdashAlpha = /-([\da-z])/gi, fcamelCase = function (all, letter) {
            return (letter + "").toUpperCase()
        }, DOMContentLoaded = function () {
            if (document.addEventListener) {
                document.removeEventListener("DOMContentLoaded", DOMContentLoaded, false);
                jQuery.ready()
            } else {
                if (document.readyState === "complete") {
                    document.detachEvent("onreadystatechange", DOMContentLoaded);
                    jQuery.ready()
                }
            }
        }, class2type = {};
        jQuery.fn = jQuery.prototype = {
            constructor: jQuery, init: function (selector, context, rootjQuery) {
                var match, elem, ret, doc;
                if (!selector) {
                    return this
                }
                if (selector.nodeType) {
                    this.context = this[0] = selector;
                    this.length = 1;
                    return this
                }
                if (typeof selector === "string") {
                    if (selector.charAt(0) === "<" && selector.charAt(selector.length - 1) === ">" && selector.length >= 3) {
                        match = [null, selector, null]
                    } else {
                        match = rquickExpr.exec(selector)
                    }
                    if (match && (match[1] || !context)) {
                        if (match[1]) {
                            context = context instanceof jQuery ? context[0] : context;
                            doc = (context && context.nodeType ? context.ownerDocument || context : document);
                            selector = jQuery.parseHTML(match[1], doc, true);
                            if (rsingleTag.test(match[1]) && jQuery.isPlainObject(context)) {
                                this.attr.call(selector, context, true)
                            }
                            return jQuery.merge(this, selector)
                        } else {
                            elem = document.getElementById(match[2]);
                            if (elem && elem.parentNode) {
                                if (elem.id !== match[2]) {
                                    return rootjQuery.find(selector)
                                }
                                this.length = 1;
                                this[0] = elem
                            }
                            this.context = document;
                            this.selector = selector;
                            return this
                        }
                    } else {
                        if (!context || context.jquery) {
                            return (context || rootjQuery).find(selector)
                        } else {
                            return this.constructor(context).find(selector)
                        }
                    }
                } else {
                    if (jQuery.isFunction(selector)) {
                        return rootjQuery.ready(selector)
                    }
                }
                if (selector.selector !== undefined) {
                    this.selector = selector.selector;
                    this.context = selector.context
                }
                return jQuery.makeArray(selector, this)
            }, selector: "", jquery: "1.8.3", length: 0, size: function () {
                return this.length
            }, toArray: function () {
                return core_slice.call(this)
            }, get: function (num) {
                return num == null ? this.toArray() : (num < 0 ? this[this.length + num] : this[num])
            }, pushStack: function (elems, name, selector) {
                var ret = jQuery.merge(this.constructor(), elems);
                ret.prevObject = this;
                ret.context = this.context;
                if (name === "find") {
                    ret.selector = this.selector + (this.selector ? " " : "") + selector
                } else {
                    if (name) {
                        ret.selector = this.selector + "." + name + "(" + selector + ")"
                    }
                }
                return ret
            }, each: function (callback, args) {
                return jQuery.each(this, callback, args)
            }, ready: function (fn) {
                jQuery.ready.promise().done(fn);
                return this
            }, eq: function (i) {
                i = +i;
                return i === -1 ? this.slice(i) : this.slice(i, i + 1)
            }, first: function () {
                return this.eq(0)
            }, last: function () {
                return this.eq(-1)
            }, slice: function () {
                return this.pushStack(core_slice.apply(this, arguments), "slice", core_slice.call(arguments).join(","))
            }, map: function (callback) {
                return this.pushStack(jQuery.map(this, function (elem, i) {
                    return callback.call(elem, i, elem)
                }))
            }, end: function () {
                return this.prevObject || this.constructor(null)
            }, push: core_push, sort: [].sort, splice: [].splice
        };
        jQuery.fn.init.prototype = jQuery.fn;
        jQuery.extend = jQuery.fn.extend = function () {
            var options, name, src, copy, copyIsArray, clone, target = arguments[0] || {}, i = 1, length = arguments.length, deep = false;
            if (typeof target === "boolean") {
                deep = target;
                target = arguments[1] || {};
                i = 2
            }
            if (typeof target !== "object" && !jQuery.isFunction(target)) {
                target = {}
            }
            if (length === i) {
                target = this;
                --i
            }
            for (; i < length; i++) {
                if ((options = arguments[i]) != null) {
                    for (name in options) {
                        src = target[name];
                        copy = options[name];
                        if (target === copy) {
                            continue
                        }
                        if (deep && copy && (jQuery.isPlainObject(copy) || (copyIsArray = jQuery.isArray(copy)))) {
                            if (copyIsArray) {
                                copyIsArray = false;
                                clone = src && jQuery.isArray(src) ? src : []
                            } else {
                                clone = src && jQuery.isPlainObject(src) ? src : {}
                            }
                            target[name] = jQuery.extend(deep, clone, copy)
                        } else {
                            if (copy !== undefined) {
                                target[name] = copy
                            }
                        }
                    }
                }
            }
            return target
        };
        jQuery.extend({
            noConflict: function (deep) {
                if (window.$ === jQuery) {
                    window.$ = _$
                }
                if (deep && window.jQuery === jQuery) {
                    window.jQuery = _jQuery
                }
                return jQuery
            }, isReady: false, readyWait: 1, holdReady: function (hold) {
                if (hold) {
                    jQuery.readyWait++
                } else {
                    jQuery.ready(true)
                }
            }, ready: function (wait) {
                if (wait === true ? --jQuery.readyWait : jQuery.isReady) {
                    return
                }
                if (!document.body) {
                    return setTimeout(jQuery.ready, 1)
                }
                jQuery.isReady = true;
                if (wait !== true && --jQuery.readyWait > 0) {
                    return
                }
                readyList.resolveWith(document, [jQuery]);
                if (jQuery.fn.trigger) {
                    jQuery(document).trigger("ready").off("ready")
                }
            }, isFunction: function (obj) {
                return jQuery.type(obj) === "function"
            }, isArray: Array.isArray || function (obj) {
                return jQuery.type(obj) === "array"
            }, isWindow: function (obj) {
                return obj != null && obj == obj.window
            }, isNumeric: function (obj) {
                return !isNaN(parseFloat(obj)) && isFinite(obj)
            }, type: function (obj) {
                return obj == null ? String(obj) : class2type[core_toString.call(obj)] || "object"
            }, isPlainObject: function (obj) {
                if (!obj || jQuery.type(obj) !== "object" || obj.nodeType || jQuery.isWindow(obj)) {
                    return false
                }
                try {
                    if (obj.constructor && !core_hasOwn.call(obj, "constructor") && !core_hasOwn.call(obj.constructor.prototype, "isPrototypeOf")) {
                        return false
                    }
                } catch (e) {
                    return false
                }
                var key;
                for (key in obj) {
                }
                return key === undefined || core_hasOwn.call(obj, key)
            }, isEmptyObject: function (obj) {
                var name;
                for (name in obj) {
                    return false
                }
                return true
            }, error: function (msg) {
                throw new Error(msg)
            }, parseHTML: function (data, context, scripts) {
                var parsed;
                if (!data || typeof data !== "string") {
                    return null
                }
                if (typeof context === "boolean") {
                    scripts = context;
                    context = 0
                }
                context = context || document;
                if ((parsed = rsingleTag.exec(data))) {
                    return [context.createElement(parsed[1])]
                }
                parsed = jQuery.buildFragment([data], context, scripts ? null : []);
                return jQuery.merge([], (parsed.cacheable ? jQuery.clone(parsed.fragment) : parsed.fragment).childNodes)
            }, parseJSON: function (data) {
                if (!data || typeof data !== "string") {
                    return null
                }
                data = jQuery.trim(data);
                if (window.JSON && window.JSON.parse) {
                    return window.JSON.parse(data)
                }
                if (rvalidchars.test(data.replace(rvalidescape, "@").replace(rvalidtokens, "]").replace(rvalidbraces, ""))) {
                    return (new Function("return " + data))()
                }
                jQuery.error("Invalid JSON: " + data)
            }, parseXML: function (data) {
                var xml, tmp;
                if (!data || typeof data !== "string") {
                    return null
                }
                try {
                    if (window.DOMParser) {
                        tmp = new DOMParser();
                        xml = tmp.parseFromString(data, "text/xml")
                    } else {
                        xml = new ActiveXObject("Microsoft.XMLDOM");
                        xml.async = "false";
                        xml.loadXML(data)
                    }
                } catch (e) {
                    xml = undefined
                }
                if (!xml || !xml.documentElement || xml.getElementsByTagName("parsererror").length) {
                    jQuery.error("Invalid XML: " + data)
                }
                return xml
            }, noop: function () {
            }, globalEval: function (data) {
                if (data && core_rnotwhite.test(data)) {
                    (window.execScript || function (data) {
                        window["eval"].call(window, data)
                    })(data)
                }
            }, camelCase: function (string) {
                return string.replace(rmsPrefix, "ms-").replace(rdashAlpha, fcamelCase)
            }, nodeName: function (elem, name) {
                return elem.nodeName && elem.nodeName.toLowerCase() === name.toLowerCase()
            }, each: function (obj, callback, args) {
                var name, i = 0, length = obj.length, isObj = length === undefined || jQuery.isFunction(obj);
                if (args) {
                    if (isObj) {
                        for (name in obj) {
                            if (callback.apply(obj[name], args) === false) {
                                break
                            }
                        }
                    } else {
                        for (; i < length;) {
                            if (callback.apply(obj[i++], args) === false) {
                                break
                            }
                        }
                    }
                } else {
                    if (isObj) {
                        for (name in obj) {
                            if (callback.call(obj[name], name, obj[name]) === false) {
                                break
                            }
                        }
                    } else {
                        for (; i < length;) {
                            if (callback.call(obj[i], i, obj[i++]) === false) {
                                break
                            }
                        }
                    }
                }
                return obj
            }, trim: core_trim && !core_trim.call("\uFEFF\xA0") ? function (text) {
                return text == null ? "" : core_trim.call(text)
            } : function (text) {
                return text == null ? "" : (text + "").replace(rtrim, "")
            }, makeArray: function (arr, results) {
                var type, ret = results || [];
                if (arr != null) {
                    type = jQuery.type(arr);
                    if (arr.length == null || type === "string" || type === "function" || type === "regexp" || jQuery.isWindow(arr)) {
                        core_push.call(ret, arr)
                    } else {
                        jQuery.merge(ret, arr)
                    }
                }
                return ret
            }, inArray: function (elem, arr, i) {
                var len;
                if (arr) {
                    if (core_indexOf) {
                        return core_indexOf.call(arr, elem, i)
                    }
                    len = arr.length;
                    i = i ? i < 0 ? Math.max(0, len + i) : i : 0;
                    for (; i < len; i++) {
                        if (i in arr && arr[i] === elem) {
                            return i
                        }
                    }
                }
                return -1
            }, merge: function (first, second) {
                var l = second.length, i = first.length, j = 0;
                if (typeof l === "number") {
                    for (; j < l; j++) {
                        first[i++] = second[j]
                    }
                } else {
                    while (second[j] !== undefined) {
                        first[i++] = second[j++]
                    }
                }
                first.length = i;
                return first
            }, grep: function (elems, callback, inv) {
                var retVal, ret = [], i = 0, length = elems.length;
                inv = !!inv;
                for (; i < length; i++) {
                    retVal = !!callback(elems[i], i);
                    if (inv !== retVal) {
                        ret.push(elems[i])
                    }
                }
                return ret
            }, map: function (elems, callback, arg) {
                var value, key, ret = [], i = 0, length = elems.length, isArray = elems instanceof jQuery || length !== undefined && typeof length === "number" && ((length > 0 && elems[0] && elems[length - 1]) || length === 0 || jQuery.isArray(elems));
                if (isArray) {
                    for (; i < length; i++) {
                        value = callback(elems[i], i, arg);
                        if (value != null) {
                            ret[ret.length] = value
                        }
                    }
                } else {
                    for (key in elems) {
                        value = callback(elems[key], key, arg);
                        if (value != null) {
                            ret[ret.length] = value
                        }
                    }
                }
                return ret.concat.apply([], ret)
            }, guid: 1, proxy: function (fn, context) {
                var tmp, args, proxy;
                if (typeof context === "string") {
                    tmp = fn[context];
                    context = fn;
                    fn = tmp
                }
                if (!jQuery.isFunction(fn)) {
                    return undefined
                }
                args = core_slice.call(arguments, 2);
                proxy = function () {
                    return fn.apply(context, args.concat(core_slice.call(arguments)))
                };
                proxy.guid = fn.guid = fn.guid || jQuery.guid++;
                return proxy
            }, access: function (elems, fn, key, value, chainable, emptyGet, pass) {
                var exec, bulk = key == null, i = 0, length = elems.length;
                if (key && typeof key === "object") {
                    for (i in key) {
                        jQuery.access(elems, fn, i, key[i], 1, emptyGet, value)
                    }
                    chainable = 1
                } else {
                    if (value !== undefined) {
                        exec = pass === undefined && jQuery.isFunction(value);
                        if (bulk) {
                            if (exec) {
                                exec = fn;
                                fn = function (elem, key, value) {
                                    return exec.call(jQuery(elem), value)
                                }
                            } else {
                                fn.call(elems, value);
                                fn = null
                            }
                        }
                        if (fn) {
                            for (; i < length; i++) {
                                fn(elems[i], key, exec ? value.call(elems[i], i, fn(elems[i], key)) : value, pass)
                            }
                        }
                        chainable = 1
                    }
                }
                return chainable ? elems : bulk ? fn.call(elems) : length ? fn(elems[0], key) : emptyGet
            }, now: function () {
                return (new Date()).getTime()
            }
        });
        jQuery.ready.promise = function (obj) {
            if (!readyList) {
                readyList = jQuery.Deferred();
                if (document.readyState === "complete") {
                    setTimeout(jQuery.ready, 1)
                } else {
                    if (document.addEventListener) {
                        document.addEventListener("DOMContentLoaded", DOMContentLoaded, false);
                        window.addEventListener("load", jQuery.ready, false)
                    } else {
                        document.attachEvent("onreadystatechange", DOMContentLoaded);
                        window.attachEvent("onload", jQuery.ready);
                        var top = false;
                        try {
                            top = window.frameElement == null && document.documentElement
                        } catch (e) {
                        }
                        if (top && top.doScroll) {
                            (function doScrollCheck() {
                                if (!jQuery.isReady) {
                                    try {
                                        top.doScroll("left")
                                    } catch (e) {
                                        return setTimeout(doScrollCheck, 50)
                                    }
                                    jQuery.ready()
                                }
                            })()
                        }
                    }
                }
            }
            return readyList.promise(obj)
        };
        jQuery.each("Boolean Number String Function Array Date RegExp Object".split(" "), function (i, name) {
            class2type["[object " + name + "]"] = name.toLowerCase()
        });
        rootjQuery = jQuery(document);
        var optionsCache = {};

        function createOptions(options) {
            var object = optionsCache[options] = {};
            jQuery.each(options.split(core_rspace), function (_, flag) {
                object[flag] = true
            });
            return object
        }

        jQuery.Callbacks = function (options) {
            options = typeof options === "string" ? (optionsCache[options] || createOptions(options)) : jQuery.extend({}, options);
            var memory, fired, firing, firingStart, firingLength, firingIndex, list = [], stack = !options.once && [], fire = function (data) {
                memory = options.memory && data;
                fired = true;
                firingIndex = firingStart || 0;
                firingStart = 0;
                firingLength = list.length;
                firing = true;
                for (; list && firingIndex < firingLength; firingIndex++) {
                    if (list[firingIndex].apply(data[0], data[1]) === false && options.stopOnFalse) {
                        memory = false;
                        break
                    }
                }
                firing = false;
                if (list) {
                    if (stack) {
                        if (stack.length) {
                            fire(stack.shift())
                        }
                    } else {
                        if (memory) {
                            list = []
                        } else {
                            self.disable()
                        }
                    }
                }
            }, self = {
                add: function () {
                    if (list) {
                        var start = list.length;
                        (function add(args) {
                            jQuery.each(args, function (_, arg) {
                                var type = jQuery.type(arg);
                                if (type === "function") {
                                    if (!options.unique || !self.has(arg)) {
                                        list.push(arg)
                                    }
                                } else {
                                    if (arg && arg.length && type !== "string") {
                                        add(arg)
                                    }
                                }
                            })
                        })(arguments);
                        if (firing) {
                            firingLength = list.length
                        } else {
                            if (memory) {
                                firingStart = start;
                                fire(memory)
                            }
                        }
                    }
                    return this
                }, remove: function () {
                    if (list) {
                        jQuery.each(arguments, function (_, arg) {
                            var index;
                            while ((index = jQuery.inArray(arg, list, index)) > -1) {
                                list.splice(index, 1);
                                if (firing) {
                                    if (index <= firingLength) {
                                        firingLength--
                                    }
                                    if (index <= firingIndex) {
                                        firingIndex--
                                    }
                                }
                            }
                        })
                    }
                    return this
                }, has: function (fn) {
                    return jQuery.inArray(fn, list) > -1
                }, empty: function () {
                    list = [];
                    return this
                }, disable: function () {
                    list = stack = memory = undefined;
                    return this
                }, disabled: function () {
                    return !list
                }, lock: function () {
                    stack = undefined;
                    if (!memory) {
                        self.disable()
                    }
                    return this
                }, locked: function () {
                    return !stack
                }, fireWith: function (context, args) {
                    args = args || [];
                    args = [context, args.slice ? args.slice() : args];
                    if (list && (!fired || stack)) {
                        if (firing) {
                            stack.push(args)
                        } else {
                            fire(args)
                        }
                    }
                    return this
                }, fire: function () {
                    self.fireWith(this, arguments);
                    return this
                }, fired: function () {
                    return !!fired
                }
            };
            return self
        };
        jQuery.extend({
            Deferred: function (func) {
                var tuples = [["resolve", "done", jQuery.Callbacks("once memory"), "resolved"], ["reject", "fail", jQuery.Callbacks("once memory"), "rejected"], ["notify", "progress", jQuery.Callbacks("memory")]], state = "pending", promise = {
                    state: function () {
                        return state
                    }, always: function () {
                        deferred.done(arguments).fail(arguments);
                        return this
                    }, then: function () {
                        var fns = arguments;
                        return jQuery.Deferred(function (newDefer) {
                            jQuery.each(tuples, function (i, tuple) {
                                var action = tuple[0], fn = fns[i];
                                deferred[tuple[1]](jQuery.isFunction(fn) ? function () {
                                    var returned = fn.apply(this, arguments);
                                    if (returned && jQuery.isFunction(returned.promise)) {
                                        returned.promise().done(newDefer.resolve).fail(newDefer.reject).progress(newDefer.notify)
                                    } else {
                                        newDefer[action + "With"](this === deferred ? newDefer : this, [returned])
                                    }
                                } : newDefer[action])
                            });
                            fns = null
                        }).promise()
                    }, promise: function (obj) {
                        return obj != null ? jQuery.extend(obj, promise) : promise
                    }
                }, deferred = {};
                promise.pipe = promise.then;
                jQuery.each(tuples, function (i, tuple) {
                    var list = tuple[2], stateString = tuple[3];
                    promise[tuple[1]] = list.add;
                    if (stateString) {
                        list.add(function () {
                            state = stateString
                        }, tuples[i ^ 1][2].disable, tuples[2][2].lock)
                    }
                    deferred[tuple[0]] = list.fire;
                    deferred[tuple[0] + "With"] = list.fireWith
                });
                promise.promise(deferred);
                if (func) {
                    func.call(deferred, deferred)
                }
                return deferred
            }, when: function (subordinate) {
                var i = 0, resolveValues = core_slice.call(arguments), length = resolveValues.length, remaining = length !== 1 || (subordinate && jQuery.isFunction(subordinate.promise)) ? length : 0, deferred = remaining === 1 ? subordinate : jQuery.Deferred(), updateFunc = function (i, contexts, values) {
                    return function (value) {
                        contexts[i] = this;
                        values[i] = arguments.length > 1 ? core_slice.call(arguments) : value;
                        if (values === progressValues) {
                            deferred.notifyWith(contexts, values)
                        } else {
                            if (!(--remaining)) {
                                deferred.resolveWith(contexts, values)
                            }
                        }
                    }
                }, progressValues, progressContexts, resolveContexts;
                if (length > 1) {
                    progressValues = new Array(length);
                    progressContexts = new Array(length);
                    resolveContexts = new Array(length);
                    for (; i < length; i++) {
                        if (resolveValues[i] && jQuery.isFunction(resolveValues[i].promise)) {
                            resolveValues[i].promise().done(updateFunc(i, resolveContexts, resolveValues)).fail(deferred.reject).progress(updateFunc(i, progressContexts, progressValues))
                        } else {
                            --remaining
                        }
                    }
                }
                if (!remaining) {
                    deferred.resolveWith(resolveContexts, resolveValues)
                }
                return deferred.promise()
            }
        });
        jQuery.support = (function () {
            var support, all, a, select, opt, input, fragment, eventName, i, isSupported, clickFn, div = document.createElement("div");
            div.setAttribute("className", "t");
            div.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>";
            all = div.getElementsByTagName("*");
            a = div.getElementsByTagName("a")[0];
            if (!all || !a || !all.length) {
                return {}
            }
            select = document.createElement("select");
            opt = select.appendChild(document.createElement("option"));
            input = div.getElementsByTagName("input")[0];
            a.style.cssText = "top:1px;float:left;opacity:.5";
            support = {
                leadingWhitespace: (div.firstChild.nodeType === 3),
                tbody: !div.getElementsByTagName("tbody").length,
                htmlSerialize: !!div.getElementsByTagName("link").length,
                style: /top/.test(a.getAttribute("style")),
                hrefNormalized: (a.getAttribute("href") === "/a"),
                opacity: /^0.5/.test(a.style.opacity),
                cssFloat: !!a.style.cssFloat,
                checkOn: (input.value === "on"),
                optSelected: opt.selected,
                getSetAttribute: div.className !== "t",
                enctype: !!document.createElement("form").enctype,
                html5Clone: document.createElement("nav").cloneNode(true).outerHTML !== "<:nav></:nav>",
                boxModel: (document.compatMode === "CSS1Compat"),
                submitBubbles: true,
                changeBubbles: true,
                focusinBubbles: false,
                deleteExpando: true,
                noCloneEvent: true,
                inlineBlockNeedsLayout: false,
                shrinkWrapBlocks: false,
                reliableMarginRight: true,
                boxSizingReliable: true,
                pixelPosition: false
            };
            input.checked = true;
            support.noCloneChecked = input.cloneNode(true).checked;
            select.disabled = true;
            support.optDisabled = !opt.disabled;
            try {
                delete div.test
            } catch (e) {
                support.deleteExpando = false
            }
            if (!div.addEventListener && div.attachEvent && div.fireEvent) {
                div.attachEvent("onclick", clickFn = function () {
                    support.noCloneEvent = false
                });
                div.cloneNode(true).fireEvent("onclick");
                div.detachEvent("onclick", clickFn)
            }
            input = document.createElement("input");
            input.value = "t";
            input.setAttribute("type", "radio");
            support.radioValue = input.value === "t";
            input.setAttribute("checked", "checked");
            input.setAttribute("name", "t");
            div.appendChild(input);
            fragment = document.createDocumentFragment();
            fragment.appendChild(div.lastChild);
            support.checkClone = fragment.cloneNode(true).cloneNode(true).lastChild.checked;
            support.appendChecked = input.checked;
            fragment.removeChild(input);
            fragment.appendChild(div);
            if (div.attachEvent) {
                for (i in {submit: true, change: true, focusin: true}) {
                    eventName = "on" + i;
                    isSupported = (eventName in div);
                    if (!isSupported) {
                        div.setAttribute(eventName, "return;");
                        isSupported = (typeof div[eventName] === "function")
                    }
                    support[i + "Bubbles"] = isSupported
                }
            }
            jQuery(function () {
                var container, div, tds, marginDiv, divReset = "padding:0;margin:0;border:0;display:block;overflow:hidden;", body = document.getElementsByTagName("body")[0];
                if (!body) {
                    return
                }
                container = document.createElement("div");
                container.style.cssText = "visibility:hidden;border:0;width:0;height:0;position:static;top:0;margin-top:1px";
                body.insertBefore(container, body.firstChild);
                div = document.createElement("div");
                container.appendChild(div);
                div.innerHTML = "<table><tr><td></td><td>t</td></tr></table>";
                tds = div.getElementsByTagName("td");
                tds[0].style.cssText = "padding:0;margin:0;border:0;display:none";
                isSupported = (tds[0].offsetHeight === 0);
                tds[0].style.display = "";
                tds[1].style.display = "none";
                support.reliableHiddenOffsets = isSupported && (tds[0].offsetHeight === 0);
                div.innerHTML = "";
                div.style.cssText = "box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;padding:1px;border:1px;display:block;width:4px;margin-top:1%;position:absolute;top:1%;";
                support.boxSizing = (div.offsetWidth === 4);
                support.doesNotIncludeMarginInBodyOffset = (body.offsetTop !== 1);
                if (window.getComputedStyle) {
                    support.pixelPosition = (window.getComputedStyle(div, null) || {}).top !== "1%";
                    support.boxSizingReliable = (window.getComputedStyle(div, null) || {width: "4px"}).width === "4px";
                    marginDiv = document.createElement("div");
                    marginDiv.style.cssText = div.style.cssText = divReset;
                    marginDiv.style.marginRight = marginDiv.style.width = "0";
                    div.style.width = "1px";
                    div.appendChild(marginDiv);
                    support.reliableMarginRight = !parseFloat((window.getComputedStyle(marginDiv, null) || {}).marginRight)
                }
                if (typeof div.style.zoom !== "undefined") {
                    div.innerHTML = "";
                    div.style.cssText = divReset + "width:1px;padding:1px;display:inline;zoom:1";
                    support.inlineBlockNeedsLayout = (div.offsetWidth === 3);
                    div.style.display = "block";
                    div.style.overflow = "visible";
                    div.innerHTML = "<div></div>";
                    div.firstChild.style.width = "5px";
                    support.shrinkWrapBlocks = (div.offsetWidth !== 3);
                    container.style.zoom = 1
                }
                body.removeChild(container);
                container = div = tds = marginDiv = null
            });
            fragment.removeChild(div);
            all = a = select = opt = input = fragment = div = null;
            return support
        })();
        var rbrace = /(?:\{[\s\S]*\}|\[[\s\S]*\])$/, rmultiDash = /([A-Z])/g;
        jQuery.extend({
            cache: {},
            deletedIds: [],
            uuid: 0,
            expando: "jQuery" + (jQuery.fn.jquery + Math.random()).replace(/\D/g, ""),
            noData: {embed: true, object: "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000", applet: true},
            hasData: function (elem) {
                elem = elem.nodeType ? jQuery.cache[elem[jQuery.expando]] : elem[jQuery.expando];
                return !!elem && !isEmptyDataObject(elem)
            },
            data: function (elem, name, data, pvt) {
                if (!jQuery.acceptData(elem)) {
                    return
                }
                var thisCache, ret, internalKey = jQuery.expando, getByName = typeof name === "string", isNode = elem.nodeType, cache = isNode ? jQuery.cache : elem, id = isNode ? elem[internalKey] : elem[internalKey] && internalKey;
                if ((!id || !cache[id] || (!pvt && !cache[id].data)) && getByName && data === undefined) {
                    return
                }
                if (!id) {
                    if (isNode) {
                        elem[internalKey] = id = jQuery.deletedIds.pop() || jQuery.guid++
                    } else {
                        id = internalKey
                    }
                }
                if (!cache[id]) {
                    cache[id] = {};
                    if (!isNode) {
                        cache[id].toJSON = jQuery.noop
                    }
                }
                if (typeof name === "object" || typeof name === "function") {
                    if (pvt) {
                        cache[id] = jQuery.extend(cache[id], name)
                    } else {
                        cache[id].data = jQuery.extend(cache[id].data, name)
                    }
                }
                thisCache = cache[id];
                if (!pvt) {
                    if (!thisCache.data) {
                        thisCache.data = {}
                    }
                    thisCache = thisCache.data
                }
                if (data !== undefined) {
                    thisCache[jQuery.camelCase(name)] = data
                }
                if (getByName) {
                    ret = thisCache[name];
                    if (ret == null) {
                        ret = thisCache[jQuery.camelCase(name)]
                    }
                } else {
                    ret = thisCache
                }
                return ret
            },
            removeData: function (elem, name, pvt) {
                if (!jQuery.acceptData(elem)) {
                    return
                }
                var thisCache, i, l, isNode = elem.nodeType, cache = isNode ? jQuery.cache : elem, id = isNode ? elem[jQuery.expando] : jQuery.expando;
                if (!cache[id]) {
                    return
                }
                if (name) {
                    thisCache = pvt ? cache[id] : cache[id].data;
                    if (thisCache) {
                        if (!jQuery.isArray(name)) {
                            if (name in thisCache) {
                                name = [name]
                            } else {
                                name = jQuery.camelCase(name);
                                if (name in thisCache) {
                                    name = [name]
                                } else {
                                    name = name.split(" ")
                                }
                            }
                        }
                        for (i = 0, l = name.length; i < l; i++) {
                            delete thisCache[name[i]]
                        }
                        if (!(pvt ? isEmptyDataObject : jQuery.isEmptyObject)(thisCache)) {
                            return
                        }
                    }
                }
                if (!pvt) {
                    delete cache[id].data;
                    if (!isEmptyDataObject(cache[id])) {
                        return
                    }
                }
                if (isNode) {
                    jQuery.cleanData([elem], true)
                } else {
                    if (jQuery.support.deleteExpando || cache != cache.window) {
                        delete cache[id]
                    } else {
                        cache[id] = null
                    }
                }
            },
            _data: function (elem, name, data) {
                return jQuery.data(elem, name, data, true)
            },
            acceptData: function (elem) {
                var noData = elem.nodeName && jQuery.noData[elem.nodeName.toLowerCase()];
                return !noData || noData !== true && elem.getAttribute("classid") === noData
            }
        });
        jQuery.fn.extend({
            data: function (key, value) {
                var parts, part, attr, name, l, elem = this[0], i = 0, data = null;
                if (key === undefined) {
                    if (this.length) {
                        data = jQuery.data(elem);
                        if (elem.nodeType === 1 && !jQuery._data(elem, "parsedAttrs")) {
                            attr = elem.attributes;
                            for (l = attr.length; i < l; i++) {
                                name = attr[i].name;
                                if (!name.indexOf("data-")) {
                                    name = jQuery.camelCase(name.substring(5));
                                    dataAttr(elem, name, data[name])
                                }
                            }
                            jQuery._data(elem, "parsedAttrs", true)
                        }
                    }
                    return data
                }
                if (typeof key === "object") {
                    return this.each(function () {
                        jQuery.data(this, key)
                    })
                }
                parts = key.split(".", 2);
                parts[1] = parts[1] ? "." + parts[1] : "";
                part = parts[1] + "!";
                return jQuery.access(this, function (value) {
                    if (value === undefined) {
                        data = this.triggerHandler("getData" + part, [parts[0]]);
                        if (data === undefined && elem) {
                            data = jQuery.data(elem, key);
                            data = dataAttr(elem, key, data)
                        }
                        return data === undefined && parts[1] ? this.data(parts[0]) : data
                    }
                    parts[1] = value;
                    this.each(function () {
                        var self = jQuery(this);
                        self.triggerHandler("setData" + part, parts);
                        jQuery.data(this, key, value);
                        self.triggerHandler("changeData" + part, parts)
                    })
                }, null, value, arguments.length > 1, null, false)
            }, removeData: function (key) {
                return this.each(function () {
                    jQuery.removeData(this, key)
                })
            }
        });
        function dataAttr(elem, key, data) {
            if (data === undefined && elem.nodeType === 1) {
                var name = "data-" + key.replace(rmultiDash, "-$1").toLowerCase();
                data = elem.getAttribute(name);
                if (typeof data === "string") {
                    try {
                        data = data === "true" ? true : data === "false" ? false : data === "null" ? null : +data + "" === data ? +data : rbrace.test(data) ? jQuery.parseJSON(data) : data
                    } catch (e) {
                    }
                    jQuery.data(elem, key, data)
                } else {
                    data = undefined
                }
            }
            return data
        }

        function isEmptyDataObject(obj) {
            var name;
            for (name in obj) {
                if (name === "data" && jQuery.isEmptyObject(obj[name])) {
                    continue
                }
                if (name !== "toJSON") {
                    return false
                }
            }
            return true
        }

        jQuery.extend({
            queue: function (elem, type, data) {
                var queue;
                if (elem) {
                    type = (type || "fx") + "queue";
                    queue = jQuery._data(elem, type);
                    if (data) {
                        if (!queue || jQuery.isArray(data)) {
                            queue = jQuery._data(elem, type, jQuery.makeArray(data))
                        } else {
                            queue.push(data)
                        }
                    }
                    return queue || []
                }
            }, dequeue: function (elem, type) {
                type = type || "fx";
                var queue = jQuery.queue(elem, type), startLength = queue.length, fn = queue.shift(), hooks = jQuery._queueHooks(elem, type), next = function () {
                    jQuery.dequeue(elem, type)
                };
                if (fn === "inprogress") {
                    fn = queue.shift();
                    startLength--
                }
                if (fn) {
                    if (type === "fx") {
                        queue.unshift("inprogress")
                    }
                    delete hooks.stop;
                    fn.call(elem, next, hooks)
                }
                if (!startLength && hooks) {
                    hooks.empty.fire()
                }
            }, _queueHooks: function (elem, type) {
                var key = type + "queueHooks";
                return jQuery._data(elem, key) || jQuery._data(elem, key, {
                        empty: jQuery.Callbacks("once memory").add(function () {
                            jQuery.removeData(elem, type + "queue", true);
                            jQuery.removeData(elem, key, true)
                        })
                    })
            }
        });
        jQuery.fn.extend({
            queue: function (type, data) {
                var setter = 2;
                if (typeof type !== "string") {
                    data = type;
                    type = "fx";
                    setter--
                }
                if (arguments.length < setter) {
                    return jQuery.queue(this[0], type)
                }
                return data === undefined ? this : this.each(function () {
                    var queue = jQuery.queue(this, type, data);
                    jQuery._queueHooks(this, type);
                    if (type === "fx" && queue[0] !== "inprogress") {
                        jQuery.dequeue(this, type)
                    }
                })
            }, dequeue: function (type) {
                return this.each(function () {
                    jQuery.dequeue(this, type)
                })
            }, delay: function (time, type) {
                time = jQuery.fx ? jQuery.fx.speeds[time] || time : time;
                type = type || "fx";
                return this.queue(type, function (next, hooks) {
                    var timeout = setTimeout(next, time);
                    hooks.stop = function () {
                        clearTimeout(timeout)
                    }
                })
            }, clearQueue: function (type) {
                return this.queue(type || "fx", [])
            }, promise: function (type, obj) {
                var tmp, count = 1, defer = jQuery.Deferred(), elements = this, i = this.length, resolve = function () {
                    if (!(--count)) {
                        defer.resolveWith(elements, [elements])
                    }
                };
                if (typeof type !== "string") {
                    obj = type;
                    type = undefined
                }
                type = type || "fx";
                while (i--) {
                    tmp = jQuery._data(elements[i], type + "queueHooks");
                    if (tmp && tmp.empty) {
                        count++;
                        tmp.empty.add(resolve)
                    }
                }
                resolve();
                return defer.promise(obj)
            }
        });
        var nodeHook, boolHook, fixSpecified, rclass = /[\t\r\n]/g, rreturn = /\r/g, rtype = /^(?:button|input)$/i, rfocusable = /^(?:button|input|object|select|textarea)$/i, rclickable = /^a(?:rea|)$/i, rboolean = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i, getSetAttribute = jQuery.support.getSetAttribute;
        jQuery.fn.extend({
            attr: function (name, value) {
                return jQuery.access(this, jQuery.attr, name, value, arguments.length > 1)
            }, removeAttr: function (name) {
                return this.each(function () {
                    jQuery.removeAttr(this, name)
                })
            }, prop: function (name, value) {
                return jQuery.access(this, jQuery.prop, name, value, arguments.length > 1)
            }, removeProp: function (name) {
                name = jQuery.propFix[name] || name;
                return this.each(function () {
                    try {
                        this[name] = undefined;
                        delete this[name]
                    } catch (e) {
                    }
                })
            }, addClass: function (value) {
                var classNames, i, l, elem, setClass, c, cl;
                if (jQuery.isFunction(value)) {
                    return this.each(function (j) {
                        jQuery(this).addClass(value.call(this, j, this.className))
                    })
                }
                if (value && typeof value === "string") {
                    classNames = value.split(core_rspace);
                    for (i = 0, l = this.length; i < l; i++) {
                        elem = this[i];
                        if (elem.nodeType === 1) {
                            if (!elem.className && classNames.length === 1) {
                                elem.className = value
                            } else {
                                setClass = " " + elem.className + " ";
                                for (c = 0, cl = classNames.length; c < cl; c++) {
                                    if (setClass.indexOf(" " + classNames[c] + " ") < 0) {
                                        setClass += classNames[c] + " "
                                    }
                                }
                                elem.className = jQuery.trim(setClass)
                            }
                        }
                    }
                }
                return this
            }, removeClass: function (value) {
                var removes, className, elem, c, cl, i, l;
                if (jQuery.isFunction(value)) {
                    return this.each(function (j) {
                        jQuery(this).removeClass(value.call(this, j, this.className))
                    })
                }
                if ((value && typeof value === "string") || value === undefined) {
                    removes = (value || "").split(core_rspace);
                    for (i = 0, l = this.length; i < l; i++) {
                        elem = this[i];
                        if (elem.nodeType === 1 && elem.className) {
                            className = (" " + elem.className + " ").replace(rclass, " ");
                            for (c = 0, cl = removes.length; c < cl; c++) {
                                while (className.indexOf(" " + removes[c] + " ") >= 0) {
                                    className = className.replace(" " + removes[c] + " ", " ")
                                }
                            }
                            elem.className = value ? jQuery.trim(className) : ""
                        }
                    }
                }
                return this
            }, toggleClass: function (value, stateVal) {
                var type = typeof value, isBool = typeof stateVal === "boolean";
                if (jQuery.isFunction(value)) {
                    return this.each(function (i) {
                        jQuery(this).toggleClass(value.call(this, i, this.className, stateVal), stateVal)
                    })
                }
                return this.each(function () {
                    if (type === "string") {
                        var className, i = 0, self = jQuery(this), state = stateVal, classNames = value.split(core_rspace);
                        while ((className = classNames[i++])) {
                            state = isBool ? state : !self.hasClass(className);
                            self[state ? "addClass" : "removeClass"](className)
                        }
                    } else {
                        if (type === "undefined" || type === "boolean") {
                            if (this.className) {
                                jQuery._data(this, "__className__", this.className)
                            }
                            this.className = this.className || value === false ? "" : jQuery._data(this, "__className__") || ""
                        }
                    }
                })
            }, hasClass: function (selector) {
                var className = " " + selector + " ", i = 0, l = this.length;
                for (; i < l; i++) {
                    if (this[i].nodeType === 1 && (" " + this[i].className + " ").replace(rclass, " ").indexOf(className) >= 0) {
                        return true
                    }
                }
                return false
            }, val: function (value) {
                var hooks, ret, isFunction, elem = this[0];
                if (!arguments.length) {
                    if (elem) {
                        hooks = jQuery.valHooks[elem.type] || jQuery.valHooks[elem.nodeName.toLowerCase()];
                        if (hooks && "get" in hooks && (ret = hooks.get(elem, "value")) !== undefined) {
                            return ret
                        }
                        ret = elem.value;
                        return typeof ret === "string" ? ret.replace(rreturn, "") : ret == null ? "" : ret
                    }
                    return
                }
                isFunction = jQuery.isFunction(value);
                return this.each(function (i) {
                    var val, self = jQuery(this);
                    if (this.nodeType !== 1) {
                        return
                    }
                    if (isFunction) {
                        val = value.call(this, i, self.val())
                    } else {
                        val = value
                    }
                    if (val == null) {
                        val = ""
                    } else {
                        if (typeof val === "number") {
                            val += ""
                        } else {
                            if (jQuery.isArray(val)) {
                                val = jQuery.map(val, function (value) {
                                    return value == null ? "" : value + ""
                                })
                            }
                        }
                    }
                    hooks = jQuery.valHooks[this.type] || jQuery.valHooks[this.nodeName.toLowerCase()];
                    if (!hooks || !("set" in hooks) || hooks.set(this, val, "value") === undefined) {
                        this.value = val
                    }
                })
            }
        });
        jQuery.extend({
            valHooks: {
                option: {
                    get: function (elem) {
                        var val = elem.attributes.value;
                        return !val || val.specified ? elem.value : elem.text
                    }
                }, select: {
                    get: function (elem) {
                        var value, option, options = elem.options, index = elem.selectedIndex, one = elem.type === "select-one" || index < 0, values = one ? null : [], max = one ? index + 1 : options.length, i = index < 0 ? max : one ? index : 0;
                        for (; i < max; i++) {
                            option = options[i];
                            if ((option.selected || i === index) && (jQuery.support.optDisabled ? !option.disabled : option.getAttribute("disabled") === null) && (!option.parentNode.disabled || !jQuery.nodeName(option.parentNode, "optgroup"))) {
                                value = jQuery(option).val();
                                if (one) {
                                    return value
                                }
                                values.push(value)
                            }
                        }
                        return values
                    }, set: function (elem, value) {
                        var values = jQuery.makeArray(value);
                        jQuery(elem).find("option").each(function () {
                            this.selected = jQuery.inArray(jQuery(this).val(), values) >= 0
                        });
                        if (!values.length) {
                            elem.selectedIndex = -1
                        }
                        return values
                    }
                }
            },
            attrFn: {},
            attr: function (elem, name, value, pass) {
                var ret, hooks, notxml, nType = elem.nodeType;
                if (!elem || nType === 3 || nType === 8 || nType === 2) {
                    return
                }
                if (pass && jQuery.isFunction(jQuery.fn[name])) {
                    return jQuery(elem)[name](value)
                }
                if (typeof elem.getAttribute === "undefined") {
                    return jQuery.prop(elem, name, value)
                }
                notxml = nType !== 1 || !jQuery.isXMLDoc(elem);
                if (notxml) {
                    name = name.toLowerCase();
                    hooks = jQuery.attrHooks[name] || (rboolean.test(name) ? boolHook : nodeHook)
                }
                if (value !== undefined) {
                    if (value === null) {
                        jQuery.removeAttr(elem, name);
                        return
                    } else {
                        if (hooks && "set" in hooks && notxml && (ret = hooks.set(elem, value, name)) !== undefined) {
                            return ret
                        } else {
                            elem.setAttribute(name, value + "");
                            return value
                        }
                    }
                } else {
                    if (hooks && "get" in hooks && notxml && (ret = hooks.get(elem, name)) !== null) {
                        return ret
                    } else {
                        ret = elem.getAttribute(name);
                        return ret === null ? undefined : ret
                    }
                }
            },
            removeAttr: function (elem, value) {
                var propName, attrNames, name, isBool, i = 0;
                if (value && elem.nodeType === 1) {
                    attrNames = value.split(core_rspace);
                    for (; i < attrNames.length; i++) {
                        name = attrNames[i];
                        if (name) {
                            propName = jQuery.propFix[name] || name;
                            isBool = rboolean.test(name);
                            if (!isBool) {
                                jQuery.attr(elem, name, "")
                            }
                            elem.removeAttribute(getSetAttribute ? name : propName);
                            if (isBool && propName in elem) {
                                elem[propName] = false
                            }
                        }
                    }
                }
            },
            attrHooks: {
                type: {
                    set: function (elem, value) {
                        if (rtype.test(elem.nodeName) && elem.parentNode) {
                            jQuery.error("type property can't be changed")
                        } else {
                            if (!jQuery.support.radioValue && value === "radio" && jQuery.nodeName(elem, "input")) {
                                var val = elem.value;
                                elem.setAttribute("type", value);
                                if (val) {
                                    elem.value = val
                                }
                                return value
                            }
                        }
                    }
                }, value: {
                    get: function (elem, name) {
                        if (nodeHook && jQuery.nodeName(elem, "button")) {
                            return nodeHook.get(elem, name)
                        }
                        return name in elem ? elem.value : null
                    }, set: function (elem, value, name) {
                        if (nodeHook && jQuery.nodeName(elem, "button")) {
                            return nodeHook.set(elem, value, name)
                        }
                        elem.value = value
                    }
                }
            },
            propFix: {
                tabindex: "tabIndex",
                readonly: "readOnly",
                "for": "htmlFor",
                "class": "className",
                maxlength: "maxLength",
                cellspacing: "cellSpacing",
                cellpadding: "cellPadding",
                rowspan: "rowSpan",
                colspan: "colSpan",
                usemap: "useMap",
                frameborder: "frameBorder",
                contenteditable: "contentEditable"
            },
            prop: function (elem, name, value) {
                var ret, hooks, notxml, nType = elem.nodeType;
                if (!elem || nType === 3 || nType === 8 || nType === 2) {
                    return
                }
                notxml = nType !== 1 || !jQuery.isXMLDoc(elem);
                if (notxml) {
                    name = jQuery.propFix[name] || name;
                    hooks = jQuery.propHooks[name]
                }
                if (value !== undefined) {
                    if (hooks && "set" in hooks && (ret = hooks.set(elem, value, name)) !== undefined) {
                        return ret
                    } else {
                        return (elem[name] = value)
                    }
                } else {
                    if (hooks && "get" in hooks && (ret = hooks.get(elem, name)) !== null) {
                        return ret
                    } else {
                        return elem[name]
                    }
                }
            },
            propHooks: {
                tabIndex: {
                    get: function (elem) {
                        var attributeNode = elem.getAttributeNode("tabindex");
                        return attributeNode && attributeNode.specified ? parseInt(attributeNode.value, 10) : rfocusable.test(elem.nodeName) || rclickable.test(elem.nodeName) && elem.href ? 0 : undefined
                    }
                }
            }
        });
        boolHook = {
            get: function (elem, name) {
                var attrNode, property = jQuery.prop(elem, name);
                return property === true || typeof property !== "boolean" && (attrNode = elem.getAttributeNode(name)) && attrNode.nodeValue !== false ? name.toLowerCase() : undefined
            }, set: function (elem, value, name) {
                var propName;
                if (value === false) {
                    jQuery.removeAttr(elem, name)
                } else {
                    propName = jQuery.propFix[name] || name;
                    if (propName in elem) {
                        elem[propName] = true
                    }
                    elem.setAttribute(name, name.toLowerCase())
                }
                return name
            }
        };
        if (!getSetAttribute) {
            fixSpecified = {name: true, id: true, coords: true};
            nodeHook = jQuery.valHooks.button = {
                get: function (elem, name) {
                    var ret;
                    ret = elem.getAttributeNode(name);
                    return ret && (fixSpecified[name] ? ret.value !== "" : ret.specified) ? ret.value : undefined
                }, set: function (elem, value, name) {
                    var ret = elem.getAttributeNode(name);
                    if (!ret) {
                        ret = document.createAttribute(name);
                        elem.setAttributeNode(ret)
                    }
                    return (ret.value = value + "")
                }
            };
            jQuery.each(["width", "height"], function (i, name) {
                jQuery.attrHooks[name] = jQuery.extend(jQuery.attrHooks[name], {
                    set: function (elem, value) {
                        if (value === "") {
                            elem.setAttribute(name, "auto");
                            return value
                        }
                    }
                })
            });
            jQuery.attrHooks.contenteditable = {
                get: nodeHook.get, set: function (elem, value, name) {
                    if (value === "") {
                        value = "false"
                    }
                    nodeHook.set(elem, value, name)
                }
            }
        }
        if (!jQuery.support.hrefNormalized) {
            jQuery.each(["href", "src", "width", "height"], function (i, name) {
                jQuery.attrHooks[name] = jQuery.extend(jQuery.attrHooks[name], {
                    get: function (elem) {
                        var ret = elem.getAttribute(name, 2);
                        return ret === null ? undefined : ret
                    }
                })
            })
        }
        if (!jQuery.support.style) {
            jQuery.attrHooks.style = {
                get: function (elem) {
                    return elem.style.cssText.toLowerCase() || undefined
                }, set: function (elem, value) {
                    return (elem.style.cssText = value + "")
                }
            }
        }
        if (!jQuery.support.optSelected) {
            jQuery.propHooks.selected = jQuery.extend(jQuery.propHooks.selected, {
                get: function (elem) {
                    var parent = elem.parentNode;
                    if (parent) {
                        parent.selectedIndex;
                        if (parent.parentNode) {
                            parent.parentNode.selectedIndex
                        }
                    }
                    return null
                }
            })
        }
        if (!jQuery.support.enctype) {
            jQuery.propFix.enctype = "encoding"
        }
        if (!jQuery.support.checkOn) {
            jQuery.each(["radio", "checkbox"], function () {
                jQuery.valHooks[this] = {
                    get: function (elem) {
                        return elem.getAttribute("value") === null ? "on" : elem.value
                    }
                }
            })
        }
        jQuery.each(["radio", "checkbox"], function () {
            jQuery.valHooks[this] = jQuery.extend(jQuery.valHooks[this], {
                set: function (elem, value) {
                    if (jQuery.isArray(value)) {
                        return (elem.checked = jQuery.inArray(jQuery(elem).val(), value) >= 0)
                    }
                }
            })
        });
        var rformElems = /^(?:textarea|input|select)$/i, rtypenamespace = /^([^\.]*|)(?:\.(.+)|)$/, rhoverHack = /(?:^|\s)hover(\.\S+|)\b/, rkeyEvent = /^key/, rmouseEvent = /^(?:mouse|contextmenu)|click/, rfocusMorph = /^(?:focusinfocus|focusoutblur)$/, hoverHack = function (events) {
            return jQuery.event.special.hover ? events : events.replace(rhoverHack, "mouseenter$1 mouseleave$1")
        };
        jQuery.event = {
            add: function (elem, types, handler, data, selector) {
                var elemData, eventHandle, events, t, tns, type, namespaces, handleObj, handleObjIn, handlers, special;
                if (elem.nodeType === 3 || elem.nodeType === 8 || !types || !handler || !(elemData = jQuery._data(elem))) {
                    return
                }
                if (handler.handler) {
                    handleObjIn = handler;
                    handler = handleObjIn.handler;
                    selector = handleObjIn.selector
                }
                if (!handler.guid) {
                    handler.guid = jQuery.guid++
                }
                events = elemData.events;
                if (!events) {
                    elemData.events = events = {}
                }
                eventHandle = elemData.handle;
                if (!eventHandle) {
                    elemData.handle = eventHandle = function (e) {
                        return typeof jQuery !== "undefined" && (!e || jQuery.event.triggered !== e.type) ? jQuery.event.dispatch.apply(eventHandle.elem, arguments) : undefined
                    };
                    eventHandle.elem = elem
                }
                types = jQuery.trim(hoverHack(types)).split(" ");
                for (t = 0; t < types.length; t++) {
                    tns = rtypenamespace.exec(types[t]) || [];
                    type = tns[1];
                    namespaces = (tns[2] || "").split(".").sort();
                    special = jQuery.event.special[type] || {};
                    type = (selector ? special.delegateType : special.bindType) || type;
                    special = jQuery.event.special[type] || {};
                    handleObj = jQuery.extend({
                        type: type,
                        origType: tns[1],
                        data: data,
                        handler: handler,
                        guid: handler.guid,
                        selector: selector,
                        needsContext: selector && jQuery.expr.match.needsContext.test(selector),
                        namespace: namespaces.join(".")
                    }, handleObjIn);
                    handlers = events[type];
                    if (!handlers) {
                        handlers = events[type] = [];
                        handlers.delegateCount = 0;
                        if (!special.setup || special.setup.call(elem, data, namespaces, eventHandle) === false) {
                            if (elem.addEventListener) {
                                elem.addEventListener(type, eventHandle, false)
                            } else {
                                if (elem.attachEvent) {
                                    elem.attachEvent("on" + type, eventHandle)
                                }
                            }
                        }
                    }
                    if (special.add) {
                        special.add.call(elem, handleObj);
                        if (!handleObj.handler.guid) {
                            handleObj.handler.guid = handler.guid
                        }
                    }
                    if (selector) {
                        handlers.splice(handlers.delegateCount++, 0, handleObj)
                    } else {
                        handlers.push(handleObj)
                    }
                    jQuery.event.global[type] = true
                }
                elem = null
            },
            global: {},
            remove: function (elem, types, handler, selector, mappedTypes) {
                var t, tns, type, origType, namespaces, origCount, j, events, special, eventType, handleObj, elemData = jQuery.hasData(elem) && jQuery._data(elem);
                if (!elemData || !(events = elemData.events)) {
                    return
                }
                types = jQuery.trim(hoverHack(types || "")).split(" ");
                for (t = 0; t < types.length; t++) {
                    tns = rtypenamespace.exec(types[t]) || [];
                    type = origType = tns[1];
                    namespaces = tns[2];
                    if (!type) {
                        for (type in events) {
                            jQuery.event.remove(elem, type + types[t], handler, selector, true)
                        }
                        continue
                    }
                    special = jQuery.event.special[type] || {};
                    type = (selector ? special.delegateType : special.bindType) || type;
                    eventType = events[type] || [];
                    origCount = eventType.length;
                    namespaces = namespaces ? new RegExp("(^|\\.)" + namespaces.split(".").sort().join("\\.(?:.*\\.|)") + "(\\.|$)") : null;
                    for (j = 0; j < eventType.length; j++) {
                        handleObj = eventType[j];
                        if ((mappedTypes || origType === handleObj.origType) && (!handler || handler.guid === handleObj.guid) && (!namespaces || namespaces.test(handleObj.namespace)) && (!selector || selector === handleObj.selector || selector === "**" && handleObj.selector)) {
                            eventType.splice(j--, 1);
                            if (handleObj.selector) {
                                eventType.delegateCount--
                            }
                            if (special.remove) {
                                special.remove.call(elem, handleObj)
                            }
                        }
                    }
                    if (eventType.length === 0 && origCount !== eventType.length) {
                        if (!special.teardown || special.teardown.call(elem, namespaces, elemData.handle) === false) {
                            jQuery.removeEvent(elem, type, elemData.handle)
                        }
                        delete events[type]
                    }
                }
                if (jQuery.isEmptyObject(events)) {
                    delete elemData.handle;
                    jQuery.removeData(elem, "events", true)
                }
            },
            customEvent: {getData: true, setData: true, changeData: true},
            trigger: function (event, data, elem, onlyHandlers) {
                if (elem && (elem.nodeType === 3 || elem.nodeType === 8)) {
                    return
                }
                var cache, exclusive, i, cur, old, ontype, special, handle, eventPath, bubbleType, type = event.type || event, namespaces = [];
                if (rfocusMorph.test(type + jQuery.event.triggered)) {
                    return
                }
                if (type.indexOf("!") >= 0) {
                    type = type.slice(0, -1);
                    exclusive = true
                }
                if (type.indexOf(".") >= 0) {
                    namespaces = type.split(".");
                    type = namespaces.shift();
                    namespaces.sort()
                }
                if ((!elem || jQuery.event.customEvent[type]) && !jQuery.event.global[type]) {
                    return
                }
                event = typeof event === "object" ? event[jQuery.expando] ? event : new jQuery.Event(type, event) : new jQuery.Event(type);
                event.type = type;
                event.isTrigger = true;
                event.exclusive = exclusive;
                event.namespace = namespaces.join(".");
                event.namespace_re = event.namespace ? new RegExp("(^|\\.)" + namespaces.join("\\.(?:.*\\.|)") + "(\\.|$)") : null;
                ontype = type.indexOf(":") < 0 ? "on" + type : "";
                if (!elem) {
                    cache = jQuery.cache;
                    for (i in cache) {
                        if (cache[i].events && cache[i].events[type]) {
                            jQuery.event.trigger(event, data, cache[i].handle.elem, true)
                        }
                    }
                    return
                }
                event.result = undefined;
                if (!event.target) {
                    event.target = elem
                }
                data = data != null ? jQuery.makeArray(data) : [];
                data.unshift(event);
                special = jQuery.event.special[type] || {};
                if (special.trigger && special.trigger.apply(elem, data) === false) {
                    return
                }
                eventPath = [[elem, special.bindType || type]];
                if (!onlyHandlers && !special.noBubble && !jQuery.isWindow(elem)) {
                    bubbleType = special.delegateType || type;
                    cur = rfocusMorph.test(bubbleType + type) ? elem : elem.parentNode;
                    for (old = elem; cur; cur = cur.parentNode) {
                        eventPath.push([cur, bubbleType]);
                        old = cur
                    }
                    if (old === (elem.ownerDocument || document)) {
                        eventPath.push([old.defaultView || old.parentWindow || window, bubbleType])
                    }
                }
                for (i = 0; i < eventPath.length && !event.isPropagationStopped(); i++) {
                    cur = eventPath[i][0];
                    event.type = eventPath[i][1];
                    handle = (jQuery._data(cur, "events") || {})[event.type] && jQuery._data(cur, "handle");
                    if (handle) {
                        handle.apply(cur, data)
                    }
                    handle = ontype && cur[ontype];
                    if (handle && jQuery.acceptData(cur) && handle.apply && handle.apply(cur, data) === false) {
                        event.preventDefault()
                    }
                }
                event.type = type;
                if (!onlyHandlers && !event.isDefaultPrevented()) {
                    if ((!special._default || special._default.apply(elem.ownerDocument, data) === false) && !(type === "click" && jQuery.nodeName(elem, "a")) && jQuery.acceptData(elem)) {
                        if (ontype && elem[type] && ((type !== "focus" && type !== "blur") || event.target.offsetWidth !== 0) && !jQuery.isWindow(elem)) {
                            old = elem[ontype];
                            if (old) {
                                elem[ontype] = null
                            }
                            jQuery.event.triggered = type;
                            elem[type]();
                            jQuery.event.triggered = undefined;
                            if (old) {
                                elem[ontype] = old
                            }
                        }
                    }
                }
                return event.result
            },
            dispatch: function (event) {
                event = jQuery.event.fix(event || window.event);
                var i, j, cur, ret, selMatch, matched, matches, handleObj, sel, related, handlers = ((jQuery._data(this, "events") || {})[event.type] || []), delegateCount = handlers.delegateCount, args = core_slice.call(arguments), run_all = !event.exclusive && !event.namespace, special = jQuery.event.special[event.type] || {}, handlerQueue = [];
                args[0] = event;
                event.delegateTarget = this;
                if (special.preDispatch && special.preDispatch.call(this, event) === false) {
                    return
                }
                if (delegateCount && !(event.button && event.type === "click")) {
                    for (cur = event.target; cur != this; cur = cur.parentNode || this) {
                        if (cur.disabled !== true || event.type !== "click") {
                            selMatch = {};
                            matches = [];
                            for (i = 0; i < delegateCount; i++) {
                                handleObj = handlers[i];
                                sel = handleObj.selector;
                                if (selMatch[sel] === undefined) {
                                    selMatch[sel] = handleObj.needsContext ? jQuery(sel, this).index(cur) >= 0 : jQuery.find(sel, this, null, [cur]).length
                                }
                                if (selMatch[sel]) {
                                    matches.push(handleObj)
                                }
                            }
                            if (matches.length) {
                                handlerQueue.push({elem: cur, matches: matches})
                            }
                        }
                    }
                }
                if (handlers.length > delegateCount) {
                    handlerQueue.push({elem: this, matches: handlers.slice(delegateCount)})
                }
                for (i = 0; i < handlerQueue.length && !event.isPropagationStopped(); i++) {
                    matched = handlerQueue[i];
                    event.currentTarget = matched.elem;
                    for (j = 0; j < matched.matches.length && !event.isImmediatePropagationStopped(); j++) {
                        handleObj = matched.matches[j];
                        if (run_all || (!event.namespace && !handleObj.namespace) || event.namespace_re && event.namespace_re.test(handleObj.namespace)) {
                            event.data = handleObj.data;
                            event.handleObj = handleObj;
                            ret = ((jQuery.event.special[handleObj.origType] || {}).handle || handleObj.handler).apply(matched.elem, args);
                            if (ret !== undefined) {
                                event.result = ret;
                                if (ret === false) {
                                    event.preventDefault();
                                    event.stopPropagation()
                                }
                            }
                        }
                    }
                }
                if (special.postDispatch) {
                    special.postDispatch.call(this, event)
                }
                return event.result
            },
            props: "attrChange attrName relatedNode srcElement altKey bubbles cancelable ctrlKey currentTarget eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
            fixHooks: {},
            keyHooks: {
                props: "char charCode key keyCode".split(" "), filter: function (event, original) {
                    if (event.which == null) {
                        event.which = original.charCode != null ? original.charCode : original.keyCode
                    }
                    return event
                }
            },
            mouseHooks: {
                props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "), filter: function (event, original) {
                    var eventDoc, doc, body, button = original.button, fromElement = original.fromElement;
                    if (event.pageX == null && original.clientX != null) {
                        eventDoc = event.target.ownerDocument || document;
                        doc = eventDoc.documentElement;
                        body = eventDoc.body;
                        event.pageX = original.clientX + (doc && doc.scrollLeft || body && body.scrollLeft || 0) - (doc && doc.clientLeft || body && body.clientLeft || 0);
                        event.pageY = original.clientY + (doc && doc.scrollTop || body && body.scrollTop || 0) - (doc && doc.clientTop || body && body.clientTop || 0)
                    }
                    if (!event.relatedTarget && fromElement) {
                        event.relatedTarget = fromElement === event.target ? original.toElement : fromElement
                    }
                    if (!event.which && button !== undefined) {
                        event.which = (button & 1 ? 1 : (button & 2 ? 3 : (button & 4 ? 2 : 0)))
                    }
                    return event
                }
            },
            fix: function (event) {
                if (event[jQuery.expando]) {
                    return event
                }
                var i, prop, originalEvent = event, fixHook = jQuery.event.fixHooks[event.type] || {}, copy = fixHook.props ? this.props.concat(fixHook.props) : this.props;
                event = jQuery.Event(originalEvent);
                for (i = copy.length; i;) {
                    prop = copy[--i];
                    event[prop] = originalEvent[prop]
                }
                if (!event.target) {
                    event.target = originalEvent.srcElement || document
                }
                if (event.target.nodeType === 3) {
                    event.target = event.target.parentNode
                }
                event.metaKey = !!event.metaKey;
                return fixHook.filter ? fixHook.filter(event, originalEvent) : event
            },
            special: {
                load: {noBubble: true}, focus: {delegateType: "focusin"}, blur: {delegateType: "focusout"}, beforeunload: {
                    setup: function (data, namespaces, eventHandle) {
                        if (jQuery.isWindow(this)) {
                            this.onbeforeunload = eventHandle
                        }
                    }, teardown: function (namespaces, eventHandle) {
                        if (this.onbeforeunload === eventHandle) {
                            this.onbeforeunload = null
                        }
                    }
                }
            },
            simulate: function (type, elem, event, bubble) {
                var e = jQuery.extend(new jQuery.Event(), event, {type: type, isSimulated: true, originalEvent: {}});
                if (bubble) {
                    jQuery.event.trigger(e, null, elem)
                } else {
                    jQuery.event.dispatch.call(elem, e)
                }
                if (e.isDefaultPrevented()) {
                    event.preventDefault()
                }
            }
        };
        jQuery.event.handle = jQuery.event.dispatch;
        jQuery.removeEvent = document.removeEventListener ? function (elem, type, handle) {
            if (elem.removeEventListener) {
                elem.removeEventListener(type, handle, false)
            }
        } : function (elem, type, handle) {
            var name = "on" + type;
            if (elem.detachEvent) {
                if (typeof elem[name] === "undefined") {
                    elem[name] = null
                }
                elem.detachEvent(name, handle)
            }
        };
        jQuery.Event = function (src, props) {
            if (!(this instanceof jQuery.Event)) {
                return new jQuery.Event(src, props)
            }
            if (src && src.type) {
                this.originalEvent = src;
                this.type = src.type;
                this.isDefaultPrevented = (src.defaultPrevented || src.returnValue === false || src.getPreventDefault && src.getPreventDefault()) ? returnTrue : returnFalse
            } else {
                this.type = src
            }
            if (props) {
                jQuery.extend(this, props)
            }
            this.timeStamp = src && src.timeStamp || jQuery.now();
            this[jQuery.expando] = true
        };
        function returnFalse() {
            return false
        }

        function returnTrue() {
            return true
        }

        jQuery.Event.prototype = {
            preventDefault: function () {
                this.isDefaultPrevented = returnTrue;
                var e = this.originalEvent;
                if (!e) {
                    return
                }
                if (e.preventDefault) {
                    e.preventDefault()
                } else {
                    e.returnValue = false
                }
            }, stopPropagation: function () {
                this.isPropagationStopped = returnTrue;
                var e = this.originalEvent;
                if (!e) {
                    return
                }
                if (e.stopPropagation) {
                    e.stopPropagation()
                }
                e.cancelBubble = true
            }, stopImmediatePropagation: function () {
                this.isImmediatePropagationStopped = returnTrue;
                this.stopPropagation()
            }, isDefaultPrevented: returnFalse, isPropagationStopped: returnFalse, isImmediatePropagationStopped: returnFalse
        };
        jQuery.each({mouseenter: "mouseover", mouseleave: "mouseout"}, function (orig, fix) {
            jQuery.event.special[orig] = {
                delegateType: fix, bindType: fix, handle: function (event) {
                    var ret, target = this, related = event.relatedTarget, handleObj = event.handleObj, selector = handleObj.selector;
                    if (!related || (related !== target && !jQuery.contains(target, related))) {
                        event.type = handleObj.origType;
                        ret = handleObj.handler.apply(this, arguments);
                        event.type = fix
                    }
                    return ret
                }
            }
        });
        if (!jQuery.support.submitBubbles) {
            jQuery.event.special.submit = {
                setup: function () {
                    if (jQuery.nodeName(this, "form")) {
                        return false
                    }
                    jQuery.event.add(this, "click._submit keypress._submit", function (e) {
                        var elem = e.target, form = jQuery.nodeName(elem, "input") || jQuery.nodeName(elem, "button") ? elem.form : undefined;
                        if (form && !jQuery._data(form, "_submit_attached")) {
                            jQuery.event.add(form, "submit._submit", function (event) {
                                event._submit_bubble = true
                            });
                            jQuery._data(form, "_submit_attached", true)
                        }
                    })
                }, postDispatch: function (event) {
                    if (event._submit_bubble) {
                        delete event._submit_bubble;
                        if (this.parentNode && !event.isTrigger) {
                            jQuery.event.simulate("submit", this.parentNode, event, true)
                        }
                    }
                }, teardown: function () {
                    if (jQuery.nodeName(this, "form")) {
                        return false
                    }
                    jQuery.event.remove(this, "._submit")
                }
            }
        }
        if (!jQuery.support.changeBubbles) {
            jQuery.event.special.change = {
                setup: function () {
                    if (rformElems.test(this.nodeName)) {
                        if (this.type === "checkbox" || this.type === "radio") {
                            jQuery.event.add(this, "propertychange._change", function (event) {
                                if (event.originalEvent.propertyName === "checked") {
                                    this._just_changed = true
                                }
                            });
                            jQuery.event.add(this, "click._change", function (event) {
                                if (this._just_changed && !event.isTrigger) {
                                    this._just_changed = false
                                }
                                jQuery.event.simulate("change", this, event, true)
                            })
                        }
                        return false
                    }
                    jQuery.event.add(this, "beforeactivate._change", function (e) {
                        var elem = e.target;
                        if (rformElems.test(elem.nodeName) && !jQuery._data(elem, "_change_attached")) {
                            jQuery.event.add(elem, "change._change", function (event) {
                                if (this.parentNode && !event.isSimulated && !event.isTrigger) {
                                    jQuery.event.simulate("change", this.parentNode, event, true)
                                }
                            });
                            jQuery._data(elem, "_change_attached", true)
                        }
                    })
                }, handle: function (event) {
                    var elem = event.target;
                    if (this !== elem || event.isSimulated || event.isTrigger || (elem.type !== "radio" && elem.type !== "checkbox")) {
                        return event.handleObj.handler.apply(this, arguments)
                    }
                }, teardown: function () {
                    jQuery.event.remove(this, "._change");
                    return !rformElems.test(this.nodeName)
                }
            }
        }
        if (!jQuery.support.focusinBubbles) {
            jQuery.each({focus: "focusin", blur: "focusout"}, function (orig, fix) {
                var attaches = 0, handler = function (event) {
                    jQuery.event.simulate(fix, event.target, jQuery.event.fix(event), true)
                };
                jQuery.event.special[fix] = {
                    setup: function () {
                        if (attaches++ === 0) {
                            document.addEventListener(orig, handler, true)
                        }
                    }, teardown: function () {
                        if (--attaches === 0) {
                            document.removeEventListener(orig, handler, true)
                        }
                    }
                }
            })
        }
        jQuery.fn.extend({
            on: function (types, selector, data, fn, one) {
                var origFn, type;
                if (typeof types === "object") {
                    if (typeof selector !== "string") {
                        data = data || selector;
                        selector = undefined
                    }
                    for (type in types) {
                        this.on(type, selector, data, types[type], one)
                    }
                    return this
                }
                if (data == null && fn == null) {
                    fn = selector;
                    data = selector = undefined
                } else {
                    if (fn == null) {
                        if (typeof selector === "string") {
                            fn = data;
                            data = undefined
                        } else {
                            fn = data;
                            data = selector;
                            selector = undefined
                        }
                    }
                }
                if (fn === false) {
                    fn = returnFalse
                } else {
                    if (!fn) {
                        return this
                    }
                }
                if (one === 1) {
                    origFn = fn;
                    fn = function (event) {
                        jQuery().off(event);
                        return origFn.apply(this, arguments)
                    };
                    fn.guid = origFn.guid || (origFn.guid = jQuery.guid++)
                }
                return this.each(function () {
                    jQuery.event.add(this, types, fn, data, selector)
                })
            }, one: function (types, selector, data, fn) {
                return this.on(types, selector, data, fn, 1)
            }, off: function (types, selector, fn) {
                var handleObj, type;
                if (types && types.preventDefault && types.handleObj) {
                    handleObj = types.handleObj;
                    jQuery(types.delegateTarget).off(handleObj.namespace ? handleObj.origType + "." + handleObj.namespace : handleObj.origType, handleObj.selector, handleObj.handler);
                    return this
                }
                if (typeof types === "object") {
                    for (type in types) {
                        this.off(type, selector, types[type])
                    }
                    return this
                }
                if (selector === false || typeof selector === "function") {
                    fn = selector;
                    selector = undefined
                }
                if (fn === false) {
                    fn = returnFalse
                }
                return this.each(function () {
                    jQuery.event.remove(this, types, fn, selector)
                })
            }, bind: function (types, data, fn) {
                return this.on(types, null, data, fn)
            }, unbind: function (types, fn) {
                return this.off(types, null, fn)
            }, live: function (types, data, fn) {
                jQuery(this.context).on(types, this.selector, data, fn);
                return this
            }, die: function (types, fn) {
                jQuery(this.context).off(types, this.selector || "**", fn);
                return this
            }, delegate: function (selector, types, data, fn) {
                return this.on(types, selector, data, fn)
            }, undelegate: function (selector, types, fn) {
                return arguments.length === 1 ? this.off(selector, "**") : this.off(types, selector || "**", fn)
            }, trigger: function (type, data) {
                return this.each(function () {
                    jQuery.event.trigger(type, data, this)
                })
            }, triggerHandler: function (type, data) {
                if (this[0]) {
                    return jQuery.event.trigger(type, data, this[0], true)
                }
            }, toggle: function (fn) {
                var args = arguments, guid = fn.guid || jQuery.guid++, i = 0, toggler = function (event) {
                    var lastToggle = (jQuery._data(this, "lastToggle" + fn.guid) || 0) % i;
                    jQuery._data(this, "lastToggle" + fn.guid, lastToggle + 1);
                    event.preventDefault();
                    return args[lastToggle].apply(this, arguments) || false
                };
                toggler.guid = guid;
                while (i < args.length) {
                    args[i++].guid = guid
                }
                return this.click(toggler)
            }, hover: function (fnOver, fnOut) {
                return this.mouseenter(fnOver).mouseleave(fnOut || fnOver)
            }
        });
        jQuery.each(("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu").split(" "), function (i, name) {
            jQuery.fn[name] = function (data, fn) {
                if (fn == null) {
                    fn = data;
                    data = null
                }
                return arguments.length > 0 ? this.on(name, null, data, fn) : this.trigger(name)
            };
            if (rkeyEvent.test(name)) {
                jQuery.event.fixHooks[name] = jQuery.event.keyHooks
            }
            if (rmouseEvent.test(name)) {
                jQuery.event.fixHooks[name] = jQuery.event.mouseHooks
            }
        });
        /*!
         * Sizzle CSS Selector Engine
         * Copyright 2012 jQuery Foundation and other contributors
         * Released under the MIT license
         * http://sizzlejs.com/
         */
        (function (window, undefined) {
            var cachedruns, assertGetIdNotName, Expr, getText, isXML, contains, compile, sortOrder, hasDuplicate, outermostContext, baseHasDuplicate = true, strundefined = "undefined", expando = ("sizcache" + Math.random()).replace(".", ""), Token = String, document = window.document, docElem = document.documentElement, dirruns = 0, done = 0, pop = [].pop, push = [].push, slice = [].slice, indexOf = [].indexOf || function (elem) {
                    var i = 0, len = this.length;
                    for (; i < len; i++) {
                        if (this[i] === elem) {
                            return i
                        }
                    }
                    return -1
                }, markFunction = function (fn, value) {
                fn[expando] = value == null || value;
                return fn
            }, createCache = function () {
                var cache = {}, keys = [];
                return markFunction(function (key, value) {
                    if (keys.push(key) > Expr.cacheLength) {
                        delete cache[keys.shift()]
                    }
                    return (cache[key + " "] = value)
                }, cache)
            }, classCache = createCache(), tokenCache = createCache(), compilerCache = createCache(), whitespace = "[\\x20\\t\\r\\n\\f]", characterEncoding = "(?:\\\\.|[-\\w]|[^\\x00-\\xa0])+", identifier = characterEncoding.replace("w", "w#"), operators = "([*^$|!~]?=)", attributes = "\\[" + whitespace + "*(" + characterEncoding + ")" + whitespace + "*(?:" + operators + whitespace + "*(?:(['\"])((?:\\\\.|[^\\\\])*?)\\3|(" + identifier + ")|)|)" + whitespace + "*\\]", pseudos = ":(" + characterEncoding + ")(?:\\((?:(['\"])((?:\\\\.|[^\\\\])*?)\\2|([^()[\\]]*|(?:(?:" + attributes + ")|[^:]|\\\\.)*|.*))\\)|)", pos = ":(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + whitespace + "*((?:-\\d)?\\d*)" + whitespace + "*\\)|)(?=[^-]|$)", rtrim = new RegExp("^" + whitespace + "+|((?:^|[^\\\\])(?:\\\\.)*)" + whitespace + "+$", "g"), rcomma = new RegExp("^" + whitespace + "*," + whitespace + "*"), rcombinators = new RegExp("^" + whitespace + "*([\\x20\\t\\r\\n\\f>+~])" + whitespace + "*"), rpseudo = new RegExp(pseudos), rquickExpr = /^(?:#([\w\-]+)|(\w+)|\.([\w\-]+))$/, rnot = /^:not/, rsibling = /[\x20\t\r\n\f]*[+~]/, rendsWithNot = /:not\($/, rheader = /h\d/i, rinputs = /input|select|textarea|button/i, rbackslash = /\\(?!\\)/g, matchExpr = {
                ID: new RegExp("^#(" + characterEncoding + ")"),
                CLASS: new RegExp("^\\.(" + characterEncoding + ")"),
                NAME: new RegExp("^\\[name=['\"]?(" + characterEncoding + ")['\"]?\\]"),
                TAG: new RegExp("^(" + characterEncoding.replace("w", "w*") + ")"),
                ATTR: new RegExp("^" + attributes),
                PSEUDO: new RegExp("^" + pseudos),
                POS: new RegExp(pos, "i"),
                CHILD: new RegExp("^:(only|nth|first|last)-child(?:\\(" + whitespace + "*(even|odd|(([+-]|)(\\d*)n|)" + whitespace + "*(?:([+-]|)" + whitespace + "*(\\d+)|))" + whitespace + "*\\)|)", "i"),
                needsContext: new RegExp("^" + whitespace + "*[>+~]|" + pos, "i")
            }, assert = function (fn) {
                var div = document.createElement("div");
                try {
                    return fn(div)
                } catch (e) {
                    return false
                } finally {
                    div = null
                }
            }, assertTagNameNoComments = assert(function (div) {
                div.appendChild(document.createComment(""));
                return !div.getElementsByTagName("*").length
            }), assertHrefNotNormalized = assert(function (div) {
                div.innerHTML = "<a href='#'></a>";
                return div.firstChild && typeof div.firstChild.getAttribute !== strundefined && div.firstChild.getAttribute("href") === "#"
            }), assertAttributes = assert(function (div) {
                div.innerHTML = "<select></select>";
                var type = typeof div.lastChild.getAttribute("multiple");
                return type !== "boolean" && type !== "string"
            }), assertUsableClassName = assert(function (div) {
                div.innerHTML = "<div class='hidden e'></div><div class='hidden'></div>";
                if (!div.getElementsByClassName || !div.getElementsByClassName("e").length) {
                    return false
                }
                div.lastChild.className = "e";
                return div.getElementsByClassName("e").length === 2
            }), assertUsableName = assert(function (div) {
                div.id = expando + 0;
                div.innerHTML = "<a name='" + expando + "'></a><div name='" + expando + "'></div>";
                docElem.insertBefore(div, docElem.firstChild);
                var pass = document.getElementsByName && document.getElementsByName(expando).length === 2 + document.getElementsByName(expando + 0).length;
                assertGetIdNotName = !document.getElementById(expando);
                docElem.removeChild(div);
                return pass
            });
            try {
                slice.call(docElem.childNodes, 0)[0].nodeType
            } catch (e) {
                slice = function (i) {
                    var elem, results = [];
                    for (; (elem = this[i]); i++) {
                        results.push(elem)
                    }
                    return results
                }
            }
            function Sizzle(selector, context, results, seed) {
                results = results || [];
                context = context || document;
                var match, elem, xml, m, nodeType = context.nodeType;
                if (!selector || typeof selector !== "string") {
                    return results
                }
                if (nodeType !== 1 && nodeType !== 9) {
                    return []
                }
                xml = isXML(context);
                if (!xml && !seed) {
                    if ((match = rquickExpr.exec(selector))) {
                        if ((m = match[1])) {
                            if (nodeType === 9) {
                                elem = context.getElementById(m);
                                if (elem && elem.parentNode) {
                                    if (elem.id === m) {
                                        results.push(elem);
                                        return results
                                    }
                                } else {
                                    return results
                                }
                            } else {
                                if (context.ownerDocument && (elem = context.ownerDocument.getElementById(m)) && contains(context, elem) && elem.id === m) {
                                    results.push(elem);
                                    return results
                                }
                            }
                        } else {
                            if (match[2]) {
                                push.apply(results, slice.call(context.getElementsByTagName(selector), 0));
                                return results
                            } else {
                                if ((m = match[3]) && assertUsableClassName && context.getElementsByClassName) {
                                    push.apply(results, slice.call(context.getElementsByClassName(m), 0));
                                    return results
                                }
                            }
                        }
                    }
                }
                return select(selector.replace(rtrim, "$1"), context, results, seed, xml)
            }

            Sizzle.matches = function (expr, elements) {
                return Sizzle(expr, null, null, elements)
            };
            Sizzle.matchesSelector = function (elem, expr) {
                return Sizzle(expr, null, null, [elem]).length > 0
            };
            function createInputPseudo(type) {
                return function (elem) {
                    var name = elem.nodeName.toLowerCase();
                    return name === "input" && elem.type === type
                }
            }

            function createButtonPseudo(type) {
                return function (elem) {
                    var name = elem.nodeName.toLowerCase();
                    return (name === "input" || name === "button") && elem.type === type
                }
            }

            function createPositionalPseudo(fn) {
                return markFunction(function (argument) {
                    argument = +argument;
                    return markFunction(function (seed, matches) {
                        var j, matchIndexes = fn([], seed.length, argument), i = matchIndexes.length;
                        while (i--) {
                            if (seed[(j = matchIndexes[i])]) {
                                seed[j] = !(matches[j] = seed[j])
                            }
                        }
                    })
                })
            }

            getText = Sizzle.getText = function (elem) {
                var node, ret = "", i = 0, nodeType = elem.nodeType;
                if (nodeType) {
                    if (nodeType === 1 || nodeType === 9 || nodeType === 11) {
                        if (typeof elem.textContent === "string") {
                            return elem.textContent
                        } else {
                            for (elem = elem.firstChild; elem; elem = elem.nextSibling) {
                                ret += getText(elem)
                            }
                        }
                    } else {
                        if (nodeType === 3 || nodeType === 4) {
                            return elem.nodeValue
                        }
                    }
                } else {
                    for (; (node = elem[i]); i++) {
                        ret += getText(node)
                    }
                }
                return ret
            };
            isXML = Sizzle.isXML = function (elem) {
                var documentElement = elem && (elem.ownerDocument || elem).documentElement;
                return documentElement ? documentElement.nodeName !== "HTML" : false
            };
            contains = Sizzle.contains = docElem.contains ? function (a, b) {
                var adown = a.nodeType === 9 ? a.documentElement : a, bup = b && b.parentNode;
                return a === bup || !!(bup && bup.nodeType === 1 && adown.contains && adown.contains(bup))
            } : docElem.compareDocumentPosition ? function (a, b) {
                return b && !!(a.compareDocumentPosition(b) & 16)
            } : function (a, b) {
                while ((b = b.parentNode)) {
                    if (b === a) {
                        return true
                    }
                }
                return false
            };
            Sizzle.attr = function (elem, name) {
                var val, xml = isXML(elem);
                if (!xml) {
                    name = name.toLowerCase()
                }
                if ((val = Expr.attrHandle[name])) {
                    return val(elem)
                }
                if (xml || assertAttributes) {
                    return elem.getAttribute(name)
                }
                val = elem.getAttributeNode(name);
                return val ? typeof elem[name] === "boolean" ? elem[name] ? name : null : val.specified ? val.value : null : null
            };
            Expr = Sizzle.selectors = {
                cacheLength: 50,
                createPseudo: markFunction,
                match: matchExpr,
                attrHandle: assertHrefNotNormalized ? {} : {
                    href: function (elem) {
                        return elem.getAttribute("href", 2)
                    }, type: function (elem) {
                        return elem.getAttribute("type")
                    }
                },
                find: {
                    ID: assertGetIdNotName ? function (id, context, xml) {
                        if (typeof context.getElementById !== strundefined && !xml) {
                            var m = context.getElementById(id);
                            return m && m.parentNode ? [m] : []
                        }
                    } : function (id, context, xml) {
                        if (typeof context.getElementById !== strundefined && !xml) {
                            var m = context.getElementById(id);
                            return m ? m.id === id || typeof m.getAttributeNode !== strundefined && m.getAttributeNode("id").value === id ? [m] : undefined : []
                        }
                    }, TAG: assertTagNameNoComments ? function (tag, context) {
                        if (typeof context.getElementsByTagName !== strundefined) {
                            return context.getElementsByTagName(tag)
                        }
                    } : function (tag, context) {
                        var results = context.getElementsByTagName(tag);
                        if (tag === "*") {
                            var elem, tmp = [], i = 0;
                            for (; (elem = results[i]); i++) {
                                if (elem.nodeType === 1) {
                                    tmp.push(elem)
                                }
                            }
                            return tmp
                        }
                        return results
                    }, NAME: assertUsableName && function (tag, context) {
                        if (typeof context.getElementsByName !== strundefined) {
                            return context.getElementsByName(name)
                        }
                    }, CLASS: assertUsableClassName && function (className, context, xml) {
                        if (typeof context.getElementsByClassName !== strundefined && !xml) {
                            return context.getElementsByClassName(className)
                        }
                    }
                },
                relative: {">": {dir: "parentNode", first: true}, " ": {dir: "parentNode"}, "+": {dir: "previousSibling", first: true}, "~": {dir: "previousSibling"}},
                preFilter: {
                    ATTR: function (match) {
                        match[1] = match[1].replace(rbackslash, "");
                        match[3] = (match[4] || match[5] || "").replace(rbackslash, "");
                        if (match[2] === "~=") {
                            match[3] = " " + match[3] + " "
                        }
                        return match.slice(0, 4)
                    }, CHILD: function (match) {
                        match[1] = match[1].toLowerCase();
                        if (match[1] === "nth") {
                            if (!match[2]) {
                                Sizzle.error(match[0])
                            }
                            match[3] = +(match[3] ? match[4] + (match[5] || 1) : 2 * (match[2] === "even" || match[2] === "odd"));
                            match[4] = +((match[6] + match[7]) || match[2] === "odd")
                        } else {
                            if (match[2]) {
                                Sizzle.error(match[0])
                            }
                        }
                        return match
                    }, PSEUDO: function (match) {
                        var unquoted, excess;
                        if (matchExpr.CHILD.test(match[0])) {
                            return null
                        }
                        if (match[3]) {
                            match[2] = match[3]
                        } else {
                            if ((unquoted = match[4])) {
                                if (rpseudo.test(unquoted) && (excess = tokenize(unquoted, true)) && (excess = unquoted.indexOf(")", unquoted.length - excess) - unquoted.length)) {
                                    unquoted = unquoted.slice(0, excess);
                                    match[0] = match[0].slice(0, excess)
                                }
                                match[2] = unquoted
                            }
                        }
                        return match.slice(0, 3)
                    }
                },
                filter: {
                    ID: assertGetIdNotName ? function (id) {
                        id = id.replace(rbackslash, "");
                        return function (elem) {
                            return elem.getAttribute("id") === id
                        }
                    } : function (id) {
                        id = id.replace(rbackslash, "");
                        return function (elem) {
                            var node = typeof elem.getAttributeNode !== strundefined && elem.getAttributeNode("id");
                            return node && node.value === id
                        }
                    }, TAG: function (nodeName) {
                        if (nodeName === "*") {
                            return function () {
                                return true
                            }
                        }
                        nodeName = nodeName.replace(rbackslash, "").toLowerCase();
                        return function (elem) {
                            return elem.nodeName && elem.nodeName.toLowerCase() === nodeName
                        }
                    }, CLASS: function (className) {
                        var pattern = classCache[expando][className + " "];
                        return pattern || (pattern = new RegExp("(^|" + whitespace + ")" + className + "(" + whitespace + "|$)")) && classCache(className, function (elem) {
                                return pattern.test(elem.className || (typeof elem.getAttribute !== strundefined && elem.getAttribute("class")) || "")
                            })
                    }, ATTR: function (name, operator, check) {
                        return function (elem, context) {
                            var result = Sizzle.attr(elem, name);
                            if (result == null) {
                                return operator === "!="
                            }
                            if (!operator) {
                                return true
                            }
                            result += "";
                            return operator === "=" ? result === check : operator === "!=" ? result !== check : operator === "^=" ? check && result.indexOf(check) === 0 : operator === "*=" ? check && result.indexOf(check) > -1 : operator === "$=" ? check && result.substr(result.length - check.length) === check : operator === "~=" ? (" " + result + " ").indexOf(check) > -1 : operator === "|=" ? result === check || result.substr(0, check.length + 1) === check + "-" : false
                        }
                    }, CHILD: function (type, argument, first, last) {
                        if (type === "nth") {
                            return function (elem) {
                                var node, diff, parent = elem.parentNode;
                                if (first === 1 && last === 0) {
                                    return true
                                }
                                if (parent) {
                                    diff = 0;
                                    for (node = parent.firstChild; node; node = node.nextSibling) {
                                        if (node.nodeType === 1) {
                                            diff++;
                                            if (elem === node) {
                                                break
                                            }
                                        }
                                    }
                                }
                                diff -= last;
                                return diff === first || (diff % first === 0 && diff / first >= 0)
                            }
                        }
                        return function (elem) {
                            var node = elem;
                            switch (type) {
                                case"only":
                                case"first":
                                    while ((node = node.previousSibling)) {
                                        if (node.nodeType === 1) {
                                            return false
                                        }
                                    }
                                    if (type === "first") {
                                        return true
                                    }
                                    node = elem;
                                case"last":
                                    while ((node = node.nextSibling)) {
                                        if (node.nodeType === 1) {
                                            return false
                                        }
                                    }
                                    return true
                            }
                        }
                    }, PSEUDO: function (pseudo, argument) {
                        var args, fn = Expr.pseudos[pseudo] || Expr.setFilters[pseudo.toLowerCase()] || Sizzle.error("unsupported pseudo: " + pseudo);
                        if (fn[expando]) {
                            return fn(argument)
                        }
                        if (fn.length > 1) {
                            args = [pseudo, pseudo, "", argument];
                            return Expr.setFilters.hasOwnProperty(pseudo.toLowerCase()) ? markFunction(function (seed, matches) {
                                var idx, matched = fn(seed, argument), i = matched.length;
                                while (i--) {
                                    idx = indexOf.call(seed, matched[i]);
                                    seed[idx] = !(matches[idx] = matched[i])
                                }
                            }) : function (elem) {
                                return fn(elem, 0, args)
                            }
                        }
                        return fn
                    }
                },
                pseudos: {
                    not: markFunction(function (selector) {
                        var input = [], results = [], matcher = compile(selector.replace(rtrim, "$1"));
                        return matcher[expando] ? markFunction(function (seed, matches, context, xml) {
                            var elem, unmatched = matcher(seed, null, xml, []), i = seed.length;
                            while (i--) {
                                if ((elem = unmatched[i])) {
                                    seed[i] = !(matches[i] = elem)
                                }
                            }
                        }) : function (elem, context, xml) {
                            input[0] = elem;
                            matcher(input, null, xml, results);
                            return !results.pop()
                        }
                    }),
                    has: markFunction(function (selector) {
                        return function (elem) {
                            return Sizzle(selector, elem).length > 0
                        }
                    }),
                    contains: markFunction(function (text) {
                        return function (elem) {
                            return (elem.textContent || elem.innerText || getText(elem)).indexOf(text) > -1
                        }
                    }),
                    enabled: function (elem) {
                        return elem.disabled === false
                    },
                    disabled: function (elem) {
                        return elem.disabled === true
                    },
                    checked: function (elem) {
                        var nodeName = elem.nodeName.toLowerCase();
                        return (nodeName === "input" && !!elem.checked) || (nodeName === "option" && !!elem.selected)
                    },
                    selected: function (elem) {
                        if (elem.parentNode) {
                            elem.parentNode.selectedIndex
                        }
                        return elem.selected === true
                    },
                    parent: function (elem) {
                        return !Expr.pseudos.empty(elem)
                    },
                    empty: function (elem) {
                        var nodeType;
                        elem = elem.firstChild;
                        while (elem) {
                            if (elem.nodeName > "@" || (nodeType = elem.nodeType) === 3 || nodeType === 4) {
                                return false
                            }
                            elem = elem.nextSibling
                        }
                        return true
                    },
                    header: function (elem) {
                        return rheader.test(elem.nodeName)
                    },
                    text: function (elem) {
                        var type, attr;
                        return elem.nodeName.toLowerCase() === "input" && (type = elem.type) === "text" && ((attr = elem.getAttribute("type")) == null || attr.toLowerCase() === type)
                    },
                    radio: createInputPseudo("radio"),
                    checkbox: createInputPseudo("checkbox"),
                    file: createInputPseudo("file"),
                    password: createInputPseudo("password"),
                    image: createInputPseudo("image"),
                    submit: createButtonPseudo("submit"),
                    reset: createButtonPseudo("reset"),
                    button: function (elem) {
                        var name = elem.nodeName.toLowerCase();
                        return name === "input" && elem.type === "button" || name === "button"
                    },
                    input: function (elem) {
                        return rinputs.test(elem.nodeName)
                    },
                    focus: function (elem) {
                        var doc = elem.ownerDocument;
                        return elem === doc.activeElement && (!doc.hasFocus || doc.hasFocus()) && !!(elem.type || elem.href || ~elem.tabIndex)
                    },
                    active: function (elem) {
                        return elem === elem.ownerDocument.activeElement
                    },
                    first: createPositionalPseudo(function () {
                        return [0]
                    }),
                    last: createPositionalPseudo(function (matchIndexes, length) {
                        return [length - 1]
                    }),
                    eq: createPositionalPseudo(function (matchIndexes, length, argument) {
                        return [argument < 0 ? argument + length : argument]
                    }),
                    even: createPositionalPseudo(function (matchIndexes, length) {
                        for (var i = 0; i < length; i += 2) {
                            matchIndexes.push(i)
                        }
                        return matchIndexes
                    }),
                    odd: createPositionalPseudo(function (matchIndexes, length) {
                        for (var i = 1; i < length; i += 2) {
                            matchIndexes.push(i)
                        }
                        return matchIndexes
                    }),
                    lt: createPositionalPseudo(function (matchIndexes, length, argument) {
                        for (var i = argument < 0 ? argument + length : argument; --i >= 0;) {
                            matchIndexes.push(i)
                        }
                        return matchIndexes
                    }),
                    gt: createPositionalPseudo(function (matchIndexes, length, argument) {
                        for (var i = argument < 0 ? argument + length : argument; ++i < length;) {
                            matchIndexes.push(i)
                        }
                        return matchIndexes
                    })
                }
            };
            function siblingCheck(a, b, ret) {
                if (a === b) {
                    return ret
                }
                var cur = a.nextSibling;
                while (cur) {
                    if (cur === b) {
                        return -1
                    }
                    cur = cur.nextSibling
                }
                return 1
            }

            sortOrder = docElem.compareDocumentPosition ? function (a, b) {
                if (a === b) {
                    hasDuplicate = true;
                    return 0
                }
                return (!a.compareDocumentPosition || !b.compareDocumentPosition ? a.compareDocumentPosition : a.compareDocumentPosition(b) & 4) ? -1 : 1
            } : function (a, b) {
                if (a === b) {
                    hasDuplicate = true;
                    return 0
                } else {
                    if (a.sourceIndex && b.sourceIndex) {
                        return a.sourceIndex - b.sourceIndex
                    }
                }
                var al, bl, ap = [], bp = [], aup = a.parentNode, bup = b.parentNode, cur = aup;
                if (aup === bup) {
                    return siblingCheck(a, b)
                } else {
                    if (!aup) {
                        return -1
                    } else {
                        if (!bup) {
                            return 1
                        }
                    }
                }
                while (cur) {
                    ap.unshift(cur);
                    cur = cur.parentNode
                }
                cur = bup;
                while (cur) {
                    bp.unshift(cur);
                    cur = cur.parentNode
                }
                al = ap.length;
                bl = bp.length;
                for (var i = 0; i < al && i < bl; i++) {
                    if (ap[i] !== bp[i]) {
                        return siblingCheck(ap[i], bp[i])
                    }
                }
                return i === al ? siblingCheck(a, bp[i], -1) : siblingCheck(ap[i], b, 1)
            };
            [0, 0].sort(sortOrder);
            baseHasDuplicate = !hasDuplicate;
            Sizzle.uniqueSort = function (results) {
                var elem, duplicates = [], i = 1, j = 0;
                hasDuplicate = baseHasDuplicate;
                results.sort(sortOrder);
                if (hasDuplicate) {
                    for (; (elem = results[i]); i++) {
                        if (elem === results[i - 1]) {
                            j = duplicates.push(i)
                        }
                    }
                    while (j--) {
                        results.splice(duplicates[j], 1)
                    }
                }
                return results
            };
            Sizzle.error = function (msg) {
                throw new Error("Syntax error, unrecognized expression: " + msg)
            };
            function tokenize(selector, parseOnly) {
                var matched, match, tokens, type, soFar, groups, preFilters, cached = tokenCache[expando][selector + " "];
                if (cached) {
                    return parseOnly ? 0 : cached.slice(0)
                }
                soFar = selector;
                groups = [];
                preFilters = Expr.preFilter;
                while (soFar) {
                    if (!matched || (match = rcomma.exec(soFar))) {
                        if (match) {
                            soFar = soFar.slice(match[0].length) || soFar
                        }
                        groups.push(tokens = [])
                    }
                    matched = false;
                    if ((match = rcombinators.exec(soFar))) {
                        tokens.push(matched = new Token(match.shift()));
                        soFar = soFar.slice(matched.length);
                        matched.type = match[0].replace(rtrim, " ")
                    }
                    for (type in Expr.filter) {
                        if ((match = matchExpr[type].exec(soFar)) && (!preFilters[type] || (match = preFilters[type](match)))) {
                            tokens.push(matched = new Token(match.shift()));
                            soFar = soFar.slice(matched.length);
                            matched.type = type;
                            matched.matches = match
                        }
                    }
                    if (!matched) {
                        break
                    }
                }
                return parseOnly ? soFar.length : soFar ? Sizzle.error(selector) : tokenCache(selector, groups).slice(0)
            }

            function addCombinator(matcher, combinator, base) {
                var dir = combinator.dir, checkNonElements = base && combinator.dir === "parentNode", doneName = done++;
                return combinator.first ? function (elem, context, xml) {
                    while ((elem = elem[dir])) {
                        if (checkNonElements || elem.nodeType === 1) {
                            return matcher(elem, context, xml)
                        }
                    }
                } : function (elem, context, xml) {
                    if (!xml) {
                        var cache, dirkey = dirruns + " " + doneName + " ", cachedkey = dirkey + cachedruns;
                        while ((elem = elem[dir])) {
                            if (checkNonElements || elem.nodeType === 1) {
                                if ((cache = elem[expando]) === cachedkey) {
                                    return elem.sizset
                                } else {
                                    if (typeof cache === "string" && cache.indexOf(dirkey) === 0) {
                                        if (elem.sizset) {
                                            return elem
                                        }
                                    } else {
                                        elem[expando] = cachedkey;
                                        if (matcher(elem, context, xml)) {
                                            elem.sizset = true;
                                            return elem
                                        }
                                        elem.sizset = false
                                    }
                                }
                            }
                        }
                    } else {
                        while ((elem = elem[dir])) {
                            if (checkNonElements || elem.nodeType === 1) {
                                if (matcher(elem, context, xml)) {
                                    return elem
                                }
                            }
                        }
                    }
                }
            }

            function elementMatcher(matchers) {
                return matchers.length > 1 ? function (elem, context, xml) {
                    var i = matchers.length;
                    while (i--) {
                        if (!matchers[i](elem, context, xml)) {
                            return false
                        }
                    }
                    return true
                } : matchers[0]
            }

            function condense(unmatched, map, filter, context, xml) {
                var elem, newUnmatched = [], i = 0, len = unmatched.length, mapped = map != null;
                for (; i < len; i++) {
                    if ((elem = unmatched[i])) {
                        if (!filter || filter(elem, context, xml)) {
                            newUnmatched.push(elem);
                            if (mapped) {
                                map.push(i)
                            }
                        }
                    }
                }
                return newUnmatched
            }

            function setMatcher(preFilter, selector, matcher, postFilter, postFinder, postSelector) {
                if (postFilter && !postFilter[expando]) {
                    postFilter = setMatcher(postFilter)
                }
                if (postFinder && !postFinder[expando]) {
                    postFinder = setMatcher(postFinder, postSelector)
                }
                return markFunction(function (seed, results, context, xml) {
                    var temp, i, elem, preMap = [], postMap = [], preexisting = results.length, elems = seed || multipleContexts(selector || "*", context.nodeType ? [context] : context, []), matcherIn = preFilter && (seed || !selector) ? condense(elems, preMap, preFilter, context, xml) : elems, matcherOut = matcher ? postFinder || (seed ? preFilter : preexisting || postFilter) ? [] : results : matcherIn;
                    if (matcher) {
                        matcher(matcherIn, matcherOut, context, xml)
                    }
                    if (postFilter) {
                        temp = condense(matcherOut, postMap);
                        postFilter(temp, [], context, xml);
                        i = temp.length;
                        while (i--) {
                            if ((elem = temp[i])) {
                                matcherOut[postMap[i]] = !(matcherIn[postMap[i]] = elem)
                            }
                        }
                    }
                    if (seed) {
                        if (postFinder || preFilter) {
                            if (postFinder) {
                                temp = [];
                                i = matcherOut.length;
                                while (i--) {
                                    if ((elem = matcherOut[i])) {
                                        temp.push((matcherIn[i] = elem))
                                    }
                                }
                                postFinder(null, (matcherOut = []), temp, xml)
                            }
                            i = matcherOut.length;
                            while (i--) {
                                if ((elem = matcherOut[i]) && (temp = postFinder ? indexOf.call(seed, elem) : preMap[i]) > -1) {
                                    seed[temp] = !(results[temp] = elem)
                                }
                            }
                        }
                    } else {
                        matcherOut = condense(matcherOut === results ? matcherOut.splice(preexisting, matcherOut.length) : matcherOut);
                        if (postFinder) {
                            postFinder(null, results, matcherOut, xml)
                        } else {
                            push.apply(results, matcherOut)
                        }
                    }
                })
            }

            function matcherFromTokens(tokens) {
                var checkContext, matcher, j, len = tokens.length, leadingRelative = Expr.relative[tokens[0].type], implicitRelative = leadingRelative || Expr.relative[" "], i = leadingRelative ? 1 : 0, matchContext = addCombinator(function (elem) {
                    return elem === checkContext
                }, implicitRelative, true), matchAnyContext = addCombinator(function (elem) {
                    return indexOf.call(checkContext, elem) > -1
                }, implicitRelative, true), matchers = [function (elem, context, xml) {
                    return (!leadingRelative && (xml || context !== outermostContext)) || ((checkContext = context).nodeType ? matchContext(elem, context, xml) : matchAnyContext(elem, context, xml))
                }];
                for (; i < len; i++) {
                    if ((matcher = Expr.relative[tokens[i].type])) {
                        matchers = [addCombinator(elementMatcher(matchers), matcher)]
                    } else {
                        matcher = Expr.filter[tokens[i].type].apply(null, tokens[i].matches);
                        if (matcher[expando]) {
                            j = ++i;
                            for (; j < len; j++) {
                                if (Expr.relative[tokens[j].type]) {
                                    break
                                }
                            }
                            return setMatcher(i > 1 && elementMatcher(matchers), i > 1 && tokens.slice(0, i - 1).join("").replace(rtrim, "$1"), matcher, i < j && matcherFromTokens(tokens.slice(i, j)), j < len && matcherFromTokens((tokens = tokens.slice(j))), j < len && tokens.join(""))
                        }
                        matchers.push(matcher)
                    }
                }
                return elementMatcher(matchers)
            }

            function matcherFromGroupMatchers(elementMatchers, setMatchers) {
                var bySet = setMatchers.length > 0, byElement = elementMatchers.length > 0, superMatcher = function (seed, context, xml, results, expandContext) {
                    var elem, j, matcher, setMatched = [], matchedCount = 0, i = "0", unmatched = seed && [], outermost = expandContext != null, contextBackup = outermostContext, elems = seed || byElement && Expr.find.TAG("*", expandContext && context.parentNode || context), dirrunsUnique = (dirruns += contextBackup == null ? 1 : Math.E);
                    if (outermost) {
                        outermostContext = context !== document && context;
                        cachedruns = superMatcher.el
                    }
                    for (; (elem = elems[i]) != null; i++) {
                        if (byElement && elem) {
                            for (j = 0; (matcher = elementMatchers[j]); j++) {
                                if (matcher(elem, context, xml)) {
                                    results.push(elem);
                                    break
                                }
                            }
                            if (outermost) {
                                dirruns = dirrunsUnique;
                                cachedruns = ++superMatcher.el
                            }
                        }
                        if (bySet) {
                            if ((elem = !matcher && elem)) {
                                matchedCount--
                            }
                            if (seed) {
                                unmatched.push(elem)
                            }
                        }
                    }
                    matchedCount += i;
                    if (bySet && i !== matchedCount) {
                        for (j = 0; (matcher = setMatchers[j]); j++) {
                            matcher(unmatched, setMatched, context, xml)
                        }
                        if (seed) {
                            if (matchedCount > 0) {
                                while (i--) {
                                    if (!(unmatched[i] || setMatched[i])) {
                                        setMatched[i] = pop.call(results)
                                    }
                                }
                            }
                            setMatched = condense(setMatched)
                        }
                        push.apply(results, setMatched);
                        if (outermost && !seed && setMatched.length > 0 && (matchedCount + setMatchers.length) > 1) {
                            Sizzle.uniqueSort(results)
                        }
                    }
                    if (outermost) {
                        dirruns = dirrunsUnique;
                        outermostContext = contextBackup
                    }
                    return unmatched
                };
                superMatcher.el = 0;
                return bySet ? markFunction(superMatcher) : superMatcher
            }

            compile = Sizzle.compile = function (selector, group) {
                var i, setMatchers = [], elementMatchers = [], cached = compilerCache[expando][selector + " "];
                if (!cached) {
                    if (!group) {
                        group = tokenize(selector)
                    }
                    i = group.length;
                    while (i--) {
                        cached = matcherFromTokens(group[i]);
                        if (cached[expando]) {
                            setMatchers.push(cached)
                        } else {
                            elementMatchers.push(cached)
                        }
                    }
                    cached = compilerCache(selector, matcherFromGroupMatchers(elementMatchers, setMatchers))
                }
                return cached
            };
            function multipleContexts(selector, contexts, results) {
                var i = 0, len = contexts.length;
                for (; i < len; i++) {
                    Sizzle(selector, contexts[i], results)
                }
                return results
            }

            function select(selector, context, results, seed, xml) {
                var i, tokens, token, type, find, match = tokenize(selector), j = match.length;
                if (!seed) {
                    if (match.length === 1) {
                        tokens = match[0] = match[0].slice(0);
                        if (tokens.length > 2 && (token = tokens[0]).type === "ID" && context.nodeType === 9 && !xml && Expr.relative[tokens[1].type]) {
                            context = Expr.find.ID(token.matches[0].replace(rbackslash, ""), context, xml)[0];
                            if (!context) {
                                return results
                            }
                            selector = selector.slice(tokens.shift().length)
                        }
                        for (i = matchExpr.POS.test(selector) ? -1 : tokens.length - 1; i >= 0; i--) {
                            token = tokens[i];
                            if (Expr.relative[(type = token.type)]) {
                                break
                            }
                            if ((find = Expr.find[type])) {
                                if ((seed = find(token.matches[0].replace(rbackslash, ""), rsibling.test(tokens[0].type) && context.parentNode || context, xml))) {
                                    tokens.splice(i, 1);
                                    selector = seed.length && tokens.join("");
                                    if (!selector) {
                                        push.apply(results, slice.call(seed, 0));
                                        return results
                                    }
                                    break
                                }
                            }
                        }
                    }
                }
                compile(selector, match)(seed, context, xml, results, rsibling.test(selector));
                return results
            }

            if (document.querySelectorAll) {
                (function () {
                    var disconnectedMatch, oldSelect = select, rescape = /'|\\/g, rattributeQuotes = /\=[\x20\t\r\n\f]*([^'"\]]*)[\x20\t\r\n\f]*\]/g, rbuggyQSA = [":focus"], rbuggyMatches = [":active"], matches = docElem.matchesSelector || docElem.mozMatchesSelector || docElem.webkitMatchesSelector || docElem.oMatchesSelector || docElem.msMatchesSelector;
                    assert(function (div) {
                        div.innerHTML = "<select><option selected=''></option></select>";
                        if (!div.querySelectorAll("[selected]").length) {
                            rbuggyQSA.push("\\[" + whitespace + "*(?:checked|disabled|ismap|multiple|readonly|selected|value)")
                        }
                        if (!div.querySelectorAll(":checked").length) {
                            rbuggyQSA.push(":checked")
                        }
                    });
                    assert(function (div) {
                        div.innerHTML = "<p test=''></p>";
                        if (div.querySelectorAll("[test^='']").length) {
                            rbuggyQSA.push("[*^$]=" + whitespace + "*(?:\"\"|'')")
                        }
                        div.innerHTML = "<input type='hidden'/>";
                        if (!div.querySelectorAll(":enabled").length) {
                            rbuggyQSA.push(":enabled", ":disabled")
                        }
                    });
                    rbuggyQSA = new RegExp(rbuggyQSA.join("|"));
                    select = function (selector, context, results, seed, xml) {
                        if (!seed && !xml && !rbuggyQSA.test(selector)) {
                            var groups, i, old = true, nid = expando, newContext = context, newSelector = context.nodeType === 9 && selector;
                            if (context.nodeType === 1 && context.nodeName.toLowerCase() !== "object") {
                                groups = tokenize(selector);
                                if ((old = context.getAttribute("id"))) {
                                    nid = old.replace(rescape, "\\$&")
                                } else {
                                    context.setAttribute("id", nid)
                                }
                                nid = "[id='" + nid + "'] ";
                                i = groups.length;
                                while (i--) {
                                    groups[i] = nid + groups[i].join("")
                                }
                                newContext = rsibling.test(selector) && context.parentNode || context;
                                newSelector = groups.join(",")
                            }
                            if (newSelector) {
                                try {
                                    push.apply(results, slice.call(newContext.querySelectorAll(newSelector), 0));
                                    return results
                                } catch (qsaError) {
                                } finally {
                                    if (!old) {
                                        context.removeAttribute("id")
                                    }
                                }
                            }
                        }
                        return oldSelect(selector, context, results, seed, xml)
                    };
                    if (matches) {
                        assert(function (div) {
                            disconnectedMatch = matches.call(div, "div");
                            try {
                                matches.call(div, "[test!='']:sizzle");
                                rbuggyMatches.push("!=", pseudos)
                            } catch (e) {
                            }
                        });
                        rbuggyMatches = new RegExp(rbuggyMatches.join("|"));
                        Sizzle.matchesSelector = function (elem, expr) {
                            expr = expr.replace(rattributeQuotes, "='$1']");
                            if (!isXML(elem) && !rbuggyMatches.test(expr) && !rbuggyQSA.test(expr)) {
                                try {
                                    var ret = matches.call(elem, expr);
                                    if (ret || disconnectedMatch || elem.document && elem.document.nodeType !== 11) {
                                        return ret
                                    }
                                } catch (e) {
                                }
                            }
                            return Sizzle(expr, null, null, [elem]).length > 0
                        }
                    }
                })()
            }
            Expr.pseudos.nth = Expr.pseudos.eq;
            function setFilters() {
            }

            Expr.filters = setFilters.prototype = Expr.pseudos;
            Expr.setFilters = new setFilters();
            Sizzle.attr = jQuery.attr;
            jQuery.find = Sizzle;
            jQuery.expr = Sizzle.selectors;
            jQuery.expr[":"] = jQuery.expr.pseudos;
            jQuery.unique = Sizzle.uniqueSort;
            jQuery.text = Sizzle.getText;
            jQuery.isXMLDoc = Sizzle.isXML;
            jQuery.contains = Sizzle.contains
        })(window);
        var runtil = /Until$/, rparentsprev = /^(?:parents|prev(?:Until|All))/, isSimple = /^.[^:#\[\.,]*$/, rneedsContext = jQuery.expr.match.needsContext, guaranteedUnique = {
            children: true,
            contents: true,
            next: true,
            prev: true
        };
        jQuery.fn.extend({
            find: function (selector) {
                var i, l, length, n, r, ret, self = this;
                if (typeof selector !== "string") {
                    return jQuery(selector).filter(function () {
                        for (i = 0, l = self.length; i < l; i++) {
                            if (jQuery.contains(self[i], this)) {
                                return true
                            }
                        }
                    })
                }
                ret = this.pushStack("", "find", selector);
                for (i = 0, l = this.length; i < l; i++) {
                    length = ret.length;
                    jQuery.find(selector, this[i], ret);
                    if (i > 0) {
                        for (n = length; n < ret.length; n++) {
                            for (r = 0; r < length; r++) {
                                if (ret[r] === ret[n]) {
                                    ret.splice(n--, 1);
                                    break
                                }
                            }
                        }
                    }
                }
                return ret
            }, has: function (target) {
                var i, targets = jQuery(target, this), len = targets.length;
                return this.filter(function () {
                    for (i = 0; i < len; i++) {
                        if (jQuery.contains(this, targets[i])) {
                            return true
                        }
                    }
                })
            }, not: function (selector) {
                return this.pushStack(winnow(this, selector, false), "not", selector)
            }, filter: function (selector) {
                return this.pushStack(winnow(this, selector, true), "filter", selector)
            }, is: function (selector) {
                return !!selector && (typeof selector === "string" ? rneedsContext.test(selector) ? jQuery(selector, this.context).index(this[0]) >= 0 : jQuery.filter(selector, this).length > 0 : this.filter(selector).length > 0)
            }, closest: function (selectors, context) {
                var cur, i = 0, l = this.length, ret = [], pos = rneedsContext.test(selectors) || typeof selectors !== "string" ? jQuery(selectors, context || this.context) : 0;
                for (; i < l; i++) {
                    cur = this[i];
                    while (cur && cur.ownerDocument && cur !== context && cur.nodeType !== 11) {
                        if (pos ? pos.index(cur) > -1 : jQuery.find.matchesSelector(cur, selectors)) {
                            ret.push(cur);
                            break
                        }
                        cur = cur.parentNode
                    }
                }
                ret = ret.length > 1 ? jQuery.unique(ret) : ret;
                return this.pushStack(ret, "closest", selectors)
            }, index: function (elem) {
                if (!elem) {
                    return (this[0] && this[0].parentNode) ? this.prevAll().length : -1
                }
                if (typeof elem === "string") {
                    return jQuery.inArray(this[0], jQuery(elem))
                }
                return jQuery.inArray(elem.jquery ? elem[0] : elem, this)
            }, add: function (selector, context) {
                var set = typeof selector === "string" ? jQuery(selector, context) : jQuery.makeArray(selector && selector.nodeType ? [selector] : selector), all = jQuery.merge(this.get(), set);
                return this.pushStack(isDisconnected(set[0]) || isDisconnected(all[0]) ? all : jQuery.unique(all))
            }, addBack: function (selector) {
                return this.add(selector == null ? this.prevObject : this.prevObject.filter(selector))
            }
        });
        jQuery.fn.andSelf = jQuery.fn.addBack;
        function isDisconnected(node) {
            return !node || !node.parentNode || node.parentNode.nodeType === 11
        }

        function sibling(cur, dir) {
            do {
                cur = cur[dir]
            } while (cur && cur.nodeType !== 1);
            return cur
        }

        jQuery.each({
            parent: function (elem) {
                var parent = elem.parentNode;
                return parent && parent.nodeType !== 11 ? parent : null
            }, parents: function (elem) {
                return jQuery.dir(elem, "parentNode")
            }, parentsUntil: function (elem, i, until) {
                return jQuery.dir(elem, "parentNode", until)
            }, next: function (elem) {
                return sibling(elem, "nextSibling")
            }, prev: function (elem) {
                return sibling(elem, "previousSibling")
            }, nextAll: function (elem) {
                return jQuery.dir(elem, "nextSibling")
            }, prevAll: function (elem) {
                return jQuery.dir(elem, "previousSibling")
            }, nextUntil: function (elem, i, until) {
                return jQuery.dir(elem, "nextSibling", until)
            }, prevUntil: function (elem, i, until) {
                return jQuery.dir(elem, "previousSibling", until)
            }, siblings: function (elem) {
                return jQuery.sibling((elem.parentNode || {}).firstChild, elem)
            }, children: function (elem) {
                return jQuery.sibling(elem.firstChild)
            }, contents: function (elem) {
                return jQuery.nodeName(elem, "iframe") ? elem.contentDocument || elem.contentWindow.document : jQuery.merge([], elem.childNodes)
            }
        }, function (name, fn) {
            jQuery.fn[name] = function (until, selector) {
                var ret = jQuery.map(this, fn, until);
                if (!runtil.test(name)) {
                    selector = until
                }
                if (selector && typeof selector === "string") {
                    ret = jQuery.filter(selector, ret)
                }
                ret = this.length > 1 && !guaranteedUnique[name] ? jQuery.unique(ret) : ret;
                if (this.length > 1 && rparentsprev.test(name)) {
                    ret = ret.reverse()
                }
                return this.pushStack(ret, name, core_slice.call(arguments).join(","))
            }
        });
        jQuery.extend({
            filter: function (expr, elems, not) {
                if (not) {
                    expr = ":not(" + expr + ")"
                }
                return elems.length === 1 ? jQuery.find.matchesSelector(elems[0], expr) ? [elems[0]] : [] : jQuery.find.matches(expr, elems)
            }, dir: function (elem, dir, until) {
                var matched = [], cur = elem[dir];
                while (cur && cur.nodeType !== 9 && (until === undefined || cur.nodeType !== 1 || !jQuery(cur).is(until))) {
                    if (cur.nodeType === 1) {
                        matched.push(cur)
                    }
                    cur = cur[dir]
                }
                return matched
            }, sibling: function (n, elem) {
                var r = [];
                for (; n; n = n.nextSibling) {
                    if (n.nodeType === 1 && n !== elem) {
                        r.push(n)
                    }
                }
                return r
            }
        });
        function winnow(elements, qualifier, keep) {
            qualifier = qualifier || 0;
            if (jQuery.isFunction(qualifier)) {
                return jQuery.grep(elements, function (elem, i) {
                    var retVal = !!qualifier.call(elem, i, elem);
                    return retVal === keep
                })
            } else {
                if (qualifier.nodeType) {
                    return jQuery.grep(elements, function (elem, i) {
                        return (elem === qualifier) === keep
                    })
                } else {
                    if (typeof qualifier === "string") {
                        var filtered = jQuery.grep(elements, function (elem) {
                            return elem.nodeType === 1
                        });
                        if (isSimple.test(qualifier)) {
                            return jQuery.filter(qualifier, filtered, !keep)
                        } else {
                            qualifier = jQuery.filter(qualifier, filtered)
                        }
                    }
                }
            }
            return jQuery.grep(elements, function (elem, i) {
                return (jQuery.inArray(elem, qualifier) >= 0) === keep
            })
        }

        function createSafeFragment(document) {
            var list = nodeNames.split("|"), safeFrag = document.createDocumentFragment();
            if (safeFrag.createElement) {
                while (list.length) {
                    safeFrag.createElement(list.pop())
                }
            }
            return safeFrag
        }

        var nodeNames = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|figcaption|figure|footer|header|hgroup|mark|meter|nav|output|progress|section|summary|time|video", rinlinejQuery = / jQuery\d+="(?:null|\d+)"/g, rleadingWhitespace = /^\s+/, rxhtmlTag = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:]+)[^>]*)\/>/gi, rtagName = /<([\w:]+)/, rtbody = /<tbody/i, rhtml = /<|&#?\w+;/, rnoInnerhtml = /<(?:script|style|link)/i, rnocache = /<(?:script|object|embed|option|style)/i, rnoshimcache = new RegExp("<(?:" + nodeNames + ")[\\s/>]", "i"), rcheckableType = /^(?:checkbox|radio)$/, rchecked = /checked\s*(?:[^=]|=\s*.checked.)/i, rscriptType = /\/(java|ecma)script/i, rcleanScript = /^\s*<!(?:\[CDATA\[|\-\-)|[\]\-]{2}>\s*$/g, wrapMap = {
            option: [1, "<select multiple='multiple'>", "</select>"],
            legend: [1, "<fieldset>", "</fieldset>"],
            thead: [1, "<table>", "</table>"],
            tr: [2, "<table><tbody>", "</tbody></table>"],
            td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
            col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
            area: [1, "<map>", "</map>"],
            _default: [0, "", ""]
        }, safeFragment = createSafeFragment(document), fragmentDiv = safeFragment.appendChild(document.createElement("div"));
        wrapMap.optgroup = wrapMap.option;
        wrapMap.tbody = wrapMap.tfoot = wrapMap.colgroup = wrapMap.caption = wrapMap.thead;
        wrapMap.th = wrapMap.td;
        if (!jQuery.support.htmlSerialize) {
            wrapMap._default = [1, "X<div>", "</div>"]
        }
        jQuery.fn.extend({
            text: function (value) {
                return jQuery.access(this, function (value) {
                    return value === undefined ? jQuery.text(this) : this.empty().append((this[0] && this[0].ownerDocument || document).createTextNode(value))
                }, null, value, arguments.length)
            }, wrapAll: function (html) {
                if (jQuery.isFunction(html)) {
                    return this.each(function (i) {
                        jQuery(this).wrapAll(html.call(this, i))
                    })
                }
                if (this[0]) {
                    var wrap = jQuery(html, this[0].ownerDocument).eq(0).clone(true);
                    if (this[0].parentNode) {
                        wrap.insertBefore(this[0])
                    }
                    wrap.map(function () {
                        var elem = this;
                        while (elem.firstChild && elem.firstChild.nodeType === 1) {
                            elem = elem.firstChild
                        }
                        return elem
                    }).append(this)
                }
                return this
            }, wrapInner: function (html) {
                if (jQuery.isFunction(html)) {
                    return this.each(function (i) {
                        jQuery(this).wrapInner(html.call(this, i))
                    })
                }
                return this.each(function () {
                    var self = jQuery(this), contents = self.contents();
                    if (contents.length) {
                        contents.wrapAll(html)
                    } else {
                        self.append(html)
                    }
                })
            }, wrap: function (html) {
                var isFunction = jQuery.isFunction(html);
                return this.each(function (i) {
                    jQuery(this).wrapAll(isFunction ? html.call(this, i) : html)
                })
            }, unwrap: function () {
                return this.parent().each(function () {
                    if (!jQuery.nodeName(this, "body")) {
                        jQuery(this).replaceWith(this.childNodes)
                    }
                }).end()
            }, append: function () {
                return this.domManip(arguments, true, function (elem) {
                    if (this.nodeType === 1 || this.nodeType === 11) {
                        this.appendChild(elem)
                    }
                })
            }, prepend: function () {
                return this.domManip(arguments, true, function (elem) {
                    if (this.nodeType === 1 || this.nodeType === 11) {
                        this.insertBefore(elem, this.firstChild)
                    }
                })
            }, before: function () {
                if (!isDisconnected(this[0])) {
                    return this.domManip(arguments, false, function (elem) {
                        this.parentNode.insertBefore(elem, this)
                    })
                }
                if (arguments.length) {
                    var set = jQuery.clean(arguments);
                    return this.pushStack(jQuery.merge(set, this), "before", this.selector)
                }
            }, after: function () {
                if (!isDisconnected(this[0])) {
                    return this.domManip(arguments, false, function (elem) {
                        this.parentNode.insertBefore(elem, this.nextSibling)
                    })
                }
                if (arguments.length) {
                    var set = jQuery.clean(arguments);
                    return this.pushStack(jQuery.merge(this, set), "after", this.selector)
                }
            }, remove: function (selector, keepData) {
                var elem, i = 0;
                for (; (elem = this[i]) != null; i++) {
                    if (!selector || jQuery.filter(selector, [elem]).length) {
                        if (!keepData && elem.nodeType === 1) {
                            jQuery.cleanData(elem.getElementsByTagName("*"));
                            jQuery.cleanData([elem])
                        }
                        if (elem.parentNode) {
                            elem.parentNode.removeChild(elem)
                        }
                    }
                }
                return this
            }, empty: function () {
                var elem, i = 0;
                for (; (elem = this[i]) != null; i++) {
                    if (elem.nodeType === 1) {
                        jQuery.cleanData(elem.getElementsByTagName("*"))
                    }
                    while (elem.firstChild) {
                        elem.removeChild(elem.firstChild)
                    }
                }
                return this
            }, clone: function (dataAndEvents, deepDataAndEvents) {
                dataAndEvents = dataAndEvents == null ? false : dataAndEvents;
                deepDataAndEvents = deepDataAndEvents == null ? dataAndEvents : deepDataAndEvents;
                return this.map(function () {
                    return jQuery.clone(this, dataAndEvents, deepDataAndEvents)
                })
            }, html: function (value) {
                return jQuery.access(this, function (value) {
                    var elem = this[0] || {}, i = 0, l = this.length;
                    if (value === undefined) {
                        return elem.nodeType === 1 ? elem.innerHTML.replace(rinlinejQuery, "") : undefined
                    }
                    if (typeof value === "string" && !rnoInnerhtml.test(value) && (jQuery.support.htmlSerialize || !rnoshimcache.test(value)) && (jQuery.support.leadingWhitespace || !rleadingWhitespace.test(value)) && !wrapMap[(rtagName.exec(value) || ["", ""])[1].toLowerCase()]) {
                        value = value.replace(rxhtmlTag, "<$1></$2>");
                        try {
                            for (; i < l; i++) {
                                elem = this[i] || {};
                                if (elem.nodeType === 1) {
                                    jQuery.cleanData(elem.getElementsByTagName("*"));
                                    elem.innerHTML = value
                                }
                            }
                            elem = 0
                        } catch (e) {
                        }
                    }
                    if (elem) {
                        this.empty().append(value)
                    }
                }, null, value, arguments.length)
            }, replaceWith: function (value) {
                if (!isDisconnected(this[0])) {
                    if (jQuery.isFunction(value)) {
                        return this.each(function (i) {
                            var self = jQuery(this), old = self.html();
                            self.replaceWith(value.call(this, i, old))
                        })
                    }
                    if (typeof value !== "string") {
                        value = jQuery(value).detach()
                    }
                    return this.each(function () {
                        var next = this.nextSibling, parent = this.parentNode;
                        jQuery(this).remove();
                        if (next) {
                            jQuery(next).before(value)
                        } else {
                            jQuery(parent).append(value)
                        }
                    })
                }
                return this.length ? this.pushStack(jQuery(jQuery.isFunction(value) ? value() : value), "replaceWith", value) : this
            }, detach: function (selector) {
                return this.remove(selector, true)
            }, domManip: function (args, table, callback) {
                args = [].concat.apply([], args);
                var results, first, fragment, iNoClone, i = 0, value = args[0], scripts = [], l = this.length;
                if (!jQuery.support.checkClone && l > 1 && typeof value === "string" && rchecked.test(value)) {
                    return this.each(function () {
                        jQuery(this).domManip(args, table, callback)
                    })
                }
                if (jQuery.isFunction(value)) {
                    return this.each(function (i) {
                        var self = jQuery(this);
                        args[0] = value.call(this, i, table ? self.html() : undefined);
                        self.domManip(args, table, callback)
                    })
                }
                if (this[0]) {
                    results = jQuery.buildFragment(args, this, scripts);
                    fragment = results.fragment;
                    first = fragment.firstChild;
                    if (fragment.childNodes.length === 1) {
                        fragment = first
                    }
                    if (first) {
                        table = table && jQuery.nodeName(first, "tr");
                        for (iNoClone = results.cacheable || l - 1; i < l; i++) {
                            callback.call(table && jQuery.nodeName(this[i], "table") ? findOrAppend(this[i], "tbody") : this[i], i === iNoClone ? fragment : jQuery.clone(fragment, true, true))
                        }
                    }
                    fragment = first = null;
                    if (scripts.length) {
                        jQuery.each(scripts, function (i, elem) {
                            if (elem.src) {
                                if (jQuery.ajax) {
                                    jQuery.ajax({url: elem.src, type: "GET", dataType: "script", async: false, global: false, "throws": true})
                                } else {
                                    jQuery.error("no ajax")
                                }
                            } else {
                                jQuery.globalEval((elem.text || elem.textContent || elem.innerHTML || "").replace(rcleanScript, ""))
                            }
                            if (elem.parentNode) {
                                elem.parentNode.removeChild(elem)
                            }
                        })
                    }
                }
                return this
            }
        });
        function findOrAppend(elem, tag) {
            return elem.getElementsByTagName(tag)[0] || elem.appendChild(elem.ownerDocument.createElement(tag))
        }

        function cloneCopyEvent(src, dest) {
            if (dest.nodeType !== 1 || !jQuery.hasData(src)) {
                return
            }
            var type, i, l, oldData = jQuery._data(src), curData = jQuery._data(dest, oldData), events = oldData.events;
            if (events) {
                delete curData.handle;
                curData.events = {};
                for (type in events) {
                    for (i = 0, l = events[type].length; i < l; i++) {
                        jQuery.event.add(dest, type, events[type][i])
                    }
                }
            }
            if (curData.data) {
                curData.data = jQuery.extend({}, curData.data)
            }
        }

        function cloneFixAttributes(src, dest) {
            var nodeName;
            if (dest.nodeType !== 1) {
                return
            }
            if (dest.clearAttributes) {
                dest.clearAttributes()
            }
            if (dest.mergeAttributes) {
                dest.mergeAttributes(src)
            }
            nodeName = dest.nodeName.toLowerCase();
            if (nodeName === "object") {
                if (dest.parentNode) {
                    dest.outerHTML = src.outerHTML
                }
                if (jQuery.support.html5Clone && (src.innerHTML && !jQuery.trim(dest.innerHTML))) {
                    dest.innerHTML = src.innerHTML
                }
            } else {
                if (nodeName === "input" && rcheckableType.test(src.type)) {
                    dest.defaultChecked = dest.checked = src.checked;
                    if (dest.value !== src.value) {
                        dest.value = src.value
                    }
                } else {
                    if (nodeName === "option") {
                        dest.selected = src.defaultSelected
                    } else {
                        if (nodeName === "input" || nodeName === "textarea") {
                            dest.defaultValue = src.defaultValue
                        } else {
                            if (nodeName === "script" && dest.text !== src.text) {
                                dest.text = src.text
                            }
                        }
                    }
                }
            }
            dest.removeAttribute(jQuery.expando)
        }

        jQuery.buildFragment = function (args, context, scripts) {
            var fragment, cacheable, cachehit, first = args[0];
            context = context || document;
            context = !context.nodeType && context[0] || context;
            context = context.ownerDocument || context;
            if (args.length === 1 && typeof first === "string" && first.length < 512 && context === document && first.charAt(0) === "<" && !rnocache.test(first) && (jQuery.support.checkClone || !rchecked.test(first)) && (jQuery.support.html5Clone || !rnoshimcache.test(first))) {
                cacheable = true;
                fragment = jQuery.fragments[first];
                cachehit = fragment !== undefined
            }
            if (!fragment) {
                fragment = context.createDocumentFragment();
                jQuery.clean(args, context, fragment, scripts);
                if (cacheable) {
                    jQuery.fragments[first] = cachehit && fragment
                }
            }
            return {fragment: fragment, cacheable: cacheable}
        };
        jQuery.fragments = {};
        jQuery.each({appendTo: "append", prependTo: "prepend", insertBefore: "before", insertAfter: "after", replaceAll: "replaceWith"}, function (name, original) {
            jQuery.fn[name] = function (selector) {
                var elems, i = 0, ret = [], insert = jQuery(selector), l = insert.length, parent = this.length === 1 && this[0].parentNode;
                if ((parent == null || parent && parent.nodeType === 11 && parent.childNodes.length === 1) && l === 1) {
                    insert[original](this[0]);
                    return this
                } else {
                    for (; i < l; i++) {
                        elems = (i > 0 ? this.clone(true) : this).get();
                        jQuery(insert[i])[original](elems);
                        ret = ret.concat(elems)
                    }
                    return this.pushStack(ret, name, insert.selector)
                }
            }
        });
        function getAll(elem) {
            if (typeof elem.getElementsByTagName !== "undefined") {
                return elem.getElementsByTagName("*")
            } else {
                if (typeof elem.querySelectorAll !== "undefined") {
                    return elem.querySelectorAll("*")
                } else {
                    return []
                }
            }
        }

        function fixDefaultChecked(elem) {
            if (rcheckableType.test(elem.type)) {
                elem.defaultChecked = elem.checked
            }
        }

        jQuery.extend({
            clone: function (elem, dataAndEvents, deepDataAndEvents) {
                var srcElements, destElements, i, clone;
                if (jQuery.support.html5Clone || jQuery.isXMLDoc(elem) || !rnoshimcache.test("<" + elem.nodeName + ">")) {
                    clone = elem.cloneNode(true)
                } else {
                    fragmentDiv.innerHTML = elem.outerHTML;
                    fragmentDiv.removeChild(clone = fragmentDiv.firstChild)
                }
                if ((!jQuery.support.noCloneEvent || !jQuery.support.noCloneChecked) && (elem.nodeType === 1 || elem.nodeType === 11) && !jQuery.isXMLDoc(elem)) {
                    cloneFixAttributes(elem, clone);
                    srcElements = getAll(elem);
                    destElements = getAll(clone);
                    for (i = 0; srcElements[i]; ++i) {
                        if (destElements[i]) {
                            cloneFixAttributes(srcElements[i], destElements[i])
                        }
                    }
                }
                if (dataAndEvents) {
                    cloneCopyEvent(elem, clone);
                    if (deepDataAndEvents) {
                        srcElements = getAll(elem);
                        destElements = getAll(clone);
                        for (i = 0; srcElements[i]; ++i) {
                            cloneCopyEvent(srcElements[i], destElements[i])
                        }
                    }
                }
                srcElements = destElements = null;
                return clone
            }, clean: function (elems, context, fragment, scripts) {
                var i, j, elem, tag, wrap, depth, div, hasBody, tbody, len, handleScript, jsTags, safe = context === document && safeFragment, ret = [];
                if (!context || typeof context.createDocumentFragment === "undefined") {
                    context = document
                }
                for (i = 0; (elem = elems[i]) != null; i++) {
                    if (typeof elem === "number") {
                        elem += ""
                    }
                    if (!elem) {
                        continue
                    }
                    if (typeof elem === "string") {
                        if (!rhtml.test(elem)) {
                            elem = context.createTextNode(elem)
                        } else {
                            safe = safe || createSafeFragment(context);
                            div = context.createElement("div");
                            safe.appendChild(div);
                            elem = elem.replace(rxhtmlTag, "<$1></$2>");
                            tag = (rtagName.exec(elem) || ["", ""])[1].toLowerCase();
                            wrap = wrapMap[tag] || wrapMap._default;
                            depth = wrap[0];
                            div.innerHTML = wrap[1] + elem + wrap[2];
                            while (depth--) {
                                div = div.lastChild
                            }
                            if (!jQuery.support.tbody) {
                                hasBody = rtbody.test(elem);
                                tbody = tag === "table" && !hasBody ? div.firstChild && div.firstChild.childNodes : wrap[1] === "<table>" && !hasBody ? div.childNodes : [];
                                for (j = tbody.length - 1; j >= 0; --j) {
                                    if (jQuery.nodeName(tbody[j], "tbody") && !tbody[j].childNodes.length) {
                                        tbody[j].parentNode.removeChild(tbody[j])
                                    }
                                }
                            }
                            if (!jQuery.support.leadingWhitespace && rleadingWhitespace.test(elem)) {
                                div.insertBefore(context.createTextNode(rleadingWhitespace.exec(elem)[0]), div.firstChild)
                            }
                            elem = div.childNodes;
                            div.parentNode.removeChild(div)
                        }
                    }
                    if (elem.nodeType) {
                        ret.push(elem)
                    } else {
                        jQuery.merge(ret, elem)
                    }
                }
                if (div) {
                    elem = div = safe = null
                }
                if (!jQuery.support.appendChecked) {
                    for (i = 0; (elem = ret[i]) != null; i++) {
                        if (jQuery.nodeName(elem, "input")) {
                            fixDefaultChecked(elem)
                        } else {
                            if (typeof elem.getElementsByTagName !== "undefined") {
                                jQuery.grep(elem.getElementsByTagName("input"), fixDefaultChecked)
                            }
                        }
                    }
                }
                if (fragment) {
                    handleScript = function (elem) {
                        if (!elem.type || rscriptType.test(elem.type)) {
                            return scripts ? scripts.push(elem.parentNode ? elem.parentNode.removeChild(elem) : elem) : fragment.appendChild(elem)
                        }
                    };
                    for (i = 0; (elem = ret[i]) != null; i++) {
                        if (!(jQuery.nodeName(elem, "script") && handleScript(elem))) {
                            fragment.appendChild(elem);
                            if (typeof elem.getElementsByTagName !== "undefined") {
                                jsTags = jQuery.grep(jQuery.merge([], elem.getElementsByTagName("script")), handleScript);
                                ret.splice.apply(ret, [i + 1, 0].concat(jsTags));
                                i += jsTags.length
                            }
                        }
                    }
                }
                return ret
            }, cleanData: function (elems, acceptData) {
                var data, id, elem, type, i = 0, internalKey = jQuery.expando, cache = jQuery.cache, deleteExpando = jQuery.support.deleteExpando, special = jQuery.event.special;
                for (; (elem = elems[i]) != null; i++) {
                    if (acceptData || jQuery.acceptData(elem)) {
                        id = elem[internalKey];
                        data = id && cache[id];
                        if (data) {
                            if (data.events) {
                                for (type in data.events) {
                                    if (special[type]) {
                                        jQuery.event.remove(elem, type)
                                    } else {
                                        jQuery.removeEvent(elem, type, data.handle)
                                    }
                                }
                            }
                            if (cache[id]) {
                                delete cache[id];
                                if (deleteExpando) {
                                    delete elem[internalKey]
                                } else {
                                    if (elem.removeAttribute) {
                                        elem.removeAttribute(internalKey)
                                    } else {
                                        elem[internalKey] = null
                                    }
                                }
                                jQuery.deletedIds.push(id)
                            }
                        }
                    }
                }
            }
        });
        (function () {
            var matched, browser;
            jQuery.uaMatch = function (ua) {
                ua = ua.toLowerCase();
                var match = /(chrome)[ \/]([\w.]+)/.exec(ua) || /(webkit)[ \/]([\w.]+)/.exec(ua) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(ua) || /(msie) ([\w.]+)/.exec(ua) || ua.indexOf("compatible") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(ua) || [];
                return {browser: match[1] || "", version: match[2] || "0"}
            };
            matched = jQuery.uaMatch(navigator.userAgent);
            browser = {};
            if (matched.browser) {
                browser[matched.browser] = true;
                browser.version = matched.version
            }
            if (browser.chrome) {
                browser.webkit = true
            } else {
                if (browser.webkit) {
                    browser.safari = true
                }
            }
            jQuery.browser = browser;
            jQuery.sub = function () {
                function jQuerySub(selector, context) {
                    return new jQuerySub.fn.init(selector, context)
                }

                jQuery.extend(true, jQuerySub, this);
                jQuerySub.superclass = this;
                jQuerySub.fn = jQuerySub.prototype = this();
                jQuerySub.fn.constructor = jQuerySub;
                jQuerySub.sub = this.sub;
                jQuerySub.fn.init = function init(selector, context) {
                    if (context && context instanceof jQuery && !(context instanceof jQuerySub)) {
                        context = jQuerySub(context)
                    }
                    return jQuery.fn.init.call(this, selector, context, rootjQuerySub)
                };
                jQuerySub.fn.init.prototype = jQuerySub.fn;
                var rootjQuerySub = jQuerySub(document);
                return jQuerySub
            }
        })();
        var curCSS, iframe, iframeDoc, ralpha = /alpha\([^)]*\)/i, ropacity = /opacity=([^)]*)/, rposition = /^(top|right|bottom|left)$/, rdisplayswap = /^(none|table(?!-c[ea]).+)/, rmargin = /^margin/, rnumsplit = new RegExp("^(" + core_pnum + ")(.*)$", "i"), rnumnonpx = new RegExp("^(" + core_pnum + ")(?!px)[a-z%]+$", "i"), rrelNum = new RegExp("^([-+])=(" + core_pnum + ")", "i"), elemdisplay = {BODY: "block"}, cssShow = {
            position: "absolute",
            visibility: "hidden",
            display: "block"
        }, cssNormalTransform = {letterSpacing: 0, fontWeight: 400}, cssExpand = ["Top", "Right", "Bottom", "Left"], cssPrefixes = ["Webkit", "O", "Moz", "ms"], eventsToggle = jQuery.fn.toggle;

        function vendorPropName(style, name) {
            if (name in style) {
                return name
            }
            var capName = name.charAt(0).toUpperCase() + name.slice(1), origName = name, i = cssPrefixes.length;
            while (i--) {
                name = cssPrefixes[i] + capName;
                if (name in style) {
                    return name
                }
            }
            return origName
        }

        function isHidden(elem, el) {
            elem = el || elem;
            return jQuery.css(elem, "display") === "none" || !jQuery.contains(elem.ownerDocument, elem)
        }

        function showHide(elements, show) {
            var elem, display, values = [], index = 0, length = elements.length;
            for (; index < length; index++) {
                elem = elements[index];
                if (!elem.style) {
                    continue
                }
                values[index] = jQuery._data(elem, "olddisplay");
                if (show) {
                    if (!values[index] && elem.style.display === "none") {
                        elem.style.display = ""
                    }
                    if (elem.style.display === "" && isHidden(elem)) {
                        values[index] = jQuery._data(elem, "olddisplay", css_defaultDisplay(elem.nodeName))
                    }
                } else {
                    display = curCSS(elem, "display");
                    if (!values[index] && display !== "none") {
                        jQuery._data(elem, "olddisplay", display)
                    }
                }
            }
            for (index = 0; index < length; index++) {
                elem = elements[index];
                if (!elem.style) {
                    continue
                }
                if (!show || elem.style.display === "none" || elem.style.display === "") {
                    elem.style.display = show ? values[index] || "" : "none"
                }
            }
            return elements
        }

        jQuery.fn.extend({
            css: function (name, value) {
                return jQuery.access(this, function (elem, name, value) {
                    return value !== undefined ? jQuery.style(elem, name, value) : jQuery.css(elem, name)
                }, name, value, arguments.length > 1)
            }, show: function () {
                return showHide(this, true)
            }, hide: function () {
                return showHide(this)
            }, toggle: function (state, fn2) {
                var bool = typeof state === "boolean";
                if (jQuery.isFunction(state) && jQuery.isFunction(fn2)) {
                    return eventsToggle.apply(this, arguments)
                }
                return this.each(function () {
                    if (bool ? state : isHidden(this)) {
                        jQuery(this).show()
                    } else {
                        jQuery(this).hide()
                    }
                })
            }
        });
        jQuery.extend({
            cssHooks: {
                opacity: {
                    get: function (elem, computed) {
                        if (computed) {
                            var ret = curCSS(elem, "opacity");
                            return ret === "" ? "1" : ret
                        }
                    }
                }
            },
            cssNumber: {fillOpacity: true, fontWeight: true, lineHeight: true, opacity: true, orphans: true, widows: true, zIndex: true, zoom: true},
            cssProps: {"float": jQuery.support.cssFloat ? "cssFloat" : "styleFloat"},
            style: function (elem, name, value, extra) {
                if (!elem || elem.nodeType === 3 || elem.nodeType === 8 || !elem.style) {
                    return
                }
                var ret, type, hooks, origName = jQuery.camelCase(name), style = elem.style;
                name = jQuery.cssProps[origName] || (jQuery.cssProps[origName] = vendorPropName(style, origName));
                hooks = jQuery.cssHooks[name] || jQuery.cssHooks[origName];
                if (value !== undefined) {
                    type = typeof value;
                    if (type === "string" && (ret = rrelNum.exec(value))) {
                        value = (ret[1] + 1) * ret[2] + parseFloat(jQuery.css(elem, name));
                        type = "number"
                    }
                    if (value == null || type === "number" && isNaN(value)) {
                        return
                    }
                    if (type === "number" && !jQuery.cssNumber[origName]) {
                        value += "px"
                    }
                    if (!hooks || !("set" in hooks) || (value = hooks.set(elem, value, extra)) !== undefined) {
                        try {
                            style[name] = value
                        } catch (e) {
                        }
                    }
                } else {
                    if (hooks && "get" in hooks && (ret = hooks.get(elem, false, extra)) !== undefined) {
                        return ret
                    }
                    return style[name]
                }
            },
            css: function (elem, name, numeric, extra) {
                var val, num, hooks, origName = jQuery.camelCase(name);
                name = jQuery.cssProps[origName] || (jQuery.cssProps[origName] = vendorPropName(elem.style, origName));
                hooks = jQuery.cssHooks[name] || jQuery.cssHooks[origName];
                if (hooks && "get" in hooks) {
                    val = hooks.get(elem, true, extra)
                }
                if (val === undefined) {
                    val = curCSS(elem, name)
                }
                if (val === "normal" && name in cssNormalTransform) {
                    val = cssNormalTransform[name]
                }
                if (numeric || extra !== undefined) {
                    num = parseFloat(val);
                    return numeric || jQuery.isNumeric(num) ? num || 0 : val
                }
                return val
            },
            swap: function (elem, options, callback) {
                var ret, name, old = {};
                for (name in options) {
                    old[name] = elem.style[name];
                    elem.style[name] = options[name]
                }
                ret = callback.call(elem);
                for (name in options) {
                    elem.style[name] = old[name]
                }
                return ret
            }
        });
        if (window.getComputedStyle) {
            curCSS = function (elem, name) {
                var ret, width, minWidth, maxWidth, computed = window.getComputedStyle(elem, null), style = elem.style;
                if (computed) {
                    ret = computed.getPropertyValue(name) || computed[name];
                    if (ret === "" && !jQuery.contains(elem.ownerDocument, elem)) {
                        ret = jQuery.style(elem, name)
                    }
                    if (rnumnonpx.test(ret) && rmargin.test(name)) {
                        width = style.width;
                        minWidth = style.minWidth;
                        maxWidth = style.maxWidth;
                        style.minWidth = style.maxWidth = style.width = ret;
                        ret = computed.width;
                        style.width = width;
                        style.minWidth = minWidth;
                        style.maxWidth = maxWidth
                    }
                }
                return ret
            }
        } else {
            if (document.documentElement.currentStyle) {
                curCSS = function (elem, name) {
                    var left, rsLeft, ret = elem.currentStyle && elem.currentStyle[name], style = elem.style;
                    if (ret == null && style && style[name]) {
                        ret = style[name]
                    }
                    if (rnumnonpx.test(ret) && !rposition.test(name)) {
                        left = style.left;
                        rsLeft = elem.runtimeStyle && elem.runtimeStyle.left;
                        if (rsLeft) {
                            elem.runtimeStyle.left = elem.currentStyle.left
                        }
                        style.left = name === "fontSize" ? "1em" : ret;
                        ret = style.pixelLeft + "px";
                        style.left = left;
                        if (rsLeft) {
                            elem.runtimeStyle.left = rsLeft
                        }
                    }
                    return ret === "" ? "auto" : ret
                }
            }
        }
        function setPositiveNumber(elem, value, subtract) {
            var matches = rnumsplit.exec(value);
            return matches ? Math.max(0, matches[1] - (subtract || 0)) + (matches[2] || "px") : value
        }

        function augmentWidthOrHeight(elem, name, extra, isBorderBox) {
            var i = extra === (isBorderBox ? "border" : "content") ? 4 : name === "width" ? 1 : 0, val = 0;
            for (; i < 4; i += 2) {
                if (extra === "margin") {
                    val += jQuery.css(elem, extra + cssExpand[i], true)
                }
                if (isBorderBox) {
                    if (extra === "content") {
                        val -= parseFloat(curCSS(elem, "padding" + cssExpand[i])) || 0
                    }
                    if (extra !== "margin") {
                        val -= parseFloat(curCSS(elem, "border" + cssExpand[i] + "Width")) || 0
                    }
                } else {
                    val += parseFloat(curCSS(elem, "padding" + cssExpand[i])) || 0;
                    if (extra !== "padding") {
                        val += parseFloat(curCSS(elem, "border" + cssExpand[i] + "Width")) || 0
                    }
                }
            }
            return val
        }

        function getWidthOrHeight(elem, name, extra) {
            var val = name === "width" ? elem.offsetWidth : elem.offsetHeight, valueIsBorderBox = true, isBorderBox = jQuery.support.boxSizing && jQuery.css(elem, "boxSizing") === "border-box";
            if (val <= 0 || val == null) {
                val = curCSS(elem, name);
                if (val < 0 || val == null) {
                    val = elem.style[name]
                }
                if (rnumnonpx.test(val)) {
                    return val
                }
                valueIsBorderBox = isBorderBox && (jQuery.support.boxSizingReliable || val === elem.style[name]);
                val = parseFloat(val) || 0
            }
            return (val + augmentWidthOrHeight(elem, name, extra || (isBorderBox ? "border" : "content"), valueIsBorderBox)) + "px"
        }

        function css_defaultDisplay(nodeName) {
            if (elemdisplay[nodeName]) {
                return elemdisplay[nodeName]
            }
            var elem = jQuery("<" + nodeName + ">").appendTo(document.body), display = elem.css("display");
            elem.remove();
            if (display === "none" || display === "") {
                iframe = document.body.appendChild(iframe || jQuery.extend(document.createElement("iframe"), {frameBorder: 0, width: 0, height: 0}));
                if (!iframeDoc || !iframe.createElement) {
                    iframeDoc = (iframe.contentWindow || iframe.contentDocument).document;
                    iframeDoc.write("<!doctype html><html><body>");
                    iframeDoc.close()
                }
                elem = iframeDoc.body.appendChild(iframeDoc.createElement(nodeName));
                display = curCSS(elem, "display");
                document.body.removeChild(iframe)
            }
            elemdisplay[nodeName] = display;
            return display
        }

        jQuery.each(["height", "width"], function (i, name) {
            jQuery.cssHooks[name] = {
                get: function (elem, computed, extra) {
                    if (computed) {
                        if (elem.offsetWidth === 0 && rdisplayswap.test(curCSS(elem, "display"))) {
                            return jQuery.swap(elem, cssShow, function () {
                                return getWidthOrHeight(elem, name, extra)
                            })
                        } else {
                            return getWidthOrHeight(elem, name, extra)
                        }
                    }
                }, set: function (elem, value, extra) {
                    return setPositiveNumber(elem, value, extra ? augmentWidthOrHeight(elem, name, extra, jQuery.support.boxSizing && jQuery.css(elem, "boxSizing") === "border-box") : 0)
                }
            }
        });
        if (!jQuery.support.opacity) {
            jQuery.cssHooks.opacity = {
                get: function (elem, computed) {
                    return ropacity.test((computed && elem.currentStyle ? elem.currentStyle.filter : elem.style.filter) || "") ? (0.01 * parseFloat(RegExp.$1)) + "" : computed ? "1" : ""
                }, set: function (elem, value) {
                    var style = elem.style, currentStyle = elem.currentStyle, opacity = jQuery.isNumeric(value) ? "alpha(opacity=" + value * 100 + ")" : "", filter = currentStyle && currentStyle.filter || style.filter || "";
                    style.zoom = 1;
                    if (value >= 1 && jQuery.trim(filter.replace(ralpha, "")) === "" && style.removeAttribute) {
                        style.removeAttribute("filter");
                        if (currentStyle && !currentStyle.filter) {
                            return
                        }
                    }
                    style.filter = ralpha.test(filter) ? filter.replace(ralpha, opacity) : filter + " " + opacity
                }
            }
        }
        jQuery(function () {
            if (!jQuery.support.reliableMarginRight) {
                jQuery.cssHooks.marginRight = {
                    get: function (elem, computed) {
                        return jQuery.swap(elem, {display: "inline-block"}, function () {
                            if (computed) {
                                return curCSS(elem, "marginRight")
                            }
                        })
                    }
                }
            }
            if (!jQuery.support.pixelPosition && jQuery.fn.position) {
                jQuery.each(["top", "left"], function (i, prop) {
                    jQuery.cssHooks[prop] = {
                        get: function (elem, computed) {
                            if (computed) {
                                var ret = curCSS(elem, prop);
                                return rnumnonpx.test(ret) ? jQuery(elem).position()[prop] + "px" : ret
                            }
                        }
                    }
                })
            }
        });
        if (jQuery.expr && jQuery.expr.filters) {
            jQuery.expr.filters.hidden = function (elem) {
                return (elem.offsetWidth === 0 && elem.offsetHeight === 0) || (!jQuery.support.reliableHiddenOffsets && ((elem.style && elem.style.display) || curCSS(elem, "display")) === "none")
            };
            jQuery.expr.filters.visible = function (elem) {
                return !jQuery.expr.filters.hidden(elem)
            }
        }
        jQuery.each({margin: "", padding: "", border: "Width"}, function (prefix, suffix) {
            jQuery.cssHooks[prefix + suffix] = {
                expand: function (value) {
                    var i, parts = typeof value === "string" ? value.split(" ") : [value], expanded = {};
                    for (i = 0; i < 4; i++) {
                        expanded[prefix + cssExpand[i] + suffix] = parts[i] || parts[i - 2] || parts[0]
                    }
                    return expanded
                }
            };
            if (!rmargin.test(prefix)) {
                jQuery.cssHooks[prefix + suffix].set = setPositiveNumber
            }
        });
        var r20 = /%20/g, rbracket = /\[\]$/, rCRLF = /\r?\n/g, rinput = /^(?:color|date|datetime|datetime-local|email|hidden|month|number|password|range|search|tel|text|time|url|week)$/i, rselectTextarea = /^(?:select|textarea)/i;
        jQuery.fn.extend({
            serialize: function () {
                return jQuery.param(this.serializeArray())
            }, serializeArray: function () {
                return this.map(function () {
                    return this.elements ? jQuery.makeArray(this.elements) : this
                }).filter(function () {
                    return this.name && !this.disabled && (this.checked || rselectTextarea.test(this.nodeName) || rinput.test(this.type))
                }).map(function (i, elem) {
                    var val = jQuery(this).val();
                    return val == null ? null : jQuery.isArray(val) ? jQuery.map(val, function (val, i) {
                        return {name: elem.name, value: val.replace(rCRLF, "\r\n")}
                    }) : {name: elem.name, value: val.replace(rCRLF, "\r\n")}
                }).get()
            }
        });
        jQuery.param = function (a, traditional) {
            var prefix, s = [], add = function (key, value) {
                value = jQuery.isFunction(value) ? value() : (value == null ? "" : value);
                s[s.length] = encodeURIComponent(key) + "=" + encodeURIComponent(value)
            };
            if (traditional === undefined) {
                traditional = jQuery.ajaxSettings && jQuery.ajaxSettings.traditional
            }
            if (jQuery.isArray(a) || (a.jquery && !jQuery.isPlainObject(a))) {
                jQuery.each(a, function () {
                    add(this.name, this.value)
                })
            } else {
                for (prefix in a) {
                    buildParams(prefix, a[prefix], traditional, add)
                }
            }
            return s.join("&").replace(r20, "+")
        };
        function buildParams(prefix, obj, traditional, add) {
            var name;
            if (jQuery.isArray(obj)) {
                jQuery.each(obj, function (i, v) {
                    if (traditional || rbracket.test(prefix)) {
                        add(prefix, v)
                    } else {
                        buildParams(prefix + "[" + (typeof v === "object" ? i : "") + "]", v, traditional, add)
                    }
                })
            } else {
                if (!traditional && jQuery.type(obj) === "object") {
                    for (name in obj) {
                        buildParams(prefix + "[" + name + "]", obj[name], traditional, add)
                    }
                } else {
                    add(prefix, obj)
                }
            }
        }

        var ajaxLocParts, ajaxLocation, rhash = /#.*$/, rheaders = /^(.*?):[ \t]*([^\r\n]*)\r?$/mg, rlocalProtocol = /^(?:about|app|app\-storage|.+\-extension|file|res|widget):$/, rnoContent = /^(?:GET|HEAD)$/, rprotocol = /^\/\//, rquery = /\?/, rscript = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, rts = /([?&])_=[^&]*/, rurl = /^([\w\+\.\-]+:)(?:\/\/([^\/?#:]*)(?::(\d+)|)|)/, _load = jQuery.fn.load, prefilters = {}, transports = {}, allTypes = ["*/"] + ["*"];
        try {
            ajaxLocation = location.href
        } catch (e) {
            ajaxLocation = document.createElement("a");
            ajaxLocation.href = "";
            ajaxLocation = ajaxLocation.href
        }
        ajaxLocParts = rurl.exec(ajaxLocation.toLowerCase()) || [];
        function addToPrefiltersOrTransports(structure) {
            return function (dataTypeExpression, func) {
                if (typeof dataTypeExpression !== "string") {
                    func = dataTypeExpression;
                    dataTypeExpression = "*"
                }
                var dataType, list, placeBefore, dataTypes = dataTypeExpression.toLowerCase().split(core_rspace), i = 0, length = dataTypes.length;
                if (jQuery.isFunction(func)) {
                    for (; i < length; i++) {
                        dataType = dataTypes[i];
                        placeBefore = /^\+/.test(dataType);
                        if (placeBefore) {
                            dataType = dataType.substr(1) || "*"
                        }
                        list = structure[dataType] = structure[dataType] || [];
                        list[placeBefore ? "unshift" : "push"](func)
                    }
                }
            }
        }

        function inspectPrefiltersOrTransports(structure, options, originalOptions, jqXHR, dataType, inspected) {
            dataType = dataType || options.dataTypes[0];
            inspected = inspected || {};
            inspected[dataType] = true;
            var selection, list = structure[dataType], i = 0, length = list ? list.length : 0, executeOnly = (structure === prefilters);
            for (; i < length && (executeOnly || !selection); i++) {
                selection = list[i](options, originalOptions, jqXHR);
                if (typeof selection === "string") {
                    if (!executeOnly || inspected[selection]) {
                        selection = undefined
                    } else {
                        options.dataTypes.unshift(selection);
                        selection = inspectPrefiltersOrTransports(structure, options, originalOptions, jqXHR, selection, inspected)
                    }
                }
            }
            if ((executeOnly || !selection) && !inspected["*"]) {
                selection = inspectPrefiltersOrTransports(structure, options, originalOptions, jqXHR, "*", inspected)
            }
            return selection
        }

        function ajaxExtend(target, src) {
            var key, deep, flatOptions = jQuery.ajaxSettings.flatOptions || {};
            for (key in src) {
                if (src[key] !== undefined) {
                    (flatOptions[key] ? target : (deep || (deep = {})))[key] = src[key]
                }
            }
            if (deep) {
                jQuery.extend(true, target, deep)
            }
        }

        jQuery.fn.load = function (url, params, callback) {
            if (typeof url !== "string" && _load) {
                return _load.apply(this, arguments)
            }
            if (!this.length) {
                return this
            }
            var selector, type, response, self = this, off = url.indexOf(" ");
            if (off >= 0) {
                selector = url.slice(off, url.length);
                url = url.slice(0, off)
            }
            if (jQuery.isFunction(params)) {
                callback = params;
                params = undefined
            } else {
                if (params && typeof params === "object") {
                    type = "POST"
                }
            }
            jQuery.ajax({
                url: url, type: type, dataType: "html", data: params, complete: function (jqXHR, status) {
                    if (callback) {
                        self.each(callback, response || [jqXHR.responseText, status, jqXHR])
                    }
                }
            }).done(function (responseText) {
                response = arguments;
                self.html(selector ? jQuery("<div>").append(responseText.replace(rscript, "")).find(selector) : responseText)
            });
            return this
        };
        jQuery.each("ajaxStart ajaxStop ajaxComplete ajaxError ajaxSuccess ajaxSend".split(" "), function (i, o) {
            jQuery.fn[o] = function (f) {
                return this.on(o, f)
            }
        });
        jQuery.each(["get", "post"], function (i, method) {
            jQuery[method] = function (url, data, callback, type) {
                if (jQuery.isFunction(data)) {
                    type = type || callback;
                    callback = data;
                    data = undefined
                }
                return jQuery.ajax({type: method, url: url, data: data, success: callback, dataType: type})
            }
        });
        jQuery.extend({
            getScript: function (url, callback) {
                return jQuery.get(url, undefined, callback, "script")
            },
            getJSON: function (url, data, callback) {
                return jQuery.get(url, data, callback, "json")
            },
            ajaxSetup: function (target, settings) {
                if (settings) {
                    ajaxExtend(target, jQuery.ajaxSettings)
                } else {
                    settings = target;
                    target = jQuery.ajaxSettings
                }
                ajaxExtend(target, settings);
                return target
            },
            ajaxSettings: {
                url: ajaxLocation,
                isLocal: rlocalProtocol.test(ajaxLocParts[1]),
                global: true,
                type: "GET",
                contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                processData: true,
                async: true,
                accepts: {xml: "application/xml, text/xml", html: "text/html", text: "text/plain", json: "application/json, text/javascript", "*": allTypes},
                contents: {xml: /xml/, html: /html/, json: /json/},
                responseFields: {xml: "responseXML", text: "responseText"},
                converters: {"* text": window.String, "text html": true, "text json": jQuery.parseJSON, "text xml": jQuery.parseXML},
                flatOptions: {context: true, url: true}
            },
            ajaxPrefilter: addToPrefiltersOrTransports(prefilters),
            ajaxTransport: addToPrefiltersOrTransports(transports),
            ajax: function (url, options) {
                if (typeof url === "object") {
                    options = url;
                    url = undefined
                }
                options = options || {};
                var ifModifiedKey, responseHeadersString, responseHeaders, transport, timeoutTimer, parts, fireGlobals, i, s = jQuery.ajaxSetup({}, options), callbackContext = s.context || s, globalEventContext = callbackContext !== s && (callbackContext.nodeType || callbackContext instanceof jQuery) ? jQuery(callbackContext) : jQuery.event, deferred = jQuery.Deferred(), completeDeferred = jQuery.Callbacks("once memory"), statusCode = s.statusCode || {}, requestHeaders = {}, requestHeadersNames = {}, state = 0, strAbort = "canceled", jqXHR = {
                    readyState: 0,
                    setRequestHeader: function (name, value) {
                        if (!state) {
                            var lname = name.toLowerCase();
                            name = requestHeadersNames[lname] = requestHeadersNames[lname] || name;
                            requestHeaders[name] = value
                        }
                        return this
                    },
                    getAllResponseHeaders: function () {
                        return state === 2 ? responseHeadersString : null
                    },
                    getResponseHeader: function (key) {
                        var match;
                        if (state === 2) {
                            if (!responseHeaders) {
                                responseHeaders = {};
                                while ((match = rheaders.exec(responseHeadersString))) {
                                    responseHeaders[match[1].toLowerCase()] = match[2]
                                }
                            }
                            match = responseHeaders[key.toLowerCase()]
                        }
                        return match === undefined ? null : match
                    },
                    overrideMimeType: function (type) {
                        if (!state) {
                            s.mimeType = type
                        }
                        return this
                    },
                    abort: function (statusText) {
                        statusText = statusText || strAbort;
                        if (transport) {
                            transport.abort(statusText)
                        }
                        done(0, statusText);
                        return this
                    }
                };

                function done(status, nativeStatusText, responses, headers) {
                    var isSuccess, success, error, response, modified, statusText = nativeStatusText;
                    if (state === 2) {
                        return
                    }
                    state = 2;
                    if (timeoutTimer) {
                        clearTimeout(timeoutTimer)
                    }
                    transport = undefined;
                    responseHeadersString = headers || "";
                    jqXHR.readyState = status > 0 ? 4 : 0;
                    if (responses) {
                        response = ajaxHandleResponses(s, jqXHR, responses)
                    }
                    if (status >= 200 && status < 300 || status === 304) {
                        if (s.ifModified) {
                            modified = jqXHR.getResponseHeader("Last-Modified");
                            if (modified) {
                                jQuery.lastModified[ifModifiedKey] = modified
                            }
                            modified = jqXHR.getResponseHeader("Etag");
                            if (modified) {
                                jQuery.etag[ifModifiedKey] = modified
                            }
                        }
                        if (status === 304) {
                            statusText = "notmodified";
                            isSuccess = true
                        } else {
                            isSuccess = ajaxConvert(s, response);
                            statusText = isSuccess.state;
                            success = isSuccess.data;
                            error = isSuccess.error;
                            isSuccess = !error
                        }
                    } else {
                        error = statusText;
                        if (!statusText || status) {
                            statusText = "error";
                            if (status < 0) {
                                status = 0
                            }
                        }
                    }
                    jqXHR.status = status;
                    jqXHR.statusText = (nativeStatusText || statusText) + "";
                    if (isSuccess) {
                        deferred.resolveWith(callbackContext, [success, statusText, jqXHR])
                    } else {
                        deferred.rejectWith(callbackContext, [jqXHR, statusText, error])
                    }
                    jqXHR.statusCode(statusCode);
                    statusCode = undefined;
                    if (fireGlobals) {
                        globalEventContext.trigger("ajax" + (isSuccess ? "Success" : "Error"), [jqXHR, s, isSuccess ? success : error])
                    }
                    completeDeferred.fireWith(callbackContext, [jqXHR, statusText]);
                    if (fireGlobals) {
                        globalEventContext.trigger("ajaxComplete", [jqXHR, s]);
                        if (!(--jQuery.active)) {
                            jQuery.event.trigger("ajaxStop")
                        }
                    }
                }

                deferred.promise(jqXHR);
                jqXHR.success = jqXHR.done;
                jqXHR.error = jqXHR.fail;
                jqXHR.complete = completeDeferred.add;
                jqXHR.statusCode = function (map) {
                    if (map) {
                        var tmp;
                        if (state < 2) {
                            for (tmp in map) {
                                statusCode[tmp] = [statusCode[tmp], map[tmp]]
                            }
                        } else {
                            tmp = map[jqXHR.status];
                            jqXHR.always(tmp)
                        }
                    }
                    return this
                };
                s.url = ((url || s.url) + "").replace(rhash, "").replace(rprotocol, ajaxLocParts[1] + "//");
                s.dataTypes = jQuery.trim(s.dataType || "*").toLowerCase().split(core_rspace);
                if (s.crossDomain == null) {
                    parts = rurl.exec(s.url.toLowerCase());
                    s.crossDomain = !!(parts && (parts[1] !== ajaxLocParts[1] || parts[2] !== ajaxLocParts[2] || (parts[3] || (parts[1] === "http:" ? 80 : 443)) != (ajaxLocParts[3] || (ajaxLocParts[1] === "http:" ? 80 : 443))))
                }
                if (s.data && s.processData && typeof s.data !== "string") {
                    s.data = jQuery.param(s.data, s.traditional)
                }
                inspectPrefiltersOrTransports(prefilters, s, options, jqXHR);
                if (state === 2) {
                    return jqXHR
                }
                fireGlobals = s.global;
                s.type = s.type.toUpperCase();
                s.hasContent = !rnoContent.test(s.type);
                if (fireGlobals && jQuery.active++ === 0) {
                    jQuery.event.trigger("ajaxStart")
                }
                if (!s.hasContent) {
                    if (s.data) {
                        s.url += (rquery.test(s.url) ? "&" : "?") + s.data;
                        delete s.data
                    }
                    ifModifiedKey = s.url;
                    if (s.cache === false) {
                        var ts = jQuery.now(), ret = s.url.replace(rts, "$1_=" + ts);
                        s.url = ret + ((ret === s.url) ? (rquery.test(s.url) ? "&" : "?") + "_=" + ts : "")
                    }
                }
                if (s.data && s.hasContent && s.contentType !== false || options.contentType) {
                    jqXHR.setRequestHeader("Content-Type", s.contentType)
                }
                if (s.ifModified) {
                    ifModifiedKey = ifModifiedKey || s.url;
                    if (jQuery.lastModified[ifModifiedKey]) {
                        jqXHR.setRequestHeader("If-Modified-Since", jQuery.lastModified[ifModifiedKey])
                    }
                    if (jQuery.etag[ifModifiedKey]) {
                        jqXHR.setRequestHeader("If-None-Match", jQuery.etag[ifModifiedKey])
                    }
                }
                jqXHR.setRequestHeader("Accept", s.dataTypes[0] && s.accepts[s.dataTypes[0]] ? s.accepts[s.dataTypes[0]] + (s.dataTypes[0] !== "*" ? ", " + allTypes + "; q=0.01" : "") : s.accepts["*"]);
                for (i in s.headers) {
                    jqXHR.setRequestHeader(i, s.headers[i])
                }
                if (s.beforeSend && (s.beforeSend.call(callbackContext, jqXHR, s) === false || state === 2)) {
                    return jqXHR.abort()
                }
                strAbort = "abort";
                for (i in {success: 1, error: 1, complete: 1}) {
                    jqXHR[i](s[i])
                }
                transport = inspectPrefiltersOrTransports(transports, s, options, jqXHR);
                if (!transport) {
                    done(-1, "No Transport")
                } else {
                    jqXHR.readyState = 1;
                    if (fireGlobals) {
                        globalEventContext.trigger("ajaxSend", [jqXHR, s])
                    }
                    if (s.async && s.timeout > 0) {
                        timeoutTimer = setTimeout(function () {
                            jqXHR.abort("timeout")
                        }, s.timeout)
                    }
                    try {
                        state = 1;
                        transport.send(requestHeaders, done)
                    } catch (e) {
                        if (state < 2) {
                            done(-1, e)
                        } else {
                            throw e
                        }
                    }
                }
                return jqXHR
            },
            active: 0,
            lastModified: {},
            etag: {}
        });
        function ajaxHandleResponses(s, jqXHR, responses) {
            var ct, type, finalDataType, firstDataType, contents = s.contents, dataTypes = s.dataTypes, responseFields = s.responseFields;
            for (type in responseFields) {
                if (type in responses) {
                    jqXHR[responseFields[type]] = responses[type]
                }
            }
            while (dataTypes[0] === "*") {
                dataTypes.shift();
                if (ct === undefined) {
                    ct = s.mimeType || jqXHR.getResponseHeader("content-type")
                }
            }
            if (ct) {
                for (type in contents) {
                    if (contents[type] && contents[type].test(ct)) {
                        dataTypes.unshift(type);
                        break
                    }
                }
            }
            if (dataTypes[0] in responses) {
                finalDataType = dataTypes[0]
            } else {
                for (type in responses) {
                    if (!dataTypes[0] || s.converters[type + " " + dataTypes[0]]) {
                        finalDataType = type;
                        break
                    }
                    if (!firstDataType) {
                        firstDataType = type
                    }
                }
                finalDataType = finalDataType || firstDataType
            }
            if (finalDataType) {
                if (finalDataType !== dataTypes[0]) {
                    dataTypes.unshift(finalDataType)
                }
                return responses[finalDataType]
            }
        }

        function ajaxConvert(s, response) {
            var conv, conv2, current, tmp, dataTypes = s.dataTypes.slice(), prev = dataTypes[0], converters = {}, i = 0;
            if (s.dataFilter) {
                response = s.dataFilter(response, s.dataType)
            }
            if (dataTypes[1]) {
                for (conv in s.converters) {
                    converters[conv.toLowerCase()] = s.converters[conv]
                }
            }
            for (; (current = dataTypes[++i]);) {
                if (current !== "*") {
                    if (prev !== "*" && prev !== current) {
                        conv = converters[prev + " " + current] || converters["* " + current];
                        if (!conv) {
                            for (conv2 in converters) {
                                tmp = conv2.split(" ");
                                if (tmp[1] === current) {
                                    conv = converters[prev + " " + tmp[0]] || converters["* " + tmp[0]];
                                    if (conv) {
                                        if (conv === true) {
                                            conv = converters[conv2]
                                        } else {
                                            if (converters[conv2] !== true) {
                                                current = tmp[0];
                                                dataTypes.splice(i--, 0, current)
                                            }
                                        }
                                        break
                                    }
                                }
                            }
                        }
                        if (conv !== true) {
                            if (conv && s["throws"]) {
                                response = conv(response)
                            } else {
                                try {
                                    response = conv(response)
                                } catch (e) {
                                    return {state: "parsererror", error: conv ? e : "No conversion from " + prev + " to " + current}
                                }
                            }
                        }
                    }
                    prev = current
                }
            }
            return {state: "success", data: response}
        }

        var oldCallbacks = [], rquestion = /\?/, rjsonp = /(=)\?(?=&|$)|\?\?/, nonce = jQuery.now();
        jQuery.ajaxSetup({
            jsonp: "callback", jsonpCallback: function () {
                var callback = oldCallbacks.pop() || (jQuery.expando + "_" + (nonce++));
                this[callback] = true;
                return callback
            }
        });
        jQuery.ajaxPrefilter("json jsonp", function (s, originalSettings, jqXHR) {
            var callbackName, overwritten, responseContainer, data = s.data, url = s.url, hasCallback = s.jsonp !== false, replaceInUrl = hasCallback && rjsonp.test(url), replaceInData = hasCallback && !replaceInUrl && typeof data === "string" && !(s.contentType || "").indexOf("application/x-www-form-urlencoded") && rjsonp.test(data);
            if (s.dataTypes[0] === "jsonp" || replaceInUrl || replaceInData) {
                callbackName = s.jsonpCallback = jQuery.isFunction(s.jsonpCallback) ? s.jsonpCallback() : s.jsonpCallback;
                overwritten = window[callbackName];
                if (replaceInUrl) {
                    s.url = url.replace(rjsonp, "$1" + callbackName)
                } else {
                    if (replaceInData) {
                        s.data = data.replace(rjsonp, "$1" + callbackName)
                    } else {
                        if (hasCallback) {
                            s.url += (rquestion.test(url) ? "&" : "?") + s.jsonp + "=" + callbackName
                        }
                    }
                }
                s.converters["script json"] = function () {
                    if (!responseContainer) {
                        jQuery.error(callbackName + " was not called")
                    }
                    return responseContainer[0]
                };
                s.dataTypes[0] = "json";
                window[callbackName] = function () {
                    responseContainer = arguments
                };
                jqXHR.always(function () {
                    window[callbackName] = overwritten;
                    if (s[callbackName]) {
                        s.jsonpCallback = originalSettings.jsonpCallback;
                        oldCallbacks.push(callbackName)
                    }
                    if (responseContainer && jQuery.isFunction(overwritten)) {
                        overwritten(responseContainer[0])
                    }
                    responseContainer = overwritten = undefined
                });
                return "script"
            }
        });
        jQuery.ajaxSetup({
            accepts: {script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"},
            contents: {script: /javascript|ecmascript/},
            converters: {
                "text script": function (text) {
                    jQuery.globalEval(text);
                    return text
                }
            }
        });
        jQuery.ajaxPrefilter("script", function (s) {
            if (s.cache === undefined) {
                s.cache = false
            }
            if (s.crossDomain) {
                s.type = "GET";
                s.global = false
            }
        });
        jQuery.ajaxTransport("script", function (s) {
            if (s.crossDomain) {
                var script, head = document.head || document.getElementsByTagName("head")[0] || document.documentElement;
                return {
                    send: function (_, callback) {
                        script = document.createElement("script");
                        script.async = "async";
                        if (s.scriptCharset) {
                            script.charset = s.scriptCharset
                        }
                        script.src = s.url;
                        script.onload = script.onreadystatechange = function (_, isAbort) {
                            if (isAbort || !script.readyState || /loaded|complete/.test(script.readyState)) {
                                script.onload = script.onreadystatechange = null;
                                if (head && script.parentNode) {
                                    head.removeChild(script)
                                }
                                script = undefined;
                                if (!isAbort) {
                                    callback(200, "success")
                                }
                            }
                        };
                        head.insertBefore(script, head.firstChild)
                    }, abort: function () {
                        if (script) {
                            script.onload(0, 1)
                        }
                    }
                }
            }
        });
        var xhrCallbacks, xhrOnUnloadAbort = window.ActiveXObject ? function () {
            for (var key in xhrCallbacks) {
                xhrCallbacks[key](0, 1)
            }
        } : false, xhrId = 0;

        function createStandardXHR() {
            try {
                return new window.XMLHttpRequest()
            } catch (e) {
            }
        }

        function createActiveXHR() {
            try {
                return new window.ActiveXObject("Microsoft.XMLHTTP")
            } catch (e) {
            }
        }

        jQuery.ajaxSettings.xhr = window.ActiveXObject ? function () {
            return !this.isLocal && createStandardXHR() || createActiveXHR()
        } : createStandardXHR;
        (function (xhr) {
            jQuery.extend(jQuery.support, {ajax: !!xhr, cors: !!xhr && ("withCredentials" in xhr)})
        })(jQuery.ajaxSettings.xhr());
        if (jQuery.support.ajax) {
            jQuery.ajaxTransport(function (s) {
                if (!s.crossDomain || jQuery.support.cors) {
                    var callback;
                    return {
                        send: function (headers, complete) {
                            var handle, i, xhr = s.xhr();
                            if (s.username) {
                                xhr.open(s.type, s.url, s.async, s.username, s.password)
                            } else {
                                xhr.open(s.type, s.url, s.async)
                            }
                            if (s.xhrFields) {
                                for (i in s.xhrFields) {
                                    xhr[i] = s.xhrFields[i]
                                }
                            }
                            if (s.mimeType && xhr.overrideMimeType) {
                                xhr.overrideMimeType(s.mimeType)
                            }
                            if (!s.crossDomain && !headers["X-Requested-With"]) {
                                headers["X-Requested-With"] = "XMLHttpRequest"
                            }
                            try {
                                for (i in headers) {
                                    xhr.setRequestHeader(i, headers[i])
                                }
                            } catch (_) {
                            }
                            xhr.send((s.hasContent && s.data) || null);
                            callback = function (_, isAbort) {
                                var status, statusText, responseHeaders, responses, xml;
                                try {
                                    if (callback && (isAbort || xhr.readyState === 4)) {
                                        callback = undefined;
                                        if (handle) {
                                            xhr.onreadystatechange = jQuery.noop;
                                            if (xhrOnUnloadAbort) {
                                                delete xhrCallbacks[handle]
                                            }
                                        }
                                        if (isAbort) {
                                            if (xhr.readyState !== 4) {
                                                xhr.abort()
                                            }
                                        } else {
                                            status = xhr.status;
                                            responseHeaders = xhr.getAllResponseHeaders();
                                            responses = {};
                                            xml = xhr.responseXML;
                                            if (xml && xml.documentElement) {
                                                responses.xml = xml
                                            }
                                            try {
                                                responses.text = xhr.responseText
                                            } catch (e) {
                                            }
                                            try {
                                                statusText = xhr.statusText
                                            } catch (e) {
                                                statusText = ""
                                            }
                                            if (!status && s.isLocal && !s.crossDomain) {
                                                status = responses.text ? 200 : 404
                                            } else {
                                                if (status === 1223) {
                                                    status = 204
                                                }
                                            }
                                        }
                                    }
                                } catch (firefoxAccessException) {
                                    if (!isAbort) {
                                        complete(-1, firefoxAccessException)
                                    }
                                }
                                if (responses) {
                                    complete(status, statusText, responses, responseHeaders)
                                }
                            };
                            if (!s.async) {
                                callback()
                            } else {
                                if (xhr.readyState === 4) {
                                    setTimeout(callback, 0)
                                } else {
                                    handle = ++xhrId;
                                    if (xhrOnUnloadAbort) {
                                        if (!xhrCallbacks) {
                                            xhrCallbacks = {};
                                            jQuery(window).unload(xhrOnUnloadAbort)
                                        }
                                        xhrCallbacks[handle] = callback
                                    }
                                    xhr.onreadystatechange = callback
                                }
                            }
                        }, abort: function () {
                            if (callback) {
                                callback(0, 1)
                            }
                        }
                    }
                }
            })
        }
        var fxNow, timerId, rfxtypes = /^(?:toggle|show|hide)$/, rfxnum = new RegExp("^(?:([-+])=|)(" + core_pnum + ")([a-z%]*)$", "i"), rrun = /queueHooks$/, animationPrefilters = [defaultPrefilter], tweeners = {
            "*": [function (prop, value) {
                var end, unit, tween = this.createTween(prop, value), parts = rfxnum.exec(value), target = tween.cur(), start = +target || 0, scale = 1, maxIterations = 20;
                if (parts) {
                    end = +parts[2];
                    unit = parts[3] || (jQuery.cssNumber[prop] ? "" : "px");
                    if (unit !== "px" && start) {
                        start = jQuery.css(tween.elem, prop, true) || end || 1;
                        do {
                            scale = scale || ".5";
                            start = start / scale;
                            jQuery.style(tween.elem, prop, start + unit)
                        } while (scale !== (scale = tween.cur() / target) && scale !== 1 && --maxIterations)
                    }
                    tween.unit = unit;
                    tween.start = start;
                    tween.end = parts[1] ? start + (parts[1] + 1) * end : end
                }
                return tween
            }]
        };

        function createFxNow() {
            setTimeout(function () {
                fxNow = undefined
            }, 0);
            return (fxNow = jQuery.now())
        }

        function createTweens(animation, props) {
            jQuery.each(props, function (prop, value) {
                var collection = (tweeners[prop] || []).concat(tweeners["*"]), index = 0, length = collection.length;
                for (; index < length; index++) {
                    if (collection[index].call(animation, prop, value)) {
                        return
                    }
                }
            })
        }

        function Animation(elem, properties, options) {
            var result, index = 0, tweenerIndex = 0, length = animationPrefilters.length, deferred = jQuery.Deferred().always(function () {
                delete tick.elem
            }), tick = function () {
                var currentTime = fxNow || createFxNow(), remaining = Math.max(0, animation.startTime + animation.duration - currentTime), temp = remaining / animation.duration || 0, percent = 1 - temp, index = 0, length = animation.tweens.length;
                for (; index < length; index++) {
                    animation.tweens[index].run(percent)
                }
                deferred.notifyWith(elem, [animation, percent, remaining]);
                if (percent < 1 && length) {
                    return remaining
                } else {
                    deferred.resolveWith(elem, [animation]);
                    return false
                }
            }, animation = deferred.promise({
                elem: elem,
                props: jQuery.extend({}, properties),
                opts: jQuery.extend(true, {specialEasing: {}}, options),
                originalProperties: properties,
                originalOptions: options,
                startTime: fxNow || createFxNow(),
                duration: options.duration,
                tweens: [],
                createTween: function (prop, end, easing) {
                    var tween = jQuery.Tween(elem, animation.opts, prop, end, animation.opts.specialEasing[prop] || animation.opts.easing);
                    animation.tweens.push(tween);
                    return tween
                },
                stop: function (gotoEnd) {
                    var index = 0, length = gotoEnd ? animation.tweens.length : 0;
                    for (; index < length; index++) {
                        animation.tweens[index].run(1)
                    }
                    if (gotoEnd) {
                        deferred.resolveWith(elem, [animation, gotoEnd])
                    } else {
                        deferred.rejectWith(elem, [animation, gotoEnd])
                    }
                    return this
                }
            }), props = animation.props;
            propFilter(props, animation.opts.specialEasing);
            for (; index < length; index++) {
                result = animationPrefilters[index].call(animation, elem, props, animation.opts);
                if (result) {
                    return result
                }
            }
            createTweens(animation, props);
            if (jQuery.isFunction(animation.opts.start)) {
                animation.opts.start.call(elem, animation)
            }
            jQuery.fx.timer(jQuery.extend(tick, {anim: animation, queue: animation.opts.queue, elem: elem}));
            return animation.progress(animation.opts.progress).done(animation.opts.done, animation.opts.complete).fail(animation.opts.fail).always(animation.opts.always)
        }

        function propFilter(props, specialEasing) {
            var index, name, easing, value, hooks;
            for (index in props) {
                name = jQuery.camelCase(index);
                easing = specialEasing[name];
                value = props[index];
                if (jQuery.isArray(value)) {
                    easing = value[1];
                    value = props[index] = value[0]
                }
                if (index !== name) {
                    props[name] = value;
                    delete props[index]
                }
                hooks = jQuery.cssHooks[name];
                if (hooks && "expand" in hooks) {
                    value = hooks.expand(value);
                    delete props[name];
                    for (index in value) {
                        if (!(index in props)) {
                            props[index] = value[index];
                            specialEasing[index] = easing
                        }
                    }
                } else {
                    specialEasing[name] = easing
                }
            }
        }

        jQuery.Animation = jQuery.extend(Animation, {
            tweener: function (props, callback) {
                if (jQuery.isFunction(props)) {
                    callback = props;
                    props = ["*"]
                } else {
                    props = props.split(" ")
                }
                var prop, index = 0, length = props.length;
                for (; index < length; index++) {
                    prop = props[index];
                    tweeners[prop] = tweeners[prop] || [];
                    tweeners[prop].unshift(callback)
                }
            }, prefilter: function (callback, prepend) {
                if (prepend) {
                    animationPrefilters.unshift(callback)
                } else {
                    animationPrefilters.push(callback)
                }
            }
        });
        function defaultPrefilter(elem, props, opts) {
            var index, prop, value, length, dataShow, toggle, tween, hooks, oldfire, anim = this, style = elem.style, orig = {}, handled = [], hidden = elem.nodeType && isHidden(elem);
            if (!opts.queue) {
                hooks = jQuery._queueHooks(elem, "fx");
                if (hooks.unqueued == null) {
                    hooks.unqueued = 0;
                    oldfire = hooks.empty.fire;
                    hooks.empty.fire = function () {
                        if (!hooks.unqueued) {
                            oldfire()
                        }
                    }
                }
                hooks.unqueued++;
                anim.always(function () {
                    anim.always(function () {
                        hooks.unqueued--;
                        if (!jQuery.queue(elem, "fx").length) {
                            hooks.empty.fire()
                        }
                    })
                })
            }
            if (elem.nodeType === 1 && ("height" in props || "width" in props)) {
                opts.overflow = [style.overflow, style.overflowX, style.overflowY];
                if (jQuery.css(elem, "display") === "inline" && jQuery.css(elem, "float") === "none") {
                    if (!jQuery.support.inlineBlockNeedsLayout || css_defaultDisplay(elem.nodeName) === "inline") {
                        style.display = "inline-block"
                    } else {
                        style.zoom = 1
                    }
                }
            }
            if (opts.overflow) {
                style.overflow = "hidden";
                if (!jQuery.support.shrinkWrapBlocks) {
                    anim.done(function () {
                        style.overflow = opts.overflow[0];
                        style.overflowX = opts.overflow[1];
                        style.overflowY = opts.overflow[2]
                    })
                }
            }
            for (index in props) {
                value = props[index];
                if (rfxtypes.exec(value)) {
                    delete props[index];
                    toggle = toggle || value === "toggle";
                    if (value === (hidden ? "hide" : "show")) {
                        continue
                    }
                    handled.push(index)
                }
            }
            length = handled.length;
            if (length) {
                dataShow = jQuery._data(elem, "fxshow") || jQuery._data(elem, "fxshow", {});
                if ("hidden" in dataShow) {
                    hidden = dataShow.hidden
                }
                if (toggle) {
                    dataShow.hidden = !hidden
                }
                if (hidden) {
                    jQuery(elem).show()
                } else {
                    anim.done(function () {
                        jQuery(elem).hide()
                    })
                }
                anim.done(function () {
                    var prop;
                    jQuery.removeData(elem, "fxshow", true);
                    for (prop in orig) {
                        jQuery.style(elem, prop, orig[prop])
                    }
                });
                for (index = 0; index < length; index++) {
                    prop = handled[index];
                    tween = anim.createTween(prop, hidden ? dataShow[prop] : 0);
                    orig[prop] = dataShow[prop] || jQuery.style(elem, prop);
                    if (!(prop in dataShow)) {
                        dataShow[prop] = tween.start;
                        if (hidden) {
                            tween.end = tween.start;
                            tween.start = prop === "width" || prop === "height" ? 1 : 0
                        }
                    }
                }
            }
        }

        function Tween(elem, options, prop, end, easing) {
            return new Tween.prototype.init(elem, options, prop, end, easing)
        }

        jQuery.Tween = Tween;
        Tween.prototype = {
            constructor: Tween, init: function (elem, options, prop, end, easing, unit) {
                this.elem = elem;
                this.prop = prop;
                this.easing = easing || "swing";
                this.options = options;
                this.start = this.now = this.cur();
                this.end = end;
                this.unit = unit || (jQuery.cssNumber[prop] ? "" : "px")
            }, cur: function () {
                var hooks = Tween.propHooks[this.prop];
                return hooks && hooks.get ? hooks.get(this) : Tween.propHooks._default.get(this)
            }, run: function (percent) {
                var eased, hooks = Tween.propHooks[this.prop];
                if (this.options.duration) {
                    this.pos = eased = jQuery.easing[this.easing](percent, this.options.duration * percent, 0, 1, this.options.duration)
                } else {
                    this.pos = eased = percent
                }
                this.now = (this.end - this.start) * eased + this.start;
                if (this.options.step) {
                    this.options.step.call(this.elem, this.now, this)
                }
                if (hooks && hooks.set) {
                    hooks.set(this)
                } else {
                    Tween.propHooks._default.set(this)
                }
                return this
            }
        };
        Tween.prototype.init.prototype = Tween.prototype;
        Tween.propHooks = {
            _default: {
                get: function (tween) {
                    var result;
                    if (tween.elem[tween.prop] != null && (!tween.elem.style || tween.elem.style[tween.prop] == null)) {
                        return tween.elem[tween.prop]
                    }
                    result = jQuery.css(tween.elem, tween.prop, false, "");
                    return !result || result === "auto" ? 0 : result
                }, set: function (tween) {
                    if (jQuery.fx.step[tween.prop]) {
                        jQuery.fx.step[tween.prop](tween)
                    } else {
                        if (tween.elem.style && (tween.elem.style[jQuery.cssProps[tween.prop]] != null || jQuery.cssHooks[tween.prop])) {
                            jQuery.style(tween.elem, tween.prop, tween.now + tween.unit)
                        } else {
                            tween.elem[tween.prop] = tween.now
                        }
                    }
                }
            }
        };
        Tween.propHooks.scrollTop = Tween.propHooks.scrollLeft = {
            set: function (tween) {
                if (tween.elem.nodeType && tween.elem.parentNode) {
                    tween.elem[tween.prop] = tween.now
                }
            }
        };
        jQuery.each(["toggle", "show", "hide"], function (i, name) {
            var cssFn = jQuery.fn[name];
            jQuery.fn[name] = function (speed, easing, callback) {
                return speed == null || typeof speed === "boolean" || (!i && jQuery.isFunction(speed) && jQuery.isFunction(easing)) ? cssFn.apply(this, arguments) : this.animate(genFx(name, true), speed, easing, callback)
            }
        });
        jQuery.fn.extend({
            fadeTo: function (speed, to, easing, callback) {
                return this.filter(isHidden).css("opacity", 0).show().end().animate({opacity: to}, speed, easing, callback)
            }, animate: function (prop, speed, easing, callback) {
                var empty = jQuery.isEmptyObject(prop), optall = jQuery.speed(speed, easing, callback), doAnimation = function () {
                    var anim = Animation(this, jQuery.extend({}, prop), optall);
                    if (empty) {
                        anim.stop(true)
                    }
                };
                return empty || optall.queue === false ? this.each(doAnimation) : this.queue(optall.queue, doAnimation)
            }, stop: function (type, clearQueue, gotoEnd) {
                var stopQueue = function (hooks) {
                    var stop = hooks.stop;
                    delete hooks.stop;
                    stop(gotoEnd)
                };
                if (typeof type !== "string") {
                    gotoEnd = clearQueue;
                    clearQueue = type;
                    type = undefined
                }
                if (clearQueue && type !== false) {
                    this.queue(type || "fx", [])
                }
                return this.each(function () {
                    var dequeue = true, index = type != null && type + "queueHooks", timers = jQuery.timers, data = jQuery._data(this);
                    if (index) {
                        if (data[index] && data[index].stop) {
                            stopQueue(data[index])
                        }
                    } else {
                        for (index in data) {
                            if (data[index] && data[index].stop && rrun.test(index)) {
                                stopQueue(data[index])
                            }
                        }
                    }
                    for (index = timers.length; index--;) {
                        if (timers[index].elem === this && (type == null || timers[index].queue === type)) {
                            timers[index].anim.stop(gotoEnd);
                            dequeue = false;
                            timers.splice(index, 1)
                        }
                    }
                    if (dequeue || !gotoEnd) {
                        jQuery.dequeue(this, type)
                    }
                })
            }
        });
        function genFx(type, includeWidth) {
            var which, attrs = {height: type}, i = 0;
            includeWidth = includeWidth ? 1 : 0;
            for (; i < 4; i += 2 - includeWidth) {
                which = cssExpand[i];
                attrs["margin" + which] = attrs["padding" + which] = type
            }
            if (includeWidth) {
                attrs.opacity = attrs.width = type
            }
            return attrs
        }

        jQuery.each({
            slideDown: genFx("show"),
            slideUp: genFx("hide"),
            slideToggle: genFx("toggle"),
            fadeIn: {opacity: "show"},
            fadeOut: {opacity: "hide"},
            fadeToggle: {opacity: "toggle"}
        }, function (name, props) {
            jQuery.fn[name] = function (speed, easing, callback) {
                return this.animate(props, speed, easing, callback)
            }
        });
        jQuery.speed = function (speed, easing, fn) {
            var opt = speed && typeof speed === "object" ? jQuery.extend({}, speed) : {
                complete: fn || !fn && easing || jQuery.isFunction(speed) && speed,
                duration: speed,
                easing: fn && easing || easing && !jQuery.isFunction(easing) && easing
            };
            opt.duration = jQuery.fx.off ? 0 : typeof opt.duration === "number" ? opt.duration : opt.duration in jQuery.fx.speeds ? jQuery.fx.speeds[opt.duration] : jQuery.fx.speeds._default;
            if (opt.queue == null || opt.queue === true) {
                opt.queue = "fx"
            }
            opt.old = opt.complete;
            opt.complete = function () {
                if (jQuery.isFunction(opt.old)) {
                    opt.old.call(this)
                }
                if (opt.queue) {
                    jQuery.dequeue(this, opt.queue)
                }
            };
            return opt
        };
        jQuery.easing = {
            linear: function (p) {
                return p
            }, swing: function (p) {
                return 0.5 - Math.cos(p * Math.PI) / 2
            }
        };
        jQuery.timers = [];
        jQuery.fx = Tween.prototype.init;
        jQuery.fx.tick = function () {
            var timer, timers = jQuery.timers, i = 0;
            fxNow = jQuery.now();
            for (; i < timers.length; i++) {
                timer = timers[i];
                if (!timer() && timers[i] === timer) {
                    timers.splice(i--, 1)
                }
            }
            if (!timers.length) {
                jQuery.fx.stop()
            }
            fxNow = undefined
        };
        jQuery.fx.timer = function (timer) {
            if (timer() && jQuery.timers.push(timer) && !timerId) {
                timerId = setInterval(jQuery.fx.tick, jQuery.fx.interval)
            }
        };
        jQuery.fx.interval = 13;
        jQuery.fx.stop = function () {
            clearInterval(timerId);
            timerId = null
        };
        jQuery.fx.speeds = {slow: 600, fast: 200, _default: 400};
        jQuery.fx.step = {};
        if (jQuery.expr && jQuery.expr.filters) {
            jQuery.expr.filters.animated = function (elem) {
                return jQuery.grep(jQuery.timers, function (fn) {
                    return elem === fn.elem
                }).length
            }
        }
        var rroot = /^(?:body|html)$/i;
        jQuery.fn.offset = function (options) {
            if (arguments.length) {
                return options === undefined ? this : this.each(function (i) {
                    jQuery.offset.setOffset(this, options, i)
                })
            }
            var docElem, body, win, clientTop, clientLeft, scrollTop, scrollLeft, box = {top: 0, left: 0}, elem = this[0], doc = elem && elem.ownerDocument;
            if (!doc) {
                return
            }
            if ((body = doc.body) === elem) {
                return jQuery.offset.bodyOffset(elem)
            }
            docElem = doc.documentElement;
            if (!jQuery.contains(docElem, elem)) {
                return box
            }
            if (typeof elem.getBoundingClientRect !== "undefined") {
                box = elem.getBoundingClientRect()
            }
            win = getWindow(doc);
            clientTop = docElem.clientTop || body.clientTop || 0;
            clientLeft = docElem.clientLeft || body.clientLeft || 0;
            scrollTop = win.pageYOffset || docElem.scrollTop;
            scrollLeft = win.pageXOffset || docElem.scrollLeft;
            return {top: box.top + scrollTop - clientTop, left: box.left + scrollLeft - clientLeft}
        };
        jQuery.offset = {
            bodyOffset: function (body) {
                var top = body.offsetTop, left = body.offsetLeft;
                if (jQuery.support.doesNotIncludeMarginInBodyOffset) {
                    top += parseFloat(jQuery.css(body, "marginTop")) || 0;
                    left += parseFloat(jQuery.css(body, "marginLeft")) || 0
                }
                return {top: top, left: left}
            }, setOffset: function (elem, options, i) {
                var position = jQuery.css(elem, "position");
                if (position === "static") {
                    elem.style.position = "relative"
                }
                var curElem = jQuery(elem), curOffset = curElem.offset(), curCSSTop = jQuery.css(elem, "top"), curCSSLeft = jQuery.css(elem, "left"), calculatePosition = (position === "absolute" || position === "fixed") && jQuery.inArray("auto", [curCSSTop, curCSSLeft]) > -1, props = {}, curPosition = {}, curTop, curLeft;
                if (calculatePosition) {
                    curPosition = curElem.position();
                    curTop = curPosition.top;
                    curLeft = curPosition.left
                } else {
                    curTop = parseFloat(curCSSTop) || 0;
                    curLeft = parseFloat(curCSSLeft) || 0
                }
                if (jQuery.isFunction(options)) {
                    options = options.call(elem, i, curOffset)
                }
                if (options.top != null) {
                    props.top = (options.top - curOffset.top) + curTop
                }
                if (options.left != null) {
                    props.left = (options.left - curOffset.left) + curLeft
                }
                if ("using" in options) {
                    options.using.call(elem, props)
                } else {
                    curElem.css(props)
                }
            }
        };
        jQuery.fn.extend({
            position: function () {
                if (!this[0]) {
                    return
                }
                var elem = this[0], offsetParent = this.offsetParent(), offset = this.offset(), parentOffset = rroot.test(offsetParent[0].nodeName) ? {top: 0, left: 0} : offsetParent.offset();
                offset.top -= parseFloat(jQuery.css(elem, "marginTop")) || 0;
                offset.left -= parseFloat(jQuery.css(elem, "marginLeft")) || 0;
                parentOffset.top += parseFloat(jQuery.css(offsetParent[0], "borderTopWidth")) || 0;
                parentOffset.left += parseFloat(jQuery.css(offsetParent[0], "borderLeftWidth")) || 0;
                return {top: offset.top - parentOffset.top, left: offset.left - parentOffset.left}
            }, offsetParent: function () {
                return this.map(function () {
                    var offsetParent = this.offsetParent || document.body;
                    while (offsetParent && (!rroot.test(offsetParent.nodeName) && jQuery.css(offsetParent, "position") === "static")) {
                        offsetParent = offsetParent.offsetParent
                    }
                    return offsetParent || document.body
                })
            }
        });
        jQuery.each({scrollLeft: "pageXOffset", scrollTop: "pageYOffset"}, function (method, prop) {
            var top = /Y/.test(prop);
            jQuery.fn[method] = function (val) {
                return jQuery.access(this, function (elem, method, val) {
                    var win = getWindow(elem);
                    if (val === undefined) {
                        return win ? (prop in win) ? win[prop] : win.document.documentElement[method] : elem[method]
                    }
                    if (win) {
                        win.scrollTo(!top ? val : jQuery(win).scrollLeft(), top ? val : jQuery(win).scrollTop())
                    } else {
                        elem[method] = val
                    }
                }, method, val, arguments.length, null)
            }
        });
        function getWindow(elem) {
            return jQuery.isWindow(elem) ? elem : elem.nodeType === 9 ? elem.defaultView || elem.parentWindow : false
        }

        jQuery.each({Height: "height", Width: "width"}, function (name, type) {
            jQuery.each({padding: "inner" + name, content: type, "": "outer" + name}, function (defaultExtra, funcName) {
                jQuery.fn[funcName] = function (margin, value) {
                    var chainable = arguments.length && (defaultExtra || typeof margin !== "boolean"), extra = defaultExtra || (margin === true || value === true ? "margin" : "border");
                    return jQuery.access(this, function (elem, type, value) {
                        var doc;
                        if (jQuery.isWindow(elem)) {
                            return elem.document.documentElement["client" + name]
                        }
                        if (elem.nodeType === 9) {
                            doc = elem.documentElement;
                            return Math.max(elem.body["scroll" + name], doc["scroll" + name], elem.body["offset" + name], doc["offset" + name], doc["client" + name])
                        }
                        return value === undefined ? jQuery.css(elem, type, value, extra) : jQuery.style(elem, type, value, extra)
                    }, type, chainable ? margin : undefined, chainable, null)
                }
            })
        });
        window.jQuery = window.$ = jQuery;
        if (typeof define === "function" && define.amd && define.amd.jQuery) {
            define("jquery", [], function () {
                return jQuery
            })
        }
    })(window);
    define("lib/clone", ["require"], function (require) {
        var clone = function (json) {
            return JSON.parse(JSON.stringify(json))
        };
        return clone
    });
    define("main/parse_query_config", [], function () {
        return function () {
            var query = location.search;
            if (query[0] === "?") {
                query = query.slice(1)
            }
            var paramStrings = query.split("&");
            var params = {};
            for (var i = 0; i < paramStrings.length; i++) {
                var pair = paramStrings[i].split("=");
                params[pair[0]] = (pair.length === 2) ? pair[1] : true
            }
            function checkOption(option) {
                return params.hasOwnProperty(option)
            }

            var config = {};
            config.testing = checkOption("testing");
            config.menus = checkOption("menus");
            config.zoomButtons = checkOption("zoomButtons");
            config.keypad = checkOption("embed") ? checkOption("keypad") : true;
            config.maintenance = checkOption("maintenance");
            config.disablelocale = checkOption("disablelocale");
            config.lockViewport = checkOption("lockViewport");
            config.iframe = checkOption("iframe");
            config.folders = true;
            if (checkOption("embed") || checkOption("concepts") || checkOption("noconcat")) {
                config.no_navigation_warning = true
            }
            if (checkOption("embed") || checkOption("concepts")) {
                config.disable_dblclick_zooming = true
            }
            if (checkOption("handwriting")) {
                config.handwriting = true
            }
            if (checkOption("nographpaper")) {
                config.nographpaper = true
            }
            if (checkOption("noexpressions")) {
                config.noexpressions = true
            }
            if (checkOption("expressionsCollapsed")) {
                config.expressionsCollapsed = true
            }
            if (checkOption("nofocus")) {
                config.no_focus = true
            }
            if (!checkOption("noimages") && !checkOption("embed")) {
                config.images = true
            }
            if (checkOption("lang")) {
                config.lang = params.lang
            }
            if (checkOption("detectlocale")) {
                config.detectlocale = true
            }
            config.dragpoints = !checkOption("disabledragpoints");
            config.languagemenu = !checkOption("disablelanguagemenu");
            config.implicit = !checkOption("disableimplicit");
            config.folders = !checkOption("nofolders");
            if (checkOption("ios")) {
                config.tablet = true;
                config.platform = "ios"
            } else {
                if (checkOption("android")) {
                    config.tablet = true;
                    config.platform = "android"
                } else {
                    config.platform = "www"
                }
            }
            return config
        }
    });
    define("config", ["require", "lib/clone", "main/parse_query_config"], function (require) {
        var clone = require("lib/clone");
        var parseQueryConfig = require("main/parse_query_config");
        var config = {};
        if (typeof Desmos !== "undefined" && Desmos.config) {
            config = clone(Desmos.config)
        }
        var re = new RegExp("desmos_config=([^&]+)");
        var match = location.search.match(re);
        if (match !== null) {
            config = JSON.parse(decodeURIComponent(match[1]))
        }
        var queryConfig = parseQueryConfig();
        for (var k in queryConfig) {
            if (!queryConfig.hasOwnProperty(k)) {
                continue
            }
            if (config.hasOwnProperty(k)) {
                continue
            }
            config[k] = queryConfig[k]
        }
        return {
            get: function (prop) {
                return config[prop]
            }, use: function (props, func) {
                var configOriginal = clone(config);
                for (var prop in props) {
                    config[prop] = props[prop]
                }
                try {
                    func()
                } finally {
                    config = configOriginal
                }
            }, all: function () {
                return clone(config)
            }
        }
    });
    define("math/builtin", ["require"], function (require) {
        var BuiltIn = {};
        BuiltIn.mod = function (a, b) {
            return a - b * Math.floor(a / b)
        };
        BuiltIn.min = function (a, b) {
            return (a < b) ? a : b
        };
        BuiltIn.max = function (a, b) {
            return (a > b) ? a : b
        };
        BuiltIn.sign = function (x) {
            if (x === 0) {
                return 0
            }
            if (x > 0) {
                return 1
            }
            if (x < 0) {
                return -1
            }
            return NaN
        };
        BuiltIn.lcm = function (a, b) {
            a = BuiltIn.smartTruncate(a);
            b = BuiltIn.smartTruncate(b);
            var gcd = BuiltIn.getGCD(a, b);
            return Math.abs(a * b / gcd)
        };
        BuiltIn.gcd = function (a, b) {
            return BuiltIn.getGCD(a, b)
        };
        BuiltIn.nCr = function (n, r) {
            n = BuiltIn.smartTruncate(n);
            r = BuiltIn.smartTruncate(r);
            if (r > n || n < 0 || r < 0) {
                return 0
            }
            var total = 1;
            for (var i = 0; i < r; i++) {
                total *= (n - i) / (i + 1)
            }
            return total
        };
        BuiltIn.nPr = function (n, r) {
            n = BuiltIn.smartTruncate(n);
            r = BuiltIn.smartTruncate(r);
            if (r > n || n < 0 || r < 0) {
                return 0
            }
            var total = 1;
            for (var i = 0; i < r; i++) {
                total *= (n - i)
            }
            return total
        };
        BuiltIn.factorial = function (x) {
            return BuiltIn.gamma(x + 1)
        };
        BuiltIn._integerFactorial = function (n) {
            if (n !== Math.floor(n)) {
                return NaN
            }
            if (n < 0) {
                return NaN
            }
            if (n > 170) {
                return NaN
            }
            if (n === 0 || n === 1) {
                return 1
            }
            var output = 1;
            for (var i = 2; i <= n; i++) {
                output *= i
            }
            return output
        };
        BuiltIn.gamma = function (x) {
            if (x === Math.floor(x)) {
                return BuiltIn._integerFactorial(x - 1)
            }
            if (x < 0) {
                return Math.PI / (Math.sin(Math.PI * x) * BuiltIn.gamma(1 - x))
            }
            return Math.exp(BuiltIn.lnGamma(x))
        };
        BuiltIn.lnGamma = function (x) {
            if (x < 0) {
                return NaN
            }
            var cof = [57.15623566586292, -59.59796035547549, 14.136097974741746, -0.4919138160976202, 0.00003399464998481189, 0.00004652362892704858, -0.00009837447530487956, 0.0001580887032249125, -0.00021026444172410488, 0.00021743961811521265, -0.0001643181065367639, 0.00008441822398385275, -0.000026190838401581408, 0.0000036899182659531625];
            var s = 0.9999999999999971;
            for (var i = 0; i < 14; i++) {
                s += cof[i] / (x + i + 1)
            }
            var t = x + 5.2421875;
            return (x + 0.5) * Math.log(t) - t + Math.log(2.5066282746310007 * s / x)
        };
        BuiltIn.bernoulliTable = [1 / 6, -1 / 30, 1 / 42, -1 / 30, 5 / 66, -691 / 2730, 7 / 6, -3617 / 510, 43867 / 798, -174611 / 330, 854513 / 138, -236364091 / 2730, 8553103 / 6, -23749461029 / 870];
        BuiltIn.cotDerivative = function (m, x) {
            if (m !== Math.floor(m)) {
                return NaN
            }
            if (m < 0) {
                return NaN
            }
            if (m === 0) {
                return 1 / BuiltIn.tan(x)
            }
            var sinx = BuiltIn.sin(x);
            if (m === 1) {
                return -1 / (sinx * sinx)
            }
            var cosx = BuiltIn.cos(x);
            if (m === 2) {
                return 2 * cosx / (sinx * sinx * sinx)
            }
            var aprev = [0, 2];
            var a;
            var mp, n;
            var t1, t2;
            for (mp = 3; mp <= m; mp++) {
                a = [];
                for (n = 0; n < mp; n++) {
                    t1 = 0;
                    t2 = 0;
                    if (n > 0) {
                        t1 = (mp - n + 1) * aprev[n - 1]
                    }
                    if (n + 2 < mp) {
                        t2 = (n + 1) * aprev[n + 1]
                    }
                    a.push(-(t1 + t2))
                }
                aprev = a
            }
            var s = 0;
            for (n = m - 1; n >= 0; n--) {
                s = a[n] + cosx * s
            }
            return s / Math.pow(sinx, m + 1)
        };
        BuiltIn.polyGamma = function (m, n) {
            if (m < 0) {
                return NaN
            }
            if (m !== Math.floor(m)) {
                return NaN
            }
            var sign = (m % 2 === 0) ? -1 : 1;
            if (n < 0) {
                return -sign * BuiltIn.polyGamma(m, 1 - n) - Math.pow(Math.PI, m + 1) * BuiltIn.cotDerivative(m, Math.PI * n)
            }
            var mfac = BuiltIn.factorial(m);
            var s = 0;
            var npmm = Math.pow(n, -(m + 1));
            while (n < 10) {
                s += npmm;
                n++;
                npmm = Math.pow(n, -(m + 1))
            }
            s += (m === 0) ? -Math.log(n) : npmm * n / m;
            s += 0.5 * npmm;
            var bt = BuiltIn.bernoulliTable;
            var num = m + 1;
            var denom = 2;
            var pre = npmm * n * num / denom;
            var nsqinv = 1 / (n * n);
            for (var k = 1; k <= 14; k++) {
                pre *= nsqinv;
                s += pre * bt[k - 1];
                num++;
                denom++;
                pre *= num / denom;
                num++;
                denom++;
                pre *= num / denom
            }
            return mfac * sign * s
        };
        BuiltIn.getGCD = function (x, y) {
            var a = BuiltIn.smartTruncate(x);
            var b = BuiltIn.smartTruncate(y);
            if (a < 0) {
                a = -a
            }
            if (b < 0) {
                b = -b
            }
            if (b > a) {
                var temp = b;
                b = a;
                a = temp
            }
            if (b === 0) {
                return a
            }
            var m = a % b;
            while (m > 0) {
                a = b;
                b = m;
                m = a % b
            }
            return b
        };
        BuiltIn.toFraction = function (x, maxDenominator) {
            if (x === Infinity) {
                return {n: Infinity, d: 1}
            }
            if (x === -Infinity) {
                return {n: -Infinity, d: 1}
            }
            if (!isFinite(x)) {
                return {n: NaN, d: 1}
            }
            var whole, n0 = 0, n1 = 1, d0 = 1, d1 = 0, n, d;
            if (!maxDenominator) {
                maxDenominator = 1000000
            }
            while (true) {
                whole = Math.floor(x);
                n = whole * n1 + n0;
                d = whole * d1 + d0;
                if (d > maxDenominator) {
                    break
                }
                n0 = n1;
                d0 = d1;
                n1 = n;
                d1 = d;
                if (x === whole) {
                    break
                }
                x = 1 / (x - whole)
            }
            return {n: n1, d: d1}
        };
        BuiltIn.approx = function (x1, x2, bits) {
            var m = Math.max(Math.max(Math.abs(x1), Math.abs(x2)), 1);
            var d = (bits === undefined) ? 0.5 : Math.pow(0.5, bits);
            return m === m + d * Math.abs(x2 - x1)
        };
        BuiltIn.smartTruncate = function (x) {
            if (x < 0) {
                return Math.ceil(x)
            } else {
                return Math.floor(x)
            }
        };
        BuiltIn.log_base = function (n, base) {
            return Math.log(n) / Math.log(base)
        };
        BuiltIn.pow = function (x, n) {
            if (x >= 0 || n === Math.floor(n)) {
                return Math.pow(x, n)
            }
            var frac = BuiltIn.toFraction(n, 100);
            if (BuiltIn.approx(frac.n / frac.d, n, 2) && frac.d % 2 === 1) {
                return (frac.n % 2 === 0 ? 1 : -1) * Math.pow(-x, n)
            }
            return NaN
        };
        BuiltIn.nthroot = function (x, n) {
            return BuiltIn.pow(x, 1 / n)
        };
        var PI_INV = 1 / Math.PI;
        BuiltIn.sin = function (x) {
            if ((x * PI_INV * 2 % 2) + Math.floor(x) === Math.floor(x)) {
                return 0
            }
            return Math.sin(x)
        };
        BuiltIn.cos = function (x) {
            if (((x * PI_INV * 2 + 1) % 2) + Math.floor(x) === Math.floor(x)) {
                return 0
            }
            return Math.cos(x)
        };
        BuiltIn.tan = function (x) {
            if ((x * PI_INV * 2 % 2) + Math.floor(x) === Math.floor(x)) {
                return 0
            }
            if (((x * PI_INV * 2 + 1) % 2) + Math.floor(x) === Math.floor(x)) {
                return Infinity
            }
            return Math.tan(x)
        };
        BuiltIn.sec = function (x) {
            if (((x * PI_INV * 2 + 1) % 2) + Math.floor(x) === Math.floor(x)) {
                return Infinity
            }
            return 1 / Math.cos(x)
        };
        BuiltIn.csc = function (x) {
            if ((x * PI_INV * 2 % 2) + Math.floor(x) === Math.floor(x)) {
                return Infinity
            }
            return 1 / Math.sin(x)
        };
        BuiltIn.cot = function (x) {
            if ((x * PI_INV * 2 % 2) + Math.floor(x) === Math.floor(x)) {
                return Infinity
            }
            if (((x * PI_INV * 2 + 1) % 2) + Math.floor(x) === Math.floor(x)) {
                return 0
            }
            return 1 / Math.tan(x)
        };
        BuiltIn.acot = function (x) {
            return Math.PI / 2 - Math.atan(x)
        };
        BuiltIn.acsc = function (x) {
            return Math.asin(1 / x)
        };
        BuiltIn.asec = function (x) {
            return Math.acos(1 / x)
        };
        BuiltIn.sinh = function (x) {
            return (Math.exp(x) - Math.exp(-x)) / 2
        };
        BuiltIn.cosh = function (x) {
            return (Math.exp(x) + Math.exp(-x)) / 2
        };
        BuiltIn.tanh = function (x) {
            if (x > 0) {
                return (1 - Math.exp(-2 * x)) / (1 + Math.exp(-2 * x))
            } else {
                return (Math.exp(2 * x) - 1) / (Math.exp(2 * x) + 1)
            }
        };
        BuiltIn.sech = function (x) {
            return 1 / BuiltIn.cosh(x)
        };
        BuiltIn.csch = function (x) {
            return 1 / BuiltIn.sinh(x)
        };
        BuiltIn.coth = function (x) {
            return 1 / BuiltIn.tanh(x)
        };
        BuiltIn.asinh = function (x) {
            return Math.log(x + Math.sqrt(x * x + 1))
        };
        BuiltIn.acosh = function (x) {
            return Math.log(x + Math.sqrt(x + 1) * Math.sqrt(x - 1))
        };
        BuiltIn.atanh = function (x) {
            return 0.5 * Math.log((1 + x) / (1 - x))
        };
        BuiltIn.asech = function (x) {
            return Math.log(1 / x + Math.sqrt((1 / x + 1)) * Math.sqrt((1 / x - 1)))
        };
        BuiltIn.acsch = function (x) {
            return Math.log(1 / x + Math.sqrt((1 / (x * x) + 1)))
        };
        BuiltIn.acoth = function (x) {
            return 0.5 * Math.log((x + 1) / (x - 1))
        };
        return BuiltIn
    });
    define("math/evalframe", ["require", "pjs"], function (require) {
        var P = require("pjs");
        var EvalFrame = P(function (frame) {
            frame.init = function (parentFrame) {
                if (parentFrame instanceof EvalFrame) {
                    this.parentFrame = parentFrame
                } else {
                    this.parentFrame = null
                }
                this.variables = {};
                this.functions = {};
                this.evalStrings = {};
                this.definitionIds = {};
                if (this.parentFrame) {
                    for (var variable in this.parentFrame.evalStrings) {
                        this.evalStrings[variable] = this.parentFrame.getEvalStrings(variable)
                    }
                }
            };
            frame.setVariable = function (name, value) {
                this.variables[name] = value
            };
            frame.getVariable = function (name) {
                if (this.variables.hasOwnProperty(name)) {
                    return this.variables[name]
                }
                if (this.parentFrame) {
                    return this.parentFrame.getVariable(name)
                }
                throw ("Variable '" + name + "' not defined")
            };
            frame.setDefinitionId = function (name, id) {
                this.definitionIds[name] = id
            };
            frame.getDefinitionId = function (name) {
                return this.definitionIds[name]
            };
            frame.setFunction = function (name, arity, body, tree, args, source) {
                this.functions[name] = {arity: arity, body: body, tree: tree, source: source, args: args}
            };
            frame.hasFunction = function (name) {
                if (this.functions.hasOwnProperty(name)) {
                    return true
                }
                if (this.parentFrame) {
                    return this.parentFrame.hasFunction(name)
                }
                return false
            };
            frame.hasFunctionWithArity = function (name, arity) {
                if (this.functions.hasOwnProperty(name) && this.functions[name].arity == arity) {
                    return true
                }
                if (this.parentFrame) {
                    return this.parentFrame.hasFunction(name)
                }
                return false
            };
            frame.hasVariable = function (name) {
                if (this.variables.hasOwnProperty(name)) {
                    return true
                }
                if (this.parentFrame) {
                    return this.parentFrame.hasVariable(name)
                }
                return false
            };
            frame.getFunctionTree = function (name) {
                if (this.functions.hasOwnProperty(name)) {
                    var f = this.functions[name];
                    return f.tree
                }
                if (this.parentFrame) {
                    return this.parentFrame.getFunctionTree(name)
                }
                throw ("Function '" + name + "' not defined")
            };
            frame.callFunction = function (name, args) {
                if (this.functions.hasOwnProperty(name)) {
                    var f = this.functions[name];
                    if (f.arity == args.length) {
                        return f.body.apply(null, args)
                    }
                    throw ("Function " + name + " expects " + f.arity + " arguments, but was called with " + args.length)
                }
                if (this.parentFrame) {
                    return this.parentFrame.callFunction(name, args)
                }
                throw ("Function '" + name + "' not defined")
            };
            frame.defines = function (name) {
                return this.hasVariable(name) || this.hasFunction(name)
            };
            frame.arity = function (name) {
                if (this.hasVariable(name)) {
                    return 0
                }
                if (this.hasFunction(name)) {
                    return this.functions[name].arity
                }
                if (this.parentFrame) {
                    return this.parentFrame.arity(name)
                }
            };
            frame.setEvalStrings = function (name, s) {
                this.evalStrings[name] = s
            };
            frame.getEvalStrings = function (name) {
                if (this.evalStrings.hasOwnProperty(name)) {
                    return this.evalStrings[name]
                } else {
                    return {expression: name, statements: ""}
                }
            };
            frame.functionMap = function (leafOnly) {
                var allFunctions = {};
                if (this.parentFrame && !leafOnly) {
                    allFunctions = this.parentFrame.functionMap()
                }
                for (var name in this.functions) {
                    if (this.functions.hasOwnProperty(name)) {
                        allFunctions[name] = this.functions[name].body
                    }
                }
                return allFunctions
            };
            frame.leafFunctionMap = function () {
                return this.functionMap(true)
            };
            frame.functionSourceMap = function (leafOnly) {
                var compiledFunctions = {};
                if (this.parentFrame && !leafOnly) {
                    compiledFunctions = this.parentFrame.functionSourceMap()
                }
                for (var name in this.functions) {
                    if (this.functions.hasOwnProperty(name) && this.functions[name].source) {
                        compiledFunctions[name] = {args: this.functions[name].args, source: this.functions[name].source}
                    }
                }
                return compiledFunctions
            };
            frame.leafFunctionSourceMap = function () {
                return this.functionSourceMap(true)
            }
        });
        return EvalFrame
    });
    define("math/comparators", ["require"], function (require) {
        var ComparatorTable = {
            "<": {inclusive: false, direction: -1},
            "!=": {inclusive: false, direction: 0},
            ">": {inclusive: false, direction: 1},
            "<=": {inclusive: true, direction: -1},
            "=": {inclusive: true, direction: 0},
            ">=": {inclusive: true, direction: 1}
        };
        var getComparator = function (inclusive, direction) {
            switch (direction) {
                case -1:
                    return (inclusive ? "<=" : "<");
                case 0:
                    return (inclusive ? "=" : "!=");
                case 1:
                    return (inclusive ? ">=" : ">");
                default:
                    throw"Programming error.  Comparators must have a direction of -1, 0, or 1"
            }
        };
        return {table: ComparatorTable, get: getComparator}
    });
    define("math/inverses", [], function () {
        var inverses = {};
        var arcNames = ["sin", "cos", "tan", "cot", "sec", "csc", "sinh", "cosh", "tanh", "coth", "sech", "csch"];
        arcNames.forEach(function (name) {
            inverses[name] = "arc" + name;
            inverses["arc" + name] = name
        });
        return inverses
    });
    define("main/cookie", [], function () {
        function getCookie(c_name) {
            var encoded_c_name = encodeURIComponent(c_name);
            var i, x, y, ARRcookies = document.cookie.split(";");
            for (i = 0; i < ARRcookies.length; i++) {
                x = ARRcookies[i].substr(0, ARRcookies[i].indexOf("="));
                y = ARRcookies[i].substr(ARRcookies[i].indexOf("=") + 1);
                x = x.replace(/^\s+|\s+$/g, "");
                if (x == encoded_c_name) {
                    return decodeURIComponent(y)
                }
            }
        }

        function setCookie(c_name, value, duration) {
            var expires = new Date();
            expires.setDate(expires.getDate() + (duration || 30));
            document.cookie = (encodeURIComponent(c_name) + "=" + encodeURIComponent(value) + "; expires=" + expires.toUTCString() + "; path=/")
        }

        return {getCookie: getCookie, setCookie: setCookie}
    });
    define("i18n", ["require", "config", "main/cookie", "underscore"], function (require) {
        var Config = require("config");
        var Cookie = require("main/cookie");
        var _ = require("underscore");
        var default_lang = "";
        var language_dict = {};
        var enabled_languages = {en: {displayName: "English (US)", userGuideURL: "https://desmos.s3.amazonaws.com/Desmos_User_Guide.pdf"}};

        function init(lang, dict) {
            default_lang = lang || "";
            language_dict = dict || {}
        }

        function translateString(message, variables) {
            var translation = language_dict[default_lang] && language_dict[default_lang][message] || message || "";
            for (var variable in variables) {
                if (variables.hasOwnProperty(variable)) {
                    translation = translation.split("__" + variable + "__").join(variables[variable])
                }
            }
            return translation
        }

        function detectLanguage() {
            if (Config.get("lang")) {
                return Config.get("lang")
            }
            var preferences = [Cookie.getCookie("lang")];
            if (!Config.get("disablelocale")) {
                var browserLocale;
                if (navigator.userLanguage) {
                    browserLocale = navigator.userLanguage
                } else {
                    browserLocale = navigator.language
                }
                var baseLocale = browserLocale.split("-")[0];
                preferences.push(browserLocale);
                preferences.push(baseLocale);
                _.each(enabled_languages, function (lang, code) {
                    if (code.split("-")[0] === baseLocale && lang.useAsRoot) {
                        preferences.push(code)
                    }
                })
            }
            for (var i = 0; i < preferences.length; i++) {
                var lang = preferences[i];
                if (enabled_languages.hasOwnProperty(lang)) {
                    return lang
                }
            }
            return "zh-CN"
        }

        function currentLanguage() {
            return default_lang
        }

        return {init: init, t: translateString, detectLanguage: detectLanguage, currentLanguage: currentLanguage, enabled_languages: enabled_languages}
    });
    var define_enum_constant;
    var enum_strings = {};
    var debuggable_enums = true;
    if (debuggable_enums) {
        define_enum_constant = function (s) {
            this[s] = s
        }
    } else {
        var next_enum = 1000;
        define_enum_constant = function (s) {
            enum_strings[next_enum] = s;
            this[s] = next_enum++
        }
    }
    define_enum_constant("EXPRESSION");
    define_enum_constant("FUNCTION_DEFINITION");
    define_enum_constant("VARIABLE_DEFINITION");
    define_enum_constant("ORDERED_PAIR_LIST");
    define_enum_constant("DOUBLE_INEQUALITY");
    define_enum_constant("COMPARATOR");
    define_enum_constant("CHAINED_COMPARATOR");
    define_enum_constant("EQUATION");
    define_enum_constant("CONSTANT");
    define_enum_constant("IDENTIFIER");
    define("math/enums", function () {
    });
    define("math/quadratic", ["require"], function (require) {
        var Quadratic = {
            formula: function (coeffs, rootNumber) {
                if (coeffs.length != 3) {
                    throw"Where did you learn the quadratic formula?"
                }
                var a = coeffs[0];
                var b = coeffs[1];
                var c = coeffs[2];
                if (a === 0) {
                    return [-c / b, -c / b]
                }
                var radical = Math.sqrt(b * b - 4 * a * c);
                var root0 = (-b + radical) / (2 * a);
                var root1 = (-b - radical) / (2 * a);
                if (rootNumber === 0) {
                    return root0
                }
                if (rootNumber === 1) {
                    return root1
                }
                return [root0, root1]
            }, inequalityRegions: function (coeffs) {
                var large = 1e+305;
                var a = coeffs[0];
                var b = coeffs[1];
                var c = coeffs[2];
                if (a === 0 && b === 0) {
                    return (c > 0) ? [NaN, -large, large, NaN] : [NaN, NaN, NaN, NaN]
                }
                if (a === 0) {
                    return (b > 0) ? [NaN, NaN, NaN, -c / b] : [-c / b, NaN, NaN, NaN]
                }
                var discriminant = Math.sqrt(b * b - 4 * a * c);
                if (!isFinite(discriminant)) {
                    return (a > 0) ? [NaN, -large, large, NaN] : [NaN, NaN, NaN, NaN]
                }
                var upper = (-b + discriminant) / (2 * a);
                var lower = (-b - discriminant) / (2 * a);
                return (a > 0) ? [lower, NaN, NaN, upper] : [NaN, upper, lower, NaN]
            }, formulaEvalStrings: function (strings) {
                var function_1, function_2;
                switch (strings.expressions.length) {
                    case 2:
                        function_1 = strings.statements + "return -" + strings.expressions[0] + "/" + strings.expressions[1];
                        return [function_1];
                    case 3:
                        var statements = strings.statements + "var coeffs = [" + strings.expressions[2] + "," + strings.expressions[1] + "," + strings.expressions[0] + "];";
                        function_1 = statements + "return this.quadraticFormula(coeffs, 0);";
                        function_2 = statements + "return this.quadraticFormula(coeffs, 1);";
                        return [function_1, function_2]
                }
            }, inequalityRegionEvalStrings: function (strings) {
                var expressions = strings.expressions.slice();
                while (expressions.length < 3) {
                    expressions.push("0")
                }
                var statements = strings.statements + "var coeffs = [" + expressions[2] + "," + expressions[1] + "," + expressions[0] + "];";
                return [statements + "return this.quadraticInequalityRegions(coeffs)[0]", statements + "return this.quadraticInequalityRegions(coeffs)[1]", statements + "return this.quadraticInequalityRegions(coeffs)[2]", statements + "return this.quadraticInequalityRegions(coeffs)[3]"]
            }
        };
        return Quadratic
    });
    define("math/builtinframe", ["require", "./builtin", "./evalframe", "./inverses", "math/quadratic"], function (require) {
        var BuiltIn = require("./builtin");
        var EvalFrame = require("./evalframe");
        var inverses = require("./inverses");
        var Quadratic = require("math/quadratic");
        var frame = EvalFrame();
        // frame.setEvalStrings("pi", {expression: String(Math.PI), statements: ""});
        // frame.setEvalStrings("tau", {expression: String(2 * Math.PI), statements: ""});
        // frame.setEvalStrings("e", {expression: String(Math.E), statements: ""});
        frame.setDegreeMode = function (on) {
            frame._angleMultiplier = (on ? Math.PI / 180 : 1)
        };
        frame.setDegreeMode(false);
        frame.setFunction("angleMultiplier", 1, function () {
            return frame._angleMultiplier
        });
        var registerTrig = function (name, fn, fn_inverse) {
            frame.setFunction(name, 1, function (x) {
                return fn(x * frame._angleMultiplier)
            });
            frame.setFunction(inverses[name], 1, function (x) {
                return fn_inverse(x) / frame._angleMultiplier
            })
        };
        registerTrig("sin", BuiltIn.sin, Math.asin);
        registerTrig("cos", BuiltIn.cos, Math.acos);
        registerTrig("tan", BuiltIn.tan, Math.atan);
        registerTrig("cot", BuiltIn.cot, BuiltIn.acot);
        registerTrig("sec", BuiltIn.sec, BuiltIn.asec);
        registerTrig("csc", BuiltIn.csc, BuiltIn.acsc);
        var registerHyperbolicTrig = function (name, fn, fn_inverse) {
            frame.setFunction(name, 1, fn);
            frame.setFunction(inverses[name], 1, fn_inverse)
        };
        registerHyperbolicTrig("sinh", BuiltIn.sinh, BuiltIn.asinh);
        registerHyperbolicTrig("cosh", BuiltIn.cosh, BuiltIn.acosh);
        registerHyperbolicTrig("tanh", BuiltIn.tanh, BuiltIn.atanh);
        registerHyperbolicTrig("coth", BuiltIn.coth, BuiltIn.acoth);
        registerHyperbolicTrig("sech", BuiltIn.sech, BuiltIn.asech);
        registerHyperbolicTrig("csch", BuiltIn.csch, BuiltIn.acsch);
        frame.setFunction("pow", 2, BuiltIn.pow);
        frame.setFunction("sqrt", 1, Math.sqrt);
        frame.setFunction("nthroot", 2, BuiltIn.nthroot);
        frame.setFunction("log", 2, BuiltIn.log_base);
        frame.setFunction("exp", 1, Math.exp);
        frame.setFunction("floor", 1, Math.floor);
        frame.setFunction("ceil", 1, Math.ceil);
        frame.setFunction("round", 1, Math.round);
        frame.setFunction("abs", 1, Math.abs);
        frame.setFunction("mod", 2, BuiltIn.mod);
        frame.setFunction("max", 2, BuiltIn.max);
        frame.setFunction("min", 2, BuiltIn.min);
        frame.setFunction("sign", 1, BuiltIn.sign);
        frame.setFunction("lcm", 2, BuiltIn.lcm);
        frame.setFunction("gcd", 2, BuiltIn.gcd);
        frame.setFunction("nCr", 2, BuiltIn.nCr);
        frame.setFunction("nPr", 2, BuiltIn.nPr);
        frame.setFunction("factorial", 1, BuiltIn.factorial);
        frame.setFunction("polyGamma", 2, BuiltIn.polyGamma);
        frame.setFunction("quadraticFormula", 2, Quadratic.formula);
        frame.setFunction("quadraticInequalityRegions", 1, Quadratic.inequalityRegions);
        return frame
    });
    define("graphing/graphmode", {X: 1, Y: 2, XYPOINT: 3, XYPOINT_MOVABLE: 4, PARAMETRIC: 5, POLAR: 6, POLYGONFILL: 7, IMPLICIT: 8});
    define("math/evaluationstate", ["require", "pjs", "graphing/graphmode", "math/comparators"], function (require) {
        var P = require("pjs");
        var GRAPHMODE = require("graphing/graphmode");
        var Comparators = require("math/comparators");
        var EvaluationState = P(function (state) {
            state.init = function (analysis, context, statement) {
                var graphMode;
                this.error = analysis.error;
                this.is_graphable = statement && statement.isGraphable();
                if (this.is_graphable) {
                    graphMode = analysis.graph_info.graphMode
                }
                this.is_evaluable = statement && statement.isEvaluable();
                if (this.is_evaluable) {
                    this.zero_values = statement.getZeroValues()
                }
                this.is_point_list = graphMode === GRAPHMODE.XYPOINT || graphMode === GRAPHMODE.XYPOINT_MOVABLE;
                this.is_parametric = graphMode === GRAPHMODE.PARAMETRIC;
                this.is_shade_between = this.is_graphable && !!statement.shade_between;
                if (this.is_shade_between) {
                    this.shade_between_operators = statement.getOperators()
                }
                this.is_double_inequality = this.is_shade_between && statement.getOperators().length == 2;
                if (statement) {
                    this.operator = statement.getOperator();
                    this.assignment = statement.getAssignedVariable();
                    if (this.is_graphable) {
                        this.variables = []
                    } else {
                        this.variables = statement.getSlidableVariables()
                    }
                    this.simple_constant = statement.getSliderValue();
                    this.is_inequality = this.is_double_inequality || Comparators.table[this.operator].direction !== 0
                } else {
                    this.variables = []
                }
                this.is_slidable = !!analysis.slider;
                this.is_animatable = this.is_slidable && !this.is_graphable;
                if (analysis.moveIds) {
                    this.move_ids = analysis.moveIds;
                    if (analysis.moveMatrix) {
                        this.move_matrix = analysis.moveMatrix
                    }
                }
                this.is_tableable = (this.is_graphable && !this.is_parametric && !statement.is_solved_equation && this.operator === "=" && !this.is_double_inequality);
                if (this.is_tableable) {
                    this.table_info = statement.getTableInfo();
                    var independent = this.table_info.independent_variable;
                    if (independent === "y" || independent === "theta") {
                        this.is_tableable = false;
                        delete (this.table_info)
                    }
                }
            }
        });
        return EvaluationState
    });
    define("graphing/columnmode", {POINTS: "POINTS", LINES: "LINES", POINTS_AND_LINES: "POINTS_AND_LINES"});
    define("math/evaluatorobject", ["require", "underscore", "pjs", "i18n", "./comparators", "./evalframe", "./quadratic", "./evaluationstate", "config", "graphing/graphmode", "graphing/columnmode"], function (require) {
        var _ = require("underscore");
        var P = require("pjs");
        var i18n = require("i18n");
        var Comparators = require("./comparators");
        var EvalFrame = require("./evalframe");
        var Quadratic = require("./quadratic");
        var EvaluationState = require("./evaluationstate");
        var Config = require("config");
        var GRAPHMODE = require("graphing/graphmode");
        var COLUMNMODE = require("graphing/columnmode");
        var ERROR = {name: "ERROR"};
        var WARNING = {name: "WARNING"};
        var EVALUABLE = {name: "EVALUABLE"};
        var GRAPHABLE = {name: "GRAPHABLE"};
        var SILENT = {name: "SILENT"};
        var AnalysisClass = {};

        function copyDefinedPOIs(points) {
            var xs = [];
            var ys = [];
            var len = points.length;
            for (var i = 0; i < len; i++) {
                xs.push(points[i][0]);
                ys.push(points[i][1])
            }
            return {defined: {x: xs, y: ys}}
        }

        var AnalysisObject = P(function (obj) {
            obj.init = function (context) {
                this._context = context;
                this._analysis = null;
                this.compiler = context.compiler
            };
            obj.exportDefinitionsTo = function (frame) {
            };
            obj.getAllIds = function () {
                return []
            };
            obj.cleanupId = function (id) {
                throw"base analysis object can't cleanup ID"
            };
            obj.invalidate = function () {
                this._analysis = null
            };
            obj.getAnalysis = function () {
                if (!this._analysis) {
                    this._context.updateAnalysis()
                }
                return this._analysis
            };
            obj.setAnalysis = function (analysis) {
                this._analysis = analysis
            };
            obj.shouldIntersect = function () {
                return false
            };
            obj.isEvaluable = function () {
                return this.getAnalysis().status == EVALUABLE
            };
            obj.isGraphable = function () {
                return this.getAnalysis().status == GRAPHABLE
            };
            obj.isGraphed = function () {
                return this.isGraphable()
            };
            obj.graphModeFromVariables = function (independent, dependent) {
                if (dependent === "x" || independent === "y") {
                    return GRAPHMODE.X
                }
                if ((dependent === "r" && independent === "theta") || (dependent === "r" && independent === undefined) || (dependent === undefined && independent === "theta")) {
                    return GRAPHMODE.POLAR
                }
                return GRAPHMODE.Y
            };
            obj.setGraphMode = function (mode, independent, dependent) {
                if (dependent === "y" && !independent) {
                    independent = "x"
                }
                if (dependent === "x" && !independent) {
                    independent = "y"
                }
                if (dependent === "r" && !independent) {
                    independent = "theta"
                }
                if (!mode) {
                    mode = this.graphModeFromVariables(independent, dependent)
                }
                this._analysis.graph_info = {
                    color: this._statement.color,
                    style: this._statement.style,
                    graphMode: mode,
                    independent: independent,
                    dependent: dependent,
                    operator: this.getOperator(),
                    domain: this._statement.domain
                };
                return GRAPHABLE
            };
            obj.computeGraphData = function (viewport) {
            };
            obj.getStatus = function () {
                return this.getAnalysis().status
            };
            obj.getAssignedVariable = function () {
                return null
            };
            obj.compile = function () {
                return undefined
            };
            obj.getSlidableVariables = function () {
                return []
            };
            obj.getSliderValue = function () {
                return NaN
            };
            obj.getZeroValues = function () {
                return []
            };
            obj.addFreeVariables = function (variables) {
                for (var i = 0; i < variables.length; i++) {
                    var variable = variables[i];
                    if (this._analysis.free_variables.indexOf(variable) > -1) {
                        continue
                    }
                    this._analysis.free_variables.push(variable)
                }
            }
        });
        var StatementAnalysis = P(AnalysisObject, function (obj, _super) {
            obj.init = function (context, statement, tree) {
                _super.init.call(this, context);
                this._statement = statement;
                this._tree = tree;
                this.id = statement.id;
                this.color = statement.color;
                this.style = statement.style;
                this.domain = statement.domain
            };
            obj.isGraphed = function () {
                return this.isGraphable() && this._statement.shouldGraph
            };
            obj.getAllIds = function () {
                return [this.id]
            };
            obj.getGraphInfo = function () {
                return this._analysis.graph_info
            };
            obj.shouldIntersect = function () {
                if (!this.isGraphed()) {
                    return false
                }
                var graphMode = this.getGraphInfo().graphMode;
                return (graphMode === GRAPHMODE.Y || graphMode === GRAPHMODE.X)
            };
            obj.computeGraphData = function (viewState) {
                var graphData = {};
                var frame = this._context.getFrame();
                var compiled = this.compile(frame);
                compiled.fn.derivative = this.compileDerivative(frame).fn;
                var graph_info = this._analysis.graph_info;
                var order = this._tree.polynomialOrder(frame, graph_info.independent);
                if (order === 1) {
                    graph_info.isLinear = true
                }
                graphData[this.id][0].compiled = compiled;
                return graphData
            };
            obj.getEvaluationState = function () {
                return EvaluationState(this._analysis, this._context, this)
            };
            obj.computeStatus = function () {
                return this.markError(i18n.t("Something went wrong, please report this to desmos.com support. (Error __error_num__)", {error_num: "49972"}))
            };
            obj.getZeroValues = function () {
                return [{val: this._tree.evaluateOnce(this._context.getFrame()), operator: "="}]
            };
            obj.referencesSymbol = function (symbol) {
                return this._tree.references(symbol)
            };
            obj.getSlidableVariables = function () {
                var free_variables = this._analysis.free_variables;
                var variables = [];
                for (var i = 0; i < free_variables.length; i++) {
                    var variable = free_variables[i];
                    if (this._context.assignmentForbidden(variable)) {
                        continue
                    }
                    if (this._analysis.hasOwnProperty("solution")) {
                        if (variable == this._analysis.solution.variable) {
                            continue
                        }
                    }
                    variables.push(variable)
                }
                return variables
            };
            obj.exportedSymbols = function () {
                var exported = {};
                if (this._tree.assigns) {
                    exported[this._tree.assigns.identifier] = this._tree.arity
                }
                return exported
            };
            obj.exportDefinitionsTo = function (frame, id) {
                if (!this._tree.assigns) {
                    return
                }
                var symbol = this._tree.assigns.identifier;
                if (this._context.assignmentForbidden(symbol)) {
                    return
                }
                this._tree.exportDefinitionsTo(frame, this.compiler);
                frame.setDefinitionId(symbol, id)
            };
            obj.shadowedSymbols = function () {
                return []
            };
            obj.getDependencies = function () {
                return this._tree.dependencies()
            };
            obj.getType = function () {
                return this._tree.statementType
            };
            obj.freeVariablesError = function (free_variables) {
                for (var i = 0; i < free_variables.length; i++) {
                    if (this._context.assignmentForbidden(free_variables[i])) {
                        continue
                    }
                    return this.markError(i18n.t("Too many variables.  Try defining '__variable__'.", {variable: free_variables[i]}))
                }
                if (_.filter(free_variables, function (v) {
                        return (v !== "x" && v !== "y")
                    }).length > 0) {
                    return this.markError(i18n.t("We only support implicit equations of x and y."))
                }
                return this.markError(i18n.t("Try adding an equals sign to turn this into an equation."))
            };
            obj.getParseError = function () {
                if (this._tree.valid) {
                    return undefined
                }
                return this._tree.error_msg
            };
            obj.markError = function (msg) {
                this._analysis.error = msg;
                this._analysis.status = ERROR;
                return ERROR
            };
            obj.evaluateOnce = function (frame) {
                return this._tree.evaluateOnce(frame)
            };
            obj.evalStrings = function (frame) {
                return this._tree.getEvalStrings(frame)
            };
            obj.compileAllBranches = function (frame) {
                return [this.compile(frame)]
            };
            obj.compile = function (frame) {
                var source = this.compile_to_strings(frame, this.independent_variable());
                source.fn = this.compiler.compile(source.args, source.function_string);
                return source
            };
            obj.compileDerivative = function (frame) {
                var independent_variable = this.independent_variable();
                var identifier = IdentifierNode(independent_variable);
                var derivative_tree;
                if (this._tree.expressionDerivative) {
                    derivative_tree = this._tree.expressionDerivative(frame, identifier)
                } else {
                    derivative_tree = this._tree.takeDerivative(frame, identifier)
                }
                var derivativeObject = StatementAnalysis(this._context, this._statement, derivative_tree);
                var source = derivativeObject.compile_to_strings(frame, independent_variable);
                source.fn = this.compiler.compile(source.args, source.function_string);
                return source
            };
            obj.independent_variable = function () {
                if (this._analysis.status === GRAPHABLE) {
                    return this._analysis.graph_info.independent
                } else {
                    if (this._analysis.free_variables.length === 1) {
                        return this._analysis.free_variables[0]
                    }
                }
            };
            obj.compile_to_strings = function (frame, independent_variable) {
                var eval_strings = this._tree.getEvalStrings(frame);
                var function_string = eval_strings.statements + "return " + eval_strings.expression;
                return {args: [independent_variable], function_string: function_string}
            };
            obj.getOperator = function () {
                return "="
            };
            obj.getTableInfo = function () {
                return undefined
            };
            obj.getTableInfo = function () {
                return {independent_variable: this._analysis.graph_info.independent, dependent_column: this._tree.getInputString(), by_reference: false}
            }
        });
        AnalysisClass[EXPRESSION] = P(StatementAnalysis, function (obj, _super) {
            obj.computeStatus = function (frame) {
                var free_variables = this._analysis.free_variables;
                if (free_variables.length === 0) {
                    return EVALUABLE
                }
                if (free_variables.length === 1) {
                    if (free_variables[0] === "x") {
                        return this.setGraphMode(GRAPHMODE.Y, "x")
                    }
                    var dep = "y";
                    if (free_variables[0] === "y") {
                        dep = "x"
                    }
                    if (free_variables[0] === "theta") {
                        dep = "r"
                    }
                    return this.markError(i18n.t("Try adding '__var__=' to the beginning of this equation.", {vars: dep}))
                }
                return this.freeVariablesError(free_variables)
            }
        });
        AnalysisClass[FUNCTION_DEFINITION] = P(StatementAnalysis, function (obj, _super) {
            obj.init = function (context, statement, tree) {
                _super.init.call(this, context, statement, tree);
                this.arity = this._tree.arity
            };
            obj.shadowedSymbols = function () {
                return this._tree.passed_variables
            };
            obj.computeStatus = function (frame) {
                if (this._tree.arity === 1) {
                    if (this._tree.assigns.identifier === this._tree.passed_variables[0]) {
                        return this.markError(i18n.t("Something went wrong, please report this to desmos.com support. (Error __error_num__)", {error_num: "14573"}))
                    }
                    if (this._analysis.free_variables.length > 0) {
                        return this.markError(i18n.t("Something went wrong, please report this to desmos.com support. (Error __error_num__)", {error_num: "66347"}))
                    }
                    return this.setGraphMode(undefined, this._tree.passed_variables[0], this._tree.assigns.identifier)
                }
                if (this._tree.arity > 1) {
                    return WARNING
                }
            };
            obj.addFreeVariables = function (variables) {
                var passed_variables = this._tree.passedVariables();
                for (var i = 0; i < variables.length; i++) {
                    var variable = variables[i];
                    if (passed_variables.indexOf(variable) > -1) {
                        continue
                    }
                    if (this._analysis.free_variables.indexOf(variable) > -1) {
                        continue
                    }
                    if (["x", "y", "r", "theta"].indexOf(variable) >= 0) {
                        this.markError(i18n.t("Try including '__variable__' as one of the arguments of this function.", {variable: variable}))
                    } else {
                        this.markError(i18n.t("Too many variables.  Try defining '__variable__'.", {variable: variable}))
                    }
                    this._analysis.free_variables.push(variable)
                }
            };
            obj.conflictError = function (symbol) {
                var msg = i18n.t("You can't use '__symbol__' here because it's already defined.", {symbol: symbol});
                return this.markError(msg)
            };
            obj.getTableInfo = function () {
                if (this._context.assignmentForbidden(this._tree.assigns.identifier)) {
                    return {independent_variable: this._analysis.graph_info.independent, dependent_column: this._tree.expression.getInputString(), by_reference: false}
                } else {
                    return {independent_variable: this._analysis.graph_info.independent, dependent_column: this._tree.getInputString(), by_reference: true}
                }
            };
            obj.getSlidableVariables = function () {
                var free_variables = this._analysis.free_variables;
                var variables = [];
                for (var i = 0; i < free_variables.length; i++) {
                    var variable = free_variables[i];
                    if (this._context.assignmentForbidden(variable)) {
                        continue
                    }
                    variables.push(variable)
                }
                return variables
            }
        });
        AnalysisClass[VARIABLE_DEFINITION] = P(StatementAnalysis, function (obj, _super) {
            obj.computeStatus = function (frame) {
                var variable = this._tree.assigns.identifier;
                var free_variables = this._analysis.free_variables;
                if (variable === "theta") {
                    return this.markError(i18n.t("Sorry, you can't graph θ as a function of anything yet."))
                }
                if (free_variables.length === 0) {
                    if ("xyr".indexOf(variable) !== -1) {
                        return this.setGraphMode(undefined, undefined, variable)
                    }
                    return should_slide ? SILENT : EVALUABLE
                }
                if (free_variables.length === 1) {
                    if (free_variables[0] === variable) {
                        return this.markError(i18n.t("There is a circular dependency."))
                    }
                    return this.setGraphMode(undefined, free_variables[0], variable)
                }
                return this.freeVariablesError(free_variables)
            };
            obj.getAssignedVariable = function () {
                return this._tree.assigns.identifier
            };
            obj.getSliderValue = function () {
                return _super.getSliderValue()
            };
            obj.getTableInfo = function () {
                if (this._context.assignmentForbidden(this._tree.assigns.identifier)) {
                    return {independent_variable: this._analysis.graph_info.independent, dependent_column: this._tree.expression.getInputString(), by_reference: false}
                } else {
                    return {independent_variable: this._analysis.graph_info.independent, dependent_column: this._analysis.graph_info.dependent, by_reference: true}
                }
            }
        });
        AnalysisClass[IDENTIFIER] = P(StatementAnalysis, function (obj, _super) {
            obj.computeStatus = function (frame) {
                var free_variables = this._analysis.free_variables;
                if (free_variables.length === 1 && free_variables[0] === "x") {
                    return this.setGraphMode(GRAPHMODE.Y, "x")
                }
                if (free_variables.length > 0) {
                    return SILENT
                }
                return EVALUABLE
            }
        });
        AnalysisClass[CONSTANT] = P(StatementAnalysis, function (obj, _super) {
            obj.computeStatus = function (frame) {
                return SILENT
            };
            obj.getSliderValue = function () {
                return this._tree.evaluateOnce()
            }
        });
        AnalysisClass[ORDERED_PAIR_LIST] = P(StatementAnalysis, function (obj, _super) {
            obj.computeMovable = function (frame) {
                var self = this;
                if (self._analysis.status != GRAPHABLE) {
                    return
                }
                if (self._analysis.free_variables.length !== 0) {
                    return
                }
                if (self._tree.elements.length !== 1) {
                    return
                }
                var movable;
                var coupled;
                var moveIds = [undefined, undefined];
                var moveMatrix = [[1, 0, 0], [0, 1, 0]];
                var coordTrees = self._tree.elements[0].children;
                coordTrees.forEach(function (tree, index) {
                    if (coupled) {
                        return
                    }
                    var symbols = tree._referencedSymbols;
                    var otherTree = coordTrees[index === 0 ? 1 : 0];
                    for (var i = symbols.length - 1; i >= 0; i--) {
                        var symbol = symbols[i];
                        var definitionId = frame.getDefinitionId(symbol);
                        if (definitionId === undefined) {
                            continue
                        }
                        if (!self._context.statements[definitionId]._analysis.slider) {
                            continue
                        }
                        var order = tree.polynomialOrder(frame, symbol);
                        if (order !== 1) {
                            continue
                        }
                        var coeffs = tree.quadraticCoefficients(frame, symbol);
                        if (coeffs[1] === 0) {
                            continue
                        }
                        var otherOrder = otherTree.polynomialOrder(frame, symbol);
                        if (otherOrder > 0) {
                            if (moveIds[0]) {
                                continue
                            }
                            if (otherOrder !== 0) {
                                coupled = true
                            }
                        }
                        moveMatrix[index][index] = 1 / coeffs[1];
                        moveMatrix[index][2] = -coeffs[2] / coeffs[1];
                        movable = true;
                        moveIds[index] = definitionId;
                        break
                    }
                });
                if (movable) {
                    self._analysis.movable = true;
                    if (self._analysis.graph_info.graphMode === GRAPHMODE.XYPOINT) {
                        self._analysis.graph_info.graphMode = GRAPHMODE.XYPOINT_MOVABLE
                    }
                    if (moveIds[1] === moveIds[0]) {
                        moveIds[1] = undefined
                    }
                    self._analysis.moveIds = moveIds;
                    self._analysis.moveMatrix = moveMatrix
                }
            };
            obj.computeStatus = function (frame) {
                var free_variables = this._analysis.free_variables;
                if (free_variables.length === 0) {
                    return this.setGraphMode(GRAPHMODE.XYPOINT)
                }
                if (free_variables.length === 1) {
                    if (free_variables[0] === "t" && this._tree.elements.length == 1) {
                        return this.setGraphMode(GRAPHMODE.PARAMETRIC, "t")
                    }
                    return this.markError(i18n.t("Too many variables.  Try defining '__variable__'.", {variable: free_variables[0]}))
                }
                if (free_variables.length > 1) {
                    return this.freeVariablesError(free_variables)
                }
            };
            obj.getSlidableVariables = function () {
                var variables = _super.getSlidableVariables.call(this);
                var index = variables.indexOf("t");
                if (index > -1) {
                    variables.splice(index, 1)
                }
                return variables
            };
            obj.computeGraphData = function (viewState) {
                var graph_info = this._analysis.graph_info;
                var graphData = {};
                if (graph_info.graphMode === GRAPHMODE.XYPOINT || graph_info.graphMode === GRAPHMODE.XYPOINT_MOVABLE) {
                    var points = this._tree.evaluateOnce(this._context.getFrame());
                    var datum = {segments: [points], graphMode: graph_info.graphMode, color: this._statement.color, style: this._statement.style, poi: copyDefinedPOIs(points)};
                    graphData[this.id] = [datum];
                    return graphData
                }
                var compiled = this.compile(this._context.getFrame());
                var fn = function (x) {
                    return compiled.fn(x)[0]
                };
                return graphData
            };
            obj.getTableInfo = function () {
                var values = this._tree.evaluateOnce(this._context.getFrame());
                return {independent_variable: "x", dependent_column: "y", by_reference: false, values: values}
            }
        });
        AnalysisClass[DOUBLE_INEQUALITY] = P(StatementAnalysis, function (obj, _super) {
            obj.init = function (context, statement, tree) {
                _super.init.call(this, context, statement, tree);
                this._inequalities = [];
                for (var i = 0; i < 2; i++) {
                    var subtree = tree.getInequality(i);
                    this._inequalities.push(AnalysisClass[COMPARATOR](context, statement, subtree))
                }
            };
            obj.shade_between = true;
            obj.computeStatus = function (frame) {
                for (var i = 0; i < 2; i++) {
                    this._inequalities[i].setAnalysis({free_variables: this._analysis.free_variables})
                }
                var statuses = this._inequalities.map(function (x) {
                    x._analysis.status = x.computeStatus(frame);
                    return x._analysis.status
                });
                if (statuses[0] === GRAPHABLE && statuses[1] === GRAPHABLE) {
                    this._analysis.graph_info = this._inequalities[0]._analysis.graph_info;
                    if (this._analysis.graph_info.graphMode === GRAPHMODE.POLAR) {
                        return this.markError(i18n.t("Double inequalities are only supported for x and y. Try deleting one side of the inequality."))
                    }
                    return GRAPHABLE
                } else {
                    return this.markError(i18n.t("Error in this double inequality. Try deleting one side of the inequality."))
                }
            };
            obj.computeGraphData = function (frame) {
                var id = this.id;
                var graphData = {};
                graphData[id] = [];
                var updateOperator = function (s) {
                    s.operator = Comparators.get(Comparators.table[s.operator].inclusive, 0)
                };
                for (var i = 0; i < 2; i++) {
                    var subGraphData = this._inequalities[i].computeGraphData(frame)[id].slice(0, 4);
                    subGraphData.forEach(updateOperator);
                    graphData[id].push.apply(graphData[id], subGraphData)
                }
                var graphMode = graphData[id][0].graphMode;
                var polygons;
                graphData[id].push({graphMode: GRAPHMODE.POLYGONFILL, segments: polygons, poi: {}});
                graphData[id].push({graphMode: GRAPHMODE.POLYGONFILL, segments: polygons, poi: {}});
                return graphData
            };
            obj.compileAllBranches = function (frame) {
                var compiled = [];
                for (var i = 0; i < 2; i++) {
                    compiled.push.apply(compiled, this._inequalities[i].compileAllBranches(frame))
                }
                return compiled
            };
            obj.getOperators = function () {
                return [this._inequalities[0].getOperator(), this._inequalities[1].getOperator()]
            }
        });
        AnalysisClass[EQUATION] = P(StatementAnalysis, function (obj, _super) {
            obj.init = function (context, statement, tree) {
                _super.init.call(this, context, statement, tree);
                this.temp_tree = BinaryOperatorNode("-", this._tree.lhs, this._tree.rhs)
            };
            obj.is_solved_equation = true;
            obj.computeStatus = function (frame) {
                var free_variables = this._analysis.free_variables;
                if (free_variables.length > 2) {
                    return this.freeVariablesError(free_variables)
                }
                if (free_variables.length === 2) {
                    if ((free_variables[0] === "x" && free_variables[1] === "y") || (free_variables[0] === "y" && free_variables[1] === "x")) {
                        var x_order = this.temp_tree.polynomialOrder(frame, "x");
                        var y_order = this.temp_tree.polynomialOrder(frame, "y");
                        if (y_order <= 2 && y_order > 0) {
                            return this.setGraphMode(GRAPHMODE.Y, "x", "y")
                        }
                        if (x_order <= 2 && x_order > 0) {
                            return this.setGraphMode(GRAPHMODE.X, "y", "x")
                        }
                        if (Config.get("implicit")) {
                            return this.setGraphMode(GRAPHMODE.IMPLICIT, "x", "y")
                        } else {
                            return this.markError("Equation is too complicated. One variable needs to be quadratic.")
                        }
                    }
                    return this.markError(i18n.t("We only support implicit equations of x and y."))
                }
                if (free_variables.length === 1) {
                    var solution = this.solveEvaluable(frame);
                    if (solution) {
                        this._analysis.solution = solution;
                        return EVALUABLE
                    } else {
                        return this.markError(i18n.t("We don't solve complicated single-variable equations yet."))
                    }
                }
                if (free_variables.length === 0) {
                    return this.markError(i18n.t("This equation has no variables in it - there's nothing to solve"))
                }
            };
            obj.solveEvaluable = function (frame) {
                var coeffs, roots;
                if (this._analysis.free_variables.length != 1) {
                    return false
                }
                var variable = this._analysis.free_variables[0];
                var order = this.temp_tree.polynomialOrder(frame, variable);
                switch (order) {
                    case 1:
                        coeffs = this.temp_tree.quadraticCoefficients(frame, variable);
                        roots = [-coeffs[2] / coeffs[1]];
                        break;
                    case 2:
                        coeffs = this.temp_tree.quadraticCoefficients(frame, variable);
                        roots = Quadratic.formula(coeffs);
                        break;
                    default:
                        return false
                }
                return {roots: roots, variable: variable}
            };
            obj.getZeroValues = function () {
                var retval = [];
                var roots = this._analysis.solution.roots;
                for (var i = 0; i < roots.length; i++) {
                    retval.push({val: roots[i], operator: "="})
                }
                return retval
            };
            obj.getAssignedVariable = function () {
                switch (this._analysis.status) {
                    case EVALUABLE:
                        return this._analysis.solution.variable;
                    case GRAPHABLE:
                        return this._analysis.graph_info.dependent
                }
            };
            obj.computeGraphData = function (viewState) {
                var graphData = {};
                var compiled = this.compileAllBranches(this._context.getFrame());
                var graph_info = this._analysis.graph_info;
                graphData[this.id] = [];
                for (var i = 0; i < compiled.length; i++) {
                }
                return graphData
            };
            obj.compileAllBranches = function (frame) {
                var compiled = [];
                var independent = this._analysis.graph_info.independent;
                var dependent = this._analysis.graph_info.dependent;
                var args, evalStrings;
                if (this._analysis.graph_info.graphMode === GRAPHMODE.IMPLICIT) {
                    args = [independent, dependent];
                    evalStrings = this.temp_tree.getEvalStrings(frame);
                    var function_string = evalStrings.statements + "return " + evalStrings.expression;
                    compiled.push({fn: this.compiler.compile(args, function_string), args: args, function_string: function_string})
                } else {
                    var coeffEvalStrings = this.temp_tree.polynomialEvalStrings(frame, dependent, independent);
                    evalStrings = Quadratic.formulaEvalStrings(coeffEvalStrings);
                    args = [independent];
                    for (var i = 0; i < evalStrings.length; i++) {
                        compiled.push({fn: this.compiler.compile(args, evalStrings[i]), args: args, function_string: evalStrings[i]})
                    }
                }
                return compiled
            }
        });
        AnalysisClass[COMPARATOR] = P(StatementAnalysis, function (obj, _super) {
            obj.init = function (context, statement, tree) {
                _super.init.call(this, context, statement, tree);
                var operator = this._tree.operator;
                if (Comparators.table[operator].direction === 1) {
                    this.temp_tree = BinaryOperatorNode("-", this._tree.args[0], this._tree.args[1])
                } else {
                    this.temp_tree = BinaryOperatorNode("-", this._tree.args[1], this._tree.args[0])
                }
            };
            obj.getDependencies = function () {
                var deps = this._tree.dependencies();
                if (_.isEqual(deps, {r: 0, theta: 0})) {
                    this.addFreeVariables(["r", "theta"]);
                    return []
                }
                if (_.isEqual(deps, {r: 0})) {
                    this.addFreeVariables(["r"]);
                    return []
                }
                return deps
            };
            obj.computeStatus = function (frame) {
                var free_variables = this._analysis.free_variables;
                if (free_variables.length === 0) {
                    return EVALUABLE
                }
                var singleVariables = {x: true, y: true, r: true};
                var fv0 = free_variables[0], fv1 = free_variables[1];
                var order0, x_order, y_order, r_order;
                if (free_variables.length === 1) {
                    if (!singleVariables.hasOwnProperty(fv0)) {
                        return this.markError(i18n.t("We only plot inequalities of x and y, or r and θ."))
                    }
                    order0 = this.temp_tree.polynomialOrder(frame, fv0);
                    if (fv0 === "r" && order0 > 1) {
                        return this.markError(i18n.t("We only support implicit equations of x and y."))
                    }
                    if (order0 > 2) {
                        return this.markError(i18n.t("We can only plot inequalities when one variable is quadratic or linear."))
                    }
                    return this.setGraphMode(undefined, undefined, fv0)
                }
                var twoVariables = {x: "y", y: "x", r: "theta", theta: "r"};
                if (free_variables.length === 2) {
                    if (twoVariables[fv0] !== fv1) {
                        return this.markError(i18n.t("We only plot inequalities of x and y, or r and θ."))
                    }
                    if (fv0 === "r" || fv1 === "r") {
                        r_order = this.temp_tree.polynomialOrder(frame, "r");
                        if (r_order > 1) {
                            return this.markError(i18n.t("We only support implicit equations of x and y."))
                        }
                        return this.setGraphMode(GRAPHMODE.POLAR, "theta", "r")
                    }
                    x_order = this.temp_tree.polynomialOrder(frame, "x");
                    y_order = this.temp_tree.polynomialOrder(frame, "y");
                    if (y_order <= 2) {
                        return this.setGraphMode(GRAPHMODE.Y, "x", "y")
                    }
                    if (x_order <= 2) {
                        return this.setGraphMode(GRAPHMODE.X, "y", "x")
                    }
                    return this.markError(i18n.t("We can only plot inequalities when one variable is quadratic or linear."))
                }
            };
            obj.computeGraphData = function (viewState) {
                var graphData = {};
                var compiled = this.compileAllBranches(this._context.getFrame());
                var graph_info = this._analysis.graph_info;
                var operator = this._tree.operator;
                var thisGraphData = graphData[this.id] = [];
                var data;
                var polarities = [-1, 0, 0, 1];
                for (var i = 0; i < 4; i++) {
                }
                var polygons;
                return graphData
            };
            obj.compileAllBranches = function (frame) {
                var compiled = [];
                var independent = this._analysis.graph_info.independent;
                var dependent = this._analysis.graph_info.dependent;
                var coeffEvalStrings = this.temp_tree.polynomialEvalStrings(frame, dependent, independent);
                var evalStrings = Quadratic.inequalityRegionEvalStrings(coeffEvalStrings);
                var args = [independent];
                for (var i = 0; i < evalStrings.length; i++) {
                    compiled.push({fn: this.compiler.compile(args, evalStrings[i]), args: args, function_string: evalStrings[i]})
                }
                return compiled
            };
            obj.getOperator = function () {
                return this._tree.operator
            };
            obj.getSlidableVariables = function () {
                return _super.getSlidableVariables.call(this).filter(function (v) {
                    return (v !== "r")
                })
            }
        });
        AnalysisClass[CHAINED_COMPARATOR] = P(StatementAnalysis, function (obj, _super) {
            obj.computeStatus = function (frame) {
                var free_variables = this._analysis.free_variables;
                if (free_variables.length === 0) {
                    return EVALUABLE
                }
                return this.markError(i18n.t("We only support solved double inequalities. Try deleting one side of the inequality."))
            }
        });
        var createAnalysisObject = function (context, statement) {
            switch (statement.type) {
                case"table":
                    return Table(context, statement)
            }
        };
        return {createAnalysisObject: createAnalysisObject, status: {ERROR: ERROR, WARNING: WARNING, EVALUABLE: EVALUABLE, GRAPHABLE: GRAPHABLE, SILENT: SILENT}}
    });
    define("math/functions", ["require", "underscore", "pjs"], function (require) {
        var _ = require("underscore");
        var P = require("pjs");
        var FunctionCompiler = P(function (compiler) {
            compiler.init = function () {
                var fn_map = {};
                this.compile = function (args, evalString) {
                    var fn = new Function(args, evalString);
                    return _.bind(fn, fn_map)
                };
                this.register = function (name, fn) {
                    fn_map[name] = fn
                }
            };
            compiler.dehydrateGraphData = function (data) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].compiled) {
                        delete data[i].compiled.fn
                    }
                }
            };
            compiler.rehydrateGraphData = function (data) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].compiled) {
                        data[i].compiled.fn = this.compile(data[i].compiled.args, data[i].compiled.function_string)
                    }
                }
            };
            compiler.updateFromFunctionMap = function (fnmap) {
                for (var name in fnmap) {
                    if (!fnmap.hasOwnProperty(name)) {
                        continue
                    }
                    this.register(name, fnmap[name])
                }
            };
            compiler.updateFromSourceMap = function (sourcemap) {
                for (var name in sourcemap) {
                    if (!sourcemap.hasOwnProperty(name)) {
                        continue
                    }
                    var source = sourcemap[name];
                    this.register(name, this.compile(source.args, source.source))
                }
            }
        });
        return FunctionCompiler
    });
    define("math/evaluatorcontext", ["require", "pjs", "underscore", "./evalframe", "./evaluatorobject", "./functions", "config", "graphing/graphmode", "i18n"], function (require) {
        var P = require("pjs");
        var _ = require("underscore");
        var EvalFrame = require("./evalframe");
        var EvaluatorObject = require("./evaluatorobject");
        var Functions = require("./functions");
        var Config = require("config");
        var GRAPHMODE = require("graphing/graphmode");
        var i18n = require("i18n");
        var EvaluatorContext = P(function (context) {
            context.triggerGraphComputed = function () {
            };
            context.triggerStatusChange = function () {
            };
            context.triggerRemoveGraph = function () {
            };
            context.triggerRender = function () {
            };
            context.triggerRenderSlowly = function () {
            };
            context.triggerDidAddStatement = function () {
            };
            context.triggerDidRemoveStatement = function () {
            };
            context.triggerDidSetCompleteState = function () {
            };
            context.triggerDidSetDegreeMode = function () {
            };
            context.triggerDidUpdateIntersections = function () {
            };
            context.triggerDidUpdateFunctionMap = function () {
            };
            context.init = function (frame) {
                if (!frame) {
                    frame = EvalFrame()
                }
                this.parent_frame = frame;
                this.statements = {};
                this.analysis = null;
                this.current_state = {};
                this.dirty = {};
                this.graph_changed = [];
                this.compiler = Functions();
                this.intersectIds = {};
                var fm = frame.functionMap();
                for (var name in fm) {
                    this.compiler.register(name, fm[name])
                }
            };
            context.eachStatement = function (fn) {
                for (var id in this.statements) {
                    fn.apply(this, [this.statements[id]])
                }
            };
            context.processChangeSet = function (changeSet) {
                var ids, triggerRender;
                if (changeSet.isCompleteState) {
                    this.statements = {};
                    this.invalidate()
                }
                if (changeSet.viewState) {
                    this.setViewState(changeSet.viewState)
                }
                if (changeSet.hasOwnProperty("degreeMode")) {
                    this.setDegreeMode(changeSet.degreeMode)
                }
                if (changeSet.hasOwnProperty("intersectIds")) {
                    this.intersectIds = changeSet.intersectIds
                }
                if (changeSet.statements) {
                    for (var id in changeSet.statements) {
                        var statement = changeSet.statements[id];
                        if (statement === null) {
                            if (!changeSet.isCompleteState && this.statements.hasOwnProperty(id)) {
                                ids = this.statements[id].getAllIds()
                            }
                            this.removeStatement(id);
                            if (!changeSet.isCompleteState && ids) {
                                for (var i = 0; i < ids.length; i++) {
                                    this.triggerRemoveGraph(ids[i])
                                }
                                this.triggerDidRemoveStatement(id)
                            }
                        } else {
                            this.addStatement(statement);
                            if (!changeSet.isCompleteState) {
                                this.triggerDidAddStatement(statement)
                            }
                        }
                    }
                }
                if (changeSet.hasOwnProperty("intersectId")) {
                    this.updateIntersections(changeSet.intersectId)
                }
                if (changeSet.isCompleteState) {
                    this.triggerDidSetCompleteState(changeSet.statements);
                    triggerRender = this.triggerRender;
                    this.triggerRender = this.triggerRenderSlowly;
                    this.publishing_paused = false
                }
                this.updateAnalysis();
                this.publishChanges();
                if (changeSet.isCompleteState) {
                    this.triggerRender = triggerRender
                }
            };
            context.setViewState = function (viewState) {
                if (_.isEqual(viewState, this.viewState)) {
                    return
                }
                this.viewState = viewState;
                this.invalidate()
            };
            context.setDegreeMode = function (use_degrees) {
                this.parent_frame.setDegreeMode(use_degrees);
                this.invalidate();
                this.triggerDidSetDegreeMode(use_degrees)
            };
            context.publishing_paused = false;
            context.changes_pending = false;
            context.pausePublishing = function () {
                this.publishing_paused = true
            };
            context.resumePublishing = function () {
                this.publishing_paused = false;
                if (this.changes_pending) {
                    this.publishChanges()
                }
            };
            context.publishChanges = function () {
                if (this.publishing_paused) {
                    this.changes_pending = true;
                    return
                }
                this.changes_pending = false;
                this.publishAllStatuses()
            };
            context.publishAllStatuses = function () {
                var changes = {};
                var last_state = this.current_state;
                this.current_state = {};
                this.eachStatement(function (statement) {
                });
                this.triggerStatusChange(changes)
            };
            context.graphAllChanged = function () {
                if (!this.graph_changed.length) {
                    return
                }
                var viewState = this.viewState;
                var id;
                var i;
                for (i = 0; i < this.graph_changed.length; i++) {
                    id = this.graph_changed[i];
                    if (!this.statements.hasOwnProperty(id)) {
                        continue
                    }
                    if (this.statements[id].isGraphed()) {
                        this.graph(id, viewState)
                    } else {
                        this.triggerRemoveGraph(id)
                    }
                }
                var graphChangedSet = {};
                for (i = 0; i < this.graph_changed.length; i++) {
                    graphChangedSet[this.graph_changed[i]] = true
                }
                this.graph_changed = [];
                for (id in this.intersectIds) {
                    if (!this.intersectIds.hasOwnProperty(id)) {
                        continue
                    }
                    if (graphChangedSet.hasOwnProperty(id)) {
                        continue
                    }
                    this.updateIntersections(id)
                }
                this.triggerRender()
            };
            context.graph = function (id, viewState) {
                if (!viewState) {
                    return
                }
                var statement = this.statements[id];
                var graphData = statement.computeGraphData(viewState);
                if (this.intersectIds.hasOwnProperty(id) && statement.shouldIntersect() && graphData.hasOwnProperty(id)) {
                    var someIntersections = this.findSomeIntersectionsWith(id);
                    for (var branch = 0; branch < someIntersections.intersections.length; branch++) {
                        graphData[id][branch].poi.intersections = someIntersections.intersections[branch]
                    }
                    someIntersections.streamRest()
                }
                for (var sketch_id in graphData) {
                    this.triggerGraphComputed(sketch_id, graphData[sketch_id])
                }
            };
            context.updateIntersections = function (id) {
                if (!this.viewState) {
                    return
                }
                var statement = this.statements[id];
                if (!statement || !statement.shouldIntersect()) {
                    this.triggerDidUpdateIntersections(id, []);
                    return
                }
                this.findSomeIntersectionsWith(id).streamRest()
            };
            var streamIntersectionsTimeouts = {};
            context.findSomeIntersectionsWith = function (id1) {
                this.cancelIntersectionStreaming(id1);
                var runFor = 20;
                var waitFor = 60;
                var self = this;
                var push = Array.prototype.push;
                var statement1 = self.statements[id1];
                var graph_info = statement1.getGraphInfo();
                var graphMode = graph_info.graphMode;
                var compiled1 = self.statements[id1].compileAllBranches(self.getFrame());
                var otherStatements = [];
                for (var id2 in self.statements) {
                    if (!self.statements.hasOwnProperty(id2)) {
                        continue
                    }
                    if (String(id2) === String(id1)) {
                        continue
                    }
                    otherStatements.push(self.statements[id2])
                }
                var intersections = [];
                for (var branch = 0; branch < compiled1.length; branch++) {
                    intersections[branch] = {x: [], y: [], intersects: []}
                }
                var i = otherStatements.length - 1;
                var stream = false;
                var computeSome = function () {
                    var now = new Date();
                    var updated = false;
                    var fn1;
                    var fn2;
                    var newIntersections;
                    var statement2;
                    var compiled2;
                    var swap;
                    var indicatorSamples;
                    for (i; i >= 0; i--) {
                        if (new Date() - now > runFor) {
                            if (!stream) {
                                return
                            }
                            streamIntersectionsTimeouts[id1] = setTimeout(computeSome, waitFor);
                            if (!updated) {
                                return
                            }
                            self.triggerDidUpdateIntersections(id1, intersections);
                            return
                        }
                        statement2 = otherStatements[i];
                        if (!statement2.shouldIntersect()) {
                            continue
                        }
                        compiled2 = statement2.compileAllBranches(self.getFrame());
                        var graphMode2 = statement2.getGraphInfo().graphMode;
                        var modesxx = graphMode === GRAPHMODE.X && graphMode2 === GRAPHMODE.X;
                        var modesyy = graphMode === GRAPHMODE.Y && graphMode2 === GRAPHMODE.Y;
                        var modesxy = graphMode === GRAPHMODE.X && graphMode2 === GRAPHMODE.Y;
                        var modesyx = graphMode === GRAPHMODE.Y && graphMode2 === GRAPHMODE.X;
                        if (!(modesxx || modesyy || modesxy || modesyx)) {
                            continue
                        }
                        for (var branch1 = 0; branch1 < compiled1.length; branch1++) {
                            fn1 = compiled1[branch1].fn;
                            for (var branch2 = 0; branch2 < compiled2.length; branch2++) {
                                fn2 = compiled2[branch2].fn;
                                var indicatorFn;
                                if (modesxx || modesyy) {
                                    indicatorFn = function (x) {
                                        return fn2(x) - fn1(x)
                                    }
                                } else {
                                    if (modesxy || modesyx) {
                                        indicatorFn = function (x) {
                                            return x - fn2(fn1(x))
                                        }
                                    } else {
                                        continue
                                    }
                                }
                                if (newIntersections.x.length) {
                                    updated = true
                                }
                                newIntersections.intersects = Array(newIntersections.x.length);
                                for (var j = 0, jlen = newIntersections.x.length; j < jlen; j++) {
                                    newIntersections.intersects[j] = statement2.id
                                }
                                if (graphMode === GRAPHMODE.X) {
                                    swap = newIntersections.y;
                                    newIntersections.y = newIntersections.x;
                                    newIntersections.x = swap
                                }
                                push.apply(intersections[branch1].x, newIntersections.x);
                                push.apply(intersections[branch1].y, newIntersections.y);
                                push.apply(intersections[branch1].intersects, newIntersections.intersects)
                            }
                        }
                    }
                    if (!stream || !updated) {
                        return
                    }
                    self.triggerDidUpdateIntersections(id1, intersections);
                    self.cancelIntersectionStreaming(id1)
                };
                computeSome();
                return {
                    intersections: intersections, streamRest: function () {
                        self.triggerDidUpdateIntersections(id1, intersections);
                        stream = true;
                        computeSome()
                    }
                }
            };
            context.cancelIntersectionStreaming = function (id) {
                clearTimeout(streamIntersectionsTimeouts[id]);
                delete streamIntersectionsTimeouts[id]
            };
            context.cancelAllIntersectionStreaming = function () {
                for (var id in streamIntersectionsTimeouts[id]) {
                    if (!streamIntersectionsTimeouts.hasOwnProperty(id)) {
                        continue
                    }
                    this.cancelIntersectionStreaming(id)
                }
            };
            context.addStatement = function (statement) {
                if (!statement) {
                    return
                }
                var id = statement.id;
                this.markDirty(id);
                var previous_ids;
                if (this.statements.hasOwnProperty(id)) {
                    previous_ids = this.statements[id].getAllIds()
                }
                this.statements[id] = EvaluatorObject.createAnalysisObject(this, statement);
                if (previous_ids) {
                    for (var i = 0; i < previous_ids.length; i++) {
                        var previous_id = previous_ids[i];
                        if (previous_id != id) {
                            this.statements[id].cleanupId(previous_id)
                        }
                    }
                }
                this.markClean(statement.id);
                this.markDirty(statement.id)
            };
            context.removeStatement = function (id) {
                if (!this.statements.hasOwnProperty(id)) {
                    return
                }
                this.markDirty(id);
                delete this.statements[id]
            };
            context.recompute = function () {
                this.invalidate();
                this.publishChanges()
            };
            context.invalidate = function () {
                this.analysis = null;
                this.current_state = {};
                this.cancelAllIntersectionStreaming()
            };
            context.markDirty = function (id) {
                if (this.dirty[id]) {
                    return
                }
                this.dirty[id] = true;
                this.cancelIntersectionStreaming(id);
                if (!this.statements[id]) {
                    return
                }
                for (var symbol in this.statements[id].exportedSymbols()) {
                    this.markSymbolDirty(symbol)
                }
            };
            context.markSymbolDirty = function (symbol) {
                if (this.assignmentForbidden(symbol)) {
                    return
                }
                this.eachStatement(function (statement) {
                    if (statement.referencesSymbol(symbol)) {
                        this.markDirty(statement.id)
                    }
                })
            };
            context.markClean = function (id) {
                delete (this.dirty[id])
            };
            context.isDirty = function (id) {
                return this.dirty.hasOwnProperty(id)
            };
            context.getFrame = function () {
                return this.getAnalysis().frame
            };
            context.getAnalysis = function () {
                this.updateAnalysis();
                return this.analysis
            };
            context.getType = function (id) {
                return this.statements[id].getType()
            };
            context.updateAnalysis = function () {
                if (this.hasOwnProperty("partial_analysis")) {
                    throw"Programming error - two overlapping call to updateAnalysis"
                }
                var dirty_statements = [];
                var id;
                if (this.analysis) {
                    for (id in this.dirty) {
                        dirty_statements.push(id)
                    }
                    if (dirty_statements.length === 0) {
                        return
                    }
                } else {
                    for (id in this.statements) {
                        dirty_statements.push(id)
                    }
                }
                delete (this.analysis);
                this.partial_analysis = {};
                var a = this.partial_analysis;
                try {
                    a.frame = EvalFrame(this.parent_frame);
                    this.eachStatement(function (statement) {
                        var id = statement.id;
                        a[id] = {};
                        statement.setAnalysis(a[id]);
                        var error = statement.getParseError();
                        if (error) {
                            a[id].error = error
                        }
                    });
                    a.assignments = this.analyzeAssignments();
                    this.markVariableConflicts(a.assignments);
                    this.analyzeDependencies(a);
                    for (var i = 0; i < a.dependencyOrder.length; i++) {
                        id = a.dependencyOrder[i];
                        this.statements[id].exportDefinitionsTo(a.frame, id)
                    }
                    this.graph_changed = dirty_statements;
                    this.dirty = {};
                    var fm = a.frame.leafFunctionMap();
                    for (var name in fm) {
                        this.compiler.register(name, fm[name])
                    }
                    this.triggerDidUpdateFunctionMap(a.frame);
                    this.analyzeStatus(a);
                    if (Config.get("dragpoints")) {
                        this.analyzeMovable(a)
                    }
                    this.analysis = this.partial_analysis
                } catch (e) {
                    this.invalidate()
                } finally {
                    delete (this.partial_analysis)
                }
            };
            context.evaluateOnce = function (id) {
                if (!this.statements.hasOwnProperty(id)) {
                    throw ("Statement " + id + " not defined")
                }
                return this.statements[id].evaluateOnce(this.getFrame())
            };
            context.compile = function (id) {
                return this.statements[id].compile(this.getFrame())
            };
            context.evalStrings = function (id) {
                return this.statements[id].evalStrings(this.getFrame())
            };
            context.analyzeStatus = function (a) {
                this.eachStatement(function (statement) {
                    var id = statement.id;
                    var s = this.partial_analysis[id];
                    if (s.error) {
                        s.status = EvaluatorObject.status.ERROR
                    }
                    if (s.status) {
                        return
                    }
                    s.status = statement.computeStatus(a.frame)
                })
            };
            context.assignmentForbidden = function (identifier) {
                return (identifier === "x" || identifier === "y" || identifier === "theta")
            };
            context.getStatus = function (id) {
                if (this.getAnalysis()[id] === undefined) {
                    return undefined
                }
                return this.getAnalysis()[id].status
            };
            context.getEvaluationState = function (id) {
                this.getAnalysis();
                return this.statements[id].getEvaluationState()
            };
            context.analyzeAssignments = function () {
                var assignments = {};
                this.eachStatement(function (statement) {
                    var exports = statement.exportedSymbols();
                    for (var symbol in exports) {
                        if (this.assignmentForbidden(symbol)) {
                            continue
                        }
                        if (this.parent_frame && this.parent_frame.defines(symbol)) {
                            statement.markError(i18n.t("You can't use '__symbol__' here because it's already defined.", {symbol: symbol.replace("pi", "π")}));
                            continue
                        }
                        if (!assignments.hasOwnProperty(symbol)) {
                            assignments[symbol] = []
                        }
                        assignments[symbol].push({id: statement.id, arity: exports[symbol]})
                    }
                });
                return assignments
            };
            context.markVariableConflicts = function (assignments) {
                this.eachStatement(function (statement) {
                    var shadowed = statement.shadowedSymbols();
                    for (var i = 0; i < shadowed.length; i++) {
                        var symbol = shadowed[i];
                        if (assignments.hasOwnProperty(symbol)) {
                            statement.conflictError(symbol)
                        }
                    }
                })
            };
            context.analyzeDependencies = function (a) {
                var order = [];
                var ready = [];
                var block_count = {};
                var blocked_on = {};
                for (var id in this.statements) {
                    var s = a[id];
                    s.free_variables = [];
                    if (!this.statements.hasOwnProperty(id)) {
                        continue
                    }
                    var dependencies = this.statements[id].getDependencies();
                    block_count[id] = 0;
                    for (var dependency in dependencies) {
                        if (!dependencies.hasOwnProperty(dependency)) {
                            continue
                        }
                        var dependency_arity = dependencies[dependency];
                        if (this.parent_frame) {
                            if ((dependency_arity <= 1) && this.parent_frame.hasVariable(dependency)) {
                                continue
                            }
                            if ((dependency_arity >= 1) && this.parent_frame.hasFunctionWithArity(dependency, dependency_arity)) {
                                continue
                            }
                        }
                        var assigners = a.assignments[dependency];
                        if (this.parent_frame && this.parent_frame.defines(dependency)) {
                            var real_arity = this.parent_frame.arity(dependency);
                            if (real_arity === 0) {
                                s.error = i18n.t("Variable '__dependency__' can't be used as a function.", {dependency: dependency})
                            }
                            if (real_arity > 0) {
                                if (real_arity > 1) {
                                    s.error = i18n.t("Function '__dependency__' requires __num__ arguments.", {dependency: dependency, num: real_arity})
                                } else {
                                    s.error = i18n.t("Function '__dependency__' requires 1 argument.", {dependency: dependency}) + " " + i18n.t("For example, try typing: __recommendation__", {recommendation: dependency + "(x)"})
                                }
                            } else {
                                s.error = i18n.t("Something went wrong, please report this to desmos.com support. (Error __error_num__)", {error_num: "01185"})
                            }
                            continue
                        }
                        if (!assigners || assigners.length === 0) {
                            if (dependency_arity <= 1) {
                                this.statements[id].addFreeVariables([dependency])
                            } else {
                                s.error = i18n.t("Function '__dependency__' is not defined.", {dependency: dependency})
                            }
                        }
                        if (assigners && assigners.length === 1) {
                            var assignment_arity = assigners[0].arity;
                            if (assignment_arity === dependency_arity || (assignment_arity === 0 && dependency_arity === 1)) {
                                if (!blocked_on.hasOwnProperty(dependency)) {
                                    blocked_on[dependency] = []
                                }
                                blocked_on[dependency].push(id);
                                block_count[id]++
                            } else {
                                if (assignment_arity === 0) {
                                    s.error = i18n.t("Variable '__dependency__' can't be used as a function.", {dependency: dependency})
                                } else {
                                    if (assignment_arity == 1) {
                                        s.error = (i18n.t("Function '__dependency__' requires 1 argument.", {dependency: dependency}) + " " + i18n.t("For example, try typing: __recommendation__", {recommendation: dependency + "(x)"}))
                                    } else {
                                        s.error = i18n.t("Function '__dependency__' requires __num__ arguments.", {dependency: dependency, num: assignment_arity})
                                    }
                                }
                            }
                        }
                        if (assigners && assigners.length > 1) {
                            s.error = (i18n.t("You've defined '__dependency__' in more than one place. Try picking a different variable, or deleting some of the definitions of '__dependency__'.", {dependency: dependency}))
                        }
                    }
                    if (block_count[id] === 0) {
                        ready.push(id)
                    }
                }
                while (ready.length) {
                    var next = ready.pop();
                    if (a[next].error) {
                        continue
                    }
                    order.push(next);
                    var exported = this.statements[next].exportedSymbols();
                    for (var symbol in exported) {
                        var unblocked_list = blocked_on[symbol];
                        if (!unblocked_list) {
                            continue
                        }
                        while (unblocked_list.length) {
                            var unblocked = unblocked_list.pop();
                            this.statements[unblocked].addFreeVariables(a[next].free_variables);
                            block_count[unblocked]--;
                            if (block_count[unblocked] === 0) {
                                delete block_count[unblocked];
                                ready.push(unblocked)
                            }
                        }
                    }
                }
                for (id in block_count) {
                    if (block_count.hasOwnProperty(id) && block_count[id] !== 0) {
                        a[id].unresolved = true;
                        a[id].error = i18n.t("There is a circular dependency.")
                    }
                }
                a.dependencyOrder = order
            };
            context.analyzeMovable = function (a) {
                this.eachStatement(function (statement) {
                    if (statement.computeMovable) {
                        statement.computeMovable(a.frame)
                    }
                })
            }
        });
        return EvaluatorContext
    });
    define("worker/workercore", ["require", "math/evaluatorcontext", "math/builtinframe"], function (require) {
        var EvaluatorContext = require("math/evaluatorcontext");
        var BuiltInFrame = require("math/builtinframe");
        return function (sendMessage) {
            var context = EvaluatorContext(BuiltInFrame);
            context.triggerGraphComputed = function (id, data) {
                for (var i = 0; i < data.length; i++) {
                    if (data[i].compiled) {
                        delete data[i].compiled.fn
                    }
                }
                sendMessage("graphComputed", {id: id, graphData: data})
            };
            context.triggerDidUpdateIntersections = function (id, intersections) {
                sendMessage("updateIntersections", {id: id, intersections: intersections})
            };
            context.triggerDidUpdateFunctionMap = function (frame) {
                sendMessage("updateFunctionMap", frame.leafFunctionSourceMap())
            };
            context.triggerRender = function () {
                sendMessage("render")
            };
            context.triggerRenderSlowly = function () {
                sendMessage("renderSlowly")
            };
            context.triggerRemoveGraph = function (id) {
                sendMessage("removeGraph", id)
            };
            context.triggerDidSetDegreeMode = function (use_degrees) {
                sendMessage("setDegreeMode", use_degrees)
            };
            context.triggerStatusChange = function (data) {
                sendMessage("statusChange", data)
            };
            return {
                processChangeSet: function (changeSet) {
                    context.processChangeSet(changeSet);
                    sendMessage("processChangeSet", changeSet)
                }
            }
        }
    });
    define("worker/fakeworker", ["require", "worker/workercore"], function (require) {
        var WorkerCore = require("worker/workercore");
        return function (messageListener) {
            var fakeWorker = {};
            var workerCore = WorkerCore(sendMessage);

            function sendMessage(type, payload) {
                messageListener({data: {type: type, payload: payload}})
            }

            fakeWorker.postMessage = function (e) {
                setTimeout(function () {
                    workerCore.processChangeSet(e)
                }, 0)
            };
            return fakeWorker
        }
    });
    define("api/cross_origin_worker", ["require"], function (require) {
        return function (workerURL, config) {
            var location = window.location;
            var a = document.createElement("a");
            a.href = workerURL;
            a.href = a.href;
            var configString = JSON.stringify(config);
            if (a.protocol === location.protocol && a.host === location.host) {
                return workerURL + "?desmos_config=" + encodeURIComponent(configString)
            }
            var loadConfig = "Desmos = {}; Desmos.config = JSON.parse('" + configString + "');";
            var importString = "importScripts('" + workerURL + "');";
            var codeString = loadConfig + importString;
            var blob;
            try {
                blob = new Blob([codeString], {type: "application/javascript"})
            } catch (e) {
                var BlobBuilder = window.BlobBuilder || window.WebKitBlobBuilder || window.MozBlobBuilder || window.MSBlobBuilder;
                var blobBuilder = new BlobBuilder();
                blobBuilder.append(codeString);
                blob = blobBuilder.getBlob("application/javascript")
            }
            var URL = window.URL || window.webkitURL;
            return URL.createObjectURL(blob)
        }
    });
    define("main/evaluator", ["require", "pjs", "math/builtinframe", "worker/fakeworker", "math/functions", "api/cross_origin_worker", "config", "i18n"], function (require) {
        var P = require("pjs");
        var BuiltInFrame = require("math/builtinframe");
        var FakeWorker = require("worker/fakeworker");
        var Functions = require("math/functions");
        var crossOriginWorkerURL = require("api/cross_origin_worker");
        var Config = require("config");
        var i18n = require("i18n");
        var Evaluator = P(function (evaluator) {
            evaluator.triggerStatusChange = function (changes) {
            };
            evaluator.triggerRemove = function (id) {
            };
            evaluator.triggerGraphComputed = function (id, graphData) {
            };
            evaluator.triggerUpdateIntersections = function (id, intersections) {
            };
            evaluator.triggerRender = function () {
            };
            evaluator.triggerRenderSlowly = function () {
            };
            evaluator.init = function (workerPath) {
                this.functions = Functions();
                this.changeSet = null;
                this.jobsInWorker = 0;
                this.syncId = 1;
                this.processingDisabled = false;
                var useFakeWorker = function () {
                    this.worker = FakeWorker(this.processMessage.bind(this));
                    this.spawnNewWorker = function () {
                    }
                }.bind(this);
                if (workerPath) {
                    try {
                        var workerConfig = Config.all();
                        workerConfig.lang = i18n.currentLanguage();
                        this.workerPath = crossOriginWorkerURL(workerPath, workerConfig);
                        this.spawnNewWorker()
                    } catch (e) {
                        useFakeWorker()
                    }
                } else {
                    console.log("No worker path specified. Not using workers");
                    useFakeWorker()
                }
                this.syncRequests = [];
                this.listeners.setDegreeMode = function (use_degrees) {
                    BuiltInFrame.setDegreeMode(use_degrees)
                };
                this.functions.updateFromFunctionMap(BuiltInFrame.functionMap())
            };
            evaluator.spawnNewWorker = function () {
                if (this.worker) {
                    this.worker.terminate()
                }
                this.worker = new Worker(this.workerPath);
                this.worker.addEventListener("message", this.processMessage.bind(this));
                this.worker.onerror = function (evt) {
                    console.log(evt)
                };
                this.jobsInWorker = 0
            };
            evaluator.processMessage = function (e) {
                this.listeners[e.data.type].call(this, e.data.payload)
            };
            evaluator.listeners = {};
            evaluator.listeners.processChangeSet = function (changeSet) {
                var syncId = changeSet.syncId;
                while (this.syncRequests.length && this.syncRequests[0].id <= syncId) {
                    var syncRequest = this.syncRequests.shift();
                    syncRequest.callback()
                }
                this.jobsInWorker--;
                this.processChangeSet()
            };
            evaluator.listeners.log = function (msg) {
                console.log(msg)
            };
            evaluator.listeners.removeGraph = function (id) {
                this.triggerRemove(id)
            };
            evaluator.listeners.graphComputed = function (payload) {
                this.functions.rehydrateGraphData(payload.graphData);
                this.triggerGraphComputed(payload.id, payload.graphData)
            };
            evaluator.listeners.updateFunctionMap = function (sourceFunctionMap) {
                this.functions.updateFromSourceMap(sourceFunctionMap)
            };
            evaluator.listeners.updateIntersections = function (payload) {
                this.triggerUpdateIntersections(payload.id, payload.intersections)
            };
            evaluator.listeners.statusChange = function (changes) {
                this.triggerStatusChange(changes)
            };
            evaluator.listeners.render = function () {
                this.triggerRender()
            };
            evaluator.listeners.renderSlowly = function () {
                this.triggerRenderSlowly()
            };
            evaluator._disableProcessing = function () {
                this.processingDisabled = true
            };
            evaluator._enableProcessing = function () {
                this.processingDisabled = false;
                this.processChangeSet()
            };
            evaluator.batch = function (fn) {
                var alreadyDisabled = this.processingDisabled;
                this._disableProcessing();
                try {
                    fn()
                } finally {
                    if (!alreadyDisabled) {
                        this._enableProcessing()
                    }
                }
            };
            evaluator.processChangeSet = function () {
                if (!this.changeSet) {
                    return
                }
                if (this.processingDisabled) {
                    return
                }
                if (this.jobsInWorker > 0) {
                    return
                }
                var changeSet = this.changeSet;
                this.jobsInWorker++;
                this.changeSet = null;
                this.worker.postMessage(changeSet)
            };
            var withChangeSet = function (fn) {
                return function () {
                    if (!this.changeSet) {
                        this.changeSet = {}
                    }
                    fn.apply(this, arguments);
                    this.processChangeSet()
                }
            };
            evaluator.setViewState = withChangeSet(function (viewState) {
                this.changeSet.viewState = viewState
            });
            evaluator.setCompleteState = withChangeSet(function (statements) {
                if (this.jobsInWorker > 0) {
                    this.spawnNewWorker()
                }
                this.changeSet.isCompleteState = true;
                this.changeSet.statements = statements
            });
            evaluator.addStatement = withChangeSet(function (statement) {
                if (!this.changeSet.statements) {
                    this.changeSet.statements = {}
                }
                this.changeSet.statements[statement.id] = statement
            });
            evaluator.addStatements = withChangeSet(function (statements) {
                for (var i = 0; i < statements.length; i++) {
                    this.addStatement(statements[i])
                }
            });
            evaluator.removeStatement = withChangeSet(function (id) {
                if (!this.changeSet.statements) {
                    this.changeSet.statements = {}
                }
                this.changeSet.statements[id] = null
            });
            evaluator.removeStatements = withChangeSet(function (ids) {
                for (var i = 0; i < ids.length; i++) {
                    this.removeStatement(ids[i])
                }
            });
            evaluator.setIntersectIds = withChangeSet(function (intersectIds) {
                this.changeSet.intersectIds = intersectIds
            });
            evaluator.updateIntersections = withChangeSet(function (id) {
                this.changeSet.intersectId = id
            });
            evaluator.setDegreeMode = withChangeSet(function (use_degrees) {
                this.changeSet.degreeMode = use_degrees
            });
            evaluator.notifyWhenSynced = withChangeSet(function (callback) {
                this.syncId++;
                this.syncRequests.push({id: this.syncId, callback: callback});
                this.changeSet.syncId = this.syncId
            })
        });
        return Evaluator
    });
    define("browser", ["require", "jquery"], function (require) {
        var $ = require("jquery");
        var Browser = {
            IS_IE8: navigator.userAgent.match(/MSIE 8.0/i) !== null,
            IS_IE9: navigator.userAgent.match(/MSIE 9.0/i) !== null,
            IS_IE: navigator.userAgent.match(/MSIE/i) !== null,
            IS_IPAD: navigator.userAgent.match(/iPad/i) !== null,
            IS_MOBILE: navigator.userAgent.match(/Mobile|Android/i) !== null,
            IS_ANDROID: navigator.userAgent.match(/Android/i) !== null,
            IS_KINDLE: navigator.userAgent.match(/Kindle/i) !== null || navigator.userAgent.match(/Silk/i) !== null,
            IS_IN_IFRAME: window.parent !== window
        };
        Browser.IS_TABLET = (Browser.IS_IPAD || Browser.IS_ANDROID || Browser.IS_KINDLE);
        Browser.IS_OPERA_LT_12 = (function () {
            if (!navigator.userAgent.match(/OPERA/i)) {
                return false
            }
            var match = navigator.userAgent.match(/Version\/(\d+)/);
            if (!(match && match[1])) {
                return false
            }
            var operaVersion = parseInt(match[1], 10);
            return operaVersion < 12
        })();
        Browser.SUPPORTS_TRANSLATE3D = false;
        $(document).ready(function () {
            var el = document.createElement("p");
            var has3d;
            var computedStyle;
            var transforms = {webkitTransform: "-webkit-transform", OTransform: "-o-transform", msTransform: "-ms-transform", MozTransform: "-moz-transform", transform: "transform"};
            document.body.insertBefore(el, null);
            for (var t in transforms) {
                if (el.style[t] !== undefined) {
                    el.style[t] = "translate3d(1px,1px,1px)";
                    computedStyle = window.getComputedStyle(el);
                    if (!computedStyle) {
                        return
                    }
                    has3d = computedStyle.getPropertyValue(transforms[t])
                }
            }
            document.body.removeChild(el);
            Browser.SUPPORTS_TRANSLATE3D = (has3d !== undefined && has3d.length > 0 && has3d !== "none")
        });
        Browser.translateRule = function (x, y) {
            if (Browser.SUPPORTS_TRANSLATE3D) {
                return "translate3d(" + x + (x ? "px" : "") + "," + y + (y ? "px" : "") + ",0)"
            }
            return "translate(" + x + (x ? "px" : "") + "," + y + (y ? "px" : "") + ")"
        };
        Browser.CAPABLE_BROWSER = (function () {
            var is_too_small = false;
            if (window.matchMedia) {
                var mq = window.matchMedia("(max-device-width:480px)");
                if (mq && mq.matches) {
                    is_too_small = true
                }
            } else {
                if (Browser.IS_ANDROID) {
                    is_too_small = true
                }
            }
            var elem = document.createElement("canvas");
            var supports_canvas = !!(elem.getContext && elem.getContext("2d"));
            var is_iOS3 = (Browser.IS_IPAD && (navigator.userAgent.match(/OS 3/i) !== null));
            return ((supports_canvas) && !(is_too_small || Browser.IS_KINDLE || is_iOS3))
        })();
        return Browser
    });
    define("graphing/viewport", ["require"], function (require) {
        function Viewport(xmin, xmax, ymin, ymax) {
            this.xmin = xmin !== undefined ? xmin : -10;
            this.xmax = xmax !== undefined ? xmax : 10;
            this.ymin = ymin !== undefined ? ymin : -10;
            this.ymax = ymax !== undefined ? ymax : 10
        }

        Viewport.prototype.toObject = function () {
            return {xmin: this.xmin, ymin: this.ymin, xmax: this.xmax, ymax: this.ymax}
        };
        Viewport.fromObject = function (obj) {
            return new Viewport(obj.xmin, obj.xmax, obj.ymin, obj.ymax)
        };
        Viewport.prototype.equals = function (viewport) {
            if (this.xmin !== viewport.xmin) {
                return false
            }
            if (this.ymin !== viewport.ymin) {
                return false
            }
            if (this.xmax !== viewport.xmax) {
                return false
            }
            if (this.ymax !== viewport.ymax) {
                return false
            }
            return true
        };
        Viewport.prototype.isXValid = function () {
            return (this.xmax - this.xmin > 0)
        };
        Viewport.prototype.isYValid = function () {
            return (this.ymax - this.ymin > 0)
        };
        Viewport.prototype.isValid = function () {
            return this.isXValid() && this.isYValid()
        };
        Viewport.prototype.isSquare = function (screen) {
            return Math.abs(screen.height - screen.width * this.aspectRatio()) < 1
        };
        Viewport.prototype.aspectRatio = function () {
            return (this.ymax - this.ymin) / (this.xmax - this.xmin)
        };
        Viewport.prototype.squareXAxis = function (screen) {
            var xrange = this.xmax - this.xmin;
            var yrange = this.ymax - this.ymin;
            var xcenter = this.xmin + xrange / 2;
            var new_xrange = yrange / screen.height * screen.width;
            this.xmin = xcenter - new_xrange / 2;
            this.xmax = xcenter + new_xrange / 2
        };
        Viewport.prototype.squareYAxis = function (screen) {
            if (screen.width === 0 || screen.height === 0) {
                return
            }
            var xrange = this.xmax - this.xmin;
            var yrange = this.ymax - this.ymin;
            var ycenter = this.ymin + yrange / 2;
            var new_yrange = xrange / screen.width * screen.height;
            this.ymin = ycenter - new_yrange / 2;
            this.ymax = ycenter + new_yrange / 2
        };
        Viewport.prototype.squareCrop = function (screen) {
            if (this.aspectRatio() > screen.height / screen.width) {
                this.squareYAxis(screen)
            } else {
                this.squareXAxis(screen)
            }
        };
        Viewport.prototype.round = function (screen) {
            if (screen.height === 0 || screen.width === 0) {
                return
            }
            var xrange = this.xmax - this.xmin;
            var yrange = this.ymax - this.ymin;
            var x_pixel_units = xrange / screen.width;
            var y_pixel_units = yrange / screen.height
        };
        Viewport.prototype.clone = function () {
            return new Viewport(this.xmin, this.xmax, this.ymin, this.ymax)
        };
        Viewport.prototype.polarDiameter = function () {
            var d1 = Math.abs(this.xmax), d2 = Math.abs(this.xmin);
            var d3 = Math.abs(this.ymax), d4 = Math.abs(this.ymin);
            return 1.5 * Math.max(d1, d2, d3, d4)
        };
        Viewport.prototype.largestR = function () {
            return Math.sqrt(Math.pow(Math.max(-this.xmin, this.xmax), 2) + Math.pow(Math.max(-this.ymin, this.ymax), 2))
        };
        Viewport.prototype.smallestR = function () {
            if (this.xmin <= 0 && this.xmax >= 0 && this.ymin <= 0 && this.ymax >= 0) {
                return 0
            }
            if (this.xmin <= 0 && this.xmax >= 0) {
                return Math.min(Math.abs(this.ymin), Math.abs(this.ymax))
            }
            if (this.ymin <= 0 && this.ymax >= 0) {
                return Math.min(Math.abs(this.xmin), Math.abs(this.xmax))
            }
            return Math.sqrt(Math.pow(Math.max(this.xmin, -this.xmax), 2) + Math.pow(Math.max(this.ymin, -this.ymax), 2))
        };
        return Viewport
    });
    define("graphing/screen", ["require"], function (require) {
        function Screen(width, height) {
            this.width = width;
            this.height = height;
            return this
        }

        return Screen
    });
    define("text", ["module"], function (module) {
        var text, fs, Cc, Ci, progIds = ["Msxml2.XMLHTTP", "Microsoft.XMLHTTP", "Msxml2.XMLHTTP.4.0"], xmlRegExp = /^\s*<\?xml(\s)+version=[\'\"](\d)*.(\d)*[\'\"](\s)*\?>/im, bodyRegExp = /<body[^>]*>\s*([\s\S]+)\s*<\/body>/im, hasLocation = typeof location !== "undefined" && location.href, defaultProtocol = hasLocation && location.protocol && location.protocol.replace(/\:/, ""), defaultHostName = hasLocation && location.hostname, defaultPort = hasLocation && (location.port || undefined), buildMap = {}, masterConfig = (module.config && module.config()) || {};
        text = {
            version: "2.0.7", strip: function (content) {
                if (content) {
                    content = content.replace(xmlRegExp, "");
                    var matches = content.match(bodyRegExp);
                    if (matches) {
                        content = matches[1]
                    }
                } else {
                    content = ""
                }
                return content
            }, jsEscape: function (content) {
                return content.replace(/(['\\])/g, "\\$1").replace(/[\f]/g, "\\f").replace(/[\b]/g, "\\b").replace(/[\n]/g, "\\n").replace(/[\t]/g, "\\t").replace(/[\r]/g, "\\r").replace(/[\u2028]/g, "\\u2028").replace(/[\u2029]/g, "\\u2029")
            }, createXhr: masterConfig.createXhr || function () {
                var xhr, i, progId;
                if (typeof XMLHttpRequest !== "undefined") {
                    return new XMLHttpRequest()
                } else {
                    if (typeof ActiveXObject !== "undefined") {
                        for (i = 0; i < 3; i += 1) {
                            progId = progIds[i];
                            try {
                                xhr = new ActiveXObject(progId)
                            } catch (e) {
                            }
                            if (xhr) {
                                progIds = [progId];
                                break
                            }
                        }
                    }
                }
                return xhr
            }, parseName: function (name) {
                var modName, ext, temp, strip = false, index = name.indexOf("."), isRelative = name.indexOf("./") === 0 || name.indexOf("../") === 0;
                if (index !== -1 && (!isRelative || index > 1)) {
                    modName = name.substring(0, index);
                    ext = name.substring(index + 1, name.length)
                } else {
                    modName = name
                }
                temp = ext || modName;
                index = temp.indexOf("!");
                if (index !== -1) {
                    strip = temp.substring(index + 1) === "strip";
                    temp = temp.substring(0, index);
                    if (ext) {
                        ext = temp
                    } else {
                        modName = temp
                    }
                }
                return {moduleName: modName, ext: ext, strip: strip}
            }, xdRegExp: /^((\w+)\:)?\/\/([^\/\\]+)/, useXhr: function (url, protocol, hostname, port) {
                var uProtocol, uHostName, uPort, match = text.xdRegExp.exec(url);
                if (!match) {
                    return true
                }
                uProtocol = match[2];
                uHostName = match[3];
                uHostName = uHostName.split(":");
                uPort = uHostName[1];
                uHostName = uHostName[0];
                return (!uProtocol || uProtocol === protocol) && (!uHostName || uHostName.toLowerCase() === hostname.toLowerCase()) && ((!uPort && !uHostName) || uPort === port)
            }, finishLoad: function (name, strip, content, onLoad) {
                content = strip ? text.strip(content) : content;
                if (masterConfig.isBuild) {
                    buildMap[name] = content
                }
                onLoad(content)
            }, load: function (name, req, onLoad, config) {
                if (config.isBuild && !config.inlineText) {
                    onLoad();
                    return
                }
                masterConfig.isBuild = config.isBuild;
                var parsed = text.parseName(name), nonStripName = parsed.moduleName + (parsed.ext ? "." + parsed.ext : ""), url = req.toUrl(nonStripName), useXhr = (masterConfig.useXhr) || text.useXhr;
                if (!hasLocation || useXhr(url, defaultProtocol, defaultHostName, defaultPort)) {
                    text.get(url, function (content) {
                        text.finishLoad(name, parsed.strip, content, onLoad)
                    }, function (err) {
                        if (onLoad.error) {
                            onLoad.error(err)
                        }
                    })
                } else {
                    req([nonStripName], function (content) {
                        text.finishLoad(parsed.moduleName + "." + parsed.ext, parsed.strip, content, onLoad)
                    })
                }
            }, write: function (pluginName, moduleName, write, config) {
                if (buildMap.hasOwnProperty(moduleName)) {
                    var content = text.jsEscape(buildMap[moduleName]);
                    write.asModule(pluginName + "!" + moduleName, "define(function () { return '" + content + "';});\n")
                }
            }, writeFile: function (pluginName, moduleName, req, write, config) {
                var parsed = text.parseName(moduleName), extPart = parsed.ext ? "." + parsed.ext : "", nonStripName = parsed.moduleName + extPart, fileName = req.toUrl(parsed.moduleName + extPart) + ".js";
                text.load(nonStripName, req, function (value) {
                    var textWrite = function (contents) {
                        return write(fileName, contents)
                    };
                    textWrite.asModule = function (moduleName, contents) {
                        return write.asModule(moduleName, fileName, contents)
                    };
                    text.write(pluginName, nonStripName, textWrite, config)
                }, config)
            }
        };
        if (masterConfig.env === "node" || (!masterConfig.env && typeof process !== "undefined" && process.versions && !!process.versions.node)) {
            fs = require.nodeRequire("fs");
            text.get = function (url, callback, errback) {
                try {
                    var file = fs.readFileSync(url, "utf8");
                    if (file.indexOf("\uFEFF") === 0) {
                        file = file.substring(1)
                    }
                    callback(file)
                } catch (e) {
                    errback(e)
                }
            }
        } else {
            if (masterConfig.env === "xhr" || (!masterConfig.env && text.createXhr())) {
                text.get = function (url, callback, errback, headers) {
                    var xhr = text.createXhr(), header;
                    xhr.open("GET", url, true);
                    if (headers) {
                        for (header in headers) {
                            if (headers.hasOwnProperty(header)) {
                                xhr.setRequestHeader(header.toLowerCase(), headers[header])
                            }
                        }
                    }
                    if (masterConfig.onXhr) {
                        masterConfig.onXhr(xhr, url)
                    }
                    xhr.onreadystatechange = function (evt) {
                        var status, err;
                        if (xhr.readyState === 4) {
                            status = xhr.status;
                            if (status > 399 && status < 600) {
                                err = new Error(url + " HTTP status: " + status);
                                err.xhr = xhr;
                                errback(err)
                            } else {
                                callback(xhr.responseText)
                            }
                            if (masterConfig.onXhrComplete) {
                                masterConfig.onXhrComplete(xhr, url)
                            }
                        }
                    };
                    xhr.send(null)
                }
            } else {
                if (masterConfig.env === "rhino" || (!masterConfig.env && typeof Packages !== "undefined" && typeof java !== "undefined")) {
                    text.get = function (url, callback) {
                        var stringBuffer, line, encoding = "utf-8", file = new java.io.File(url), lineSeparator = java.lang.System.getProperty("line.separator"), input = new java.io.BufferedReader(new java.io.InputStreamReader(new java.io.FileInputStream(file), encoding)), content = "";
                        try {
                            stringBuffer = new java.lang.StringBuffer();
                            line = input.readLine();
                            if (line && line.length() && line.charAt(0) === 65279) {
                                line = line.substring(1)
                            }
                            if (line !== null) {
                                stringBuffer.append(line)
                            }
                            while ((line = input.readLine()) !== null) {
                                stringBuffer.append(lineSeparator);
                                stringBuffer.append(line)
                            }
                            content = String(stringBuffer.toString())
                        } finally {
                            input.close()
                        }
                        callback(content)
                    }
                } else {
                    if (masterConfig.env === "xpconnect" || (!masterConfig.env && typeof Components !== "undefined" && Components.classes && Components.interfaces)) {
                        Cc = Components.classes, Ci = Components.interfaces;
                        Components.utils["import"]("resource://gre/modules/FileUtils.jsm");
                        text.get = function (url, callback) {
                            var inStream, convertStream, readData = {}, fileObj = new FileUtils.File(url);
                            try {
                                inStream = Cc["@mozilla.org/network/file-input-stream;1"].createInstance(Ci.nsIFileInputStream);
                                inStream.init(fileObj, 1, 0, false);
                                convertStream = Cc["@mozilla.org/intl/converter-input-stream;1"].createInstance(Ci.nsIConverterInputStream);
                                convertStream.init(inStream, "utf-8", inStream.available(), Ci.nsIConverterInputStream.DEFAULT_REPLACEMENT_CHARACTER);
                                convertStream.readString(inStream.available(), readData);
                                convertStream.close();
                                inStream.close();
                                callback(readData.value)
                            } catch (e) {
                                throw new Error((fileObj && fileObj.path || "") + ": " + e)
                            }
                        }
                    }
                }
            }
        }
        return text
    });
    define("loadcss", ["text"], function (text) {
        var buildMap = {};

        function inject_css_file(href) {
            var head = document.getElementsByTagName("head")[0];
            var link = document.createElement("link");
            link.href = href;
            link.rel = "stylesheet";
            link.type = "text/css";
            head.appendChild(link)
        }

        return {
            load: function (name, req, onLoad, config) {
                var filename = req.toUrl(name) + ".css";
                if (config.isBuild) {
                    text.get(filename, function (css_source) {
                        buildMap[name] = css_source;
                        onLoad()
                    })
                } else {
                    inject_css_file(filename);
                    onLoad()
                }
            }, onLayerEnd: function (write, data) {
                var complete_css = "";
                for (var moduleName in buildMap) {
                    complete_css += buildMap[moduleName]
                }
                var fs = require.nodeRequire("fs");
                var css_file = data.path.replace(/\.js/g, ".required.css");
                fs.writeFileSync(css_file, complete_css, "utf8")
            }, write: function (pluginName, moduleName, write) {
                if (moduleName in buildMap) {
                    write("define('" + pluginName + "!" + moduleName + "', function(){});")
                } else {
                    console.log("ERROR - failed to find css " + moduleName + " in buildMap")
                }
            }
        }
    });
    (function ($) {
        $.fn.disableTextSelection = function (removeFocus) {
            if (removeFocus) {
                this.each(function () {
                    $(this).bind("mousedown touchstart", function () {
                        $(document.activeElement).focusout()
                    })
                })
            }
            return this.each(function () {
                $(this).attr("unselectable", "on").css({"-moz-user-select": "none", "-webkit-user-select": "none", "user-select": "none"}).each(function () {
                    this.onselectstart = function () {
                        return false
                    }
                })
            })
        }
    })(jQuery);
    define("jquery.disabletextselection", function () {
    });
    define("ipad.ghostevents", ["require"], function (require) {
        var inGhostEventMode = false;
        var startingActiveElement = null;

        function stopGhostEvent(evt) {
            if (inGhostEventMode) {
                evt.stopPropagation();
                evt.stopImmediatePropagation()
            }
        }

        function stopAndPreventGhostEvent(evt) {
            if (inGhostEventMode) {
                evt.preventDefault();
                evt.stopPropagation();
                evt.stopImmediatePropagation()
            }
        }

        var touchTrackingCallbacks = {
            isGhostEvent: function (evt) {
                return false
            }
        };
        document.addEventListener("mousedown", function (evt) {
            startingActiveElement = document.activeElement;
            inGhostEventMode = touchTrackingCallbacks.isGhostEvent(evt);
            stopGhostEvent(evt)
        }, true);
        document.addEventListener("mouseup", stopGhostEvent, true);
        document.addEventListener("click", function (evt) {
            stopAndPreventGhostEvent(evt);
            if (inGhostEventMode && document.activeElement !== startingActiveElement) {
                if (document.activeElement) {
                    document.activeElement.blur()
                }
                if (startingActiveElement) {
                    startingActiveElement.focus()
                }
            }
            inGhostEventMode = false
        }, true);
        document.addEventListener("focus", stopAndPreventGhostEvent, true);
        document.addEventListener("blur", stopAndPreventGhostEvent, true);
        return touchTrackingCallbacks
    });
    define("touchtracking", ["require", "jquery", "ipad.ghostevents"], function (require) {
        var $ = require("jquery");
        var GhostEvents = require("ipad.ghostevents");
        GhostEvents.isGhostEvent = function (evt) {
            if (mode !== TOUCH_MODE && !hasRecentlyEndedTouchMode()) {
                return false
            }
            if (evt.target === lastTarget) {
                return false
            }
            if (evt.target && $.contains(evt.target, lastTarget)) {
                return false
            }
            if (lastTarget && $.contains(lastTarget, evt.target)) {
                return false
            }
            return true
        };
        var NO_MODE = 0;
        var TOUCH_MODE = 1;
        var MOUSE_MODE = 2;
        var MSPOINTER_TYPE_PEN = 3;
        var MSPOINTER_TYPE_MOUSE = 4;
        var mode = NO_MODE;
        var modeEvents = {};
        var modeTargets = [];
        var endTouchModeTime = 0;
        var endTouchModeTimeout = null;
        var lastTarget = null;
        var longholdTimeout = null;
        var pointerTouches = [];
        var getAncestors = function (node) {
            var nodes = [];
            while (node) {
                nodes.push(node);
                node = node.parentNode
            }
            return nodes
        };
        var filterSortedNodesWithinScope = function (sortedNodes) {
            var filtered = [];
            for (var i = 0; i < sortedNodes.length; i++) {
                var node = sortedNodes[i];
                filtered.push(node);
                if ($(node).hasClass("dcg-container")) {
                    return filtered
                }
            }
            return []
        };
        var beginMode = function (evnt) {
            lastTarget = null;
            if (evnt.type === "mousedown") {
                mode = MOUSE_MODE;
                modeTargets = getAncestors(evnt.target)
            } else {
                if (evnt.type === "pointerdown" || evnt.type === "MSPointerDown") {
                    mode = TOUCH_MODE;
                    modeTargets = getAncestors(evnt.target)
                } else {
                    mode = TOUCH_MODE;
                    modeTargets = getAncestors(evnt.originalEvent.touches[0].target)
                }
            }
            $(filterSortedNodesWithinScope(modeTargets)).addClass("dcg-depressed");
            $(modeTargets).each(function () {
                var elm = $(this);
                elm.data({originalScrollTop: elm.scrollTop(), originalScrollLeft: elm.scrollLeft()})
            });
            modeEvents = {}
        };
        var endMode = function (evnt) {
            lastTarget = null;
            $(".dcg-depressed").removeClass("dcg-depressed");
            $(modeTargets).each(function () {
                var elm = $(this);
                var verticalOffset = elm.data("originalScrollTop") - elm.scrollTop();
                var horizontalOffset = elm.data("originalScrollLeft") - elm.scrollLeft();
                if (verticalOffset || horizontalOffset) {
                    modeEvents.scroll = true
                }
            });
            if (modeEvents.tapstart === 1 && modeEvents.tapend === 1 && !modeEvents.tapcancel && !modeEvents.scroll) {
                var x = evnt.device === "mouse" ? evnt.pageX : evnt.originalEvent.changedTouches[0].pageX;
                var y = evnt.device === "mouse" ? evnt.pageY : evnt.originalEvent.changedTouches[0].pageY;
                var tap_escaped_boundary = false;
                for (var i = 0; i < modeTargets.length && !tap_escaped_boundary; i++) {
                    var target = $(modeTargets[i]);
                    var offset = target.offset();
                    if (target.attr("tapboundary") === "true") {
                        tap_escaped_boundary = true
                    }
                    if (offset) {
                        if (x < offset.left || y < offset.top) {
                            continue
                        }
                        if (x > offset.left + target.outerWidth()) {
                            continue
                        }
                        if (y > offset.top + target.outerHeight()) {
                            continue
                        }
                    }
                    lastTarget = target[0];
                    dispatchEvent("tap", evnt, lastTarget);
                    break
                }
            }
            if (mode === TOUCH_MODE) {
                endTouchModeTimeout = setTimeout(function () {
                    endTouchModeTimeout = null;
                    endTouchModeTime = new Date().getTime()
                }, 1000)
            }
            modeTargets = [];
            mode = NO_MODE
        };
        var hasRecentlyEndedTouchMode = function () {
            return endTouchModeTimeout || new Date().getTime() - endTouchModeTime < 500
        };
        var clone = function (touches) {
            var cloned = [];
            for (var i = 0; i < touches.length; i++) {
                var touch = touches[i];
                cloned.push({
                    identifier: touch.identifier,
                    x: touch.pageX,
                    y: touch.pageY,
                    screenX: touch.screenX,
                    screenY: touch.screenY,
                    pageX: touch.pageX,
                    pageY: touch.pageY,
                    clientX: touch.clientX,
                    clientY: touch.clientY
                })
            }
            return cloned
        };
        var dispatchEvent = function (type, evnt, differentTarget) {
            if (modeEvents[type.toLowerCase()] === undefined) {
                modeEvents[type.toLowerCase()] = 1
            } else {
                modeEvents[type.toLowerCase()]++
            }
            var newEvnt = $.event.fix(evnt.originalEvent);
            newEvnt.type = type;
            newEvnt.device = mode === TOUCH_MODE ? "touch" : "mouse";
            newEvnt.touches = clone(evnt.originalEvent.touches);
            newEvnt.changedTouches = clone(evnt.originalEvent.changedTouches);
            newEvnt.target = differentTarget ? differentTarget : evnt.target;
            var wasLongheld = modeEvents.longhold > 0;
            newEvnt.wasLongheld = function () {
                return wasLongheld
            };
            clearTimeout(longholdTimeout);
            if (newEvnt.type === "tapstart" && newEvnt.touches.length === 1) {
                longholdTimeout = setTimeout(function () {
                    dispatchEvent("longhold", evnt, differentTarget)
                }, 500)
            }
            $(newEvnt.target).trigger(newEvnt)
        };
        var setHoveredNode = function (node) {
            var hoverableNodes = modeTargets;
            var checkIfNodeIsHoverable = !!modeTargets.length;
            var hoveredBefore = $.makeArray($(".dcg-hovered"));
            var hoveredNow = [];
            var lostHover = [];
            var gainedHover = [];
            filterSortedNodesWithinScope(getAncestors(node)).forEach(function (node) {
                if (!checkIfNodeIsHoverable || hoverableNodes.indexOf(node) !== -1) {
                    if (hoveredBefore.indexOf(node) === -1) {
                        gainedHover.push(node)
                    }
                    hoveredNow.push(node)
                }
            });
            for (var i = 0; i < hoveredBefore.length; i++) {
                node = hoveredBefore[i];
                if (hoveredNow.indexOf(node) === -1) {
                    lostHover.push(node)
                }
            }
            $(lostHover).removeClass("dcg-hovered").trigger("tipsyhide");
            $(gainedHover).addClass("dcg-hovered").trigger("tipsyshow")
        };
        var removePointerEventById = function (id) {
            for (var i = 0; i < pointerTouches.length; i++) {
                if (pointerTouches[i].pointerId === id) {
                    return pointerTouches.splice(i, 1)[0]
                }
            }
        };
        var isMSMouseEvent = function (evnt) {
            return (evnt.originalEvent.pointerType === "mouse" || evnt.originalEvent.pointerType === "pen" || evnt.originalEvent.pointerType === MSPOINTER_TYPE_MOUSE || evnt.originalEvent.pointer === MSPOINTER_TYPE_PEN)
        };
        $(document).on("pointerdown MSPointerDown", function (evnt) {
            // if (isMSMouseEvent(evnt)) {
            //     return
            // if (mode === NO_MODE) {
            //     beginMode(evnt)
            // }
            // setHoveredNode(null);
            // pointerTouches.push(evnt.originalEvent);
            // evnt.originalEvent.identifier = evnt.originalEvent.pointerId;
            // evnt.originalEvent.touches = pointerTouches;
            // evnt.originalEvent.changedTouches = [evnt.originalEvent];
            // evnt.preventDefault();
            // dispatchEvent("tapstart", evnt)
        });
        $(document).on("pointermove MSPointerMove", function (evnt) {
            if (isMSMouseEvent(evnt)) {
                return
            }
            removePointerEventById(evnt.originalEvent.pointerId);
            pointerTouches.push(evnt.originalEvent);
            evnt.originalEvent.identifier = evnt.originalEvent.pointerId;
            evnt.originalEvent.touches = pointerTouches;
            evnt.originalEvent.changedTouches = [evnt.originalEvent];
            evnt.preventDefault();
            dispatchEvent("tapmove", evnt)
        });
        $(document).on("pointercancel MSPointerCancel", function (evnt) {
            if (isMSMouseEvent(evnt)) {
                return
            }
            removePointerEventById(evnt.originalEvent.pointerId);
            evnt.originalEvent.identifier = evnt.originalEvent.pointerId;
            evnt.originalEvent.touches = pointerTouches;
            evnt.originalEvent.changedTouches = [evnt.originalEvent];
            dispatchEvent("tapcancel", evnt);
            evnt.preventDefault();
            if (evnt.originalEvent.touches.length === 0) {
                endMode(evnt)
            }
        });
        $(document).on("pointerup MSPointerUp", function (evnt) {
            // if (isMSMouseEvent(evnt)) {
            //     return
            // }
            // removePointerEventById(evnt.originalEvent.pointerId);
            // evnt.originalEvent.identifier = evnt.originalEvent.pointerId;
            // evnt.originalEvent.touches = pointerTouches;
            // evnt.originalEvent.changedTouches = [evnt.originalEvent];
            // dispatchEvent("tapend", evnt);
            // evnt.preventDefault();
            // if (evnt.originalEvent.touches.length === 0) {
            //     endMode(evnt)
            // }
        });
        $(document).on("touchstart", function (evnt) {
            if (mode === MOUSE_MODE) {
                return
            }
            if (mode === NO_MODE) {
                beginMode(evnt)
            }
            setHoveredNode(null);
            if (!Demo.canTouch) {
                if (evnt.target.className.indexOf("feedbackspan") >= 0) {
                } else {
                    return
                }
            }
            dispatchEvent("tapstart", evnt)
        });
        $(document).on("touchmove", function (evnt) {
            if (mode !== TOUCH_MODE) {
                return
            }
            dispatchEvent("tapmove", evnt)
        });
        $(document).on("touchcancel", function (evnt) {
            if (mode !== TOUCH_MODE) {
                return
            }
            dispatchEvent("tapcancel", evnt);
            if (evnt.originalEvent.touches.length === 0) {
                endMode(evnt)
            }
        });
        $(document).on("touchend", function (evnt) {
            if (mode !== TOUCH_MODE) {
                return
            }
            dispatchEvent("tapend", evnt);
            if (evnt.originalEvent.touches.length === 0) {
                endMode(evnt)
            }
        });
        $(document).on("mousedown", function (evnt) {
            if (evnt.button === 1 || evnt.button === 2) {
                return
            }
            if (mode === TOUCH_MODE || hasRecentlyEndedTouchMode()) {
                if (!$(evnt.target).is("input, textarea, select")) {
                    evnt.preventDefault()
                }
                return
            }
            beginMode(evnt);
            evnt.originalEvent.touches = [evnt];
            evnt.originalEvent.changedTouches = [evnt];
            dispatchEvent("tapstart", evnt)
        });
        $(document).ready(function () {
            $(document).on("mousedown", function (e) {
                var doNotBlur = !!$(e.target).closest(".dcg-do-not-blur").length, doBlur = !!$(e.target).closest(".dcg-do-blur").length;
                if (doNotBlur && !doBlur) {
                    e.preventDefault()
                }
                var selection = window.getSelection();
                if (selection.rangeCount === 1) {
                    var range = selection.getRangeAt(0);
                    if (range.startContainer === range.endContainer && $(range.startContainer).closest(".dcg-text-selectable").length) {
                        selection.removeAllRanges()
                    }
                }
            })
        });
        $(document).on("mouseleave", function (evnt) {
            if (mode !== NO_MODE) {
                return
            }
            if (hasRecentlyEndedTouchMode()) {
                return
            }
            setHoveredNode(null)
        });
        $(document).on("mousemove", function (evnt) {
            if (evnt.button === 1 || evnt.button === 2) {
                return
            }
            if (mode === TOUCH_MODE) {
                return
            }
            if (hasRecentlyEndedTouchMode()) {
                return
            }
            setHoveredNode(evnt.target);
            evnt.originalEvent.touches = [evnt];
            evnt.originalEvent.changedTouches = [evnt];
            dispatchEvent("tapmove", evnt)
        });
        $(document).on("mouseup", function (evnt) {
            if (evnt.button === 1 || evnt.button === 2) {
                return
            }
            if (mode !== MOUSE_MODE) {
                return
            }
            evnt.originalEvent.touches = [];
            evnt.originalEvent.changedTouches = [evnt];
            dispatchEvent("tapend", evnt);
            endMode(evnt)
        });
        return {
            isTapActive: function () {
                return (mode !== NO_MODE)
            }
        }
    });
    (function ($) {
        var GLOBAL_NAMESPACE = "_*_";
        $.Event.prototype.wasHandled = function (namespace) {
            namespace = namespace ? namespace : GLOBAL_NAMESPACE;
            var oe = this.originalEvent;
            var hb = oe && oe.handledBy;
            if (hb && hb[namespace]) {
                return true
            }
            if (namespace !== GLOBAL_NAMESPACE) {
                return false
            }
            var dom = $(this.target).closest("[handleEvent]");
            if (dom.length && dom[0] !== this.currentTarget) {
                return dom.attr("handleEvent") !== "false"
            }
            return false
        };
        $.Event.prototype.handle = function (namespace) {
            namespace = namespace ? namespace : GLOBAL_NAMESPACE;
            var oe = this.originalEvent;
            if (!oe) {
                return
            }
            var hb = oe.handledBy;
            if (!hb) {
                hb = oe.handledBy = {}
            }
            hb[namespace] = true
        }
    })(jQuery);
    /*! Copyright (c) 2013 Brandon Aaron (http://brandon.aaron.sh)
     * Licensed under the MIT License (LICENSE.txt).
     *
     * Version: 3.1.9
     *
     * Requires: jQuery 1.2.2+
     */
    (function (factory) {
        if (typeof define === "function" && define.amd) {
            define("vendor/jquery.mousewheel", ["jquery"], factory)
        } else {
            if (typeof exports === "object") {
                module.exports = factory
            } else {
                factory(jQuery)
            }
        }
    }(function ($) {
        var toFix = ["wheel", "mousewheel", "DOMMouseScroll", "MozMousePixelScroll"], toBind = ("onwheel" in document || document.documentMode >= 9) ? ["wheel"] : ["mousewheel", "DomMouseScroll", "MozMousePixelScroll"], slice = Array.prototype.slice, nullLowestDeltaTimeout, lowestDelta;
        if ($.event.fixHooks) {
            for (var i = toFix.length; i;) {
                $.event.fixHooks[toFix[--i]] = $.event.mouseHooks
            }
        }
        var special = $.event.special.mousewheel = {
            version: "3.1.9", setup: function () {
                if (this.addEventListener) {
                    for (var i = toBind.length; i;) {
                        this.addEventListener(toBind[--i], handler, false)
                    }
                } else {
                    this.onmousewheel = handler
                }
                $.data(this, "mousewheel-line-height", special.getLineHeight(this));
                $.data(this, "mousewheel-page-height", special.getPageHeight(this))
            }, teardown: function () {
                if (this.removeEventListener) {
                    for (var i = toBind.length; i;) {
                        this.removeEventListener(toBind[--i], handler, false)
                    }
                } else {
                    this.onmousewheel = null
                }
            }, getLineHeight: function (elem) {
                return parseInt($(elem)["offsetParent" in $.fn ? "offsetParent" : "parent"]().css("fontSize"), 10)
            }, getPageHeight: function (elem) {
                return $(elem).height()
            }, settings: {adjustOldDeltas: true}
        };
        $.fn.extend({
            mousewheel: function (fn) {
                return fn ? this.bind("mousewheel", fn) : this.trigger("mousewheel")
            }, unmousewheel: function (fn) {
                return this.unbind("mousewheel", fn)
            }
        });
        function handler(event) {
            var orgEvent = event || window.event, args = slice.call(arguments, 1), delta = 0, deltaX = 0, deltaY = 0, absDelta = 0;
            event = $.event.fix(orgEvent);
            event.type = "mousewheel";
            if ("detail" in orgEvent) {
                deltaY = orgEvent.detail * -1
            }
            if ("wheelDelta" in orgEvent) {
                deltaY = orgEvent.wheelDelta
            }
            if ("wheelDeltaY" in orgEvent) {
                deltaY = orgEvent.wheelDeltaY
            }
            if ("wheelDeltaX" in orgEvent) {
                deltaX = orgEvent.wheelDeltaX * -1
            }
            if ("axis" in orgEvent && orgEvent.axis === orgEvent.HORIZONTAL_AXIS) {
                deltaX = deltaY * -1;
                deltaY = 0
            }
            delta = deltaY === 0 ? deltaX : deltaY;
            if ("deltaY" in orgEvent) {
                deltaY = orgEvent.deltaY * -1;
                delta = deltaY
            }
            if ("deltaX" in orgEvent) {
                deltaX = orgEvent.deltaX;
                if (deltaY === 0) {
                    delta = deltaX * -1
                }
            }
            if (deltaY === 0 && deltaX === 0) {
                return
            }
            if (orgEvent.deltaMode === 1) {
                var lineHeight = $.data(this, "mousewheel-line-height");
                delta *= lineHeight;
                deltaY *= lineHeight;
                deltaX *= lineHeight
            } else {
                if (orgEvent.deltaMode === 2) {
                    var pageHeight = $.data(this, "mousewheel-page-height");
                    delta *= pageHeight;
                    deltaY *= pageHeight;
                    deltaX *= pageHeight
                }
            }
            absDelta = Math.max(Math.abs(deltaY), Math.abs(deltaX));
            if (!lowestDelta || absDelta < lowestDelta) {
                lowestDelta = absDelta;
                if (shouldAdjustOldDeltas(orgEvent, absDelta)) {
                    lowestDelta /= 40
                }
            }
            if (shouldAdjustOldDeltas(orgEvent, absDelta)) {
                delta /= 40;
                deltaX /= 40;
                deltaY /= 40
            }
            delta = Math[delta >= 1 ? "floor" : "ceil"](delta / lowestDelta);
            deltaX = Math[deltaX >= 1 ? "floor" : "ceil"](deltaX / lowestDelta);
            deltaY = Math[deltaY >= 1 ? "floor" : "ceil"](deltaY / lowestDelta);
            event.deltaX = deltaX;
            event.deltaY = deltaY;
            event.deltaFactor = lowestDelta;
            event.deltaMode = 0;
            args.unshift(event, delta, deltaX, deltaY);
            if (nullLowestDeltaTimeout) {
                clearTimeout(nullLowestDeltaTimeout)
            }
            nullLowestDeltaTimeout = setTimeout(nullLowestDelta, 200);
            return ($.event.dispatch || $.event.handle).apply(this, args)
        }

        function nullLowestDelta() {
            lowestDelta = null
        }

        function shouldAdjustOldDeltas(orgEvent, absDelta) {
            return special.settings.adjustOldDeltas && orgEvent.type === "mousewheel" && absDelta % 120 === 0
        }
    }));
    define("conditional_blur", ["require", "jquery"], function (require) {
        var $ = require("jquery");
        return function () {
            if (document.activeElement === document.body) {
                return
            }
            $(document.activeElement).blur()
        }
    });
    define("graphing/grapher", ["require", "jquery", "browser", "./viewport", "./screen"], function (require) {
        var $ = require("jquery");
        var Browser = require("browser");
        var Viewport = require("./viewport");

        function Grapher(container, settings, $root) {
            this.container = container;
            this.$ = $(container);
            this.$root = $root;
            this.viewport = new Viewport();
            this.settings = settings;
            this.poiController = new POIController(this);
            this.$.css("overflow", "hidden");
            this.scaleAxis = undefined;
            this.__transient = false;
            this.graphSketches = {};
            this.graphImages = {};
            this.__sketchOrder = [];
            this.selectedId = null
        }

        Grapher.prototype.setSketchOrder = function (drawOrder) {
            this.__sketchOrder = drawOrder;
            this.redrawGraphsLayer();
            this.redrawImageLayer()
        };
        Grapher.prototype.clear = function () {
            this.graphSketches = {};
            this.graphImages = {}
        };
        Grapher.prototype.getGraphSketch = function (graphId) {
            if (graphId in this.graphSketches) {
                return this.graphSketches[graphId]
            } else {
                return null
            }
        };
        Grapher.prototype.addGraphSketch = function (sketch) {
            this.graphSketches[sketch.id] = sketch
        };
        Grapher.prototype.removeGraphSketch = function (graphId) {
            delete this.graphSketches[graphId]
        };
        Grapher.prototype.addGraphImage = function (image) {
            this.graphImages[image.id] = image
        };
        Grapher.prototype.removeGraphImage = function (imageId) {
            delete this.graphImages[imageId]
        };
        Grapher.prototype.createProjection = function () {
            var projection = new Projection(this.screen, this.viewport, this.settings);
            if (this.isInTransientState()) {
                return this.transformation.transformProjection(projection)
            } else {
                return projection
            }
        };
        Grapher.prototype.computeDefaultViewport = function () {
            var viewport = new Viewport(-10, 10, -10, 10);
            viewport.squareYAxis(this.screen);
            viewport.round(this.screen);
            return viewport
        };
        Grapher.prototype.updateScreenSize = function (w, h) {
            if (w <= 0 || h <= 0) {
                return
            }
            if (this.screen && this.screen.width === w && this.screen.height === h) {
                return
            }
            this.$.width(w);
            var newScreen = new Screen(w, h);
            var newViewport;
            if (this.settings && this.settings.squareAxes) {
                if (!this.screen) {
                    newViewport = this.viewport.clone();
                    newViewport.squareYAxis(newScreen);
                    newViewport.round(newScreen)
                } else {
                    newViewport = this.createProjection().calculateViewportForScreen(newScreen)
                }
            } else {
                newViewport = this.viewport.clone()
            }
            this.screen = newScreen;
            this.redrawAllLayers()
        };
        Grapher.prototype.beginTransientState = function () {
            if (this.isInTransientState()) {
                return
            }
            var projection = this.createProjection();
            this.graphsLayer.saveUnscaledCanvas(projection);
            this.__transient = true
        };
        Grapher.prototype.endTransientState = function () {
            if (!this.isInTransientState()) {
                return
            }
            var projection = this.createProjection();
            this.viewport = projection.viewport;
            this.viewport.round(projection.screen);
            this.settings.setProperty("squareAxes", this.viewport.isSquare(projection.screen));
            this.graphsLayer.releaseUnscaledCanvas();
            this.__transient = false
        };
        Grapher.prototype.isInTransientState = function () {
            return this.__transient
        };
        Grapher.prototype.hide = function (id) {
            var sketch = this.getGraphSketch(id);
            if (sketch) {
                sketch.visible = false
            }
        };
        Grapher.prototype.select = function (id) {
            var currentSketch = this.getGraphSketch(this.selectedId);
            if (currentSketch) {
                currentSketch.showPOI = currentSketch.showHighlight = false
            }
            var newSketch = this.getGraphSketch(id);
            if (newSketch) {
                newSketch.showPOI = newSketch.showHighlight = true
            }
            this.selectedId = id
        };
        Grapher.prototype.updateSketch = function (id, graphData) {
        };
        Grapher.prototype.updateIntersections = function (id, intersections) {
            var sketch = this.getGraphSketch(id);
            if (sketch) {
                sketch.updateIntersections(intersections)
            }
        };
        Grapher.prototype.redrawAllLayers = function () {
            this.cancelRedrawSlowly();
            this.redrawGridLayer();
            this.redrawContentLayers()
        };
        Grapher.prototype.redrawContentLayers = function () {
            this.cancelRedrawSlowly();
            this.redrawGraphsLayer();
            this.redrawPOILayer();
            this.redrawTraceLayer();
            this.redrawMovablePointsLayer();
            this.redrawImageLayer()
        };
        Grapher.prototype.cancelRedrawSlowly = function () {
            clearTimeout(this.redraw_slowly_timeout);
            this.redraw_slowly_timeout = null
        };
        Grapher.prototype.redrawSlowly = function (delay, step, n) {
            if (typeof(delay) === "undefined") {
                delay = 30
            }
            if (typeof(step) === "undefined") {
                step = 1
            }
            if (typeof(n) === "undefined") {
                this.cancelRedrawSlowly();
                n = 0
            }
            this.redrawGridLayer();
            var sketches_to_draw = {};
            var stopped_early = false;
            var i = 0;
            for (var id in this.graphSketches) {
                if (i++ > n) {
                    stopped_early = true;
                    break
                }
                sketches_to_draw[id] = this.graphSketches[id]
            }
            this.graphsLayer.redraw(this.createProjection(), sketches_to_draw, this.__sketchOrder);
            if (stopped_early) {
                var self = this;
                this.redraw_slowly_timeout = setTimeout(function () {
                    self.redrawSlowly(delay, step, n + step)
                }, delay)
            } else {
                this.redrawPOILayer();
                this.redrawTraceLayer();
                this.redrawMovablePointsLayer();
                this.redraw_slowly_timeout = null
            }
        };
        Grapher.prototype.redrawGridLayer = function () {
            if (!this.screen) {
                return
            }
            this.gridLayer.redraw(this.createProjection(), this.scaleAxis)
        };
        Grapher.prototype.redrawGraphsLayer = function () {
            if (!this.screen) {
                return
            }
            if (!this.isInTransientState()) {
                this.graphsLayer.redraw(this.createProjection(), this.graphSketches, this.__sketchOrder)
            } else {
                this.graphsLayer.paintScaledCanvas(this.transformation)
            }
        };
        Grapher.prototype.redrawMovablePointsLayer = function () {
            if (!this.screen) {
                return
            }
            this.movablePointsLayer.redraw(this.createProjection(), this.graphSketches)
        };
        Grapher.prototype.redrawPOILayer = function () {
            if (!this.screen) {
                return
            }
            this.poiDotsLayer.redraw(this.createProjection(), this.graphSketches);
            this.poiLabelsLayer.redraw(this.createProjection(), this.graphSketches)
        };
        Grapher.prototype.redrawTraceLayer = function () {
            if (!this.screen) {
                return
            }
            this.traceLayer.redraw(this.createProjection())
        };
        Grapher.prototype.redrawImageLayer = function () {
            if (!this.screen) {
                return
            }
            this.imageLayer.redraw(this.createProjection(), this.graphImages, this.__sketchOrder)
        };
        Grapher.prototype.screenshot = function (width, height) {
            height = height || width || this.screen.height;
            width = width || this.screen.width;
            var screen = new Screen(width, height);
            var printLayer = CanvasLayer();
            printLayer.resize(width, height);
            var ctx = printLayer.ctx;
            var settings = this.settings.clone();
            if (width < 256 || height < 256) {
                settings.setProperty("showLabels", false)
            }
            var viewport = this.viewport.clone();
            if (viewport.isSquare(this.screen)) {
                viewport.squareCrop(screen)
            }
            var projection = new Projection(screen, viewport, settings);
            ctx.fillStyle = "white";
            ctx.fillRect(0, 0, screen.width, screen.height);
            this.settings.takingScreenshot = true;
            this.imageLayer.redrawToCtx(ctx, projection, this.graphImages);
            this.gridLayer.redrawToCtx(ctx, projection);
            this.graphsLayer.redrawToCtx(ctx, projection, this.graphSketches);
            this.settings.takingScreenshot = false;
            return printLayer.canvas_node.get(0).toDataURL("image/png")
        };
        Grapher.prototype.thumbnail = Grapher.prototype.screenshot;
        Grapher.prototype.getOpenIntersectionIds = function () {
            var openPOI;
            var hiddenOpenPOI;
            var i;
            var intersectIds = {};
            for (var id in this.graphSketches) {
                if (!this.graphSketches.hasOwnProperty(id)) {
                    continue
                }
                openPOI = this.graphSketches[id].openPOI;
                for (i = openPOI.length - 1; i >= 0; i--) {
                }
                hiddenOpenPOI = this.graphSketches[id].hiddenOpenPOI;
                for (i = hiddenOpenPOI.length - 1; i >= 0; i--) {
                }
            }
            return intersectIds
        };
        Grapher.prototype.getSetting = function (setting, _default) {
            var value = this.settings.getProperty(setting);
            return value !== undefined ? value : _default
        };
        Grapher.prototype.setSetting = function (setting, value, _default) {
            this.settings.setProperty(setting, value !== undefined ? value : _default)
        };
        Grapher.prototype.getState = function () {
            return {
                showLabels: this.getSetting("showLabels"),
                degreeMode: this.getSetting("degreeMode"),
                showGrid: this.getSetting("showGrid"),
                polarMode: this.getSetting("polarMode"),
                showAxes: this.getSetting("showAxes"),
                squareAxes: this.getSetting("squareAxes"),
                labelXMode: this.getSetting("xAxisPiLabels") ? "pi" : "",
                labelYMode: this.getSetting("yAxisPiLabels") ? "pi" : ""
            }
        };
        Grapher.prototype.setState = function (state) {
            this.setSetting("showLabels", state.showLabels, true);
            this.setSetting("showGrid", state.showGrid, true);
            this.setSetting("polarMode", state.polarMode, false);
            this.setSetting("showAxes", state.showAxes, true);
            this.setSetting("squareAxes", state.squareAxes, true);
            this.setSetting("xAxisPiLabels", state.labelXMode === "pi");
            this.setSetting("yAxisPiLabels", state.labelYMode === "pi");
            this.setSetting("degreeMode", state.degreeMode, false);
            if ("viewport" in state) {
                var viewport = Viewport.fromObject(state.viewport);
                if (this.screen && this.getSetting("squareAxes") && !viewport.isSquare(this.screen)) {
                    viewport.squareYAxis(this.screen);
                    viewport.round(this.screen)
                }
                this.viewportController.setViewport(viewport)
            }
        };
        return Grapher
    });
    (function () {
        if (!Function.prototype.bind) {
            Function.prototype.bind = function (oThis) {
                if (typeof this !== "function") {
                    throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable")
                }
                var aArgs = Array.prototype.slice.call(arguments, 1), fToBind = this, fNOP = function () {
                }, fBound = function () {
                    return fToBind.apply(this instanceof fNOP && oThis ? this : oThis, aArgs.concat(Array.prototype.slice.call(arguments)))
                };
                fNOP.prototype = this.prototype;
                fBound.prototype = new fNOP();
                return fBound
            }
        }
    })();
    define("function.bind", function () {
    });
    define("underscore_model", ["require", "underscore", "pjs", "function.bind"], function (require) {
        var _ = require("underscore");
        var P = require("pjs");
        require("function.bind");
        var UnderscoreModel = P(function (model) {
            var guid_count = 0;
            var guid_prefix = "guid_" + Math.round(Math.random() * 1000000) + "_" + (new Date().getTime()) + "_";
            model.init = function () {
                this.__observers = {};
                this.__oldProperties = {};
                this.__propertyComparators = {};
                this.guid = guid_prefix + (++guid_count)
            };
            model.getProperty = function (property) {
                return this[property]
            };
            model.getOldProperty = function (property) {
                return this.__oldProperties[property]
            };
            model.setProperty = function (property, newValue) {
                var oldValue = this[property];
                var comparator = this.__propertyComparators[property];
                if (comparator) {
                    if (comparator(oldValue, newValue)) {
                        return
                    }
                } else {
                    if (_.isEqual(oldValue, newValue)) {
                        return
                    }
                }
                this.__oldProperties[property] = oldValue;
                this[property] = newValue;
                this.notifyPropertyChange(property)
            };
            model.setProperties = function (obj) {
                for (var k in obj) {
                    if (obj.hasOwnProperty(k)) {
                        this.setProperty(k, obj[k])
                    }
                }
            };
            model.setPropertyComparator = function (property, comparator) {
                this.__propertyComparators[property] = comparator
            };
            model.notifyPropertyChange = function (property) {
                var observers = this.__observers[property];
                if (observers) {
                    for (var i = 0; i < observers.length; i++) {
                        observers[i].callback(property, this)
                    }
                }
            };
            model.unobserve = function (property_string) {
                if (!property_string) {
                    this.__observers = {};
                    return
                }
                var properties = property_string.split(" ");
                for (var i = 0; i < properties.length; i++) {
                    var property_parts = properties[i].split(".");
                    var property = property_parts[0];
                    var namespace = property_parts[1];
                    if (property && namespace) {
                        var original = this.__observers[property];
                        var filtered = [];
                        if (!original) {
                            continue
                        }
                        for (var j = 0; j < original.length; j++) {
                            var observer = original[j];
                            if (observer.namespace !== namespace) {
                                filtered.push(observer)
                            }
                        }
                        this.__observers[property] = filtered
                    } else {
                        if (property) {
                            if (this.__observers[property]) {
                                this.__observers[property] = []
                            }
                        } else {
                            if (namespace) {
                                for (property in this.__observers) {
                                    this.unobserve(property + "." + namespace)
                                }
                            }
                        }
                    }
                }
            };
            model.observe = function (property_string, callback) {
                var properties = property_string.split(" ");
                for (var i = 0; i < properties.length; i++) {
                    var property_parts = properties[i].split(".");
                    var property = property_parts[0];
                    if (!property) {
                        throw"Must supply a property to observe"
                    }
                    var namespace = property_parts[1];
                    var observer = {namespace: namespace, callback: callback};
                    var observers = this.__observers[property];
                    if (!observers) {
                        this.__observers[property] = [observer]
                    } else {
                        observers.push(observer)
                    }
                }
            }
        });
        return UnderscoreModel
    });
    define("main/graph_settings", ["require", "pjs", "underscore_model"], function (require) {
        var P = require("pjs");
        var UnderscoreModel = require("underscore_model");
        var GraphSettings = P(UnderscoreModel, function (settings, _super) {
            settings.init = function () {
                _super.init.call(this);
                this.squareAxes = true;
                this.showLabels = true;
                this.showGrid = true;
                this.polarMode = false;
                this.showAxes = true;
                this.xAxisPiLabels = false;
                this.yAxisPiLabels = false;
                this.degreeMode = false;
                this.labelHangingColor = "rgba(150,150,150,1)";
                this.labelNormalColor = "rgba(0,0,0,1)";
                this.lastChangedAxis = "x", this.projectorMode = false;
                var self = this;

                function createProjectorProperty(property, offValue, onValue) {
                    function computeProperty() {
                        self.setProperty(property, self.projectorMode ? onValue : offValue)
                    }

                    self.observe("projectorMode", computeProperty);
                    computeProperty()
                }

                function createHighlightProperty(property, off_off, off_on, on_off, on_on) {
                    function computeProperty() {
                        var value;
                        if (self.projectorMode) {
                            value = self.highlight ? on_on : on_off
                        } else {
                            value = self.highlight ? off_on : off_off
                        }
                        self.setProperty(property, value)
                    }

                    self.observe("projectorMode highlight", computeProperty);
                    computeProperty()
                }

                createProjectorProperty("labelSize", 12, 18);
                createProjectorProperty("majorAxisOpacity", 0.2, 0.5);
                createProjectorProperty("minorAxisOpacity", 0.08, 0.15);
                createProjectorProperty("axisOpacity", 0.7, 0.9);
                createProjectorProperty("axisLineWidth", 1, 2);
                createProjectorProperty("axisLineOffset", 0.5, 0);
                createProjectorProperty("pixelsPerLabel", 70, 100);
                createHighlightProperty("graphLineWidth", 2, 3, 6, 9);
                createHighlightProperty("pointLineWidth", 7, 11, 15, 22)
            };
            settings.clone = function () {
                var newSettings = GraphSettings(this.grapher);
                newSettings.setProperty("squareAxes", this.squareAxes);
                newSettings.setProperty("showLabels", this.showLabels);
                newSettings.setProperty("showGrid", this.showGrid);
                newSettings.setProperty("polarMode", this.polarMode);
                newSettings.setProperty("showAxes", this.showAxes);
                newSettings.setProperty("xAxisPiLabels", this.xAxisPiLabels);
                newSettings.setProperty("yAxisPiLabels", this.yAxisPiLabels);
                newSettings.setProperty("degreeMode", this.degreeMode);
                newSettings.setProperty("projectorMode", this.projectorMode);
                return newSettings
            };
            settings.registerCallbacks = function (grapher, expressionsView, $rootElement) {
                var redrawGridLayer = function () {
                    grapher.redrawGridLayer()
                };
                this.observe("showLabels", redrawGridLayer);
                this.observe("showAxes", redrawGridLayer);
                this.observe("showGrid", redrawGridLayer);
                this.observe("polarMode", redrawGridLayer);
                this.observe("xAxisPiLabels", redrawGridLayer);
                this.observe("yAxisPiLabels", redrawGridLayer);
                this.observe("degreeMode", redrawGridLayer);
                this.observe("squareAxes", function () {
                    grapher.viewportController.enforceSquareAxes()
                });
                var self = this;
                this.observe("projectorMode", function () {
                    grapher.redrawAllLayers();
                    $rootElement.toggleClass("dcg-PROJECTOR-MODE", !!self.projectorMode);
                    if (expressionsView) {
                        expressionsView.onProjectorModeChange()
                    }
                })
            }
        });
        return GraphSettings
    });
    define("main/timermodules", [], function () {
        var added = {};
        var loaded = {};
        var runnable = {};
        var TimerModules = {};
        TimerModules.add = function (name, setup) {
            added[name] = setup
        };
        TimerModules.load = function (name) {
            if (added[name]) {
                loaded[name] = added[name].apply(this, Array.prototype.slice.call(arguments, 1));
                if (loaded[name]) {
                    runnable[name] = loaded[name]
                }
            }
        };
        var run = function () {
            for (var i in runnable) {
                if (runnable.hasOwnProperty(i)) {
                    try {
                        runnable[i]()
                    } catch (e) {
                        if (e.stack) {
                            console.log("Caught error", e.stack)
                        }
                    }
                }
            }
            setTimeout(run, 100)
        };
        run();
        return TimerModules
    });
    define("undoredo", ["require", "underscore", "pjs"], function (require) {
        var _ = require("underscore");
        var P = require("pjs");
        var UndoRedoManager = P(function (manager, _super) {
            manager.CAUSE_OF_CHANGE = 1;
            manager.RESPONSE_TO_CHANGE = 2;
            manager.triggerFlash = function () {
            };
            manager.init = function () {
                this.undos = [];
                this.redos = [];
                this.changesCallbacks = [];
                this.__isApplyingTransaction = 0;
                this.markAsSaved();
                this.oneTransactionWrapper = function (cb) {
                    cb()
                }
            };
            manager.handleKeydown = function (evt) {
                if (evt.ctrlKey || evt.metaKey) {
                    switch (evt.which) {
                        case 90:
                            if (evt.shiftKey) {
                                this.redo()
                            } else {
                                this.undo()
                            }
                            return false;
                        case 89:
                            this.redo();
                            return false
                    }
                }
            };
            manager.clear = function () {
                this.undos = [];
                this.redos = [];
                this.markAsSaved()
            };
            manager.pushUndo = function (transaction) {
                this.undos.push(transaction);
                if (transaction.recordChange !== false) {
                    this.__changesSinceSave++;
                    this.triggerChanges()
                }
            };
            manager.pushRedo = function (transaction) {
                this.redos.push(transaction);
                if (transaction.recordChange !== false) {
                    this.__changesSinceSave--;
                    this.triggerChanges()
                }
            };
            manager.canUndo = function () {
                return this.undos.length > 0
            };
            manager.canRedo = function () {
                return this.redos.length > 0
            };
            manager.undo = function () {
                if (!this.canUndo()) {
                    return
                }
                var action = this.undos.pop();
                this.applyTransaction(action, true);
                this.pushRedo(action)
            };
            manager.redo = function () {
                if (!this.canRedo()) {
                    return
                }
                var action = this.redos.pop();
                this.applyTransaction(action);
                this.pushUndo(action)
            };
            manager.markAsSaved = function () {
                this.__changesSinceSave = 0;
                this.triggerChanges()
            };
            manager.changedSinceSave = function () {
                return this.__changesSinceSave !== 0
            };
            manager.isApplyingTransaction = function () {
                return !!this.__isApplyingTransaction
            };
            manager.__applyTransaction = function (transaction, doUndo) {
                var i;
                var batched = transaction.__batched__ ? transaction.__batched__ : [];
                var self = this;
                if (doUndo) {
                    if (batched.length) {
                        this.oneTransactionWrapper(function () {
                            for (i = batched.length - 1; i >= 0; i--) {
                                self.__applyTransaction(batched[i], doUndo)
                            }
                            transaction.undo()
                        })
                    } else {
                        transaction.undo()
                    }
                } else {
                    if (batched.length) {
                        this.oneTransactionWrapper(function () {
                            transaction.redo();
                            for (i = 0; i < batched.length; i++) {
                                self.__applyTransaction(batched[i], doUndo)
                            }
                        })
                    } else {
                        transaction.redo()
                    }
                }
            };
            manager.applyTransaction = function (transaction, doUndo) {
                this.__isApplyingTransaction++;
                try {
                    this.__applyTransaction(transaction, doUndo)
                } finally {
                    this.__isApplyingTransaction--
                }
            };
            manager.oneTransaction = function (func) {
                if (!this.__oneTransactionDepth) {
                    this.__oneTransactionDepth = 0
                }
                this.__oneTransactionDepth++;
                this.oneTransactionWrapper(func);
                this.__oneTransactionDepth--;
                if (!this.__oneTransactionDepth) {
                    this.__oneTransaction = null
                }
            };
            manager.isApplyingOneTransaction = function () {
                return this.__oneTransactionDepth > 0
            };
            manager.addTransaction = function (transaction) {
                var batched;
                if (this.isApplyingTransaction()) {
                    if (transaction.type === this.CAUSE_OF_CHANGE) {
                        transaction.redo()
                    }
                    return
                }
                if (transaction.type === this.CAUSE_OF_CHANGE) {
                    this.applyTransaction(transaction)
                }
                if (transaction.ensureChangeOccured && transaction.ensureChangeOccured()) {
                    return
                }
                this.redos.splice(0);
                if (this.isApplyingOneTransaction()) {
                    if (!this.__oneTransaction) {
                        this.__oneTransaction = transaction
                    } else {
                        batched = this.__oneTransaction.__batched__;
                        if (!batched) {
                            batched = this.__oneTransaction.__batched__ = []
                        }
                        batched.push(transaction);
                        return
                    }
                }
                this.pushUndo(transaction)
            };
            manager.triggerChanges = function () {
                _.each(this.changesCallbacks, function (cb) {
                    cb()
                })
            }
        });
        return UndoRedoManager()
    });
    define("expressions/abstractitem", ["require", "pjs", "underscore_model", "undoredo"], function (require) {
        var P = require("pjs");
        var UnderscoreModel = require("underscore_model");
        var UndoRedo = require("undoredo");
        var AbstractItemModel = P(UnderscoreModel, function (model, _super) {
            var nextItemId = 1;
            model.init = function (state, list) {
                _super.init.call(this);
                this.index = -1;
                this.selected = false;
                this.list = list;
                for (var property in state) {
                    if (state.hasOwnProperty(property)) {
                        if (property === "id") {
                            this[property] = "" + state[property]
                        } else {
                            this[property] = state[property]
                        }
                    }
                }
                if (!this.hasOwnProperty("id")) {
                    this.id = "" + nextItemId++
                } else {
                    if (parseInt(this.id, 10) >= nextItemId) {
                        nextItemId = parseInt(this.id, 10) + 1
                    }
                }
                this.observe("folder", this.updateFolder.bind(this));
                this.observe("selected", this.__onSelectedChange.bind(this))
            };
            model.onAddedToList = function () {
            };
            model.onRemovedFromList = function () {
            };
            model.onStateDidChange = function (prop) {
                var id = this.id;
                var oldValue = this.getOldProperty(prop);
                var newValue = this.getProperty(prop);
                var list = this.list;
                UndoRedo.addTransaction({
                    type: UndoRedo.RESPONSE_TO_CHANGE, undo: function () {
                        list.getItemById(id).setProperty(prop, oldValue)
                    }, redo: function () {
                        list.getItemById(id).setProperty(prop, newValue)
                    }
                })
            };
            model.updateCollapsed = function () {
                this.setProperty("inCollapsedFolder", this.folder ? this.folder.collapsed : false)
            };
            model.updateFolder = function () {
                if (this.getOldProperty("folder")) {
                    this.getOldProperty("folder").unobserve("." + this.id)
                }
                if (this.folder) {
                    this.folder.observe("collapsed." + this.id, this.updateCollapsed.bind(this))
                }
                this.updateCollapsed()
            };
            model.__onSelectedChange = function () {
                if (this.list) {
                    this.list.handleSelectionChange(this)
                }
                if (this.selected && this.inCollapsedFolder) {
                    this.folder.updateSelectedHiddenChild()
                }
            }
        });
        return AbstractItemModel
    });
    (function (global) {
        Big.DP = 20;
        Big.RM = 1;
        var MAX_DP = 1000000, MAX_POWER = 1000000, TO_EXP_NEG = -7, TO_EXP_POS = 21, P = Big.prototype, isValid = /^-?\d+(?:\.\d+)?(?:e[+-]?\d+)?$/i, ONE = new Big(1);

        function Big(n) {
            var i, j, nL, x = this;
            if (!(x instanceof Big)) {
                return new Big(n)
            }
            if (n instanceof Big) {
                x.s = n.s;
                x.e = n.e;
                x.c = n.c.slice();
                return
            }
            if (n === 0 && 1 / n < 0) {
                n = "-0"
            } else {
                if (!isValid.test(n += "")) {
                    throw NaN
                }
            }
            x.s = n.charAt(0) == "-" ? (n = n.slice(1), -1) : 1;
            if ((i = n.indexOf(".")) > -1) {
                n = n.replace(".", "")
            }
            if ((j = n.search(/e/i)) > 0) {
                if (i < 0) {
                    i = j
                }
                i += +n.slice(j + 1);
                n = n.substring(0, j)
            } else {
                if (i < 0) {
                    i = n.length
                }
            }
            for (j = 0; n.charAt(j) == "0"; j++) {
            }
            if (j == (nL = n.length)) {
                x.c = [x.e = 0]
            } else {
                for (; n.charAt(--nL) == "0";) {
                }
                x.e = i - j - 1;
                x.c = [];
                for (i = 0; j <= nL; x.c[i++] = +n.charAt(j++)) {
                }
            }
        }

        function rnd(x, dp, rm, more) {
            var xc = x.c, i = x.e + dp + 1;
            if (rm !== 0 && rm !== 1 && rm !== 2) {
                throw"!Big.RM!"
            }
            rm = rm && (xc[i] > 5 || xc[i] == 5 && (rm == 1 || more || i < 0 || xc[i + 1] != null || xc[i - 1] & 1));
            if (i < 1 || !xc[0]) {
                x.c = rm ? (x.e = -dp, [1]) : [x.e = 0]
            } else {
                xc.length = i--;
                if (rm) {
                    for (; ++xc[i] > 9;) {
                        xc[i] = 0;
                        if (!i--) {
                            ++x.e;
                            xc.unshift(1)
                        }
                    }
                }
                for (i = xc.length; !xc[--i]; xc.pop()) {
                }
            }
            return x
        }

        P.cmp = function (y) {
            var xNeg, x = this, xc = x.c, yc = (y = new Big(y))["c"], i = x.s, j = y.s, k = x.e, l = y.e;
            if (!xc[0] || !yc[0]) {
                return !xc[0] ? !yc[0] ? 0 : -j : i
            }
            if (i != j) {
                return i
            }
            xNeg = i < 0;
            if (k != l) {
                return k > l ^ xNeg ? 1 : -1
            }
            for (i = -1, j = (k = xc.length) < (l = yc.length) ? k : l; ++i < j;) {
                if (xc[i] != yc[i]) {
                    return xc[i] > yc[i] ^ xNeg ? 1 : -1
                }
            }
            return k == l ? 0 : k > l ^ xNeg ? 1 : -1
        };
        P.div = function (y) {
            var x = this, dvd = x.c, dvs = (y = new Big(y))["c"], s = x.s == y.s ? 1 : -1, dp = Big.DP;
            if (dp !== ~~dp || dp < 0 || dp > MAX_DP) {
                throw"!Big.DP!"
            }
            if (!dvd[0] || !dvs[0]) {
                if (dvd[0] == dvs[0]) {
                    throw NaN
                }
                if (!dvs[0]) {
                    throw s / 0
                }
                return new Big(s * 0)
            }
            var dvsL, dvsT, next, cmp, remI, dvsZ = dvs.slice(), dvdI = dvsL = dvs.length, dvdL = dvd.length, rem = dvd.slice(0, dvsL), remL = rem.length, quo = new Big(ONE), qc = quo.c = [], qi = 0, digits = dp + (quo.e = x.e - y.e) + 1;
            quo.s = s;
            s = digits < 0 ? 0 : digits;
            dvsZ.unshift(0);
            for (; remL++ < dvsL; rem.push(0)) {
            }
            do {
                for (next = 0; next < 10; next++) {
                    if (dvsL != (remL = rem.length)) {
                        cmp = dvsL > remL ? 1 : -1
                    } else {
                        for (remI = -1, cmp = 0; ++remI < dvsL;) {
                            if (dvs[remI] != rem[remI]) {
                                cmp = dvs[remI] > rem[remI] ? 1 : -1;
                                break
                            }
                        }
                    }
                    if (cmp < 0) {
                        for (dvsT = remL == dvsL ? dvs : dvsZ; remL;) {
                            if (rem[--remL] < dvsT[remL]) {
                                for (remI = remL; remI && !rem[--remI]; rem[remI] = 9) {
                                }
                                --rem[remI];
                                rem[remL] += 10
                            }
                            rem[remL] -= dvsT[remL]
                        }
                        for (; !rem[0]; rem.shift()) {
                        }
                    } else {
                        break
                    }
                }
                qc[qi++] = cmp ? next : ++next;
                rem[0] && cmp ? (rem[remL] = dvd[dvdI] || 0) : (rem = [dvd[dvdI]])
            } while ((dvdI++ < dvdL || rem[0] != null) && s--);
            if (!qc[0] && qi != 1) {
                qc.shift();
                quo.e--
            }
            if (qi > digits) {
                rnd(quo, dp, Big.RM, rem[0] != null)
            }
            return quo
        };
        P.minus = function (y) {
            var d, i, j, xLTy, x = this, a = x.s, b = (y = new Big(y))["s"];
            if (a != b) {
                return y.s = -b, x.plus(y)
            }
            var xc = x.c, xe = x.e, yc = y.c, ye = y.e;
            if (!xc[0] || !yc[0]) {
                return yc[0] ? (y.s = -b, y) : new Big(xc[0] ? x : 0)
            }
            if (xc = xc.slice(), a = xe - ye) {
                d = (xLTy = a < 0) ? (a = -a, xc) : (ye = xe, yc);
                for (d.reverse(), b = a; b--; d.push(0)) {
                }
                d.reverse()
            } else {
                j = ((xLTy = xc.length < yc.length) ? xc : yc).length;
                for (a = b = 0; b < j; b++) {
                    if (xc[b] != yc[b]) {
                        xLTy = xc[b] < yc[b];
                        break
                    }
                }
            }
            if (xLTy) {
                d = xc, xc = yc, yc = d;
                y.s = -y.s
            }
            if ((b = -((j = xc.length) - yc.length)) > 0) {
                for (; b--; xc[j++] = 0) {
                }
            }
            for (b = yc.length; b > a;) {
                if (xc[--b] < yc[b]) {
                    for (i = b; i && !xc[--i]; xc[i] = 9) {
                    }
                    --xc[i];
                    xc[b] += 10
                }
                xc[b] -= yc[b]
            }
            for (; xc[--j] == 0; xc.pop()) {
            }
            for (; xc[0] == 0; xc.shift(), --ye) {
            }
            if (!xc[0]) {
                xc = [ye = 0]
            }
            return y.c = xc, y.e = ye, y
        };
        P.mod = function (y) {
            y = new Big(y);
            var c, x = this, i = x.s, j = y.s;
            if (!y.c[0]) {
                throw NaN
            }
            x.s = y.s = 1;
            c = y.cmp(x) == 1;
            x.s = i, y.s = j;
            return c ? new Big(x) : (i = Big.DP, j = Big.RM, Big.DP = Big.RM = 0, x = x.div(y), Big.DP = i, Big.RM = j, this["minus"](x.times(y)))
        };
        P.plus = function (y) {
            var d, x = this, a = x.s, b = (y = new Big(y))["s"];
            if (a != b) {
                return y.s = -b, x.minus(y)
            }
            var xe = x.e, xc = x.c, ye = y.e, yc = y.c;
            if (!xc[0] || !yc[0]) {
                return yc[0] ? y : new Big(xc[0] ? x : a * 0)
            }
            if (xc = xc.slice(), a = xe - ye) {
                d = a > 0 ? (ye = xe, yc) : (a = -a, xc);
                for (d.reverse(); a--; d.push(0)) {
                }
                d.reverse()
            }
            if (xc.length - yc.length < 0) {
                d = yc, yc = xc, xc = d
            }
            for (a = yc.length, b = 0; a; b = (xc[--a] = xc[a] + yc[a] + b) / 10 ^ 0, xc[a] %= 10) {
            }
            if (b) {
                xc.unshift(b);
                ++ye
            }
            for (a = xc.length; xc[--a] == 0; xc.pop()) {
            }
            return y.c = xc, y.e = ye, y
        };
        P.pow = function (e) {
            var isNeg = e < 0, x = new Big(this), y = ONE;
            if (e !== ~~e || e < -MAX_POWER || e > MAX_POWER) {
                throw"!pow!"
            }
            for (e = isNeg ? -e : e; ;) {
                if (e & 1) {
                    y = y.times(x)
                }
                e >>= 1;
                if (!e) {
                    break
                }
                x = x.times(x)
            }
            return isNeg ? ONE.div(y) : y
        };
        P.round = function (dp, rm) {
            var x = new Big(this);
            if (dp == null) {
                dp = 0
            } else {
                if (dp !== ~~dp || dp < 0 || dp > MAX_DP) {
                    throw"!round!"
                }
            }
            rnd(x, dp, rm == null ? Big.RM : rm);
            return x
        };
        P.sqrt = function () {
            var estimate, r, approx, x = this, xc = x.c, i = x.s, e = x.e, half = new Big("0.5");
            if (!xc[0]) {
                return new Big(x)
            }
            if (i < 0) {
                throw NaN
            }
            i = Math.sqrt(x.toString());
            if (i == 0 || i == 1 / 0) {
                estimate = xc.join("");
                if (!(estimate.length + e & 1)) {
                    estimate += "0"
                }
                r = new Big(Math.sqrt(estimate).toString());
                r.e = (((e + 1) / 2) | 0) - (e < 0 || e & 1)
            } else {
                r = new Big(i.toString())
            }
            i = r.e + (Big.DP += 4);
            do {
                approx = r;
                r = half.times(approx.plus(x.div(approx)))
            } while (approx.c.slice(0, i).join("") !== r.c.slice(0, i).join(""));
            rnd(r, Big.DP -= 4, Big.RM);
            return r
        };
        P.times = function (y) {
            var c, x = this, xc = x.c, yc = (y = new Big(y))["c"], a = xc.length, b = yc.length, i = x.e, j = y.e;
            y.s = x.s == y.s ? 1 : -1;
            if (!xc[0] || !yc[0]) {
                return new Big(y.s * 0)
            }
            y.e = i + j;
            if (a < b) {
                c = xc, xc = yc, yc = c, j = a, a = b, b = j
            }
            for (j = a + b, c = []; j--; c.push(0)) {
            }
            for (i = b - 1; i > -1; i--) {
                for (b = 0, j = a + i; j > i; b = c[j] + yc[i] * xc[j - i - 1] + b, c[j--] = b % 10 | 0, b = b / 10 | 0) {
                }
                if (b) {
                    c[j] = (c[j] + b) % 10
                }
            }
            b && ++y.e;
            !c[0] && c.shift();
            for (j = c.length; !c[--j]; c.pop()) {
            }
            return y.c = c, y
        };
        P.toString = P.valueOf = function () {
            var x = this, e = x.e, str = x.c.join(""), strL = str.length;
            if (e <= TO_EXP_NEG || e >= TO_EXP_POS) {
                str = str.charAt(0) + (strL > 1 ? "." + str.slice(1) : "") + (e < 0 ? "e" : "e+") + e
            } else {
                if (e < 0) {
                    for (; ++e; str = "0" + str) {
                    }
                    str = "0." + str
                } else {
                    if (e > 0) {
                        if (++e > strL) {
                            for (e -= strL; e--; str += "0") {
                            }
                        } else {
                            if (e < strL) {
                                str = str.slice(0, e) + "." + str.slice(e)
                            }
                        }
                    } else {
                        if (strL > 1) {
                            str = str.charAt(0) + "." + str.slice(1)
                        }
                    }
                }
            }
            return x.s < 0 && x.c[0] ? "-" + str : str
        };
        function format(x, dp, toE) {
            var i = dp - (x = new Big(x))["e"], c = x.c;
            if (c.length > ++dp) {
                rnd(x, i, Big.RM)
            }
            i = !c[0] ? i + 1 : toE ? dp : (c = x.c, x.e + i + 1);
            for (; c.length < i; c.push(0)) {
            }
            i = x.e;
            return toE == 1 || toE == 2 && (dp <= i || i <= TO_EXP_NEG) ? (x.s < 0 && c[0] ? "-" : "") + (c.length > 1 ? (c.splice(1, 0, "."), c.join("")) : c[0]) + (i < 0 ? "e" : "e+") + i : x.toString()
        }

        P.toExponential = function (dp) {
            if (dp == null) {
                dp = this["c"].length - 1
            } else {
                if (dp !== ~~dp || dp < 0 || dp > MAX_DP) {
                    throw"!toExp!"
                }
            }
            return format(this, dp, 1)
        };
        P.toFixed = function (dp) {
            var str, x = this, neg = TO_EXP_NEG, pos = TO_EXP_POS;
            TO_EXP_NEG = -(TO_EXP_POS = 1 / 0);
            if (dp == null) {
                str = x.toString()
            } else {
                if (dp === ~~dp && dp >= 0 && dp <= MAX_DP) {
                    str = format(x, x.e + dp);
                    if (x.s < 0 && x.c[0] && str.indexOf("-") < 0) {
                        str = "-" + str
                    }
                }
            }
            TO_EXP_NEG = neg, TO_EXP_POS = pos;
            if (!str) {
                throw"!toFix!"
            }
            return str
        };
        P.toPrecision = function (sd) {
            if (sd == null) {
                return this.toString()
            } else {
                if (sd !== ~~sd || sd < 1 || sd > MAX_DP) {
                    throw"!toPre!"
                }
            }
            return format(this, sd - 1, 2)
        };
        if (typeof module !== "undefined" && module.exports) {
            module.exports = Big
        } else {
            if (typeof define == "function" && define.amd) {
                define("vendor/big", [], function () {
                    return Big
                })
            } else {
                global.Big = Big
            }
        }
    })(this);
    define("big", ["require", "vendor/big"], function (require) {
        var Big = require("vendor/big");
        Big.prototype.equals = function (x) {
            return this.cmp(x) === 0
        };
        return Big
    });
    define("expressions/colors", ["require"], function (require) {
        var RED = "#C0504D";
        var BLUE = "#4F81BD";
        var GREEN = "#9BBB59";
        var PURPLE = "#8064A2";
        var ORANGE = "#F79646";
        var BLACK = "#000000";
        var all = [RED, BLUE, GREEN, PURPLE, ORANGE, BLACK];
        var i = 0;

        function next() {
            var color = all[i];
            i = (i + 1) % all.length;
            return color
        }

        function reset() {
            i = 0
        }

        return {all: all, next: next, reset: reset, RED: RED, BLUE: BLUE, GREEN: GREEN, PURPLE: PURPLE, ORANGE: ORANGE, BLACK: BLACK}
    });
    define("expressions/expression", ["require", "pjs", "math/evaluationstate", "undoredo", "./abstractitem", "./colors"], function (require) {
        var P = require("pjs");
        var EvaluationState = require("math/evaluationstate");
        var UndoRedo = require("undoredo");
        var AbstractItemModel = require("./abstractitem");
        var Colors = require("./colors");
        var ExpressionObject = P(AbstractItemModel, function (model, _super) {
            model._computeNewLatex = function (latex, newValue) {
                var regex = /=(.*?)([-\.0-9]+)/;
                var matches = latex.match(regex);
                if (parseFloat(matches[2]) === newValue) {
                    return latex
                }
                return latex.replace(regex, "=$1" + newValue)
            };
            model.isExpression = true;
            model.init = function (state, list) {
                _super.init.call(this, state, list);
                this.loading = true;
                this.formula = EvaluationState({error: ""});
                this.unresolved = false;
                if (!this.color) {
                    this.color = Colors.next()
                } else {
                    if (typeof this.color === "object") {
                        this.color = this.color.value
                    }
                }
                if (this.style === undefined) {
                    this.style = "normal"
                }
                if (this.hidden === undefined) {
                    this.hidden = (this.userRequestedGraphing === "never")
                }
                if (this.latex === undefined) {
                    this.latex = ""
                }
                var raw_domain = this.domain ? this.domain : {min: 0, max: 1};
                this.computeShouldGraph();
                this.observe("formula", this.onFormulaUpdate.bind(this));
                this.observe("latex color hidden style", this.onStateDidChange.bind(this));
                this.observe("latex shouldGraph color style", this.onExpressionDidChange.bind(this));
                this.observe("hidden", this.computeShouldGraph.bind(this))
            };
            model.onStateDidChange = function (prop) {
                if (prop === "latex" && this.slider) {
                    return
                }
                if (prop === "style" && this.getOldProperty("style") === undefined) {
                    return
                }
                _super.onStateDidChange.call(this, prop)
            };
            model.updateFolder = function () {
                _super.updateFolder.call(this);
                if (this.getOldProperty("folder")) {
                    this.getOldProperty("folder").unobserve("." + this.id)
                }
                if (this.folder) {
                    this.folder.observe("hidden." + this.id, this.computeShouldGraph.bind(this))
                }
                this.computeShouldGraph()
            };
            model.computeShouldGraph = function () {
                if (this.folder && this.folder.hidden) {
                    this.setProperty("shouldGraph", false);
                    return
                }
                this.setProperty("shouldGraph", !this.hidden)
            };
            model.onExpressionDidChange = function () {
            };
            model.getParsableObject = function () {
                if (this.latex === undefined) {
                    return undefined
                }
                return {type: "statement", id: this.id, latex: this.latex, shouldGraph: this.shouldGraph, color: this.color, style: this.style}
            };
            model.requestParse = function () {
                this.list.triggerAddExp(this.getParsableObject())
            };
            model.requestUnparse = function () {
                this.list.triggerRemoveExp(this.id)
            };
            model.onAddedToList = function () {
                this.requestParse()
            };
            model.onRemovedFromList = function () {
                if (this.slider) {
                    this.slider.setProperty("isPlaying", false)
                }
                this.requestUnparse()
            };
            model.getState = function () {
                var state = {id: this.id, latex: this.latex, hidden: this.hidden, color: this.color, style: this.style};
                if (this.slider) {
                    state.sliderMin = this.slider.min;
                    state.sliderMax = this.slider.max;
                    state.sliderHardMin = this.slider.hardMin;
                    state.sliderHardMax = this.slider.hardMax;
                    state.sliderInterval = this.slider.step;
                    state.sliderAnimationPeriod = this.slider.animationPeriod;
                    state.sliderPlayDirection = this.slider.playDirection;
                    state.sliderIsPlaying = this.slider.isPlaying
                }
                return state
            };
            model.onFormulaUpdate = function () {
                var formula = this.formula;
                this.setProperty("error", formula.error ? formula.error : "");
                this.setProperty("isGraphable", formula.is_graphable);
                this.setProperty("dependent", formula.assignment);
                this.setProperty("isTableable", formula.is_tableable);
                this.setProperty("unresolved", false);
                this.validateStyle();
                if (formula.is_slidable) {
                    if (!this.slider) {
                        this.createSliderModel()
                    }
                } else {
                    this.slider = null
                }
            };
            model.validateStyle = function () {
                var formula = this.formula;
                if (formula.error) {
                    return
                }
                var self = this;

                function defaultStyleTo(style) {
                    if (self.style !== style) {
                        self.style = undefined;
                        self.setProperty("style", style)
                    }
                }

                if (formula.is_point_list) {
                    if (!(this.style === "point" || this.style === "open" || this.style === "cross")) {
                        defaultStyleTo("point")
                    }
                } else {
                    if (formula.is_inequality) {
                        defaultStyleTo("normal")
                    } else {
                        if (!(this.style === "normal" || this.style === "dashed")) {
                            defaultStyleTo("normal")
                        }
                    }
                }
            };
            model.createSliderModel = function () {
            };
            model.isEmpty = function () {
                var latex = this.latex;
                return !latex || latex.split(" ").join("") === ""
            }
        });
        return ExpressionObject
    });
    define("lib/track_feature", ["require"], function (require) {
        var discovered = {};
        var discover = function (name) {
            if (discovered.hasOwnProperty(name)) {
                return
            }
            discovered[name] = true
        };
        var use = function (name) {
            sample_usage(name, 1)
        };
        var sample_usage = function (name, n) {
            discover(name);
            if (Math.random() > 1 / n) {
                return
            }
            var params = {};
            params["E(" + name + ")"] = n
        };
        return {discover: discover, use: use, sample_usage: sample_usage}
    });
    define("expressions/list", ["require", "pjs", "underscore", "underscore_model", "./expression", "undoredo"], function (require) {
        var P = require("pjs");
        var _ = require("underscore");
        var UnderscoreModel = require("underscore_model");
        var ExpressionObject = require("./expression");
        var UndoRedo = require("undoredo");
        var ExpressionListModel = P(UnderscoreModel, function (model, _super) {
            model.init = function () {
                _super.init.call(this);
                this.__items = [];
                this.__itemIds = {};
                this.__helperItemIds = {};
                this.drawOrder = [];
                this.setPropertyComparator("selectedItem", function (a, b) {
                    return a === b
                });
                var self = this;
                this.stepHz = 25;
                var stepSliders = function () {
                    self.batchEvaluation(function () {
                        self.notifyPropertyChange("playStep")
                    });
                    setTimeout(function () {
                        stepSliders()
                    }, 1000 / self.stepHz)
                };
                stepSliders()
            };
            model.getItemByIndex = function (index) {
                return this.__items[index] || null
            };
            model.getItemsByIndexRange = function (min, max) {
                min = Math.max(0, min);
                max = Math.min(this.getItemCount() - 1, max);
                var arr = [];
                for (var i = min; i <= max; i++) {
                    arr.push(this.getItemByIndex(i))
                }
                return arr
            };
            model.onChange = function (changes) {
                var id, formula;
                for (id in changes) {
                    if (!changes.hasOwnProperty(id)) {
                        continue
                    }
                    var expression = this.getItemById(id);
                    if (expression) {
                        if (expression.constructor === ExpressionObject) {
                            formula = changes[id];
                            if (!formula) {
                                continue
                            }
                            expression.setProperty("loading", false);
                            expression.setProperty("formula", formula)
                        } else {
                            if (expression.isHelperExpression) {
                                formula = changes[id];
                                if (!formula) {
                                    continue
                                }
                                expression.setProperty("formula", formula)
                            } else {
                                if (expression.isTable) {
                                    var table_data = changes[id];
                                    expression.setComputedValues(table_data)
                                }
                            }
                        }
                    }
                }
            };
            model.onGraphComputed = function (id, graphData) {
                var item = this.getItemById(id);
                if (!item) {
                    return
                }
                var branchResolved = function (branch) {
                    if (!branch.hasOwnProperty("resolved")) {
                        return true
                    }
                    return branch.resolved
                };
                var unresolved = !graphData.every(branchResolved);
                item.setProperty("unresolved", unresolved)
            };
            model.updateDrawOrder = function () {
                var drawOrder = [];
                var listItems = _.sortBy(this.__itemIds, function (item) {
                    return item.index
                });
                _.each(listItems, function (item) {
                    if (item.hasOwnProperty("columns")) {
                        _.each(item.columns, function (column) {
                            drawOrder.push(column.id)
                        })
                    } else {
                        drawOrder.push(item.id)
                    }
                });
                this.setProperty("drawOrder", drawOrder)
            };
            model.getItemById = function (id) {
                return this.__itemIds[id] || this.__helperItemIds[id]
            };
            model._insertItemAt = function (index, item) {
                var item_id = String(item.id);
                if (this.__itemIds.hasOwnProperty(item_id)) {
                    throw Error("Item with id '" + item_id + "' is already in list")
                }
                this.__itemIds[item_id] = item;
                this.__items.splice(index, 0, item);
                item.index = index;
                if (item.selected) {
                    this.handleSelectionChange(item)
                }
                item.onAddedToList()
            };
            model.handleSelectionChange = function (item) {
                var selected = item.selected;
                if (!selected && this.selectedItem === item) {
                    this.setProperty("selectedItem", null)
                } else {
                    if (selected && !this.selectedItem) {
                        this.setProperty("selectedItem", item)
                    } else {
                        if (selected && this.selectedItem !== item) {
                            this.selectedItem.setProperty("selected", false);
                            this.setProperty("selectedItem", item)
                        }
                    }
                }
            };
            model.triggerItemInserted = function (index, item) {
            };
            model.insertItemAt = function (index, item) {
                this._insertItemAt(index, item);
                this.triggerItemInserted(index, item);
                var self = this;
                var constructor = item.constructor;
                var state = item.getState();
                UndoRedo.addTransaction({
                    type: UndoRedo.RESPONSE_TO_CHANGE, undo: function () {
                        state = item.getState();
                        self.removeItemAt(index)
                    }, redo: function () {
                        self.insertItemAt(index, constructor(state, self))
                    }
                });
                this.updateDrawOrder()
            };
            model.addHelperItem = function (obj) {
                this.__helperItemIds[obj.id] = obj;
                obj.onAddedToList()
            };
            model.removeHelperItem = function (id) {
                var item = this.__helperItemIds[id];
                if (!item) {
                    return
                }
                item.onRemovedFromList();
                delete this.__helperItemIds[id]
            };
            model.addItem = function (obj) {
                var lastObject = this.getItemByIndex(this.getItemCount() - 1);
                if (lastObject && !(lastObject.text || lastObject.columns || lastObject.headings) && lastObject.latex === "") {
                    this.removeItemAt(this.getItemCount() - 1)
                }
                this.insertItemAt(this.getItemCount(), obj)
            };
            model.updateItemById = function (id, properties) {
                this.getItemById(id).setProperties(properties);
                this.updateDrawOrder()
            };
            model._removeItemAt = function (index) {
                var item = this.__items[index];
                if (!item) {
                    return
                }
                if (this.selectedItem === item) {
                    this.setProperty("selectedItem", null)
                }
                var self = this;
                if (item.isFolder) {
                    for (var id in item.memberIds) {
                        self.removeItemAt(self.getItemById(id).index)
                    }
                }
                this.__items.splice(index, 1);
                var item_id = String(item.id);
                delete this.__itemIds[item_id];
                item.onRemovedFromList();
                return item
            };
            model._removeAllItems = function () {
                for (var i = 0; i < this.__items.length; i++) {
                    this.__items[i].onRemovedFromList()
                }
                for (var id in this.__helperItemIds) {
                    if (this.__helperItemIds.hasOwnProperty(id)) {
                        this.__helperItemIds[id].onRemovedFromList()
                    }
                }
                this.__items = [];
                this.__itemIds = {};
                this.__helperItemIds = {};
                this.setProperty("selectedItem", false)
            };
            model.triggerItemRemoved = function (index, item) {
            };
            model.removeItemAt = function (index) {
                var self = this;
                UndoRedo.oneTransaction(function () {
                    var item = this._removeItemAt(index);
                    this.triggerItemRemoved(index, item);
                    var constructor = item.constructor;
                    var state = item.getState();
                    if (item.folder) {
                        item.folder.removeItem(item)
                    }
                    UndoRedo.addTransaction({
                        type: UndoRedo.RESPONSE_TO_CHANGE, undo: function () {
                            var newItem = constructor(state, self);
                            self.insertItemAt(index, newItem)
                        }, redo: function () {
                            self.removeItemAt(index)
                        }
                    })
                }.bind(this));
                this.updateDrawOrder()
            };
            model.removeItemById = function (id) {
                var expression = this.getItemById(id);
                if (!expression) {
                    return
                }
                this.removeItemAt(expression.index)
            };
            model.triggerItemMoved = function (from, to) {
            };
            model.moveItemTo = function (a, b) {
                var self = this;
                var manipulator = function (from, to) {
                    if (from === to) {
                        return
                    }
                    var len = self.getItemCount();
                    var item = self.__items[from];
                    if (from < 0 || to < 0 || from >= len || to >= len) {
                        return
                    }
                    self.__items.splice(from, 1);
                    self.__items.splice(to, 0, item);
                    self.triggerItemMoved(from, to);
                    self.updateDrawOrder()
                };
                UndoRedo.addTransaction({
                    type: UndoRedo.CAUSE_OF_CHANGE, undo: function () {
                        manipulator(b, a)
                    }, redo: function () {
                        manipulator(a, b)
                    }
                })
            };
            model.moveItemsTo = function (a, b, n) {
                UndoRedo.oneTransaction(function () {
                    var i;
                    if (b >= a && b < a + n) {
                        return
                    }
                    if (a < b) {
                        for (i = 0; i < n; i++) {
                            this.moveItemTo(a, b)
                        }
                    } else {
                        for (i = 0; i < n; i++) {
                            this.moveItemTo(a + i, b + i)
                        }
                    }
                }.bind(this))
            };
            model.getItemCount = function () {
                return this.__items.length
            };
            model.getAllSliders = function () {
                var sliders = [];
                for (var i = 0; i < this.__items.length; i++) {
                    var item = this.__items[i];
                    if (item.slider) {
                        sliders.push(item.slider)
                    }
                }
                return sliders
            };
            model.getSelected = function () {
                return this.selectedItem
            };
            model.setSelected = function (i) {
                var nextSelected = i;
                if (typeof i === "number") {
                    nextSelected = this.getItemByIndex(i)
                }
                if (nextSelected) {
                    nextSelected.setProperty("selected", true)
                } else {
                    var selected = this.getSelected();
                    if (selected) {
                        selected.setProperty("selected", false)
                    }
                }
            };
            model.onStartMovingPoint = function (id) {
                var movedExpr = this.getItemById(id);
                var moveIds = movedExpr && movedExpr.formula && movedExpr.formula.move_ids;
                if (!moveIds) {
                    return
                }
                if (movedExpr.isHelperExpression) {
                    movedExpr.setProperty("transient", true)
                }
                var self = this;
                UndoRedo.oneTransaction(function () {
                    for (var i = 0; i < moveIds.length; i++) {
                        if (moveIds[i] === undefined) {
                            continue
                        }
                        var item = self.getItemById(moveIds[i]);
                        if (!item) {
                            continue
                        }
                        item.slider.setProperty("isMoving", true);
                        item.slider.setProperty("dcg-isPlaying", false)
                    }
                });
                if (!movedExpr.isHelperExpression) {
                    this.setSelected(null)
                }
            };
            model.onStopMovingPoint = function (id) {
                var movedExpr = this.getItemById(id);
                var moveIds = movedExpr && movedExpr.formula && movedExpr.formula.move_ids;
                if (!moveIds) {
                    return
                }
                if (movedExpr.isHelperExpression) {
                    movedExpr.setProperty("transient", false)
                }
                for (var i = 0; i < moveIds.length; i++) {
                    if (moveIds[i] === undefined) {
                        continue
                    }
                    var item = this.getItemById(moveIds[i]);
                    if (!item) {
                        continue
                    }
                    item.slider.setProperty("isMoving", false)
                }
            };
            model.onMovePoint = function (id, screen_pt, projection) {
                var movedExpr = this.getItemById(id);
                var formula = movedExpr.formula;
                if (!formula) {
                    return
                }
                var moveIds = formula.move_ids;
                if (!moveIds) {
                    return
                }
                var moveMatrix = formula.move_matrix;
                if (!moveMatrix) {
                    return
                }
                var screenTL = projection.map_pt({x: projection.viewport.xmin, y: projection.viewport.ymax});
                var screenBR = projection.map_pt({x: projection.viewport.xmax, y: projection.viewport.ymin});
                screen_pt.x = Math.min(Math.max(screen_pt.x, screenTL.x), screenBR.x);
                screen_pt.y = Math.min(Math.max(screen_pt.y, screenTL.y), screenBR.y);
                if (movedExpr.constrainPt) {
                    var viewport_pt = projection.reverse_map_pt(screen_pt);
                    screen_pt = projection.map_pt(movedExpr.constrainPt(viewport_pt))
                }
                var tl = projection.reverse_map_pt({x: screen_pt.x - 0.5, y: screen_pt.y - 0.5});
                var br = projection.reverse_map_pt({x: screen_pt.x + 0.5, y: screen_pt.y + 0.5});
                var valueLimits = [{min: tl.x, max: br.x}, {min: tl.y, max: br.y}];
                var min, max, value;
                var expr;
                var self = this;
                UndoRedo.oneTransaction(function () {
                    for (var i = 0; i < moveIds.length; i++) {
                        if (moveIds[i] === undefined) {
                            continue
                        }
                        min = moveMatrix[i][valueLimits.length];
                        max = moveMatrix[i][valueLimits.length];
                        for (var j = 0; j < valueLimits.length; j++) {
                            var k = moveMatrix[i][j];
                            min += k * (k > 0 ? valueLimits[j].min : valueLimits[j].max);
                            max += k * (k > 0 ? valueLimits[j].max : valueLimits[j].min)
                        }
                        var moveId = moveIds[i];
                        expr = self.getItemById(moveId);
                        if (expr && expr.slider) {
                            expr.slider.setProperty("value", expr.slider.computeSnappedValue(value))
                        }
                    }
                })
            };
            model.toggleAllSliders = function () {
                var sliders = this.getAllSliders();
                for (var i = 0; i < sliders.length; i++) {
                    if (sliders[i].isPlaying) {
                        this.stopAllSliders();
                        return
                    }
                }
                this.playAllSliders()
            };
            model.playAllSliders = function () {
                var sliders = this.getAllSliders();
                UndoRedo.oneTransaction(function () {
                    for (var i = 0; i < sliders.length; i++) {
                        sliders[i].setProperty("isPlaying", true)
                    }
                }.bind(this))
            };
            model.stopAllSliders = function () {
                var sliders = this.getAllSliders();
                UndoRedo.oneTransaction(function () {
                    for (var i = 0; i < sliders.length; i++) {
                        sliders[i].setProperty("isPlaying", false)
                    }
                }.bind(this))
            };
            model.isEmpty = function () {
                var len = this.getItemCount();
                if (len === 0) {
                    return true
                }
                if (len > 1) {
                    return false
                }
                return this.getItemByIndex(0).latex === ""
            };
            model.getState = function () {
                var list_state = [];
                var len = this.getItemCount();
                for (var i = 0; i < len; i++) {
                    list_state.push(this.getItemByIndex(i).getState())
                }
                return {list: list_state}
            };
            model.batchEvaluation = function (fn) {
                fn()
            };
            model.triggerSetState = function (list) {
            };
            model.setState = function (state) {
                var i;
                var list_content = [];
                var folders = [];
                var obj;
                for (i = 0; i < state.list.length; i++) {
                    var expState = state.list[i];
                    expState.renderShell = true;
                    obj = this.fromState(expState);
                    if (!obj) {
                        continue
                    }
                    if (obj.isFolder) {
                        folders.push(obj)
                    }
                    list_content.push(obj)
                }
                var self = this;
                this.batchEvaluation(function () {
                    self._removeAllItems();
                    for (i = 0; i < list_content.length; i++) {
                        self._insertItemAt(i, list_content[i])
                    }
                });
                folders.forEach(function (folder) {
                    for (var id in folder.memberIds) {
                        var item = self.getItemById(id);
                        if (item) {
                            item.setProperty("folder", folder)
                        } else {
                            delete folder.memberIds[id]
                        }
                    }
                });
                this.triggerSetState(list_content);
                this.updateDrawOrder()
            };
            model.fromState = function (itemState) {
                if (!itemState.hasOwnProperty("hidden")) {
                    if (itemState.hasOwnProperty("graphed")) {
                        itemState.hidden = !itemState.graphed
                    } else {
                        if (itemState.hasOwnProperty("userRequestedGraphing")) {
                            itemState.hidden = (itemState.userRequestedGraphing === "never")
                        }
                    }
                }
                return ExpressionObject(itemState, this)
            };
            model.triggerRemoveExps = function () {
            };
            model.triggerRemoveExp = function () {
            };
            model.triggerAddExp = function () {
            }
        });
        return ExpressionListModel
    });
    define("loadcss!vendor_css/tipsy/tipsy", function () {
    });
    define("tipsy", ["require", "loadcss!vendor_css/tipsy/tipsy", "jquery"], function (require) {
        require("loadcss!vendor_css/tipsy/tipsy");
        var $ = require("jquery");
        var openSticky = null;
        var ignoreStickyOpen = false;
        $(document).on("tap", ".tipsy-sticky", function (evnt) {
            if (ignoreStickyOpen) {
                ignoreStickyOpen = false;
                return
            }
            var opener = evnt.currentTarget;
            var $target = $(opener);
            if (!$target.attr("tooltip")) {
                $target = $target.find("[tooltip]").filter(':not([tooltip=""])')
            }
            if ($target.length !== 1) {
                return
            }
            if ($target.css("display") === "none") {
                return
            }
            if ($target.parents().filter(function () {
                    return $(this).css("display") === "none"
                }).length) {
                return
            }
            var options = $.extend({}, $.fn.tipsy.defaults);
            options.title = "tooltip";
            options.gravity = "nw";
            openSticky = new Tipsy($target[0], options);
            openSticky.show();
            openSticky.opener = opener
        });
        $(document).on("tapstart keydown", function (evnt) {
            if (openSticky) {
                openSticky.hide();
                var opener = openSticky.opener;
                if (evnt.type === "tapstart" && $(evnt.target).closest(opener).length) {
                    $(document).one("tapend", function (evnt2) {
                        if ($(evnt2.target).closest(opener).length) {
                            ignoreStickyOpen = true
                        }
                    })
                }
                openSticky = null
            }
        });
        function maybeCall(thing, ctx) {
            return (typeof thing == "function") ? (thing.call(ctx)) : thing
        }

        function Tipsy(element, options) {
            this.$element = $(element);
            this.options = options;
            this.fixTitle()
        }

        Tipsy.prototype = {
            show: function () {
                var title = this.getTitle();
                if (title && !isTipsyDisabled()) {
                    var $tip = this.tip();
                    var $arrow = $tip.find(".tipsy-arrow");
                    $tip.find(".tipsy-inner")[this.options.html ? "html" : "text"](title);
                    $tip[0].className = "tipsy";
                    $tip.remove().css({top: 0, left: 0, visibility: "hidden", display: "block"}).prependTo(document.body);
                    var pos = $.extend({}, this.$element.offset(), {width: this.$element[0].offsetWidth, height: this.$element[0].offsetHeight});
                    var tp, actualWidth = $tip[0].offsetWidth, actualHeight = $tip[0].offsetHeight, gravity = maybeCall(this.options.gravity, this.$element[0]);
                    switch (gravity.charAt(0)) {
                        case"n":
                            tp = {top: pos.top + pos.height + this.options.offset, left: pos.left + pos.width / 2 - actualWidth / 2};
                            break;
                        case"s":
                            tp = {top: pos.top - actualHeight - this.options.offset, left: pos.left + pos.width / 2 - actualWidth / 2};
                            break;
                        case"e":
                            tp = {top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left - actualWidth - this.options.offset};
                            break;
                        case"w":
                            tp = {top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left + pos.width + this.options.offset};
                            break
                    }
                    if (gravity.length == 2) {
                        if (gravity.charAt(1) == "w") {
                            tp.left = pos.left + pos.width / 2 - 15
                        } else {
                            tp.left = pos.left + pos.width / 2 - actualWidth + 15
                        }
                    }
                    var arrowMarginLeft = 0;
                    if (tp.left < 0) {
                        arrowMarginLeft = tp.left;
                        tp.left = 0
                    } else {
                        if (tp.left + actualWidth > window.innerWidth) {
                            arrowMarginLeft = tp.left + actualWidth - window.innerWidth;
                            tp.left = window.innerWidth - actualWidth
                        }
                    }
                    if (gravity === "n" || gravity === "s") {
                        arrowMarginLeft -= 5
                    }
                    $arrow.css("marginLeft", arrowMarginLeft);
                    $tip.css(tp).addClass("tipsy-" + gravity);
                    $arrow[0].className = "tipsy-arrow tipsy-arrow-" + gravity.charAt(0);
                    if (this.options.className) {
                        $tip.addClass(maybeCall(this.options.className, this.$element[0]))
                    }
                    if (this.options.fadeIn) {
                        $tip.stop().css({opacity: 0, display: "block", visibility: "visible"}).animate({opacity: this.options.opacity}, this.options.fadeIn)
                    } else {
                        $tip.css({visibility: "visible", opacity: this.options.opacity})
                    }
                    if (this.options.sticky) {
                        $tip.addClass("tipsy-sticky")
                    }
                    var self = this;
                    var validateLoop = function () {
                        self.validate();
                        self.validateTimeout = setTimeout(validateLoop, 100)
                    };
                    validateLoop()
                }
            }, hide: function () {
                clearTimeout(this.validateTimeout);
                if (this.options.fadeOut) {
                    this.tip().stop().fadeOut(this.options.fadeOut, function () {
                        $(this).remove()
                    })
                } else {
                    this.tip().remove()
                }
            }, fixTitle: function () {
                var $e = this.$element;
                if ($e.attr("title") || typeof($e.attr("original-title")) != "string") {
                    $e.attr("original-title", $e.attr("title") || "").removeAttr("title")
                }
            }, getTitle: function () {
                var title, $e = this.$element, o = this.options;
                this.fixTitle();
                o = this.options;
                if (typeof o.title == "string") {
                    title = $e.attr(o.title == "title" ? "original-title" : o.title)
                } else {
                    if (typeof o.title == "function") {
                        title = o.title.call($e[0])
                    }
                }
                if (title) {
                    title = ("" + title).replace(/(^\s*|\s*$)/, "")
                }
                return title || o.fallback
            }, tip: function () {
                if (!this.$tip) {
                    this.$tip = $('<div class="tipsy"><div class="tipsy-arrow"></div><div class="tipsy-inner"></div></div>')
                }
                return this.$tip
            }, validate: function () {
                var hasTitle = !!this.getTitle();
                var inDom = false;
                if (hasTitle) {
                    try {
                        var node = this.$element[0];
                        while (node) {
                            if (node === document) {
                                inDom = true;
                                break
                            } else {
                                node = node.parentNode
                            }
                        }
                    } catch (e) {
                    }
                }
                if (!inDom) {
                    this.hide()
                }
            }
        };
        $.fn.tipsy = function (options) {
            if (options === true) {
                return this.data("tipsy")
            } else {
                if (typeof options == "string") {
                    var tipsy = this.data("tipsy");
                    if (tipsy) {
                        tipsy[options]()
                    }
                    return this
                }
            }
            options = $.extend({}, $.fn.tipsy.defaults, options);
            options.fadeIn = options.fadeIn || options.fade;
            options.fadeOut = options.fadeOut || options.fade;
            function get(ele) {
                var tipsy = $.data(ele, "tipsy");
                if (!tipsy) {
                    tipsy = new Tipsy(ele, $.fn.tipsy.elementOptions(ele, options));
                    $.data(ele, "tipsy", tipsy)
                }
                return tipsy
            }

            function enter(evnt) {
                if (evnt.type === "tipsyshow" && evnt.target !== this) {
                    return
                }
                if (openSticky === this) {
                    return
                }
                var tipsy = get(this);
                tipsy.hoverState = "in";
                if (options.delayIn === 0) {
                    tipsy.show()
                } else {
                    tipsy.fixTitle();
                    setTimeout(function () {
                        if (tipsy.hoverState == "in") {
                            tipsy.show()
                        }
                    }, options.delayIn)
                }
            }

            function leave(evnt) {
                if (evnt.type === "tipsyhide" && evnt.target !== this) {
                    return
                }
                var tipsy = get(this);
                if (evnt.type === "tapstart" && tipsy.options.sticky) {
                    return
                }
                tipsy.hoverState = "out";
                if (options.delayOut === 0) {
                    tipsy.hide()
                } else {
                    setTimeout(function () {
                        if (tipsy.hoverState == "out") {
                            tipsy.hide()
                        }
                    }, options.delayOut)
                }
            }

            if (!options.live) {
                this.each(function () {
                    get(this)
                })
            }
            if (options.trigger != "manual") {
                var eventIn = options.trigger == "hover" ? "tipsyshow" : "focus";
                var eventOut = options.trigger == "hover" ? "tipsyhide tapstart tapend tapcancel" : "blur";
                if (options.live && options.delegate) {
                    this.on(eventIn, options.delegate, enter).on(eventOut, options.delegate, leave)
                } else {
                    var binder = options.live ? "on" : "bind";
                    this[binder](eventIn, enter)[binder](eventOut, leave)
                }
            }
            return this
        };
        $.fn.tipsy.defaults = {
            className: null,
            delayIn: 0,
            delayOut: 0,
            fade: false,
            fadeIn: false,
            fadeOut: false,
            fallback: "",
            gravity: "n",
            html: false,
            live: true,
            offset: 0,
            opacity: 1,
            title: "title",
            trigger: "hover"
        };
        $.fn.tipsy.elementOptions = function (ele, options) {
            options = $.extend({}, options);
            var gravity = $(ele).attr("tipsy-gravity");
            if (gravity) {
                options.gravity = gravity
            }
            var offset = parseInt($(ele).attr("tipsy-offset"), 10);
            if (!isNaN(offset)) {
                options.offset = offset
            }
            return options
        };
        $.fn.tipsy.autoNS = function () {
            return $(this).offset().top > ($(document).scrollTop() + $(window).height() / 2) ? "s" : "n"
        };
        $.fn.tipsy.autoWE = function () {
            return $(this).offset().left > ($(document).scrollLeft() + $(window).width() / 2) ? "e" : "w"
        };
        $.fn.tipsy.autoBounds = function (margin, prefer) {
            return function () {
                var dir = {ns: prefer[0], ew: (prefer.length > 1 ? prefer[1] : false)}, boundTop = $(document).scrollTop() + margin, boundLeft = $(document).scrollLeft() + margin, $this = $(this);
                if ($this.offset().top < boundTop) {
                    dir.ns = "n"
                }
                if ($this.offset().left < boundLeft) {
                    dir.ew = "w"
                }
                if ($(window).width() + $(document).scrollLeft() - $this.offset().left < margin) {
                    dir.ew = "e"
                }
                if ($(window).height() + $(document).scrollTop() - $this.offset().top < margin) {
                    dir.ns = "s"
                }
                return dir.ns + (dir.ew ? dir.ew : "")
            }
        };
        $(document).tipsy({title: "tooltip", wait: 0, live: true, delegate: ".tipsy-sticky", gravity: "nw", sticky: true, fade: false});
        var disableLocks = 0;

        function isTipsyDisabled() {
            return disableLocks !== 0
        }

        function removeDisableLock() {
            disableLocks--
        }

        function addDisableLock() {
            disableLocks++
        }

        return {isDisabled: isTipsyDisabled, removeDisableLock: removeDisableLock, addDisableLock: addDisableLock}
    });
    define("underscore_view", ["require", "jquery", "underscore", "./underscore_model", "pjs", "i18n"], function (require) {
        var $ = require("jquery");
        var _ = require("underscore");
        var UnderscoreModel = require("./underscore_model");
        var P = require("pjs");
        var i18n = require("i18n");
        var UnderscoreView = P(UnderscoreModel, function (view) {
            view.$ = function (selector) {
                var $node = $(this.__domNode);
                if (!selector) {
                    return $node
                } else {
                    return $node.filter(selector).add($node.find(selector))
                }
            };
            var makeInsertFn = function (methodName) {
                return function (selector) {
                    if (!this.__domNode) {
                        _render.call(this)
                    }
                    $(selector)[methodName](this.$());
                    this.didInsertElement();
                    return this.$()
                }
            };
            view.appendTo = makeInsertFn("append");
            view.replace = makeInsertFn("replaceWith");
            view.prependTo = makeInsertFn("prepend");
            view.insertAfter = makeInsertFn("after");
            view.insertBefore = makeInsertFn("before");
            view.remove = function () {
                this.$().remove();
                this.destruct()
            };
            view.destruct = function () {
            };
            view.didCreateElement = function () {
            };
            view.didInsertElement = function () {
            };
            view.getTemplateParams = function () {
                return {}
            };
            view.beforeRerender = function () {
            };
            view.afterRerender = function () {
            };
            view.rerender = function () {
                var oldDomNode = this.__domNode;
                var newParams = this.getTemplateParams();
                if (_.isEqual(newParams, this.__lastRenderParams)) {
                    return
                }
                this.beforeRerender();
                _render.call(this);
                if (oldDomNode && $.contains(document, oldDomNode)) {
                    this.replace(oldDomNode)
                }
                this.afterRerender()
            };
            view.setDomNode = function (node) {
                this.__domNode = node[0] ? node[0] : node;
                this.didInsertElement()
            };
            var _render = function () {
                var params = this.getTemplateParams();
                var helpers = {
                    t: function (key, args) {
                        return i18n.t(key, args)
                    }
                };
                var combined = _.extend({}, params, helpers);
                var html = this.template(combined);
                var $node = $(html);
                this.__domNode = $node[0];
                this.__lastRenderParams = params;
                this.didCreateElement()
            }
        });
        return UnderscoreView
    });
    define("template", ["underscore", "text"], function (_, text) {
        var buildMap = {};
        return {
            load: function (name, req, onLoad, config) {
                var text_name = "template_src/" + name + ".underscore";
                text.get(req.toUrl(text_name), function (template_source) {
                    var template = _.template(template_source);
                    if (config.isBuild) {
                        buildMap[name] = template.source
                    }
                    onLoad(template)
                })
            }, write: function (pluginName, moduleName, write) {
                if (moduleName in buildMap) {
                    var template = (buildMap[moduleName]);
                    write("define('" + pluginName + "!" + moduleName + "', ['underscore'], function(_) {return " + template + ";});")
                } else {
                    console.log("ERROR - failed to find template " + moduleName + " in buildMap")
                }
            }
        }
    });
    define("keys", ["require"], function (require) {
        var Keys = function () {
            var table = {
                8: this.BACKSPACE = "Backspace",
                9: this.TAB = "Tab",
                13: this.ENTER = "Enter",
                16: this.SHIFT = "Shift",
                17: this.CONTROL = "Control",
                18: this.ALT = "Alt",
                20: this.CAPSLOCK = "CapsLock",
                27: this.ESCAPE = "Esc",
                32: this.SPACEBAR = "Space",
                33: this.PAGEUP = "PageUp",
                34: this.PAGEDOWN = "PageDown",
                35: this.END = "End",
                36: this.HOME = "Home",
                37: this.LEFT = "Left",
                38: this.UP = "Up",
                39: this.RIGHT = "Right",
                40: this.DOWN = "Down",
                46: this.DELETE = "Del"
            };
            this.lookup = function (evt) {
                return table[evt.which]
            }
        };
        return new Keys()
    });
    (function ($) {
        $.fn.extend({
            scrollVisible: function (elms, topOffset, bottomOffset) {
                if (elms && elms.length) {
                    var topPadding = topOffset || 0;
                    var bottomPadding = -bottomOffset || 0;
                    var view_top_from_doc = this.offset().top;
                    var view_height = this.outerHeight();
                    var elms_top_from_doc = Infinity;
                    var elms_bottom_from_doc = -Infinity;
                    elms.each(function () {
                        var elm = $(this);
                        var top = elm.offset().top;
                        var bottom = elm.outerHeight() + top;
                        if (top < elms_top_from_doc) {
                            elms_top_from_doc = top
                        }
                        if (bottom > elms_bottom_from_doc) {
                            elms_bottom_from_doc = bottom
                        }
                    });
                    var elms_height = elms_bottom_from_doc - elms_top_from_doc;
                    var padded_elms_height = elms_height + topPadding + bottomPadding;
                    var scrollTop = this.scrollTop();
                    var elms_top_in_scroll_area = elms_top_from_doc - view_top_from_doc + scrollTop;
                    var elms_bottom_in_scroll_area = elms_bottom_from_doc - view_top_from_doc + scrollTop;
                    var padded_elms_top_in_scroll_area = elms_top_in_scroll_area - topPadding;
                    var padded_elms_bottom_in_scroll_area = elms_bottom_in_scroll_area + bottomPadding;
                    if (scrollTop > padded_elms_top_in_scroll_area && scrollTop + view_height < padded_elms_bottom_in_scroll_area) {
                    } else {
                        if (elms_height > view_height) {
                        } else {
                            if (padded_elms_height > view_height) {
                                var total_desired_padding = topPadding + bottomPadding;
                                var total_allowed_padding = view_height - elms_height;
                                var topPadding_weight = topPadding / total_desired_padding;
                                var proportional_topPadding = topPadding_weight * total_allowed_padding;
                                this.scrollTop(padded_elms_top_in_scroll_area - proportional_topPadding)
                            } else {
                                if (scrollTop > padded_elms_top_in_scroll_area) {
                                    this.scrollTop(padded_elms_top_in_scroll_area)
                                } else {
                                    if (scrollTop + view_height < padded_elms_bottom_in_scroll_area) {
                                        this.scrollTop(padded_elms_bottom_in_scroll_area - view_height)
                                    }
                                }
                            }
                        }
                    }
                }
                return this
            }
        })
    })(jQuery);
    define("jquery.scrollvisible", function () {
    });
    define("loadcss!css/new_expression", function () {
    });
    define("template!new_expression", ["underscore"], function (_) {
        return function (obj) {
            var __p = "";
            var print = function () {
                __p += Array.prototype.join.call(arguments, "")
            };
            with (obj || {}) {
            }
            return __p
        }
    });
    define("expressions/new_expression", ["require", "loadcss!css/new_expression", "pjs", "underscore_view", "template!new_expression", "./expression"], function (require) {
        require("loadcss!css/new_expression");
        var P = require("pjs");
        var UnderscoreView = require("underscore_view");
        var template = require("template!new_expression");
        var ExpressionObject = require("./expression");
        var NewExpressionView = P(UnderscoreView, function (view, _super) {
            view.template = template;
            view.init = function (listView) {
                _super.init.call(this);
                this.observe("index", this.updateIndex.bind(this));
                this.listView = listView
            };
            view.didInsertElement = function () {
                this.updateIndex();
                this.$(".dcg-action-newmath").on("tap", this.newMath.bind(this))
            };
            view.updateIndex = function () {
                this.$(".dcg-variable-index").text(this.index)
            };
            view.newMath = function () {
                var constructor = ExpressionObject;
                var properties = {selected: true, latex: ""};
                var obj = constructor(properties, this.listView.model);
                this.listView.model.insertItemAt(this.listView.model.getItemCount(), obj);
                this.listView.getSelectedView().addFocus()
            }
        });
        return NewExpressionView
    });
    define("expressions/renderviewport", ["require", "main/timermodules", "browser"], function (require) {
        var TimerModules = require("main/timermodules");
        var Browser = require("browser");
        TimerModules.add("expressions.renderviewport", (function (expressionsView, grapher) {
            var $exppanel = expressionsView.$(".dcg-exppanel");
            var lastScrollStableTime = 0;
            var lastScrollHeight = 0;
            var lastScrollTop = 0;

            function getUnrenderedViewportItems() {
                var time = new Date().getTime();
                if (lastScrollStableTime === 0) {
                    lastScrollStableTime = time;
                    return []
                }
                if (time - lastScrollStableTime < 300) {
                    return []
                }
                var anyUnrendered = expressionsView.model.__items.some(function (item) {
                    return item.renderShell
                });
                if (!anyUnrendered) {
                    return []
                }
                var expPanelTop = $exppanel.offset().top;
                var scrollTop = $exppanel.scrollTop();
                var scrollHeight = $exppanel.height();
                if (scrollTop !== lastScrollTop || scrollHeight !== lastScrollHeight) {
                    lastScrollTop = scrollTop;
                    lastScrollHeight = scrollHeight;
                    lastScrollStableTime = 0;
                    return []
                }
                var first = expressionsView.expressionAtPoint(5, expPanelTop);
                var last = expressionsView.expressionAbovePoint(5, expPanelTop + scrollHeight);
                if (!first || !last) {
                    return []
                }
                return expressionsView.model.getItemsByIndexRange(first.index, last.index).filter(function (item) {
                    return item.renderShell
                })
            }

            function renderItems() {
                if (Browser.IS_MOBILE || grapher.redraw_slowly_timeout) {
                    getUnrenderedViewportItems().forEach(function (item) {
                        item.setProperty("renderShell", false)
                    })
                } else {
                    var len = expressionsView.model.getItemCount();
                    for (var i = 0, j = 0; i < len && j < 10; ++i) {
                        var item = expressionsView.model.getItemByIndex(i);
                        if (item.renderShell) {
                            item.setProperty("renderShell", false);
                            j++
                        }
                    }
                }
            }

            return renderItems
        }))
    });
    define("template!unresolved_view", ["underscore"], function (_) {
        return function (obj) {
            var __p = "";
            var print = function () {
                __p += Array.prototype.join.call(arguments, "")
            };
            with (obj || {}) {
                __p += '<div class="dcg-unresolved">\n  <i class="dcg-icon-error" /> This function contains fine detail that has not been fully resolved.\n  <a href="http://support.desmos.com/entries/29577773-Unresolved-Detail-In-Plotted-Functions" target="_blank">Learn more.</a>\n</div>'
            }
            return __p
        }
    });
    define("expressions/unresolved", ["require", "pjs", "underscore_view", "template!unresolved_view"], function (require) {
        var P = require("pjs");
        var UnderscoreView = require("underscore_view");
        var template = require("template!unresolved_view");
        return P(UnderscoreView, function (view, _super) {
            view.template = template
        })
    });
    define("main/focus", ["require"], function (require) {
        return {
            takeFocus: function () {
            }
        }
    });
    define("loadcss!vendor_css/mathquill/mathquill", function () {
    });
    (function () {
        var $ = jQuery, undefined, _, mqCmdId = "mathquill-command-id", mqBlockId = "mathquill-block-id", min = Math.min, max = Math.max;
        var __slice = [].slice;

        function noop() {
        }

        function bind(cons) {
            var args = __slice.call(arguments, 1);
            return function () {
                return cons.apply(this, args)
            }
        }

        function pray(message, cond) {
            if (!cond) {
                throw new Error("prayer failed: " + message)
            }
        }

        var P = (function (prototype, ownProperty, undefined) {
            function isObject(o) {
                return typeof o === "object"
            }

            function isFunction(f) {
                return typeof f === "function"
            }

            function P(_superclass, definition) {
                if (definition === undefined) {
                    definition = _superclass;
                    _superclass = Object
                }
                function C(args) {
                    var self = this;
                    if (!(self instanceof C)) {
                        return new C(arguments)
                    }
                    if (args && isFunction(self.init)) {
                        self.init.apply(self, args)
                    }
                }

                var proto = C[prototype] = new _superclass();
                var _super = _superclass[prototype];
                var extensions;
                proto.constructor = C;
                C.mixin = function (def) {
                    C[prototype] = P(C, def)[prototype];
                    return C
                };
                return (C.open = function (def) {
                    extensions = {};
                    if (isFunction(def)) {
                        extensions = def.call(C, proto, _super, C, _superclass)
                    } else {
                        if (isObject(def)) {
                            extensions = def
                        }
                    }
                    if (isObject(extensions)) {
                        for (var ext in extensions) {
                            if (ownProperty.call(extensions, ext)) {
                                proto[ext] = extensions[ext]
                            }
                        }
                    }
                    if (!isFunction(proto.init)) {
                        proto.init = function () {
                            _superclass.apply(this, arguments)
                        }
                    }
                    return C
                })(definition)
            }

            return P
        })("prototype", ({}).hasOwnProperty);
        var manageTextarea = (function () {
            var KEY_VALUES = {
                8: "Backspace",
                9: "Tab",
                10: "Enter",
                13: "Enter",
                16: "Shift",
                17: "Control",
                18: "Alt",
                20: "CapsLock",
                27: "Esc",
                32: "Spacebar",
                33: "PageUp",
                34: "PageDown",
                35: "End",
                36: "Home",
                37: "Left",
                38: "Up",
                39: "Right",
                40: "Down",
                45: "Insert",
                46: "Del",
                144: "NumLock"
            };

            function stringify(evt) {
                var which = evt.which || evt.keyCode;
                var keyVal = KEY_VALUES[which];
                var key;
                var modifiers = [];
                if (evt.ctrlKey) {
                    modifiers.push("Ctrl")
                }
                if (evt.originalEvent && evt.originalEvent.metaKey) {
                    modifiers.push("Meta")
                }
                if (evt.altKey) {
                    modifiers.push("Alt")
                }
                if (evt.shiftKey) {
                    modifiers.push("Shift")
                }
                key = keyVal || String.fromCharCode(which);
                if (!modifiers.length && !keyVal) {
                    return key
                }
                modifiers.push(key);
                return modifiers.join("-")
            }

            return function manageTextarea(el, opts) {
                if (!el.is("textarea")) {
                    return {select: noop}
                }
                var keydown = null;
                var keypress = null;
                if (!opts) {
                    opts = {}
                }
                var textCallback = opts.text || noop;
                var keyCallback = opts.key || noop;
                var pasteCallback = opts.paste || noop;
                var onCut = opts.cut || noop;
                var textarea = $(el);
                var target = $(opts.container || textarea);
                var timeout, deferredFn;

                function defer(fn) {
                    timeout = setTimeout(fn);
                    deferredFn = fn
                }

                function flush() {
                    if (timeout) {
                        clearTimeout(timeout);
                        timeout = undefined;
                        deferredFn()
                    }
                }

                target.bind("keydown keypress input keyup focusout paste", flush);
                function select(text) {
                    flush();
                    textarea.val(text);
                    if (text) {
                        textarea[0].select()
                    }
                }

                function hasSelection() {
                    var dom = textarea[0];
                    if (!("selectionStart" in dom)) {
                        return false
                    }
                    return dom.selectionStart !== dom.selectionEnd
                }

                function popText(callback) {
                    var text = textarea.val();
                    textarea.val("");
                    if (text) {
                        callback(text)
                    }
                }

                function handleKey() {
                    keyCallback(stringify(keydown), keydown)
                }

                function onKeydown(e) {
                    keydown = e;
                    keypress = null;
                    handleKey()
                }

                function onKeypress(e) {
                    if (keydown && keypress) {
                        handleKey()
                    }
                    keypress = e;
                    defer(function () {
                        if (hasSelection()) {
                            setTimeout(function () {
                                if (!hasSelection()) {
                                    popText(textCallback)
                                }
                            })
                        } else {
                            popText(textCallback)
                        }
                        if (hasSelection()) {
                            return
                        }
                        popText(textCallback)
                    })
                }

                function onBlur() {
                    keydown = keypress = null
                }

                function onPaste(e) {
                    textarea.focus();
                    defer(function () {
                        popText(pasteCallback)
                    })
                }

                target.bind({keydown: onKeydown, keypress: onKeypress, focusout: onBlur, cut: onCut, paste: onPaste});
                return {select: select}
            }
        }());
        var Parser = P(function (_, _super, Parser) {
            function parseError(stream, message) {
                if (stream) {
                    stream = "'" + stream + "'"
                } else {
                    stream = "EOF"
                }
                throw"Parse Error: " + message + " at " + stream
            }

            _.init = function (body) {
                this._ = body
            };
            _.parse = function (stream) {
                return this.skip(eof)._(stream, success, parseError);
                function success(stream, result) {
                    return result
                }
            };
            _.or = function (alternative) {
                pray("or is passed a parser", alternative instanceof Parser);
                var self = this;
                return Parser(function (stream, onSuccess, onFailure) {
                    return self._(stream, onSuccess, failure);
                    function failure(newStream) {
                        return alternative._(stream, onSuccess, onFailure)
                    }
                })
            };
            _.then = function (next) {
                var self = this;
                return Parser(function (stream, onSuccess, onFailure) {
                    return self._(stream, success, onFailure);
                    function success(newStream, result) {
                        var nextParser = (next instanceof Parser ? next : next(result));
                        pray("a parser is returned", nextParser instanceof Parser);
                        return nextParser._(newStream, onSuccess, onFailure)
                    }
                })
            };
            _.many = function () {
                var self = this;
                return Parser(function (stream, onSuccess, onFailure) {
                    var xs = [];
                    while (self._(stream, success, failure)) {
                    }
                    return onSuccess(stream, xs);
                    function success(newStream, x) {
                        stream = newStream;
                        xs.push(x);
                        return true
                    }

                    function failure() {
                        return false
                    }
                })
            };
            _.times = function (min, max) {
                if (arguments.length < 2) {
                    max = min
                }
                var self = this;
                return Parser(function (stream, onSuccess, onFailure) {
                    var xs = [];
                    var result = true;
                    var failure;
                    for (var i = 0; i < min; i += 1) {
                        result = self._(stream, success, firstFailure);
                        if (!result) {
                            return onFailure(stream, failure)
                        }
                    }
                    for (; i < max && result; i += 1) {
                        result = self._(stream, success, secondFailure)
                    }
                    return onSuccess(stream, xs);
                    function success(newStream, x) {
                        xs.push(x);
                        stream = newStream;
                        return true
                    }

                    function firstFailure(newStream, msg) {
                        failure = msg;
                        stream = newStream;
                        return false
                    }

                    function secondFailure(newStream, msg) {
                        return false
                    }
                })
            };
            _.result = function (res) {
                return this.then(succeed(res))
            };
            _.atMost = function (n) {
                return this.times(0, n)
            };
            _.atLeast = function (n) {
                var self = this;
                return self.times(n).then(function (start) {
                    return self.many().map(function (end) {
                        return start.concat(end)
                    })
                })
            };
            _.map = function (fn) {
                return this.then(function (result) {
                    return succeed(fn(result))
                })
            };
            _.skip = function (two) {
                return this.then(function (result) {
                    return two.result(result)
                })
            };
            var string = this.string = function (str) {
                var len = str.length;
                var expected = "expected '" + str + "'";
                return Parser(function (stream, onSuccess, onFailure) {
                    var head = stream.slice(0, len);
                    if (head === str) {
                        return onSuccess(stream.slice(len), head)
                    } else {
                        return onFailure(stream, expected)
                    }
                })
            };
            var regex = this.regex = function (re) {
                pray("regexp parser is anchored", re.toString().charAt(1) === "^");
                var expected = "expected " + re;
                return Parser(function (stream, onSuccess, onFailure) {
                    var match = re.exec(stream);
                    if (match) {
                        var result = match[0];
                        return onSuccess(stream.slice(result.length), result)
                    } else {
                        return onFailure(stream, expected)
                    }
                })
            };
            var succeed = Parser.succeed = function (result) {
                return Parser(function (stream, onSuccess) {
                    return onSuccess(stream, result)
                })
            };
            var fail = Parser.fail = function (msg) {
                return Parser(function (stream, _, onFailure) {
                    return onFailure(stream, msg)
                })
            };
            var letter = Parser.letter = regex(/^[a-z]/i);
            var letters = Parser.letters = regex(/^[a-z]*/i);
            var digit = Parser.digit = regex(/^[0-9]/);
            var digits = Parser.digits = regex(/^[0-9]*/);
            var whitespace = Parser.whitespace = regex(/^\s+/);
            var optWhitespace = Parser.optWhitespace = regex(/^\s*/);
            var any = Parser.any = Parser(function (stream, onSuccess, onFailure) {
                if (!stream) {
                    return onFailure(stream, "expected any character")
                }
                return onSuccess(stream.slice(1), stream.charAt(0))
            });
            var all = Parser.all = Parser(function (stream, onSuccess, onFailure) {
                return onSuccess("", stream)
            });
            var eof = Parser.eof = Parser(function (stream, onSuccess, onFailure) {
                if (stream) {
                    return onFailure(stream, "expected EOF")
                }
                return onSuccess(stream, stream)
            })
        });
        var Node = P(function (_) {
            _.prev = 0;
            _.next = 0;
            _.parent = 0;
            _.firstChild = 0;
            _.lastChild = 0;
            _.children = function () {
                return Fragment(this.firstChild, this.lastChild)
            };
            _.eachChild = function (fn) {
                return this.children().each(fn)
            };
            _.foldChildren = function (fold, fn) {
                return this.children().fold(fold, fn)
            };
            _.adopt = function (parent, prev, next) {
                Fragment(this, this).adopt(parent, prev, next);
                return this
            };
            _.disown = function () {
                Fragment(this, this).disown();
                return this
            }
        });
        var Fragment = P(function (_) {
            _.first = 0;
            _.last = 0;
            _.init = function (first, last) {
                pray("no half-empty fragments", !first === !last);
                if (!first) {
                    return
                }
                pray("first node is passed to Fragment", first instanceof Node);
                pray("last node is passed to Fragment", last instanceof Node);
                pray("first and last have the same parent", first.parent === last.parent);
                this.first = first;
                this.last = last
            };
            function prayWellFormed(parent, prev, next) {
                pray("a parent is always present", parent);
                pray("prev is properly set up", (function () {
                    if (!prev) {
                        return parent.firstChild === next
                    }
                    return prev.next === next && prev.parent === parent
                })());
                pray("next is properly set up", (function () {
                    if (!next) {
                        return parent.lastChild === prev
                    }
                    return next.prev === prev && next.parent === parent
                })())
            }

            _.adopt = function (parent, prev, next) {
                prayWellFormed(parent, prev, next);
                var self = this;
                self.disowned = false;
                var first = self.first;
                if (!first) {
                    return this
                }
                var last = self.last;
                if (prev) {
                } else {
                    parent.firstChild = first
                }
                if (next) {
                    next.prev = last
                } else {
                    parent.lastChild = last
                }
                self.last.next = next;
                self.each(function (el) {
                    el.prev = prev;
                    el.parent = parent;
                    if (prev) {
                        prev.next = el
                    }
                    prev = el
                });
                return self
            };
            _.disown = function () {
                var self = this;
                var first = self.first;
                if (!first || self.disowned) {
                    return self
                }
                self.disowned = true;
                var last = self.last;
                var parent = first.parent;
                prayWellFormed(parent, first.prev, first);
                prayWellFormed(parent, last, last.next);
                if (first.prev) {
                    first.prev.next = last.next
                } else {
                    parent.firstChild = last.next
                }
                if (last.next) {
                    last.next.prev = first.prev
                } else {
                    parent.lastChild = first.prev
                }
                return self
            };
            _.each = function (fn) {
                var self = this;
                var el = self.first;
                if (!el) {
                    return self
                }
                for (; el !== self.last.next; el = el.next) {
                    if (fn.call(self, el) === false) {
                        break
                    }
                }
                return self
            };
            _.fold = function (fold, fn) {
                this.each(function (el) {
                    fold = fn.call(this, fold, el)
                });
                return fold
            }
        });
        var uuid = (function () {
            var id = 0;
            return function () {
                return id += 1
            }
        })();
        var MathElement = P(Node, function (_) {
            _.init = function (obj) {
                this.id = uuid();
                MathElement[this.id] = this
            };
            _.toString = function () {
                return "[MathElement " + this.id + "]"
            };
            _.bubble = function (event) {
                var args = __slice.call(arguments, 1);
                for (var ancestor = this; ancestor; ancestor = ancestor.parent) {
                    var res = ancestor[event] && ancestor[event].apply(ancestor, args);
                    if (res === false) {
                        break
                    }
                }
                return this
            };
            _.postOrder = function (fn) {
                if (typeof fn === "string") {
                    var methodName = fn;
                    fn = function (el) {
                        if (methodName in el) {
                            el[methodName].apply(el, arguments)
                        }
                    }
                }
                (function recurse(desc) {
                    desc.eachChild(recurse);
                    fn(desc)
                })(this)
            };
            _.jQ = $();
            _.jQadd = function (jQ) {
                this.jQ = this.jQ.add(jQ)
            };
            this.jQize = function (html) {
                var jQ = $(html);

                function jQadd(el) {
                    if (el.getAttribute) {
                        var cmdId = el.getAttribute("mathquill-command-id");
                        var blockId = el.getAttribute("mathquill-block-id");
                        if (cmdId) {
                            MathElement[cmdId].jQadd(el)
                        }
                        if (blockId) {
                            MathElement[blockId].jQadd(el)
                        }
                    }
                }

                function traverse(el) {
                    for (el = el.firstChild; el; el = el.nextSibling) {
                        jQadd(el);
                        if (el.firstChild) {
                            traverse(el)
                        }
                    }
                }

                for (var i = 0; i < jQ.length; i += 1) {
                    jQadd(jQ[i]);
                    traverse(jQ[i])
                }
                return jQ
            };
            _.finalizeInsert = function () {
                var self = this;
                self.postOrder("finalizeTree");
                self.postOrder("blur");
                self.postOrder("respace");
                if (self.next.respace) {
                    self.next.respace()
                }
                if (self.prev.respace) {
                    self.prev.respace()
                }
                self.postOrder("redraw");
                self.bubble("redraw");
                self.bubble("redraw")
            };
            _.seek = function (cursor, clientX, clientY, root, clientRect) {
                var frontier = [];

                function popClosest() {
                    var iClosest, minSqDist = Infinity;
                    for (var i = 0; i < frontier.length; i += 1) {
                        if (!frontier[i]) {
                            continue
                        }
                        var sqDist = frontier[i].sqDist;
                        if (sqDist < minSqDist) {
                            iClosest = i, minSqDist = sqDist
                        }
                    }
                    var closest = frontier[iClosest];
                    frontier[iClosest] = null;
                    return closest
                }

                function seekPoint(node) {
                    var pt = node.seekPoint(clientX, clientY, clientRect);
                    if (!pt) {
                        return
                    }
                    var dx = clientX - pt.x, dy = clientY - pt.y;
                    frontier.push({point: pt, sqDist: dx * dx + dy * dy})
                }

                function addNode(node) {
                    if (!node) {
                        return
                    }
                    var rect = clientRect(node);
                    var closestX = max(rect.left, min(rect.right, clientX));
                    var closestY = max(rect.top, min(rect.bottom, clientY));
                    var dx = clientX - closestX, dy = clientY - closestY;
                    frontier.push({node: node, sqDist: dx * dx + dy * dy})
                }

                function addContainer(node) {
                    if (node === root) {
                        return
                    }
                    var rect = clientRect(node);
                    var dist = max(0, min(clientX - rect.left, clientY - rect.top, rect.right - clientX, rect.bottom - clientY));
                    frontier.push({container: node, sqDist: dist * dist})
                }

                seekPoint(this);
                this.eachChild(addNode);
                addContainer(this);
                for (var closest = popClosest(); !closest.point; closest = popClosest()) {
                    if (closest.container) {
                        var container = closest.container, outer = container.parent;
                        seekPoint(outer);
                        outer.eachChild(function (n) {
                            if (n !== container) {
                                addNode(n)
                            }
                        });
                        addContainer(outer)
                    } else {
                        seekPoint(closest.node);
                        closest.node.eachChild(addNode)
                    }
                }
                if (closest.point.next) {
                    cursor.insertBefore(closest.point.next)
                } else {
                    cursor.appendTo(closest.point.parent)
                }
            }
        });
        var MathCommand = P(MathElement, function (_, _super) {
            _.init = function (ctrlSeq, htmlTemplate, textTemplate) {
                var cmd = this;
                _super.init.call(cmd);
                if (!cmd.ctrlSeq) {
                    cmd.ctrlSeq = ctrlSeq
                }
                if (htmlTemplate) {
                    cmd.htmlTemplate = htmlTemplate
                }
                if (textTemplate) {
                    cmd.textTemplate = textTemplate
                }
            };
            _.replaces = function (replacedFragment) {
                replacedFragment.disown();
                this.replacedFragment = replacedFragment
            };
            _.isEmpty = function () {
                return this.foldChildren(true, function (isEmpty, child) {
                    return isEmpty && child.isEmpty()
                })
            };
            _.parser = function () {
                var block = latexMathParser.block;
                var self = this;
                return block.times(self.numBlocks()).map(function (blocks) {
                    self.blocks = blocks;
                    for (var i = 0; i < blocks.length; i += 1) {
                        blocks[i].adopt(self, self.lastChild, 0)
                    }
                    return self
                })
            };
            _.createBefore = function (cursor) {
                var cmd = this;
                var replacedFragment = cmd.replacedFragment;
                cmd.createBlocks();
                MathElement.jQize(cmd.html());
                if (replacedFragment) {
                    replacedFragment.adopt(cmd.firstChild, 0, 0);
                    replacedFragment.jQ.appendTo(cmd.firstChild.jQ)
                }
                cursor.jQ.before(cmd.jQ);
                cursor.prev = cmd.adopt(cursor.parent, cursor.prev, cursor.next);
                cmd.finalizeInsert(cursor);
                cmd.placeCursor(cursor)
            };
            _.createBlocks = function () {
                var cmd = this, numBlocks = cmd.numBlocks(), blocks = cmd.blocks = Array(numBlocks);
                for (var i = 0; i < numBlocks; i += 1) {
                    var newBlock = blocks[i] = MathBlock();
                    newBlock.adopt(cmd, cmd.lastChild, 0)
                }
            };
            _.respace = noop;
            _.placeCursor = function (cursor) {
                cursor.appendTo(this.foldChildren(this.firstChild, function (prev, child) {
                    return prev.isEmpty() ? prev : child
                }))
            };
            _.seekPoint = noop;
            _.expectedCursorYNextTo = function (clientRect) {
                return this.firstChild.expectedCursorYInside(clientRect)
            };
            _.remove = function () {
                this.disown();
                this.jQ.remove();
                this.postOrder(function (el) {
                    delete MathElement[el.id]
                });
                return this
            };
            _.numBlocks = function () {
                var matches = this.htmlTemplate.match(/&\d+/g);
                return matches ? matches.length : 0
            };
            _.html = function () {

                var cmd = this;
                var blocks = cmd.blocks;
                var cmdId = " mathquill-command-id=" + cmd.id;
                var tokens = cmd.htmlTemplate.match(/<[^<>]+>|[^<>]+/g);
                pray("no unmatched angle brackets", tokens.join("") === this.htmlTemplate);
                for (var i = 0, token = tokens[0]; token; i += 1, token = tokens[i]) {
                    if (token.slice(-2) === "/>") {
                        tokens[i] = token.slice(0, -2) + cmdId + "/>"
                    } else {
                        if (token.charAt(0) === "<") {
                            pray("not an unmatched top-level close tag", token.charAt(1) !== "/");
                            tokens[i] = token.slice(0, -1) + cmdId + ">";
                            var nesting = 1;
                            do {
                                i += 1, token = tokens[i];
                                pray("no missing close tags", token);
                                if (token.slice(0, 2) === "</") {
                                    nesting -= 1
                                } else {
                                    if (token.charAt(0) === "<" && token.slice(-2) !== "/>") {
                                        nesting += 1
                                    }
                                }
                            } while (nesting > 0)
                        }
                    }
                }

                return tokens.join("").replace(/>&(\d+)/g, function ($0, $1) {
                    return " mathquill-block-id=" + blocks[$1].id + ">" + blocks[$1].join("html")
                })
            };
            _.latex = function () {
                return this.foldChildren(this.ctrlSeq, function (latex, child) {
                    return latex + "{" + (child.latex() || " ") + "}"
                })
            };
            _.textTemplate = [""];
            _.text = function () {
                var i = 0;
                return this.foldChildren(this.textTemplate[i], function (text, child) {
                    i += 1;
                    var child_text = child.text();
                    if (text && this.textTemplate[i] === "(" && child_text[0] === "(" && child_text.slice(-1) === ")") {
                        return text + child_text.slice(1, -1) + this.textTemplate[i]
                    }
                    return text + child.text() + (this.textTemplate[i] || "")
                })
            }
        });
        var Symbol = P(MathCommand, function (_, _super) {
            _.init = function (ctrlSeq, html, text) {
                if (!text) {
                    text = ctrlSeq && ctrlSeq.length > 1 ? ctrlSeq.slice(1) : ctrlSeq
                }
                _super.init.call(this, ctrlSeq, html, [text])
            };
            _.parser = function () {
                return Parser.succeed(this)
            };
            _.numBlocks = function () {
                return 0
            };
            _.replaces = function (replacedFragment) {
                replacedFragment.remove()
            };
            _.createBlocks = noop;
            _.seek = function (cursor, clientX, clientY, root, clientRect) {
                var rect = clientRect(this), left = rect.left, right = rect.right;
                if (clientX - left < right - clientX) {
                    cursor.insertBefore(this)
                } else {
                    cursor.insertAfter(this)
                }
            };
            _.expectedCursorYNextTo = function (clientRect) {
                return (clientRect(this).top + clientRect(this).bottom) / 2
            };
            _.latex = function () {
                return this.ctrlSeq
            };
            _.text = function () {
                return this.textTemplate
            };
            _.placeCursor = noop;
            _.isEmpty = function () {
                return true
            }
        });
        var MathBlock = P(MathElement, function (_) {
            _.join = function (methodName) {
                return this.foldChildren("", function (fold, child) {
                    return fold + child[methodName]()
                })
            };
            _.latex = function () {
                return this.join("latex")
            };
            _.text = function () {
                return this.firstChild === this.lastChild ? this.firstChild.text() : "(" + this.join("text") + ")"
            };
            _.isEmpty = function () {
                return this.firstChild === 0 && this.lastChild === 0
            };
            _.seekPoint = function (clientX, clientY, clientRect) {
                if (!this.firstChild) {
                    var pt = {next: 0, x: (clientRect(this).left + clientRect(this).right) / 2}
                } else {
                    function pointLeftOf(n) {
                        return {next: n, x: clientRect(n).left}
                    }

                    var pt = pointLeftOf(this.firstChild);
                    if (clientX > pt.x) {
                        pt = pointLeftOf(this.lastChild);
                        var rightwardPt = {next: 0, x: clientRect(pt.next).right};
                        while (clientX < pt.x) {
                            rightwardPt = pt, pt = pointLeftOf(pt.next.prev)
                        }
                        if (rightwardPt.x - clientX < clientX - pt.x) {
                            pt = rightwardPt
                        }
                    }
                }
                return {parent: this, next: pt.next, x: pt.x, y: this.expectedCursorYInside(clientRect)}
            };
            _.expectedCursorYInside = function (clientRect) {
                if (this.firstChild) {
                    return this.firstChild.expectedCursorYNextTo(clientRect)
                } else {
                    return (clientRect(this).top + clientRect(this).bottom) / 2
                }
            };
            _.focus = function () {
                this.jQ.addClass("mq-hasCursor");
                this.jQ.removeClass("mq-empty");
                return this
            };
            _.blur = function () {
                this.jQ.removeClass("mq-hasCursor");
                if (this.isEmpty()) {
                    this.jQ.addClass("mq-empty")
                }
                return this
            }
        });
        var MathFragment = P(Fragment, function (_, _super) {
            _.init = function (first, last) {
                _super.init.call(this, first, last || first);
                this.jQ = this.fold($(), function (jQ, child) {
                    return child.jQ.add(jQ)
                })
            };
            _.latex = function () {
                return this.fold("", function (latex, el) {
                    return latex + el.latex()
                })
            };
            _.remove = function () {
                this.jQ.remove();
                this.each(function (el) {
                    el.postOrder(function (desc) {
                        delete MathElement[desc.id]
                    })
                });
                return this.disown()
            }
        });

        function createRoot(container, root, textbox, editable) {
            var contents = container.contents().detach();
            if (!textbox) {
                container.addClass("mathquill-rendered-math")
            }
            root.jQ = $('<span class="mathquill-root-block"/>').appendTo(container.attr(mqBlockId, root.id));
            root.revert = function () {
                container.empty().unbind(".mathquill").removeClass("mathquill-rendered-math mathquill-editable mathquill-textbox").append(contents)
            };
            root.cursor = Cursor(root);
            root.renderLatex(contents.text())
        }

        function setupTextarea(editable, container, root, cursor) {
            var is_ios = navigator.userAgent.match(/(iPad|iPhone|iPod)/i) !== null;
            var is_android = navigator.userAgent.match(/(Android|Silk|Kindle)/i) !== null;
            var textareaSpan = root.textarea = (is_ios || is_android) ? $('<span class="mq-textarea"><span tabindex=0></span></span>') : $('<span class="mq-textarea"><textarea style="width:0px;height:0px;display:none"></textarea></span>'), textarea = textareaSpan.children();
            var textareaSelectionTimeout;
            root.selectionChanged = function () {
                if (textareaSelectionTimeout === undefined) {
                    textareaSelectionTimeout = setTimeout(setTextareaSelection)
                }
                forceIERedraw(container[0])
            };
            function setTextareaSelection() {
                textareaSelectionTimeout = undefined;
                var latex = cursor.selection ? "$" + cursor.selection.latex() + "$" : "";
                textareaManager.select(latex);
                root.triggerSpecialEvent("selectionChanged")
            }

            container.bind("selectstart.mathquill", function (e) {
                if (e.target !== textarea[0]) {
                    e.preventDefault()
                }
                e.stopPropagation()
            });
            var textareaManager = hookUpTextarea(editable, container, root, cursor, textarea, textareaSpan, setTextareaSelection);
            return textarea
        }

        function mouseEvents(ultimateRootjQ) {
            ultimateRootjQ.bind("mousedown.mathquill", function (e) {
                e.preventDefault();
                var container = $(e.target);
                if (!container.hasClass("mathquill-editable")) {
                    container = container.closest(".mathquill-root-block").parent()
                }
                var root = MathElement[container.attr(mqBlockId) || ultimateRootjQ.attr(mqBlockId)];
                var cursor = root.cursor, blink = cursor.blink;
                var textareaSpan = root.textarea, textarea = textareaSpan.children();
                if (root.ignoreMousedownTimeout !== undefined) {
                    clearTimeout(root.ignoreMousedownTimeout);
                    root.ignoreMousedownTimeout = undefined;
                    return
                }
                var cachedClientRect = cachedClientRectFnForNewCache();

                function mousemove(e) {
                    cursor.seek($(e.target), e.clientX, e.clientY, cachedClientRect);
                    if (cursor.prev !== anticursor.prev || cursor.parent !== anticursor.parent) {
                        cursor.selectFrom(anticursor)
                    }
                    e.preventDefault()
                }

                function docmousemove(e) {
                    delete e.target;
                    return mousemove(e)
                }

                function mouseup(e) {
                    anticursor = undefined;
                    cursor.blink = blink;
                    if (!cursor.selection) {
                        if (root.editable) {
                            cursor.show()
                        } else {
                            textareaSpan.detach()
                        }
                    }
                    container.unbind("mousemove", mousemove);
                    $(e.target.ownerDocument).unbind("mousemove", docmousemove).unbind("mouseup", mouseup)
                }

                cursor.blink = noop;
                cursor.hideHandle().seek($(e.target), e.clientX, e.clientY, cachedClientRect);
                var anticursor = {parent: cursor.parent, prev: cursor.prev, next: cursor.next};
                if (!root.editable && root.blurred) {
                    container.prepend(textareaSpan)
                }
                textarea.focus();
                root.blurred = false;
                container.mousemove(mousemove);
                $(e.target.ownerDocument).mousemove(docmousemove).mouseup(mouseup)
            })
        }

        function setupTouchHandle(editable, root, cursor) {
            function firstFingerOnly(ontouchstart) {
                return function (e) {
                    e.preventDefault();
                    var e = e.originalEvent, target = $(e.target);
                    if (e.changedTouches.length < e.touches.length) {
                        return
                    }
                    var touchstart = e.changedTouches[0];
                    var handlers = ontouchstart(touchstart) || 0;
                    if (handlers.touchmove) {
                        target.bind("touchmove", function (e) {
                            var touchmove = e.originalEvent.changedTouches[0];
                            if (touchmove.id !== touchstart.id) {
                                return
                            }
                            handlers.touchmove.call(this, touchmove)
                        })
                    }
                    target.bind("touchend", function (e) {
                        var touchend = e.originalEvent.changedTouches[0];
                        if (touchend.id !== touchstart.id) {
                            return
                        }
                        if (handlers.touchend) {
                            handlers.touchend.call(this, touchend)
                        }
                        target.unbind("touchmove touchend")
                    })
                }
            }

            var blink = cursor.blink;
            cursor.handle.on("touchstart", firstFingerOnly(function (e) {
                cursor.blink = noop;
                var cursorRect = cursor.jQ[0].getBoundingClientRect();
                var offsetX = e.clientX - cursorRect.left;
                var offsetY = e.clientY - (cursorRect.top + cursorRect.bottom) / 2;
                var cachedClientRect = cachedClientRectFnForNewCache();
                var onAnimationEnd;
                root.onAnimationEnd = function () {
                    onAnimationEnd()
                };
                return {
                    touchmove: function (e) {
                        var adjustedX = e.clientX - offsetX, adjustedY = e.clientY - offsetY;
                        cursor.seek(elAtPt(adjustedX, adjustedY, root), adjustedX, adjustedY, cachedClientRect, true);
                        visualHapticFeedback();
                        onAnimationEnd = visualHapticFeedback;
                        function visualHapticFeedback() {
                            var cursorRect = cursor.jQ[0].getBoundingClientRect();
                            cursor.repositionHandle(cursorRect);
                            var dx = adjustedX - cursorRect.left;
                            var dy = adjustedY - (cursorRect.top + cursorRect.bottom) / 2;
                            var dist = Math.sqrt(dx * dx + dy * dy);
                            var weight = (Math.log(dist) + 1) / dist;
                            var skewX = Math.atan2(weight * dx, offsetY);
                            var scaleY = (weight * dy + offsetY) / offsetY;
                            var steeperScale = 2 * (scaleY - 1) + 1;
                            cursor.handle.css({WebkitTransform: "translateX(.5px) skewX(" + skewX + "rad) scaleY(" + scaleY + ")", opacity: 1 - steeperScale * 0.5})
                        }
                    }, touchend: function (e) {
                        cursor.handle.css({WebkitTransform: "", opacity: ""});
                        cursor.blink = blink;
                        cursor.show(true);
                        onAnimationEnd = function () {
                            cursor.repositionHandle(cursor.jQ[0].getBoundingClientRect());
                            cursor.handle.css({WebkitTransform: "", opacity: ""});
                            delete root.onAnimationEnd
                        }
                    }
                }
            }))
        }

        function hookUpTextarea(editable, container, root, cursor, textarea, textareaSpan, setTextareaSelection) {
            if (!editable) {
                root.blurred = true;
                var textareaManager = manageTextarea(textarea, {container: container});
                container.bind("copy", setTextareaSelection).prepend('<span class="mq-selectable">$' + root.latex() + "$</span>");
                textarea.bind("cut paste", false).blur(function () {
                    cursor.clearSelection();
                    setTimeout(detach)
                });
                function detach() {
                    textareaSpan.detach();
                    root.blurred = true
                }

                return textareaManager
            }
            var textareaManager = manageTextarea(textarea, {
                container: container, key: function (key, evt) {
                    cursor.parent.bubble("onKey", key, evt)
                }, text: function (text) {
                    cursor.parent.bubble("onText", text)
                }, cut: function (e) {
                    if (cursor.selection) {
                        setTimeout(function () {
                            cursor.prepareEdit();
                            cursor.parent.bubble("redraw");
                            root.triggerSpecialEvent("render")
                        })
                    }
                    e.stopPropagation();
                    root.triggerSpecialEvent("render")
                }, paste: function (text) {
                    if (text.slice(0, 1) === "$" && text.slice(-1) === "$") {
                        text = text.slice(1, -1)
                    }
                    cursor.writeLatex(text).show();
                    root.triggerSpecialEvent("render")
                }
            });
            container.prepend(textareaSpan);
            return textareaManager
        }

        function rootCSSClasses(container, textbox) {
            container.addClass("mathquill-editable");
            if (textbox) {
                container.addClass("mathquill-textbox")
            }
        }

        function focusBlurEvents(root, cursor, textarea) {
            textarea.focus(function (e) {
                root.blurred = false;
                if (!cursor.parent) {
                    cursor.appendTo(root)
                }
                cursor.parent.jQ.addClass("mq-hasCursor");
                if (cursor.selection) {
                    cursor.selection.jQ.removeClass("mq-blur");
                    setTimeout(root.selectionChanged)
                } else {
                    cursor.show()
                }
            }).blur(function (e) {
                root.blurred = true;
                cursor.hide().parent.blur();
                if (cursor.selection) {
                    cursor.selection.jQ.addClass("mq-blur")
                }
            }).blur()
        }

        function desmosCustomEvents(container, root, cursor) {
            container.bind("select_all", function (e) {
                cursor.prepareMove().appendTo(root);
                while (cursor.prev) {
                    cursor.selectLeft()
                }
            }).bind("custom_paste", function (e, text) {
                if (text.slice(0, 1) === "$" && text.slice(-1) === "$") {
                    text = text.slice(1, -1)
                }
                cursor.writeLatex(text).show();
                root.triggerSpecialEvent("render")
            })
        }

        function elAtPt(clientX, clientY, root) {
            var el = document.elementFromPoint(clientX, clientY);
            return $.contains(root.jQ[0], el) ? $(el) : root.jQ
        }

        function cachedClientRectFnForNewCache() {
            var cache = {};

            function elById(el, id) {
                if (!cache[id]) {
                    pray("only called within Cursor::seek", "scrollLeft" in cachedClientRect);
                    var rect = el.getBoundingClientRect(), dx = cachedClientRect.scrollLeft;
                    cache[id] = {top: rect.top, right: rect.right + dx, bottom: rect.bottom, left: rect.left + dx}
                }
                return cache[id]
            }

            function cachedClientRect(node) {
                return elById(node.jQ[0], node.id)
            }

            cachedClientRect.elById = elById;
            return cachedClientRect
        }

        var RootMathBlock = P(MathBlock, function (_, _super) {
            _.latex = function () {
                return _super.latex.call(this).replace(/(\\[a-z]+) (?![a-z])/ig, "$1")
            };
            _.text = function () {
                return this.foldChildren("", function (text, child) {
                    return text + child.text()
                })
            };
            _.renderLatex = function (latex) {
                var all = Parser.all;
                var eof = Parser.eof;
                var block = latexMathParser.skip(eof).or(all.result(false)).parse(latex);
                this.firstChild = this.lastChild = 0;
                if (block) {
                    block.children().adopt(this, 0, 0)
                }
                var jQ = this.jQ;
                if (block) {
                    var html = block.join("html");
                    jQ.html(html);
                    MathElement.jQize(jQ);
                    this.focus().finalizeInsert()
                } else {
                    jQ.empty()
                }
                this.cursor.appendTo(this)
            };
            _.renderSliderLatex = function (latex) {
                function makeCmd(ch) {
                    var cmd;
                    var code = ch.charCodeAt(0);
                    if ((65 <= code && code <= 90) || (97 <= code && code <= 122)) {
                        cmd = Variable(ch)
                    } else {
                        if (CharCmds[ch] || LatexCmds[ch]) {
                            cmd = (CharCmds[ch] || LatexCmds[ch])(ch)
                        } else {
                            cmd = VanillaSymbol(ch)
                        }
                    }
                    return cmd
                }

                var matches = /^([a-z])(?:_([a-z0-9]|\{[a-z0-9]+\}))?=([-0-9.]+)$/i.exec(latex);
                pray("valid restricted slider LaTeX", matches);
                var letter = matches[1];
                var subscript = matches[2];
                var value = matches[3];
                this.firstChild = this.lastChild = 0;
                letter = Variable(letter);
                if (subscript) {
                    var sub = LatexCmds._("_");
                    var subBlock = MathBlock().adopt(sub, 0, 0);
                    sub.blocks = [subBlock];
                    if (subscript.length === 1) {
                        makeCmd(subscript).adopt(subBlock, subBlock.lastChild, 0)
                    } else {
                        for (var i = 1; i < subscript.length - 1; i += 1) {
                            makeCmd(subscript.charAt(i)).adopt(subBlock, subBlock.lastChild, 0)
                        }
                    }
                }
                letter.adopt(this, this.lastChild, 0);
                if (sub) {
                    sub.adopt(this, this.lastChild, 0)
                }
                LatexCmds["="]("=").adopt(this, this.lastChild, 0);
                for (var i = 0, l = value.length; i < l; i += 1) {
                    var ch = value.charAt(i);
                    var cmd = makeCmd(ch);
                    cmd.adopt(this, this.lastChild, 0)
                }
                var jQ = this.jQ;
                var html = this.join("html");
                jQ.html(html);
                MathElement.jQize(jQ);
                this.cursor.parent = this;
                this.cursor.prev = this.lastChild;
                this.cursor.next = 0
            };
            _.up = function () {
                this.triggerSpecialEvent("upPressed")
            };
            _.down = function () {
                this.triggerSpecialEvent("downPressed")
            };
            _.moveOutOf = function (dir) {
                this.triggerSpecialEvent(dir + "Pressed")
            };
            _.onKey = function (key, e) {
                switch (key) {
                    case"Ctrl-Shift-Backspace":
                    case"Ctrl-Backspace":
                        while (this.cursor.prev || this.cursor.selection) {
                            this.cursor.backspace()
                        }
                        break;
                    case"Shift-Backspace":
                    case"Backspace":
                        this.cursor.backspace();
                        this.triggerSpecialEvent("render");
                        break;
                    case"Esc":
                    case"Tab":
                        var parent = this.cursor.parent;
                        if (parent === this.cursor.root) {
                            return
                        }
                        this.cursor.prepareMove();
                        if (parent.next) {
                            this.cursor.prependTo(parent.next)
                        } else {
                            this.cursor.insertAfter(parent.parent)
                        }
                        break;
                    case"Shift-Tab":
                    case"Shift-Esc":
                        var parent = this.cursor.parent;
                        if (parent === this.cursor.root) {
                            return
                        }
                        this.cursor.prepareMove();
                        if (parent.prev) {
                            this.cursor.appendTo(parent.prev)
                        } else {
                            this.cursor.insertBefore(parent.parent)
                        }
                        break;
                    case"Enter":
                        this.triggerSpecialEvent("enterPressed");
                        break;
                    case"End":
                        this.cursor.prepareMove().appendTo(this.cursor.parent);
                        break;
                    case"Ctrl-End":
                        this.cursor.prepareMove().appendTo(this);
                        break;
                    case"Shift-End":
                        while (this.cursor.next) {
                            this.cursor.selectRight()
                        }
                        break;
                    case"Ctrl-Shift-End":
                        while (this.cursor.next || this.cursor.parent !== this) {
                            this.cursor.selectRight()
                        }
                        break;
                    case"Home":
                        this.cursor.prepareMove().prependTo(this.cursor.parent);
                        break;
                    case"Ctrl-Home":
                        this.cursor.prepareMove().prependTo(this);
                        break;
                    case"Shift-Home":
                        while (this.cursor.prev) {
                            this.cursor.selectLeft()
                        }
                        break;
                    case"Ctrl-Shift-Home":
                        while (this.cursor.prev || this.cursor.parent !== this) {
                            this.cursor.selectLeft()
                        }
                        break;
                    case"Left":
                        this.cursor.moveLeft();
                        break;
                    case"Shift-Left":
                        this.cursor.selectLeft();
                        break;
                    case"Ctrl-Left":
                        break;
                    case"Meta-Left":
                        break;
                    case"Right":
                        this.cursor.moveRight();
                        break;
                    case"Shift-Right":
                        this.cursor.selectRight();
                        break;
                    case"Ctrl-Right":
                        break;
                    case"Meta-Right":
                        break;
                    case"Up":
                        this.cursor.moveUp();
                        break;
                    case"Down":
                        this.cursor.moveDown();
                        break;
                    case"Shift-Up":
                        if (this.cursor.prev) {
                            while (this.cursor.prev) {
                                this.cursor.selectLeft()
                            }
                        } else {
                            this.cursor.selectLeft()
                        }
                    case"Shift-Down":
                        if (this.cursor.next) {
                            while (this.cursor.next) {
                                this.cursor.selectRight()
                            }
                        } else {
                            this.cursor.selectRight()
                        }
                    case"Ctrl-Up":
                        break;
                    case"Meta-Up":
                        break;
                    case"Ctrl-Down":
                        break;
                    case"Meta-Down":
                        break;
                    case"Ctrl-Shift-Del":
                    case"Ctrl-Del":
                        while (this.cursor.next || this.cursor.selection) {
                            this.cursor.deleteForward()
                        }
                        this.triggerSpecialEvent("render");
                        break;
                    case"Shift-Del":
                    case"Del":
                        this.cursor.deleteForward();
                        this.triggerSpecialEvent("render");
                        break;
                    case"Meta-A":
                    case"Ctrl-A":
                        if (this !== this.cursor.root) {
                            return
                        }
                        this.cursor.prepareMove().appendTo(this);
                        while (this.cursor.prev) {
                            this.cursor.selectLeft()
                        }
                        break;
                    default:
                        this.scrollHoriz();
                        return false
                }
                e.preventDefault();
                this.scrollHoriz();
                return false
            };
            _.onText = function (ch) {
                this.cursor.write(ch);
                this.triggerSpecialEvent("render");
                this.scrollHoriz();
                return false
            };
            _.scrollHoriz = function () {
                var cursor = this.cursor, seln = cursor.selection;
                var rootRect = this.jQ[0].getBoundingClientRect();
                if (!seln) {
                    var x = cursor.jQ[0].getBoundingClientRect().left;
                    if (x > rootRect.right - 20) {
                        var scrollBy = x - (rootRect.right - 20)
                    } else {
                        if (x < rootRect.left + 20) {
                            var scrollBy = x - (rootRect.left + 20)
                        } else {
                            return
                        }
                    }
                } else {
                    var rect = seln.jQ[0].getBoundingClientRect();
                    var overLeft = rect.left - (rootRect.left + 20);
                    var overRight = rect.right - (rootRect.right - 20);
                    if (seln.first === cursor.next) {
                        if (overLeft < 0) {
                            var scrollBy = overLeft
                        } else {
                            if (overRight > 0) {
                                if (rect.left - overRight < rootRect.left + 20) {
                                    var scrollBy = overLeft
                                } else {
                                    var scrollBy = overRight
                                }
                            } else {
                                return
                            }
                        }
                    } else {
                        if (overRight > 0) {
                            var scrollBy = overRight
                        } else {
                            if (overLeft < 0) {
                                if (rect.right - overLeft > rootRect.right - 20) {
                                    var scrollBy = overRight
                                } else {
                                    var scrollBy = overLeft
                                }
                            } else {
                                return
                            }
                        }
                    }
                }
                this.jQ.stop().animate({scrollLeft: "+=" + scrollBy}, 100, this.onAnimationEnd)
            };
            _.triggerSpecialEvent = function (eventName) {
                var jQ = this.jQ;
                setTimeout(function () {
                    jQ.trigger(eventName)
                }, 1)
            }
        });
        var RootMathCommand = P(MathCommand, function (_, _super) {
            _.init = function (cursor) {
                _super.init.call(this, "$");
                this.cursor = cursor
            };
            _.htmlTemplate = '<span class="mathquill-rendered-math">&0</span>';
            _.createBlocks = function () {
                this.firstChild = this.lastChild = RootMathBlock();
                this.blocks = [this.firstChild];
                this.firstChild.parent = this;
                var cursor = this.firstChild.cursor = this.cursor;
                this.firstChild.onText = function (ch) {
                    if (ch !== "$" || cursor.parent !== this) {
                        cursor.write(ch)
                    } else {
                        if (this.isEmpty()) {
                            cursor.insertAfter(this.parent).backspace().insertNew(VanillaSymbol("\\$", "$")).show()
                        } else {
                            if (!cursor.next) {
                                cursor.insertAfter(this.parent)
                            } else {
                                if (!cursor.prev) {
                                    cursor.insertBefore(this.parent)
                                } else {
                                    cursor.write(ch)
                                }
                            }
                        }
                    }
                    return false
                }
            };
            _.latex = function () {
                return "$" + this.firstChild.latex() + "$"
            }
        });
        var RootTextBlock = P(MathBlock, function (_) {
            _.renderLatex = function (latex) {
                var self = this;
                var cursor = self.cursor;
                self.jQ.children().slice(1).remove();
                self.firstChild = self.lastChild = 0;
                cursor.show().appendTo(self);
                var regex = Parser.regex;
                var string = Parser.string;
                var eof = Parser.eof;
                var all = Parser.all;
                var mathMode = string("$").then(latexMathParser).skip(string("$").or(eof)).map(function (block) {
                    var rootMathCommand = RootMathCommand(cursor);
                    rootMathCommand.createBlocks();
                    var rootMathBlock = rootMathCommand.firstChild;
                    block.children().adopt(rootMathBlock, 0, 0);
                    return rootMathCommand
                });
                var escapedDollar = string("\\$").result("$");
                var textChar = escapedDollar.or(regex(/^[^$]/)).map(VanillaSymbol);
                var latexText = mathMode.or(textChar).many();
                var commands = latexText.skip(eof).or(all.result(false)).parse(latex);
                if (commands) {
                    for (var i = 0; i < commands.length; i += 1) {
                        commands[i].adopt(self, self.lastChild, 0)
                    }
                    var html = self.join("html");
                    MathElement.jQize(html).appendTo(self.jQ);
                    this.finalizeInsert()
                }
            };
            _.onKey = RootMathBlock.prototype.onKey;
            _.onText = function (ch) {
                this.cursor.prepareEdit();
                if (ch === "$") {
                    this.cursor.insertNew(RootMathCommand(this.cursor))
                } else {
                    this.cursor.insertNew(VanillaSymbol(ch))
                }
                return false
            };
            _.scrollHoriz = RootMathBlock.prototype.scrollHoriz
        });
        var CharCmds = {}, LatexCmds = {};
        var scale, forceIERedraw = noop, div = document.createElement("div"), div_style = div.style, transformPropNames = {
            transform: 1,
            WebkitTransform: 1,
            MozTransform: 1,
            OTransform: 1,
            msTransform: 1
        }, transformPropName;
        for (var prop in transformPropNames) {

            if (prop in div_style) {
                transformPropName = prop;
                break
            }
        }
        if (transformPropName) {
            scale = function (jQ, x, y) {
                jQ.css(transformPropName, "scale(" + x + "," + y + ")")
            }
        } else {
            if ("filter" in div_style) {
                forceIERedraw = function (el) {
                    el.className = el.className
                };
                scale = function (jQ, x, y) {
                    x /= (1 + (y - 1) / 2);
                    jQ.css("fontSize", y + "em");
                    if (!jQ.hasClass("mq-matrixed-container")) {
                        jQ.addClass("mq-matrixed-container").wrapInner('<span class="mq-matrixed"></span>')
                    }
                    var innerjQ = jQ.children().css("filter", "progid:DXImageTransform.Microsoft.Matrix(M11=" + x + ",SizingMethod='auto expand')");

                    function calculateMarginRight() {
                        jQ.css("marginRight", (innerjQ.width() - 1) * (x - 1) / x + "px")
                    }

                    calculateMarginRight();
                    var intervalId = setInterval(calculateMarginRight);
                    $(window).load(function () {
                        clearTimeout(intervalId);
                        calculateMarginRight()
                    })
                }
            } else {
                scale = function (jQ, x, y) {
                    jQ.css("fontSize", y + "em")
                }
            }
        }
        var Style = P(MathCommand, function (_, _super) {
            _.init = function (ctrlSeq, tagName, attrs) {
                _super.init.call(this, ctrlSeq, "<" + tagName + " " + attrs + ">&0</" + tagName + ">")
            }
        });
        LatexCmds.mathrm = bind(Style, "\\mathrm", "span", 'class="mq-roman mq-font"');
        LatexCmds.mathit = bind(Style, "\\mathit", "i", 'class="mq-font"');
        LatexCmds.mathbf = bind(Style, "\\mathbf", "b", 'class="mq-font"');
        LatexCmds.mathsf = bind(Style, "\\mathsf", "span", 'class="mq-sans-serif mq-font"');
        LatexCmds.mathtt = bind(Style, "\\mathtt", "span", 'class="mq-monospace mq-font"');
        LatexCmds.underline = bind(Style, "\\underline", "span", 'class="mq-non-leaf mq-underline"');
        LatexCmds.overline = LatexCmds.bar = bind(Style, "\\overline", "span", 'class="mq-non-leaf mq-overline"');
        var SupSub = P(MathCommand, function (_, _super) {
            _.init = function (ctrlSeq, tag, text) {
                _super.init.call(this, ctrlSeq, "<" + tag + ' class="mq-non-leaf"><span class="mq-non-leaf mq-' + tag + '">&0</span></' + tag + ">", [text])
            };
            _.finalizeTree = function () {
                pray("SupSub is only _ and ^", this.ctrlSeq === "^" || this.ctrlSeq === "_");
                if (this.ctrlSeq === "_") {
                    this.down = this.firstChild;
                    this.firstChild.up = insertBeforeUnlessAtEnd
                } else {
                    this.up = this.firstChild;
                    this.firstChild.down = insertBeforeUnlessAtEnd
                }
            };
            function insertBeforeUnlessAtEnd(cursor) {
                var cmd = this.parent, ancestorCmd = cursor;
                do {
                    if (ancestorCmd.next) {
                        cursor.insertBefore(cmd);
                        return false
                    }
                    ancestorCmd = ancestorCmd.parent.parent
                } while (ancestorCmd !== cmd);
                cursor.insertAfter(cmd);
                return false
            }

            _.latex = function () {
                if (this.ctrlSeq === "_" && this.respaced) {
                    return ""
                }
                var latex = "";
                if (this.ctrlSeq === "^" && this.next.respaced) {
                    var block = this.next.firstChild.latex();
                    if (block.length === 1) {
                        latex += "_" + block
                    } else {
                        latex += "_{" + block + "}"
                    }
                }
                var block = this.firstChild.latex();
                if (block.length === 1) {
                    latex += this.ctrlSeq + block
                } else {
                    latex += this.ctrlSeq + "{" + (block || " ") + "}"
                }
                return latex
            };
            _.redraw = function () {
                if (this.prev) {
                    this.prev.respace()
                }
                if (!(this.prev instanceof SupSub)) {
                    this.respace();
                    if (this.next && !(this.next instanceof SupSub)) {
                        this.next.respace()
                    }
                }
            };
            _.respace = function () {
                if (this.prev.ctrlSeq === "\\int " || (this.prev instanceof SupSub && this.prev.ctrlSeq != this.ctrlSeq && this.prev.prev && this.prev.prev.ctrlSeq === "\\int ")) {
                    if (!this["int"]) {
                        this["int"] = true;
                        this.jQ.addClass("mq-int")
                    }
                } else {
                    if (this["int"]) {
                        this["int"] = false;
                        this.jQ.removeClass("mq-int")
                    }
                }
                this.respaced = this.prev instanceof SupSub && this.prev.ctrlSeq != this.ctrlSeq && !this.prev.respaced;
                if (this.respaced) {
                    var fontSize = +this.jQ.css("fontSize").slice(0, -2), prevWidth = this.prev.jQ.outerWidth(), thisWidth = this.jQ.outerWidth();
                    this.jQ.css({left: (this["int"] && this.ctrlSeq === "_" ? -0.25 : 0) - prevWidth / fontSize + "em", marginRight: 0.1 - min(thisWidth, prevWidth) / fontSize + "em"})
                } else {
                    if (this["int"] && this.ctrlSeq === "_") {
                        this.jQ.css({left: "-.25em", marginRight: ""})
                    } else {
                        this.jQ.css({left: "", marginRight: ""})
                    }
                }
                if (this.respaced) {
                    if (this.ctrlSeq === "^") {
                        this.down = this.firstChild.down = this.prev.firstChild
                    } else {
                        this.up = this.firstChild.up = this.prev.firstChild
                    }
                } else {
                    if (this.next.respaced) {
                        if (this.ctrlSeq === "_") {
                            this.up = this.firstChild.up = this.next.firstChild
                        } else {
                            this.down = this.firstChild.down = this.next.firstChild
                        }
                    } else {
                        if (this.ctrlSeq === "_") {
                            delete this.up;
                            this.firstChild.up = insertBeforeUnlessAtEnd
                        } else {
                            delete this.down;
                            this.firstChild.down = insertBeforeUnlessAtEnd
                        }
                    }
                }
                if (this.next instanceof SupSub) {
                    this.next.respace()
                }
                return this
            };
            _.onKey = function (key, e) {
                if (this.getCursor().parent.parent !== this) {
                    return
                }
                switch (key) {
                    case"Tab":
                        if (this.next.respaced) {
                            this.getCursor().prepareMove().prependTo(this.next.firstChild);
                            e.preventDefault();
                            return false
                        }
                        break;
                    case"Shift-Tab":
                        if (this.respaced) {
                            this.getCursor().prepareMove().appendTo(this.prev.firstChild);
                            e.preventDefault();
                            return false
                        }
                        break;
                    case"Left":
                        if (!this.getCursor().prev && this.respaced) {
                            this.getCursor().prepareMove().insertBefore(this.prev);
                            return false
                        }
                        break;
                    case"Right":
                        if (!this.getCursor().next && this.next.respaced) {
                            this.getCursor().prepareMove().insertAfter(this.next);
                            return false
                        }
                }
            };
            _.getCursor = function () {
                var cursor;
                for (var ancestor = this.parent; !cursor; ancestor = ancestor.parent) {
                    cursor = ancestor.cursor
                }
                this.getCursor = function () {
                    return cursor
                };
                return this.getCursor()
            };
            _.expectedCursorYNextTo = function (clientRect) {
                if (this.ctrlSeq === "_") {
                    return clientRect(this).top
                } else {
                    return clientRect(this).bottom
                }
            }
        });
        LatexCmds.subscript = LatexCmds._ = bind(SupSub, "_", "sub", "_");
        LatexCmds.superscript = LatexCmds.supscript = LatexCmds["^"] = bind(SupSub, "^", "sup", "**");
        var BigSymbol = P(MathCommand, function (_, _super) {
            _.init = function (ch, html) {
                var htmlTemplate = '<span class="mq-large-operator mq-non-leaf"><span class="mq-to" ><span>&1</span></span><big>' + html + '</big><span class="mq-from"><span>&0</span></span></span>';
                Symbol.prototype.init.call(this, ch, htmlTemplate)
            };
            _.placeCursor = function (cursor) {
                cursor.appendTo(this.firstChild).writeLatex("n=").show()
            };
            _.latex = function () {
                function simplify(latex) {
                    return latex.length === 1 ? latex : "{" + (latex || " ") + "}"
                }

                return this.ctrlSeq + "_" + simplify(this.firstChild.latex()) + "^" + simplify(this.lastChild.latex())
            };
            _.parser = function () {
                var string = Parser.string;
                var optWhitespace = Parser.optWhitespace;
                var succeed = Parser.succeed;
                var block = latexMathParser.block;
                var self = this;
                var blocks = self.blocks = [MathBlock(), MathBlock()];
                for (var i = 0; i < blocks.length; i += 1) {
                    blocks[i].adopt(self, self.lastChild, 0)
                }
                return optWhitespace.then(string("_").or(string("^"))).then(function (supOrSub) {
                    var child = blocks[supOrSub === "_" ? 0 : 1];
                    return block.then(function (block) {
                        block.children().adopt(child, child.lastChild, 0);
                        return succeed(self)
                    })
                }).many().result(self)
            };
            _.finalizeTree = function () {
                this.down = this.firstChild;
                this.firstChild.up = insertAfterUnlessAtBeginning;
                this.up = this.lastChild;
                this.lastChild.down = insertAfterUnlessAtBeginning
            };
            function insertAfterUnlessAtBeginning(cursor) {
                var cmd = this.parent, ancestorCmd = cursor;
                do {
                    if (ancestorCmd.prev) {
                        cursor.insertAfter(cmd);
                        return false
                    }
                    ancestorCmd = ancestorCmd.parent.parent
                } while (ancestorCmd !== cmd);
                cursor.insertBefore(cmd);
                return false
            }
        });
        var VBigSymbol = P(MathCommand, function (_, _super) {
            _.init = function (ch, html) {
                var htmlTemplate = '<span style="width:60px" class="mq-large-operator mq-non-leaf"><span class="mq-to" ></span><big>' + html + '</big><span class="mq-from">n→∞</span></span>';
                Symbol.prototype.init.call(this, ch, htmlTemplate)
            };
            _.placeCursor = function (cursor) {
                cursor.appendTo(this.firstChild).writeLatex("n \\to ").show()
            };
            _.latex = function () {
                function simplify(latex) {
                    return latex
                }

                return "\\begin{align}\\underset{n\\to \\infty }{\\mathop{\\lim }}\\end{align}"
            }
        });
        var DownSymbol = P(MathCommand, function (_, _super) {
            _.init = function (ch, html) {
                var htmlTemplate = '<span class="mq-large-operator mq-non-leaf"><span class="mq-to" style="height:15px;"><span>';
                if (html == "&#8994;") {
                    htmlTemplate = htmlTemplate + "<img style='width: 25px;'  src='img/hu.png'/>"
                } else {
                    htmlTemplate = htmlTemplate + html
                }
                htmlTemplate = htmlTemplate + '</span></span><span class="mq-non-leaf mq-sqrt-stem" style="border-top: 0px solid;">&0</span></span>';
                Symbol.prototype.init.call(this, ch, htmlTemplate)
            };
            _.placeCursor = function (cursor) {
                cursor.appendTo(this.firstChild).writeLatex("n=").show()
            };
            _.latex = function () {
                function simplify(latex) {
                    return latex.length === 1 ? latex : "{" + (latex || " ") + "}"
                }

                return this.ctrlSeq + "" + simplify(this.firstChild.latex())
            };
            _.parser = function () {
                var string = Parser.string;
                var optWhitespace = Parser.optWhitespace;
                var succeed = Parser.succeed;
                var block = latexMathParser.block;
                var self = this;
                var blocks = self.blocks = [MathBlock()];
                for (var i = 0; i < blocks.length; i += 1) {
                    blocks[i].adopt(self, self.lastChild, 0)
                }
                return optWhitespace.then(string("_").or(string("^"))).then(function (supOrSub) {
                    var child = blocks[supOrSub === "_" ? 0 : 1];
                    return block.then(function (block) {
                        block.children().adopt(child, child.lastChild, 0);
                        return succeed(self)
                    })
                }).many().result(self)
            };
            _.finalizeTree = function () {
                this.down = this.firstChild;
                this.firstChild.up = insertAfterUnlessAtBeginning;
                this.up = this.lastChild;
                this.lastChild.down = insertAfterUnlessAtBeginning
            };
            function insertAfterUnlessAtBeginning(cursor) {
                var cmd = this.parent, ancestorCmd = cursor;
                do {
                    if (ancestorCmd.prev) {
                        cursor.insertAfter(cmd);
                        return false
                    }
                    ancestorCmd = ancestorCmd.parent.parent
                } while (ancestorCmd !== cmd);
                cursor.insertBefore(cmd);
                return false
            }
        });
        var UpDownSymbol = P(MathCommand, function (_, _super) {
            _.init = function (ch, html) {
                var htmlTemplate = '<span class="mq-large-operator mq-non-leaf"><span class="mq-to" ><span>&1</span></span><span class="mq-non-leaf mq-sqrt-stem" style="border-top: 0px solid;">&0</span></span>';
                Symbol.prototype.init.call(this, ch, htmlTemplate)
            };
            _.placeCursor = function (cursor) {
                cursor.appendTo(this.firstChild).writeLatex("n=").show()
            };
            _.latex = function () {
                function simplify(latex) {
                    return latex.length === 1 ? latex : "{" + (latex || " ") + "}"
                }

                return this.ctrlSeq + " " + simplify(this.firstChild.latex()) + "\\limits^" + simplify(this.lastChild.latex())
            };
            _.parser = function () {
                var string = Parser.string;
                var optWhitespace = Parser.optWhitespace;
                var succeed = Parser.succeed;
                var block = latexMathParser.block;
                var self = this;
                var blocks = self.blocks = [MathBlock(), MathBlock()];
                for (var i = 0; i < blocks.length; i += 1) {
                    blocks[i].adopt(self, self.lastChild, 0)
                }
                return optWhitespace.then(string("_").or(string("^"))).then(function (supOrSub) {
                    var child = blocks[supOrSub === "_" ? 0 : 1];
                    return block.then(function (block) {
                        block.children().adopt(child, child.lastChild, 0);
                        return succeed(self)
                    })
                }).many().result(self)
            };
            _.finalizeTree = function () {
                this.down = this.firstChild;
                this.firstChild.up = insertAfterUnlessAtBeginning;
                this.up = this.lastChild;
                this.lastChild.down = insertAfterUnlessAtBeginning
            };
            function insertAfterUnlessAtBeginning(cursor) {
                var cmd = this.parent, ancestorCmd = cursor;
                do {
                    if (ancestorCmd.prev) {
                        cursor.insertAfter(cmd);
                        return false
                    }
                    ancestorCmd = ancestorCmd.parent.parent
                } while (ancestorCmd !== cmd);
                cursor.insertBefore(cmd);
                return false
            }
        });
        LatexCmds.lim = bind(VBigSymbol, "\\lim ", "lim");
        LatexCmds["\u2211"] = LatexCmds.sum = LatexCmds.summation = LatexCmds.Sigma = bind(BigSymbol, "\\sum ", "&sum;");
        LatexCmds["\u220F"] = LatexCmds.prod = LatexCmds.product = LatexCmds.Pi = bind(BigSymbol, "\\prod ", "&prod;");
        LatexCmds.widehat = bind(DownSymbol, "\\widehat", "&#8994;");
        LatexCmds.overset = bind(DownSymbol, "\\overset{\\frown}", "&#8994;");
        LatexCmds.overrightarrow = bind(DownSymbol, "\\overrightarrow", "&rarr;");
        LatexCmds.numloop = bind(DownSymbol, "\\dot", ".");
        LatexCmds.mathop = bind(UpDownSymbol, "\\mathop", "");
        var Fraction = LatexCmds.frac = LatexCmds.dfrac = LatexCmds.cfrac = LatexCmds.fraction = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\frac";
            _.htmlTemplate = '<span class="mq-fraction mq-non-leaf"><span class="mq-numerator">&0</span><span class="mq-denominator">&1</span><span style="display:inline-block;width:0;overflow:hidden">&nbsp;</span></span>';
            _.textTemplate = ["(", "/", ")"];
            _.finalizeTree = function () {
                this.up = this.lastChild.up = this.firstChild;
                this.down = this.firstChild.down = this.lastChild
            };
            _.expectedCursorYNextTo = function (clientRect) {
                return clientRect.elById(this.jQ[0].lastChild, this.id + 0.5).top
            }
        });
        var ExpGroup = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\expgroup";
            _.htmlTemplate = '<span class="ignore" style="-webkit-transform: scale(1.17, 1.9425000000000001);">{</span><span class="mq-fraction mq-non-leaf"><span class="mq-numerator">&0</span><span class="mq-denominator">&1</span><span style="display:inline-block;width:0;overflow:hidden">&nbsp;</span></span>';
            _.textTemplate = ["(", "/", ")"];
            _.finalizeTree = function () {
                this.up = this.lastChild.up = this.firstChild;
                this.down = this.firstChild.down = this.lastChild
            };
            _.expectedCursorYNextTo = function (clientRect) {
                return clientRect.elById(this.jQ[0].lastChild, this.id + 0.5).top
            };
            _.latex = function () {
                function simplify(latex) {
                    return latex.length === 1 ? latex : "{" + (latex || " ") + "}"
                }

                return "\\left\\{\\begin{array}" + this.firstChild.latex() + "\\\\" + this.lastChild.latex() + "\\end{array}\\right."
            }
        });
        var ExpImg = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\expgroup";
            _.htmlTemplate = '<span ><img src="http://www.baidu.com/img/bdlogo.gif" width="270" height="129"/></span>';
            _.textTemplate = ["(", "/", ")"];
            _.finalizeTree = function () {
                this.up = this.lastChild.up = this.firstChild;
                this.down = this.firstChild.down = this.lastChild
            };
            _.expectedCursorYNextTo = function (clientRect) {
                return clientRect.elById(this.jQ[0].lastChild, this.id + 0.5).top
            };
            _.latex = function () {
                function simplify(latex) {
                    return latex.length === 1 ? latex : "{" + (latex || " ") + "}"
                }

                return "\\left\\{\\begin{array}"
            }
        });
        LatexCmds.ddgroup = P(ExpGroup, function (_, _super) {
            _.createBefore = function (cursor) {
                if (!this.replacedFragment) {
                    var prev = cursor.prev;
                    if (prev instanceof TextBlock || prev instanceof Fraction) {
                        prev = prev.prev
                    } else {
                        while (prev && !(prev instanceof BinaryOperator || prev instanceof TextBlock || prev instanceof BigSymbol || prev instanceof Fraction || prev.ctrlSeq === "," || prev.ctrlSeq === ":" || prev.ctrlSeq === "\\space ")) {
                            prev = prev.prev
                        }
                        if (prev instanceof BigSymbol && prev.next instanceof SupSub) {
                            prev = prev.next;
                            if (prev.next instanceof SupSub && prev.next.ctrlSeq != prev.ctrlSeq) {
                                prev = prev.next
                            }
                        }
                    }
                    if (prev !== cursor.prev) {
                        this.replaces(MathFragment(prev.next || cursor.parent.firstChild, cursor.prev));
                        cursor.prev = prev
                    }
                }
                _super.createBefore.call(this, cursor)
            }
        });
        var LiveFraction = LatexCmds.over = CharCmds["/"] = P(Fraction, function (_, _super) {
            _.createBefore = function (cursor) {
                if (!this.replacedFragment) {
                    var prev = cursor.prev;
                    if (prev instanceof TextBlock || prev instanceof Fraction) {
                        prev = prev.prev
                    } else {
                        while (prev && !(prev instanceof BinaryOperator || prev instanceof TextBlock || prev instanceof BigSymbol || prev instanceof Fraction || prev.ctrlSeq === "," || prev.ctrlSeq === ":" || prev.ctrlSeq === "\\space ")) {
                            prev = prev.prev
                        }
                        if (prev instanceof BigSymbol && prev.next instanceof SupSub) {
                            prev = prev.next;
                            if (prev.next instanceof SupSub && prev.next.ctrlSeq != prev.ctrlSeq) {
                                prev = prev.next
                            }
                        }
                    }
                    if (prev !== cursor.prev) {
                        this.replaces(MathFragment(prev.next || cursor.parent.firstChild, cursor.prev));
                        cursor.prev = prev
                    }
                }
                _super.createBefore.call(this, cursor)
            }
        });
        var SquareRoot = LatexCmds.sqrt = LatexCmds["√"] = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\sqrt";
            _.htmlTemplate = '<span class="mq-non-leaf"><span class="mq-scaled mq-sqrt-prefix">&radic;</span><span class="mq-non-leaf mq-sqrt-stem">&0</span></span>';
            _.textTemplate = ["sqrt(", ")"];
            _.parser = function () {
                return latexMathParser.optBlock.then(function (optBlock) {
                    return latexMathParser.block.map(function (block) {
                        var nthroot = NthRoot();
                        nthroot.blocks = [optBlock, block];
                        optBlock.adopt(nthroot, 0, 0);
                        block.adopt(nthroot, optBlock, 0);
                        return nthroot
                    })
                }).or(_super.parser.call(this))
            };
            _.redraw = function () {
                var block = this.lastChild.jQ;
                scale(block.prev(), 1, block.innerHeight() / +block.css("fontSize").slice(0, -2) - 0.1)
            }
        });
        var NthRoot = LatexCmds.nthroot = P(SquareRoot, function (_, _super) {
            _.htmlTemplate = '<sup class="mq-nthroot mq-non-leaf">&0</sup><span class="mq-scaled"><span class="mq-sqrt-prefix mq-scaled">&radic;</span><span class="mq-sqrt-stem mq-non-leaf">&1</span></span>';
            _.textTemplate = ["sqrt[", "](", ")"];
            _.latex = function () {
                return "\\sqrt[" + this.firstChild.latex() + "]{" + this.lastChild.latex() + "}"
            };
            _.onKey = function (key, e) {
                if (this.getCursor().parent.parent !== this) {
                    return
                }
                switch (key) {
                    case"Right":
                        if (this.getCursor().next) {
                            return
                        }
                    case"Tab":
                        if (this.getCursor().parent === this.firstChild) {
                            this.getCursor().prepareMove().prependTo(this.lastChild);
                            e.preventDefault();
                            return false
                        }
                        break;
                    case"Left":
                        if (this.getCursor().prev) {
                            return
                        }
                    case"Shift-Tab":
                        if (this.getCursor().parent === this.lastChild) {
                            this.getCursor().prepareMove().appendTo(this.firstChild);
                            e.preventDefault();
                            return false
                        }
                }
            };
            _.getCursor = SupSub.prototype.getCursor;
            _.expectedCursorYNextTo = function (clientRect) {
                return clientRect.elById(this.jQ[0], this.id + 0.5).bottom
            }
        });
        var Bracket = P(MathCommand, function (_, _super) {
            _.init = function (open, close, ctrlSeq, end) {
                _super.init.call(this, "\\left" + ctrlSeq, '<span class="mq-non-leaf"><span class="mq-scaled mq-paren">' + open + '</span><span class="mq-non-leaf">&0</span><span class="mq-scaled mq-paren">' + close + "</span></span>", [open, close]);
                this.end = "\\right" + end
            };
            _.jQadd = function () {
                _super.jQadd.apply(this, arguments);
                var jQ = this.jQ;
                this.bracketjQs = jQ.children(":first").add(jQ.children(":last"))
            };
            _.finalizeTree = function () {
                if (this.firstChild.isEmpty() && this.next) {
                    var nextAll = MathFragment(this.next, this.parent.lastChild).disown();
                    nextAll.adopt(this.firstChild, 0, 0);
                    nextAll.jQ.appendTo(this.firstChild.jQ)
                }
            };
            _.placeCursor = function (cursor) {
                cursor.prependTo(this.firstChild)
            };
            _.latex = function () {
                return this.ctrlSeq + this.firstChild.latex() + this.end
            };
            _.redraw = function () {
                var blockjQ = this.firstChild.jQ;
                var height = blockjQ.outerHeight() / +blockjQ.css("fontSize").slice(0, -2);
                scale(this.bracketjQs, min(1 + 0.2 * (height - 1), 1.2), 1.05 * height)
            }
        });
        LatexCmds.left = P(MathCommand, function (_) {
            _.parser = function () {
                var regex = Parser.regex;
                var string = Parser.string;
                var regex = Parser.regex;
                var succeed = Parser.succeed;
                var block = latexMathParser.block;
                var optWhitespace = Parser.optWhitespace;
                return optWhitespace.then(regex(/^(?:[([|]|\\\{)/)).then(function (open) {
                    if (open.charAt(0) === "\\") {
                        open = open.slice(1)
                    }
                    var cmd = CharCmds[open]();
                    return latexMathParser.map(function (block) {
                        cmd.blocks = [block];
                        block.adopt(cmd, 0, 0)
                    }).then(string("\\right")).skip(optWhitespace).then(regex(/^(?:[\])|]|\\\})/)).then(function (close) {
                        return succeed(cmd)
                    })
                })
            }
        });
        LatexCmds.right = P(MathCommand, function (_) {
            _.parser = function () {
                return Parser.fail("unmatched \\right")
            }
        });
        LatexCmds.lbrace = CharCmds["{"] = bind(Bracket, "{", "}", "\\{", "\\}");
        LatexCmds.langle = LatexCmds.lang = bind(Bracket, "&lang;", "&rang;", "\\langle ", "\\rangle ");
        var CloseBracket = P(Bracket, function (_, _super) {
            _.createBefore = function (cursor) {
                if (this.replacedFragment) {
                    return _super.createBefore.call(this, cursor)
                }
                var openParen = cursor.parent.parent;
                if (openParen.ctrlSeq === this.ctrlSeq) {
                    if (cursor.next) {
                        var nextAll = MathFragment(cursor.next, openParen.firstChild.lastChild).disown();
                        nextAll.adopt(openParen.parent, openParen, openParen.next);
                        nextAll.jQ.insertAfter(openParen.jQ);
                        if (cursor.next.respace) {
                            cursor.next.respace()
                        }
                    }
                    cursor.insertAfter(openParen);
                    openParen.bubble("redraw")
                } else {
                    _super.createBefore.call(this, cursor);
                    cursor.appendTo(this.firstChild)
                }
            };
            _.finalizeTree = noop;
            _.placeCursor = function (cursor) {
                this.firstChild.blur();
                cursor.insertAfter(this)
            }
        });
        LatexCmds.rbrace = CharCmds["}"] = bind(CloseBracket, "{", "}", "\\{", "\\}");
        LatexCmds.rangle = LatexCmds.rang = bind(CloseBracket, "&lang;", "&rang;", "\\langle ", "\\rangle ");
        var parenMixin = function (_, _super) {
            _.init = function (open, close) {
                _super.init.call(this, open, close, open, close)
            }
        };
        var Paren = P(Bracket, parenMixin);
        LatexCmds.lparen = CharCmds["("] = bind(Paren, "(", ")");
        LatexCmds.lbrack = LatexCmds.lbracket = CharCmds["["] = bind(Paren, "[", "]");
        var CloseParen = P(CloseBracket, parenMixin);
        LatexCmds.rparen = CharCmds[")"] = bind(CloseParen, "(", ")");
        LatexCmds.rbrack = LatexCmds.rbracket = CharCmds["]"] = bind(CloseParen, "[", "]");
        var Pipes = LatexCmds.lpipe = LatexCmds.rpipe = CharCmds["|"] = P(Paren, function (_, _super) {
            _.init = function () {
                _super.init.call(this, "|", "|")
            };
            _.createBefore = function (cursor) {
                if (!cursor.next && cursor.parent.parent && cursor.parent.parent.end === this.end && !this.replacedFragment) {
                    cursor.insertAfter(cursor.parent.parent)
                } else {
                    MathCommand.prototype.createBefore.call(this, cursor)
                }
            };
            _.finalizeTree = noop
        });
        var TextBlock = LatexCmds.text = LatexCmds.textnormal = LatexCmds.textrm = LatexCmds.textup = LatexCmds.textmd = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\text";
            _.htmlTemplate = '<span class="mq-text">&0</span>';
            _.replaces = function (replacedText) {
                if (replacedText instanceof MathFragment) {
                    this.replacedText = replacedText.remove().jQ.text()
                } else {
                    if (typeof replacedText === "string") {
                        this.replacedText = replacedText
                    }
                }
            };
            _.textTemplate = ['"', '"'];
            _.parser = function () {
                var string = Parser.string;
                var regex = Parser.regex;
                var optWhitespace = Parser.optWhitespace;
                return optWhitespace.then(string("{")).then(regex(/^[^}]*/)).skip(string("}")).map(function (text) {
                    var cmd = TextBlock();
                    cmd.createBlocks();
                    var block = cmd.firstChild;
                    for (var i = 0; i < text.length; i += 1) {
                        var ch = VanillaSymbol(text.charAt(i));
                        ch.adopt(block, block.lastChild, 0)
                    }
                    return cmd
                })
            };
            _.createBlocks = function () {
                this.firstChild = this.lastChild = InnerTextBlock();
                this.blocks = [this.firstChild];
                this.firstChild.parent = this
            };
            _.finalizeInsert = function () {
                this.firstChild.blur = function () {
                    delete this.blur;
                    return this
                };
                _super.finalizeInsert.call(this)
            };
            _.createBefore = function (cursor) {
                _super.createBefore.call(this, this.cursor = cursor);
                if (this.replacedText) {
                    for (var i = 0; i < this.replacedText.length; i += 1) {
                        this.write(this.replacedText.charAt(i))
                    }
                }
            };
            _.write = function (ch) {
                this.cursor.insertNew(VanillaSymbol(ch))
            };
            _.onKey = function (key, e) {
                if (!this.cursor.selection && ((key === "Backspace" && !this.cursor.prev) || (key === "Del" && !this.cursor.next))) {
                    if (this.isEmpty()) {
                        this.cursor.insertAfter(this)
                    }
                    return false
                }
            };
            _.onText = function (ch) {
                this.cursor.prepareEdit();
                if (ch !== "$") {
                    this.write(ch)
                } else {
                    if (this.isEmpty()) {
                        this.cursor.insertAfter(this).backspace().insertNew(VanillaSymbol("\\$", "$"))
                    } else {
                        if (!this.cursor.next) {
                            this.cursor.insertAfter(this)
                        } else {
                            if (!this.cursor.prev) {
                                this.cursor.insertBefore(this)
                            } else {
                                var next = TextBlock(MathFragment(this.cursor.next, this.firstChild.lastChild));
                                next.placeCursor = function (cursor) {
                                    this.prev = 0;
                                    delete this.placeCursor;
                                    this.placeCursor(cursor)
                                };
                                next.firstChild.focus = function () {
                                    return this
                                };
                                this.cursor.insertAfter(this).insertNew(next);
                                next.prev = this;
                                this.cursor.insertBefore(next);
                                delete next.firstChild.focus
                            }
                        }
                    }
                }
                this.cursor.root.triggerSpecialEvent("render");
                return false
            }
        });
        var InnerTextBlock = P(MathBlock, function (_, _super) {
            _.blur = function () {
                this.jQ.removeClass("mq-hasCursor");
                if (this.isEmpty()) {
                    var textblock = this.parent, cursor = textblock.cursor;
                    if (cursor.parent === this) {
                        this.jQ.addClass("mq-empty")
                    } else {
                        cursor.hide();
                        textblock.remove();
                        if (cursor.next === textblock) {
                            cursor.next = textblock.next
                        } else {
                            if (cursor.prev === textblock) {
                                cursor.prev = textblock.prev
                            }
                        }
                        cursor.show().parent.bubble("redraw")
                    }
                }
                return this
            };
            _.focus = function () {
                _super.focus.call(this);
                var textblock = this.parent;
                if (textblock.next.ctrlSeq === textblock.ctrlSeq) {
                    var innerblock = this, cursor = textblock.cursor, next = textblock.next.firstChild;
                    next.eachChild(function (child) {
                        child.parent = innerblock;
                        child.jQ.appendTo(innerblock.jQ)
                    });
                    if (this.lastChild) {
                        this.lastChild.next = next.firstChild
                    } else {
                        this.firstChild = next.firstChild
                    }
                    next.firstChild.prev = this.lastChild;
                    this.lastChild = next.lastChild;
                    next.parent.remove();
                    if (cursor.prev) {
                        cursor.insertAfter(cursor.prev)
                    } else {
                        cursor.prependTo(this)
                    }
                    cursor.parent.bubble("redraw")
                } else {
                    if (textblock.prev.ctrlSeq === textblock.ctrlSeq) {
                        var cursor = textblock.cursor;
                        if (cursor.prev) {
                            textblock.prev.firstChild.focus()
                        } else {
                            cursor.appendTo(textblock.prev.firstChild)
                        }
                    }
                }
                return this
            }
        });

        function makeTextBlock(latex, tagName, attrs) {
            return P(TextBlock, {ctrlSeq: latex, htmlTemplate: "<" + tagName + " " + attrs + ">&0</" + tagName + ">"})
        }

        LatexCmds.em = LatexCmds.italic = LatexCmds.italics = LatexCmds.emph = LatexCmds.textit = LatexCmds.textsl = makeTextBlock("\\textit", "i", 'class="mq-text"');
        LatexCmds.strong = LatexCmds.bold = LatexCmds.textbf = makeTextBlock("\\textbf", "b", 'class="mq-text"');
        LatexCmds.sf = LatexCmds.textsf = makeTextBlock("\\textsf", "span", 'class="mq-sans-serif mq-text"');
        LatexCmds.tt = LatexCmds.texttt = makeTextBlock("\\texttt", "span", 'class="mq-monospace mq-text"');
        LatexCmds.textsc = makeTextBlock("\\textsc", "span", 'style="font-variant:small-caps" class="mq-text"');
        LatexCmds.uppercase = makeTextBlock("\\uppercase", "span", 'style="text-transform:uppercase" class="mq-text"');
        LatexCmds.lowercase = makeTextBlock("\\lowercase", "span", 'style="text-transform:lowercase" class="mq-text"');
        var LatexCommandInput = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\";
            _.replaces = function (replacedFragment) {
                this._replacedFragment = replacedFragment.disown();
                this.isEmpty = function () {
                    return false
                }
            };
            _.htmlTemplate = '<span class="mq-latex-command-input mq-non-leaf">\\<span>&0</span></span>';
            _.textTemplate = ["\\"];
            _.createBlocks = function () {
                _super.createBlocks.call(this);
                this.firstChild.focus = function () {
                    this.parent.jQ.addClass("mq-hasCursor");
                    if (this.isEmpty()) {
                        this.parent.jQ.removeClass("mq-empty")
                    }
                    return this
                };
                this.firstChild.blur = function () {
                    this.parent.jQ.removeClass("mq-hasCursor");
                    if (this.isEmpty()) {
                        this.parent.jQ.addClass("mq-empty")
                    }
                    return this
                }
            };
            _.createBefore = function (cursor) {
                _super.createBefore.call(this, cursor);
                this.cursor = cursor.appendTo(this.firstChild);
                if (this._replacedFragment) {
                    var el = this.jQ[0];
                    this.jQ = this._replacedFragment.jQ.addClass("mq-blur").bind("mousedown mousemove", function (e) {
                        $(e.target = el).trigger(e);
                        return false
                    }).insertBefore(this.jQ).add(this.jQ)
                }
            };
            _.latex = function () {
                return "\\" + this.firstChild.latex() + " "
            };
            _.onKey = function (key, e) {
                if (key === "Tab" || key === "Enter") {
                    this.renderCommand();
                    this.cursor.root.triggerSpecialEvent("render");
                    e.preventDefault();
                    return false
                }
            };
            _.onText = function (ch) {
                if (ch.match(/[a-z]/i)) {
                    this.cursor.prepareEdit();
                    this.cursor.insertNew(VanillaSymbol(ch));
                    return false
                }
                this.renderCommand();
                if (ch === " " || (ch === "\\" && this.firstChild.isEmpty())) {
                    this.cursor.root.triggerSpecialEvent("render");
                    return false
                }
            };
            _.renderCommand = function () {
                this.jQ = this.jQ.last();
                this.remove();
                if (this.next) {
                    this.cursor.insertBefore(this.next)
                } else {
                    this.cursor.appendTo(this.parent)
                }
                var latex = this.firstChild.latex(), cmd;
                if (!latex) {
                    latex = "backslash"
                }
                this.cursor.insertCmd(latex, this._replacedFragment)
            }
        });
        var Binomial = LatexCmds.binom = LatexCmds.binomial = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\binom";
            _.htmlTemplate = '<span class="mq-paren mq-scaled">(</span><span class="mq-non-leaf"><span class="mq-array mq-non-leaf"><span>&0</span><span>&1</span></span></span><span class="mq-paren mq-scaled">)</span>';
            _.textTemplate = ["choose(", ",", ")"];
            _.redraw = function () {
                var blockjQ = this.jQ.eq(1);
                var height = blockjQ.outerHeight() / +blockjQ.css("fontSize").slice(0, -2);
                var parens = this.jQ.filter(".mq-paren");
                scale(parens, min(1 + 0.2 * (height - 1), 1.2), 1.05 * height)
            };
            _.expectedCursorYNextTo = Symbol.prototype.expectedCursorYNextTo
        });
        var Choose = LatexCmds.choose = P(Binomial, function (_) {
            _.createBefore = LiveFraction.prototype.createBefore
        });
        var Vector = LatexCmds.vector = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\vector";
            _.htmlTemplate = '<span class="mq-array"><span>&0</span></span>';
            _.latex = function () {
                return "\\begin{matrix}" + this.foldChildren([], function (latex, child) {
                        latex.push(child.latex());
                        return latex
                    }).join("\\\\") + "\\end{matrix}"
            };
            _.text = function () {
                return "[" + this.foldChildren([], function (text, child) {
                        text.push(child.text());
                        return text
                    }).join() + "]"
            };
            _.createBefore = function (cursor) {
                _super.createBefore.call(this, this.cursor = cursor)
            };
            _.onKey = function (key, e) {
                var currentBlock = this.cursor.parent;
                if (currentBlock.parent === this) {
                    if (key === "Enter") {
                        var newBlock = MathBlock();
                        newBlock.parent = this;
                        newBlock.jQ = $("<span></span>").attr(mqBlockId, newBlock.id).insertAfter(currentBlock.jQ);
                        if (currentBlock.next) {
                            currentBlock.next.prev = newBlock
                        } else {
                            this.lastChild = newBlock
                        }
                        newBlock.next = currentBlock.next;
                        currentBlock.next = newBlock;
                        newBlock.prev = currentBlock;
                        this.bubble("redraw").cursor.appendTo(newBlock);
                        e.preventDefault();
                        return false
                    } else {
                        if (key === "Tab" && !currentBlock.next) {
                            if (currentBlock.isEmpty()) {
                                if (currentBlock.prev) {
                                    this.cursor.insertAfter(this);
                                    delete currentBlock.prev.next;
                                    this.lastChild = currentBlock.prev;
                                    currentBlock.jQ.remove();
                                    this.bubble("redraw");
                                    e.preventDefault();
                                    return false
                                } else {
                                    return
                                }
                            }
                            var newBlock = MathBlock();
                            newBlock.parent = this;
                            newBlock.jQ = $("<span></span>").attr(mqBlockId, newBlock.id).appendTo(this.jQ);
                            this.lastChild = newBlock;
                            currentBlock.next = newBlock;
                            newBlock.prev = currentBlock;
                            this.bubble("redraw").cursor.appendTo(newBlock);
                            e.preventDefault();
                            return false
                        } else {
                            if (e.which === 8) {
                                if (currentBlock.isEmpty()) {
                                    return false
                                } else {
                                    if (!this.cursor.prev) {
                                        e.preventDefault();
                                        return false
                                    }
                                }
                            }
                        }
                    }
                }
            };
            _.expectedCursorYNextTo = Binomial.prototype.expectedCursorYNextTo
        });
        LatexCmds.MathQuillMathField = P(MathCommand, function (_, _super) {
            _.ctrlSeq = "\\MathQuillMathField";
            _.htmlTemplate = '<span class="mathquill-editable">&0</span>';
            _.parser = function () {
                var self = this;
                var string = Parser.string, regex = Parser.regex, succeed = Parser.succeed;
                return string("[").then(regex(/^[-\w\s\\\xA0-\xFF]*/)).skip(string("]")).map(function (classnames) {
                    self.classnames = classnames
                }).or(succeed()).then(_super.parser.call(self))
            };
            _.finalizeTree = function () {
                var self = this, rootBlock = RootMathBlock();
                delete MathElement[rootBlock.id];
                rootBlock.id = self.firstChild.id;
                MathElement[rootBlock.id] = rootBlock;
                self.firstChild.children().disown().adopt(rootBlock, 0, 0);
                rootBlock.parent = self;
                self.firstChild = self.lastChild = rootBlock;
                self.blocks = [rootBlock];
                rootBlock.jQ = self.jQ.wrapInner('<span class="mathquill-root-block"/>').children();
                rootBlock.editable = true;
                var cursor = rootBlock.cursor = Cursor(rootBlock).appendTo(rootBlock);
                var textarea = setupTextarea(true, self.jQ, rootBlock, cursor);
                setupTouchHandle(true, rootBlock, cursor);
                focusBlurEvents(rootBlock, cursor, textarea);
                desmosCustomEvents(self.jQ, rootBlock, cursor);
                self.jQ.addClass(self.classnames)
            };
            _.latex = function () {
                return this.firstChild.latex()
            };
            _.text = function () {
                return this.firstChild.text()
            }
        });
        var Variable = P(Symbol, function (_, _super) {
            _.init = function (ch, html) {
                _super.init.call(this, ch, "<var>" + (html || ch) + "</var>")
            };
            _.createBefore = function (cursor) {
                var ctrlSeq = this.ctrlSeq;
                for (var i = 0, prev = cursor.prev; i < MAX_AUTOCMD_LEN - 1 && prev && prev instanceof Variable; i += 1, prev = prev.prev) {
                    ctrlSeq = prev.ctrlSeq + ctrlSeq
                }

                while (ctrlSeq.length) {
                    if (AutoCmds.hasOwnProperty(ctrlSeq)) {
                        //去除公式自动转义
                        // for (var i = 1; i < ctrlSeq.length; i += 1) {
                        //     cursor.backspace()
                        // }
                        // cursor.insertNew(LatexCmds[ctrlSeq](ctrlSeq));
                        // return
                    }
                    ctrlSeq = ctrlSeq.slice(1)
                }
                _super.createBefore.apply(this, arguments)
            };
            _.respace = _.finalizeTree = function () {
                var ctrlSeq = this.ctrlSeq;
                if (ctrlSeq.length > 1) {
                    return
                }
                for (var prev = this.prev; prev instanceof Variable && prev.ctrlSeq.length === 1; prev = prev.prev) {
                    ctrlSeq = prev.ctrlSeq + ctrlSeq
                }
                for (var next = this.next; next instanceof Variable && next.ctrlSeq.length === 1; next = next.next) {
                    ctrlSeq += next.ctrlSeq
                }
                MathFragment(prev.next || this.parent.firstChild, next.prev || this.parent.lastChild).each(function (el) {
                    el.jQ.removeClass("mq-un-italicized mq-last");
                    delete el.isFirstLetter;
                    delete el.isLastLetter
                });
                outer:for (var i = 0, first = prev.next || this.parent.firstChild; i < ctrlSeq.length; i += 1, first = first.next) {
                    for (var len = min(MAX_UNITALICIZED_LEN, ctrlSeq.length - i); len > 0; len -= 1) {
                        for (var j = 0, letter = first; j < len; j += 1, letter = letter.next) {
                            letter.jQ.addClass("mq-un-italicized");
                        }

                        continue outer
                    }
                }
            };
            _.latex = function () {
                return (this.isFirstLetter ? "\\" + this.ctrlSeq : this.isLastLetter ? this.ctrlSeq + " " : this.ctrlSeq)
            };
            _.text = function () {
                var text = this.ctrlSeq;
                if (this.prev && !(this.prev instanceof Variable) && !(this.prev instanceof BinaryOperator)) {
                    text = "*" + text
                }
                if (this.next && !(this.next instanceof BinaryOperator) && !(this.next.ctrlSeq === "^")) {
                    text += "*"
                }
                return text
            }
        });
        var UnItalicized = P(Symbol, function (_, _super) {
            _.init = function (fn) {
                this.ctrlSeq = fn
            };
            _.createBefore = function (cursor) {
                cursor.writeLatex(this.ctrlSeq).show()
            };
            _.parser = function () {
                var fn = this.ctrlSeq;
                var block = MathBlock();
                for (var i = 0; i < fn.length; i += 1) {
                    Variable(fn.charAt(i)).adopt(block, block.lastChild, 0)
                }
                return Parser.succeed(block.children())
            }
        });
        var UnItalicizedCmds = {
            mean: 1,
            ln: 1,
            log: 1,
            min: 1,
            nCr: 1,
            nPr: 1,
            gcd: 1,
            lcm: 1,
            mcm: 1,
            mcd: 1,
            ceil: 1,
            exp: 1,
            abs: 1,
            max: 1,
            mod: 1,
            gcf: 1,
            exp: 1,
            floor: 1,
            sign: 1,
            signum: 1,
            round: 1
        }, MAX_UNITALICIZED_LEN = 9, AutoCmds = {sqrt: 1, nthroot: 1, sum: 1, prod: 1, pi: 1, Pi: 1, phi: 1, Sigma: 1, tau: 1, Gamma: 1, theta: 1}, MAX_AUTOCMD_LEN = 7;
        (function () {
            var trigs = {sin: 1, cos: 1, tan: 1, sec: 1, cosec: 1, csc: 1, cotan: 1, cot: 1, ctg: 1};
            for (var trig in trigs) {
                UnItalicizedCmds[trig] = UnItalicizedCmds["arc" + trig] = UnItalicizedCmds[trig + "h"] = UnItalicizedCmds["arc" + trig + "h"] = 1
            }
            for (var fn in UnItalicizedCmds) {
                LatexCmds[fn] = UnItalicized
            }
        }());
        var VanillaSymbol = P(Symbol, function (_, _super) {
            _.init = function (ch, html) {
                _super.init.call(this, ch, "<span>" + (html || ch) + "</span>")
            }
        });
        CharCmds[" "] = bind(VanillaSymbol, "\\space ", " ");
        LatexCmds.prime = CharCmds["'"] = bind(VanillaSymbol, "'", "&prime;");
        var NonSymbolaSymbol = P(Symbol, function (_, _super) {
            _.init = function (ch, html) {
                _super.init.call(this, ch, '<span class="mq-nonSymbola">' + (html || ch) + "</span>")
            }
        });
        LatexCmds["@"] = NonSymbolaSymbol;
        LatexCmds["&"] = bind(NonSymbolaSymbol, "\\&", "&amp;");
        LatexCmds["%"] = bind(NonSymbolaSymbol, "\\%", "%");
        LatexCmds.alpha = LatexCmds.beta = LatexCmds.gamma = LatexCmds.delta = LatexCmds.zeta = LatexCmds.eta = LatexCmds.theta = LatexCmds.iota = LatexCmds.kappa = LatexCmds.mu = LatexCmds.nu = LatexCmds.xi = LatexCmds.rho = LatexCmds.sigma = LatexCmds.tau = LatexCmds.chi = LatexCmds.psi = LatexCmds.omega = P(Variable, function (_, _super) {
            _.init = function (latex) {
                _super.init.call(this, "\\" + latex + " ", "&" + latex + ";")
            }
        });
        LatexCmds.phi = bind(Variable, "\\phi ", "&#981;");
        LatexCmds.phiv = LatexCmds.varphi = bind(Variable, "\\varphi ", "&phi;");
        LatexCmds.epsilon = bind(Variable, "\\epsilon ", "&#1013;");
        LatexCmds.epsiv = LatexCmds.varepsilon = bind(Variable, "\\varepsilon ", "&epsilon;");
        LatexCmds.piv = LatexCmds.varpi = bind(Variable, "\\varpi ", "&piv;");
        LatexCmds.sigmaf = LatexCmds.sigmav = LatexCmds.varsigma = bind(Variable, "\\varsigma ", "&sigmaf;");
        LatexCmds.thetav = LatexCmds.vartheta = LatexCmds.thetasym = bind(Variable, "\\vartheta ", "&thetasym;");
        LatexCmds.upsilon = LatexCmds.upsi = bind(Variable, "\\upsilon ", "&upsilon;");
        LatexCmds.gammad = LatexCmds.Gammad = LatexCmds.digamma = bind(Variable, "\\digamma ", "&#989;");
        LatexCmds.kappav = LatexCmds.varkappa = bind(Variable, "\\varkappa ", "&#1008;");
        LatexCmds.rhov = LatexCmds.varrho = bind(Variable, "\\varrho ", "&#1009;");
        LatexCmds.pi = LatexCmds["\u03C0"] = bind(NonSymbolaSymbol, "\\pi ", "&pi;");
        LatexCmds.theta = LatexCmds["\u03B8"] = bind(NonSymbolaSymbol, "\\theta ", "&theta;");
        LatexCmds.lambda = bind(NonSymbolaSymbol, "\\lambda ", "&lambda;");
        LatexCmds.Upsilon = LatexCmds.Upsi = LatexCmds.upsih = LatexCmds.Upsih = bind(Symbol, "\\Upsilon ", '<var style="font-family: serif">&upsih;</var>');
        LatexCmds.Gamma = LatexCmds.Delta = LatexCmds.Theta = LatexCmds.Lambda = LatexCmds.Xi = LatexCmds.Phi = LatexCmds.Psi = LatexCmds.Omega = LatexCmds.forall = P(VanillaSymbol, function (_, _super) {
            _.init = function (latex) {
                _super.init.call(this, "\\" + latex + " ", "&" + latex + ";")
            }
        });
        var LatexFragment = P(MathCommand, function (_) {
            _.init = function (latex) {
                this.latex = latex
            };
            _.createBefore = function (cursor) {
                cursor.writeLatex(this.latex)
            };
            _.parser = function () {
                var frag = latexMathParser.parse(this.latex).children();
                return Parser.succeed(frag)
            }
        });
        LatexCmds["\u00b9"] = bind(LatexFragment, "^1");
        LatexCmds["\u00b2"] = bind(LatexFragment, "^2");
        LatexCmds["\u00b3"] = bind(LatexFragment, "^3");
        LatexCmds["\u00bc"] = bind(LatexFragment, "\\frac14");
        LatexCmds["\u00bd"] = bind(LatexFragment, "\\frac12");
        LatexCmds["\u00be"] = bind(LatexFragment, "\\frac34");
        LatexCmds["\u2152"] = bind(LatexFragment, "\\frac{1}{10}");
        LatexCmds["\u2153"] = bind(LatexFragment, "\\frac13");
        LatexCmds["\u2154"] = bind(LatexFragment, "\\frac23");
        var BinaryOperator = P(Symbol, function (_, _super) {
            _.init = function (ctrlSeq, html, text) {
                _super.init.call(this, ctrlSeq, '<span class="mq-binary-operator">' + html + "</span>", text)
            };
            _.createBefore = function (cursor) {
                var ctrlSeq = cursor.prev.ctrlSeq + this.ctrlSeq;
                if (ctrlSeq === "<=") {
                    cursor.backspace().insertNew(BinaryOperator("\\le ", "&le;"))
                } else {
                    if (ctrlSeq === ">=") {
                        cursor.backspace().insertNew(BinaryOperator("\\ge ", "&ge;"))
                    } else {
                        _super.createBefore.apply(this, arguments)
                    }
                }
            }
        });
        var ImgOperator = P(Symbol, function (_, _super) {
            _.init = function (ctrlSeq, imgsrc, text) {
                _super.init.call(this, ctrlSeq, '<span style="vertical-align:middle;" ><img src="' + imgsrc + '" width="20" height="24"/></span>', text)
            };
            _.createBefore = function (cursor) {
                var ctrlSeq = cursor.prev.ctrlSeq + this.ctrlSeq;
                if (ctrlSeq === "<=") {
                    cursor.backspace().insertNew(BinaryOperator("\\le ", "&le;"))
                } else {
                    if (ctrlSeq === ">=") {
                        cursor.backspace().insertNew(BinaryOperator("\\ge ", "&ge;"))
                    } else {
                        _super.createBefore.apply(this, arguments)
                    }
                }
            }
        });
        var PlusMinus = P(BinaryOperator, function (_) {
            _.init = VanillaSymbol.prototype.init;
            _.respace = function () {
                if (!this.prev) {
                    this.jQ[0].className = ""
                } else {
                    if (this.prev instanceof BinaryOperator && this.next && !(this.next instanceof BinaryOperator)) {
                        this.jQ[0].className = "mq-unary-operator"
                    } else {
                        this.jQ[0].className = "mq-binary-operator"
                    }
                }
                return this
            }
        });
        LatexCmds["+"] = bind(PlusMinus, "+", "+");
        LatexCmds["\u2013"] = LatexCmds["\u2212"] = LatexCmds["-"] = bind(PlusMinus, "-", "&minus;");
        LatexCmds["\u00B1"] = LatexCmds.pm = LatexCmds.plusmn = LatexCmds.plusminus = bind(PlusMinus, "\\pm ", "&plusmn;");
        LatexCmds.mp = LatexCmds.mnplus = LatexCmds.minusplus = bind(ImgOperator, "\\mp ", "img/mp.png");
        CharCmds["*"] = LatexCmds.sdot = LatexCmds.cdot = bind(BinaryOperator, "\\cdot ", "&middot;");
        LatexCmds["="] = bind(BinaryOperator, "=", "=");
        LatexCmds["<"] = bind(BinaryOperator, "<", "&lt;");
        LatexCmds[">"] = bind(BinaryOperator, ">", "&gt;");
        LatexCmds.intt = bind(BinaryOperator, "\\int", "&int;");
        LatexCmds.varsubsetneq = LatexCmds.notin = LatexCmds.sim = LatexCmds.cong = LatexCmds.equiv = LatexCmds.oplus = LatexCmds.otimes = P(BinaryOperator, function (_, _super) {
            _.init = function (latex) {
                _super.init.call(this, "\\" + latex + " ", "&" + latex + ";")
            }
        });
        LatexCmds.times = bind(BinaryOperator, "\\times ", "&times;", "[x]");
        LatexCmds["\u00F7"] = LatexCmds.div = LatexCmds.divide = LatexCmds.divides = bind(BinaryOperator, "\\div ", "&divide;", "[/]");
        LatexCmds["\u2260"] = LatexCmds.ne = LatexCmds.neq = bind(BinaryOperator, "\\ne ", "&ne;");
        LatexCmds.ast = LatexCmds.star = LatexCmds.loast = LatexCmds.lowast = bind(BinaryOperator, "\\ast ", "&lowast;");
        LatexCmds.therefor = LatexCmds.therefore = bind(BinaryOperator, "\\therefore ", "&there4;");
        LatexCmds.cuz = LatexCmds.because = bind(BinaryOperator, "\\because ", "&#8757;");
        LatexCmds.prop = LatexCmds.propto = bind(BinaryOperator, "\\propto ", "&prop;");
        LatexCmds["\u2248"] = LatexCmds.asymp = LatexCmds.approx = bind(BinaryOperator, "\\approx ", "&asymp;");
        LatexCmds.lt = bind(BinaryOperator, "<", "&lt;");
        LatexCmds.gt = bind(BinaryOperator, ">", "&gt;");
        LatexCmds["\u2264"] = LatexCmds.le = LatexCmds.leq = bind(BinaryOperator, "\\le ", "&le;");
        LatexCmds["\u2265"] = LatexCmds.ge = LatexCmds.geq = bind(BinaryOperator, "\\ge ", "&ge;");
        LatexCmds.isin = LatexCmds["in"] = bind(BinaryOperator, "\\in ", "&isin;");
        LatexCmds.ni = LatexCmds.contains = bind(BinaryOperator, "\\ni ", "&ni;");
        LatexCmds.notni = LatexCmds.niton = LatexCmds.notcontains = LatexCmds.doesnotcontain = bind(BinaryOperator, "\\not\\ni ", "&#8716;");
        LatexCmds.sub = LatexCmds.subset = bind(BinaryOperator, "\\subset ", "&sub;");
        LatexCmds.sup = LatexCmds.supset = LatexCmds.superset = bind(BinaryOperator, "\\supset ", "&sup;");
        LatexCmds.nsub = LatexCmds.notsub = LatexCmds.nsubset = LatexCmds.notsubset = bind(BinaryOperator, "\\not\\subset ", "&#8836;");
        LatexCmds.nsup = LatexCmds.notsup = LatexCmds.nsupset = LatexCmds.notsupset = LatexCmds.nsuperset = LatexCmds.notsuperset = bind(BinaryOperator, "\\not\\supset ", "&#8837;");
        LatexCmds.sube = LatexCmds.subeq = LatexCmds.subsete = LatexCmds.subseteq = bind(BinaryOperator, "\\subseteq ", "&sube;");
        LatexCmds.supe = LatexCmds.supeq = LatexCmds.supsete = LatexCmds.supseteq = LatexCmds.supersete = LatexCmds.superseteq = bind(BinaryOperator, "\\supseteq ", "&supe;");
        LatexCmds.nsube = LatexCmds.nsubeq = LatexCmds.notsube = LatexCmds.notsubeq = LatexCmds.nsubsete = LatexCmds.nsubseteq = LatexCmds.notsubsete = LatexCmds.notsubseteq = bind(ImgOperator, "\\not\\subseteq ", "img/nsubseteq.png");
        LatexCmds.subsetneqq = bind(ImgOperator, "\\subsetneqq ", "img/subsetneqq.png");
        LatexCmds.supsetneqq = bind(ImgOperator, "\\supsetneqq ", "img/supsetneqq.png");
        LatexCmds.complement = bind(ImgOperator, "\\complement ", "img/complement.png");
        LatexCmds.nsupe = LatexCmds.nsupeq = LatexCmds.notsupe = LatexCmds.notsupeq = LatexCmds.nsupsete = LatexCmds.nsupseteq = LatexCmds.notsupsete = LatexCmds.notsupseteq = LatexCmds.nsupersete = LatexCmds.nsuperseteq = LatexCmds.notsupersete = LatexCmds.notsuperseteq = bind(BinaryOperator, "\\not\\supseteq ", "&#8841;");
        LatexCmds.naturals = LatexCmds.Naturals = bind(VanillaSymbol, "\\mathbb{N}", "&#8469;");
        LatexCmds.primes = LatexCmds.Primes = LatexCmds.projective = LatexCmds.Projective = LatexCmds.probability = LatexCmds.Probability = bind(VanillaSymbol, "\\mathbb{P}", "&#8473;");
        LatexCmds.integers = LatexCmds.Integers = bind(VanillaSymbol, "\\mathbb{Z}", "&#8484;");
        LatexCmds.rationals = LatexCmds.Rationals = bind(VanillaSymbol, "\\mathbb{Q}", "&#8474;");
        LatexCmds.reals = LatexCmds.Reals = bind(VanillaSymbol, "\\mathbb{R}", "&#8477;");
        LatexCmds.complex = LatexCmds.Complex = LatexCmds.complexes = LatexCmds.Complexes = LatexCmds.complexplane = LatexCmds.Complexplane = LatexCmds.ComplexPlane = bind(VanillaSymbol, "\\mathbb{C}", "&#8450;");
        LatexCmds.quad = LatexCmds.emsp = bind(VanillaSymbol, "\\quad ", "    ");
        LatexCmds.qquad = bind(VanillaSymbol, "\\qquad ", "        ");
        LatexCmds.diamond = bind(VanillaSymbol, "\\diamond ", "&#9671;");
        LatexCmds.bigtriangleup = bind(VanillaSymbol, "\\bigtriangleup ", "&#9651;");
        LatexCmds.ominus = bind(VanillaSymbol, "\\ominus ", "&#8854;");
        LatexCmds.uplus = bind(VanillaSymbol, "\\uplus ", "&#8846;");
        LatexCmds.bigtriangledown = bind(VanillaSymbol, "\\bigtriangledown ", "&#9661;");
        LatexCmds.sqcap = bind(VanillaSymbol, "\\sqcap ", "&#8851;");
        LatexCmds.triangleleft = bind(VanillaSymbol, "\\triangleleft ", "&#8882;");
        LatexCmds.sqcup = bind(VanillaSymbol, "\\sqcup ", "&#8852;");
        LatexCmds.triangleright = bind(VanillaSymbol, "\\triangleright ", "&#8883;");
        LatexCmds.odot = bind(VanillaSymbol, "\\odot ", "&#8857;");
        LatexCmds.bigcirc = bind(VanillaSymbol, "\\bigcirc ", "&#9711;");
        LatexCmds.dagger = bind(VanillaSymbol, "\\dagger ", "&#0134;");
        LatexCmds.ddagger = bind(VanillaSymbol, "\\ddagger ", "&#135;");
        LatexCmds.wr = bind(VanillaSymbol, "\\wr ", "&#8768;");
        LatexCmds.amalg = bind(VanillaSymbol, "\\amalg ", "&#8720;");
        LatexCmds.models = bind(VanillaSymbol, "\\models ", "&#8872;");
        LatexCmds.prec = bind(VanillaSymbol, "\\prec ", "&#8826;");
        LatexCmds.succ = bind(VanillaSymbol, "\\succ ", "&#8827;");
        LatexCmds.preceq = bind(VanillaSymbol, "\\preceq ", "&#8828;");
        LatexCmds.succeq = bind(VanillaSymbol, "\\succeq ", "&#8829;");
        LatexCmds.simeq = bind(VanillaSymbol, "\\simeq ", "&#8771;");
        LatexCmds.mid = bind(VanillaSymbol, "\\mid ", "&#8739;");
        LatexCmds.ll = bind(VanillaSymbol, "\\ll ", "&#8810;");
        LatexCmds.gg = bind(VanillaSymbol, "\\gg ", "&#8811;");
        LatexCmds.parallel = bind(VanillaSymbol, "\\parallel ", "&#8741;");
        LatexCmds.bowtie = bind(VanillaSymbol, "\\bowtie ", "&#8904;");
        LatexCmds.sqsubset = bind(VanillaSymbol, "\\sqsubset ", "&#8847;");
        LatexCmds.sqsupset = bind(VanillaSymbol, "\\sqsupset ", "&#8848;");
        LatexCmds.smile = bind(VanillaSymbol, "\\smile ", "&#8995;");
        LatexCmds.sqsubseteq = bind(VanillaSymbol, "\\sqsubseteq ", "&#8849;");
        LatexCmds.sqsupseteq = bind(VanillaSymbol, "\\sqsupseteq ", "&#8850;");
        LatexCmds.doteq = bind(VanillaSymbol, "\\doteq ", "&#8784;");
        LatexCmds.frown = bind(VanillaSymbol, "\\frown ", "&#8994;");
        LatexCmds.vdash = bind(VanillaSymbol, "\\vdash ", "&#8870;");
        LatexCmds.dashv = bind(VanillaSymbol, "\\dashv ", "&#8867;");
        LatexCmds.longleftarrow = bind(VanillaSymbol, "\\longleftarrow ", "&#8592;");
        LatexCmds.longrightarrow = bind(VanillaSymbol, "\\longrightarrow ", "&#8594;");
        LatexCmds.Longleftarrow = bind(VanillaSymbol, "\\Longleftarrow ", "&#8656;");
        LatexCmds.Longrightarrow = bind(VanillaSymbol, "\\Longrightarrow ", "&#8658;");
        LatexCmds.longleftrightarrow = bind(VanillaSymbol, "\\longleftrightarrow ", "&#8596;");
        LatexCmds.updownarrow = bind(VanillaSymbol, "\\updownarrow ", "&#8597;");
        LatexCmds.Longleftrightarrow = bind(VanillaSymbol, "\\Longleftrightarrow ", "&#8660;");
        LatexCmds.Updownarrow = bind(VanillaSymbol, "\\Updownarrow ", "&#8661;");
        LatexCmds.mapsto = bind(VanillaSymbol, "\\mapsto ", "&#8614;");
        LatexCmds.nearrow = bind(VanillaSymbol, "\\nearrow ", "&#8599;");
        LatexCmds.hookleftarrow = bind(VanillaSymbol, "\\hookleftarrow ", "&#8617;");
        LatexCmds.hookrightarrow = bind(VanillaSymbol, "\\hookrightarrow ", "&#8618;");
        LatexCmds.searrow = bind(VanillaSymbol, "\\searrow ", "&#8600;");
        LatexCmds.leftharpoonup = bind(VanillaSymbol, "\\leftharpoonup ", "&#8636;");
        LatexCmds.rightharpoonup = bind(VanillaSymbol, "\\rightharpoonup ", "&#8640;");
        LatexCmds.swarrow = bind(VanillaSymbol, "\\swarrow ", "&#8601;");
        LatexCmds.leftharpoondown = bind(VanillaSymbol, "\\leftharpoondown ", "&#8637;");
        LatexCmds.rightharpoondown = bind(VanillaSymbol, "\\rightharpoondown ", "&#8641;");
        LatexCmds.nwarrow = bind(VanillaSymbol, "\\nwarrow ", "&#8598;");
        LatexCmds.space = bind(VanillaSymbol, "\\space ", "&nbsp;");
        LatexCmds.ldots = bind(VanillaSymbol, "\\ldots ", "&#8230;");
        LatexCmds.cdots = bind(VanillaSymbol, "\\cdots ", "&#8943;");
        LatexCmds.vdots = bind(VanillaSymbol, "\\vdots ", "&#8942;");
        LatexCmds.ddots = bind(VanillaSymbol, "\\ddots ", "&#8944;");
        LatexCmds.surd = bind(VanillaSymbol, "\\surd ", "&#8730;");
        LatexCmds.triangle = bind(VanillaSymbol, "\\triangle ", "&#9653;");
        LatexCmds.ell = bind(VanillaSymbol, "\\ell ", "&#8467;");
        LatexCmds.top = bind(VanillaSymbol, "\\top ", "&#8868;");
        LatexCmds.flat = bind(VanillaSymbol, "\\flat ", "&#9837;");
        LatexCmds.natural = bind(VanillaSymbol, "\\natural ", "&#9838;");
        LatexCmds.sharp = bind(VanillaSymbol, "\\sharp ", "&#9839;");
        LatexCmds.wp = bind(VanillaSymbol, "\\wp ", "&#8472;");
        LatexCmds.bot = bind(VanillaSymbol, "\\bot ", "&#8869;");
        LatexCmds.clubsuit = bind(VanillaSymbol, "\\clubsuit ", "&#9827;");
        LatexCmds.diamondsuit = bind(VanillaSymbol, "\\diamondsuit ", "&#9826;");
        LatexCmds.heartsuit = bind(VanillaSymbol, "\\heartsuit ", "&#9825;");
        LatexCmds.spadesuit = bind(VanillaSymbol, "\\spadesuit ", "&#9824;");
        LatexCmds.oint = bind(VanillaSymbol, "\\oint ", "&#8750;");
        LatexCmds.bigcap = bind(VanillaSymbol, "\\bigcap ", "&#8745;");
        LatexCmds.bigcup = bind(VanillaSymbol, "\\bigcup ", "&#8746;");
        LatexCmds.bigsqcup = bind(VanillaSymbol, "\\bigsqcup ", "&#8852;");
        LatexCmds.bigvee = bind(VanillaSymbol, "\\bigvee ", "&#8744;");
        LatexCmds.bigwedge = bind(VanillaSymbol, "\\bigwedge ", "&#8743;");
        LatexCmds.bigodot = bind(VanillaSymbol, "\\bigodot ", "&#8857;");
        LatexCmds.bigotimes = bind(VanillaSymbol, "\\bigotimes ", "&#8855;");
        LatexCmds.bigoplus = bind(VanillaSymbol, "\\bigoplus ", "&#8853;");
        LatexCmds.biguplus = bind(VanillaSymbol, "\\biguplus ", "&#8846;");
        LatexCmds.lfloor = bind(VanillaSymbol, "\\lfloor ", "&#8970;");
        LatexCmds.rfloor = bind(VanillaSymbol, "\\rfloor ", "&#8971;");
        LatexCmds.lceil = bind(VanillaSymbol, "\\lceil ", "&#8968;");
        LatexCmds.rceil = bind(VanillaSymbol, "\\rceil ", "&#8969;");
        LatexCmds.slash = bind(VanillaSymbol, "\\slash ", "&#47;");
        LatexCmds.opencurlybrace = bind(VanillaSymbol, "\\opencurlybrace ", "&#123;");
        LatexCmds.closecurlybrace = bind(VanillaSymbol, "\\closecurlybrace ", "&#125;");
        LatexCmds.caret = bind(VanillaSymbol, "\\caret ", "^");
        LatexCmds.underscore = bind(VanillaSymbol, "\\underscore ", "_");
        LatexCmds.backslash = bind(VanillaSymbol, "\\backslash ", "\\");
        LatexCmds.vert = bind(VanillaSymbol, "|");
        LatexCmds.perp = LatexCmds.perpendicular = bind(VanillaSymbol, "\\perp ", "&perp;");
        LatexCmds.nabla = LatexCmds.del = bind(VanillaSymbol, "\\nabla ", "&nabla;");
        LatexCmds.hbar = bind(VanillaSymbol, "\\hbar ", "&#8463;");
        LatexCmds.AA = LatexCmds.Angstrom = LatexCmds.angstrom = bind(VanillaSymbol, "\\text\\AA ", "&#8491;");
        LatexCmds.ring = LatexCmds.circ = LatexCmds.circle = bind(VanillaSymbol, "\\circ ", "&#8728;");
        LatexCmds.bull = LatexCmds.bullet = bind(VanillaSymbol, "\\bullet ", "&bull;");
        LatexCmds.setminus = LatexCmds.smallsetminus = bind(VanillaSymbol, "\\setminus ", "&#8726;");
        LatexCmds.not = LatexCmds["¬"] = LatexCmds.neg = bind(VanillaSymbol, "\\neg ", "&not;");
        LatexCmds["…"] = LatexCmds.dots = LatexCmds.ellip = LatexCmds.hellip = LatexCmds.ellipsis = LatexCmds.hellipsis = bind(VanillaSymbol, "\\dots ", "&hellip;");
        LatexCmds.converges = LatexCmds.darr = LatexCmds.dnarr = LatexCmds.dnarrow = LatexCmds.downarrow = bind(VanillaSymbol, "\\downarrow ", "&darr;");
        LatexCmds.dArr = LatexCmds.dnArr = LatexCmds.dnArrow = LatexCmds.Downarrow = bind(VanillaSymbol, "\\Downarrow ", "&dArr;");
        LatexCmds.diverges = LatexCmds.uarr = LatexCmds.uparrow = bind(VanillaSymbol, "\\uparrow ", "&uarr;");
        LatexCmds.uArr = LatexCmds.Uparrow = bind(VanillaSymbol, "\\Uparrow ", "&uArr;");
        LatexCmds.to = bind(BinaryOperator, "\\to ", "&rarr;");
        LatexCmds.rarr = LatexCmds.rightarrow = bind(VanillaSymbol, "\\rightarrow ", "&rarr;");
        LatexCmds.implies = bind(BinaryOperator, "\\Rightarrow ", "&rArr;");
        LatexCmds.rArr = LatexCmds.Rightarrow = bind(VanillaSymbol, "\\Rightarrow ", "&rArr;");
        LatexCmds.gets = bind(BinaryOperator, "\\gets ", "&larr;");
        LatexCmds.larr = LatexCmds.leftarrow = bind(VanillaSymbol, "\\leftarrow ", "&larr;");
        LatexCmds.impliedby = bind(BinaryOperator, "\\Leftarrow ", "&lArr;");
        LatexCmds.lArr = LatexCmds.Leftarrow = bind(VanillaSymbol, "\\Leftarrow ", "&lArr;");
        LatexCmds.harr = LatexCmds.lrarr = LatexCmds.leftrightarrow = bind(VanillaSymbol, "\\leftrightarrow ", "&harr;");
        LatexCmds.iff = bind(BinaryOperator, "\\Leftrightarrow ", "&hArr;");
        LatexCmds.hArr = LatexCmds.lrArr = LatexCmds.Leftrightarrow = bind(VanillaSymbol, "\\Leftrightarrow ", "&hArr;");
        LatexCmds.Re = LatexCmds.Real = LatexCmds.real = bind(VanillaSymbol, "\\Re ", "&real;");
        LatexCmds.Im = LatexCmds.imag = LatexCmds.image = LatexCmds.imagin = LatexCmds.imaginary = LatexCmds.Imaginary = bind(VanillaSymbol, "\\Im ", "&image;");
        LatexCmds.part = LatexCmds.partial = bind(VanillaSymbol, "\\partial ", "&part;");
        LatexCmds.inf = LatexCmds.infin = LatexCmds.infty = LatexCmds.infinity = bind(VanillaSymbol, "\\infty ", "&infin;");
        LatexCmds.alef = LatexCmds.alefsym = LatexCmds.aleph = LatexCmds.alephsym = bind(VanillaSymbol, "\\aleph ", "&alefsym;");
        LatexCmds.xist = LatexCmds.xists = LatexCmds.exist = LatexCmds.exists = bind(VanillaSymbol, "\\exists ", "&exist;");
        LatexCmds.and = LatexCmds.land = LatexCmds.wedge = bind(VanillaSymbol, "\\wedge ", "&and;");
        LatexCmds.or = LatexCmds.lor = LatexCmds.vee = bind(VanillaSymbol, "\\vee ", "&or;");
        LatexCmds.empty = LatexCmds.emptyset = LatexCmds.oslash = LatexCmds.Oslash = LatexCmds.nothing = LatexCmds.varnothing = bind(BinaryOperator, "\\varnothing ", "&empty;");
        LatexCmds.cup = LatexCmds.union = bind(BinaryOperator, "\\cup ", "&cup;");
        LatexCmds.cap = LatexCmds.intersect = LatexCmds.intersection = bind(BinaryOperator, "\\cap ", "&cap;");
        LatexCmds.deg = LatexCmds.degree = bind(VanillaSymbol, "^\\circ ", "&deg;");
        LatexCmds.ang = LatexCmds.angle = bind(VanillaSymbol, "\\angle ", "&ang;");
        var latexMathParser = (function () {
            function commandToBlock(cmd) {
                var block = MathBlock();
                cmd.adopt(block, 0, 0);
                return block
            }

            function joinBlocks(blocks) {
                var firstBlock = blocks[0] || MathBlock();
                for (var i = 1; i < blocks.length; i += 1) {
                    blocks[i].children().adopt(firstBlock, firstBlock.lastChild, 0)
                }
                return firstBlock
            }

            var string = Parser.string;
            var regex = Parser.regex;
            var letter = Parser.letter;
            var any = Parser.any;
            var optWhitespace = Parser.optWhitespace;
            var succeed = Parser.succeed;
            var fail = Parser.fail;
            var variable = letter.map(Variable);
            var symbol = regex(/^[^${}\\_^]/).map(VanillaSymbol);
            var controlSequence = regex(/^[^\\]/).or(string("\\").then(regex(/^[a-z]+/i).or(regex(/^\s+/).result(" ")).or(any))).then(function (ctrlSeq) {
                var cmdKlass = LatexCmds[ctrlSeq];
                if (cmdKlass) {
                    return cmdKlass(ctrlSeq).parser()
                } else {
                    return fail("unknown command: \\" + ctrlSeq)
                }
            });
            var command = controlSequence.or(variable).or(symbol);
            var mathGroup = string("{").then(function () {
                return mathSequence
            }).skip(string("}"));
            var mathBlock = optWhitespace.then(mathGroup.or(command.map(commandToBlock)));
            var mathSequence = mathBlock.many().map(joinBlocks).skip(optWhitespace);
            var optMathBlock = string("[").then(mathBlock.then(function (block) {
                return block.join("latex") !== "]" ? succeed(block) : fail()
            }).many().map(joinBlocks).skip(optWhitespace)).skip(string("]"));
            var latexMath = mathSequence;
            latexMath.block = mathBlock;
            latexMath.optBlock = optMathBlock;
            return latexMath
        })();
        var Cursor = P(function (_) {
            _.init = function (root) {
                this.parent = this.root = root;
                var jQ = this.jQ = this._jQ = $('<span class="mq-cursor"><span class="mq-line">&zwj;</span></span>');
                this.blink = function () {
                    jQ.toggleClass("mq-blink")
                };
                this.upDownCache = {};
                this.handle = $('<span class="mq-handle"></span>');
                this.handleAnchor = $('<span class="mq-handle-anchor" style="display:none"></span>').append(this.handle).insertAfter(root.jQ);
                this.handleAnchor.top = this.handleAnchor.left = 0
            };
            _.prev = 0;
            _.next = 0;
            _.parent = 0;
            _.showHandle = function () {
                if (!this.handleAnchor.visible) {
                    this.handleAnchor.show();
                    this.repositionHandle(this.jQ[0].getBoundingClientRect());
                    this.handleAnchor.visible = true
                }
                return this
            };
            _.hideHandle = function () {
                if (this.handleAnchor.visible) {
                    this.handleAnchor.hide();
                    delete this.handleAnchor.visible
                }
                return this
            };
            _.repositionHandle = function (cursorRect) {
                var anchor = this.handleAnchor;
                var anchorRect = anchor[0].getBoundingClientRect();
                anchor.css({top: anchor.top += cursorRect.bottom - anchorRect.bottom, left: anchor.left += cursorRect.left - anchorRect.left})
            };
            _.show = function (keepHandle) {
                if (!keepHandle) {
                    this.hideHandle()
                }
                this.jQ = this._jQ.removeClass("mq-blink");
                if ("intervalId" in this) {
                    clearInterval(this.intervalId)
                } else {
                    if (this.next) {
                        if (this.selection && this.selection.first.prev === this.prev) {
                            this.jQ.insertBefore(this.selection.jQ)
                        } else {
                            this.jQ.insertBefore(this.next.jQ.first())
                        }
                    } else {
                        this.jQ.appendTo(this.parent.jQ)
                    }
                    this.parent.focus()
                }
                this.intervalId = setInterval(this.blink, 500);
                return this
            };
            _.hide = function () {
                this.hideHandle();
                if ("intervalId" in this) {
                    clearInterval(this.intervalId)
                }
                delete this.intervalId;
                this.jQ.detach();
                this.jQ = $();
                return this
            };
            _.insertAt = function (parent, prev, next) {
                var old_parent = this.parent;
                this.parent = parent;
                this.prev = prev;
                this.next = next;
                old_parent.blur()
            };
            _.insertBefore = function (el) {
                this.insertAt(el.parent, el.prev, el);
                this.parent.jQ.addClass("mq-hasCursor");
                this.jQ.insertBefore(el.jQ.first());
                return this
            };
            _.insertAfter = function (el) {
                this.insertAt(el.parent, el, el.next);
                this.parent.jQ.addClass("mq-hasCursor");
                this.jQ.insertAfter(el.jQ.last());
                return this
            };
            _.prependTo = function (el) {
                this.insertAt(el, 0, el.firstChild);
                this.jQ.prependTo(el.jQ);
                el.focus();
                return this
            };
            _.appendTo = function (el) {
                this.insertAt(el, el.lastChild, 0);
                this.jQ.appendTo(el.jQ);
                el.focus();
                return this
            };
            _.hopLeft = function () {
                this.jQ.insertBefore(this.prev.jQ.first());
                this.next = this.prev;
                this.prev = this.prev.prev;
                return this
            };
            _.hopRight = function () {
                this.jQ.insertAfter(this.next.jQ.last());
                this.prev = this.next;
                this.next = this.next.next;
                return this
            };
            _.moveLeftWithin = function (block) {
                if (this.prev) {
                    if (this.prev instanceof NthRoot) {
                        this.appendTo(this.prev.lastChild)
                    } else {
                        if (this.prev.up instanceof MathBlock) {
                            this.appendTo(this.prev.up)
                        } else {
                            if (this.prev.firstChild) {
                                this.appendTo(this.prev.firstChild)
                            } else {
                                this.hopLeft()
                            }
                        }
                    }
                } else {
                    if (this.parent !== block) {
                        this.insertBefore(this.parent.parent)
                    } else {
                        if (block.moveOutOf) {
                            block.moveOutOf("left", this)
                        }
                    }
                }
            };
            _.moveRightWithin = function (block) {
                if (this.next) {
                    if (this.next.up instanceof MathBlock) {
                        this.prependTo(this.next.up)
                    } else {
                        if (this.next.firstChild) {
                            this.prependTo(this.next.firstChild)
                        } else {
                            this.hopRight()
                        }
                    }
                    Demo.hasNext = true
                } else {
                    Demo.hasNext = false;
                    if (this.parent !== block) {
                        this.insertAfter(this.parent.parent);
                        Demo.hasNext = true
                    } else {
                        if (block.moveOutOf) {
                            block.moveOutOf("right", this)
                        }
                    }
                }
            };
            _.moveLeft = function () {
                clearUpDownCache(this);
                if (this.selection) {
                    this.insertBefore(this.selection.first).clearSelection()
                } else {
                    this.moveLeftWithin(this.root)
                }
                this.root.triggerSpecialEvent("cursorMoved");
                return this.show()
            };
            _.moveRight = function () {
                clearUpDownCache(this);
                if (this.selection) {
                    this.insertAfter(this.selection.last).clearSelection()
                } else {
                    this.moveRightWithin(this.root)
                }
                this.root.triggerSpecialEvent("cursorMoved");
                return this.show()
            };
            _.moveUp = function () {
                return moveUpDown(this, "up")
            };
            _.moveDown = function () {
                return moveUpDown(this, "down")
            };
            function moveUpDown(self, dir) {
                if (self.next[dir]) {
                    self.prependTo(self.next[dir])
                } else {
                    if (self.prev[dir]) {
                        self.appendTo(self.prev[dir])
                    } else {
                        var ancestorBlock = self.parent;
                        do {
                            var prop = ancestorBlock[dir];
                            if (prop) {
                                if (typeof prop === "function") {
                                    prop = ancestorBlock[dir](self)
                                }
                                if (prop === false || prop instanceof MathBlock) {
                                    self.upDownCache[ancestorBlock.id] = {parent: self.parent, prev: self.prev, next: self.next};
                                    if (prop instanceof MathBlock) {
                                        var cached = self.upDownCache[prop.id];
                                        if (cached) {
                                            if (cached.next) {
                                                self.insertBefore(cached.next)
                                            } else {
                                                self.appendTo(cached.parent)
                                            }
                                        } else {
                                            var coords = self.jQ[0].getBoundingClientRect();
                                            var cachedClientRect = cachedClientRectFnForNewCache();
                                            if (cachedClientRect) {
                                                cachedClientRect.scrollLeft = 0;
                                                prop.seek(self, coords.left, coords.bottom, prop, cachedClientRect)
                                            }
                                        }
                                    }
                                    break
                                }
                            }
                            ancestorBlock = ancestorBlock.parent.parent
                        } while (ancestorBlock)
                    }
                }
                return self.clearSelection().show()
            }

            _.seek = function (target, clientX, clientY, clientRect, keepHandle) {
                clearUpDownCache(this);
                var cursor = this.clearSelection().show(keepHandle);
                var nodeId = target.attr(mqBlockId) || target.attr(mqCmdId);
                if (!nodeId) {
                    var targetParent = target.parent();
                    nodeId = targetParent.attr(mqBlockId) || targetParent.attr(mqCmdId)
                }
                var node = nodeId ? MathElement[nodeId] : cursor.root;
                pray("nodeId is the id of some Node that exists", node);
                var dx = clientRect.scrollLeft = this.root.jQ.scrollLeft();
                node.seek(cursor, clientX + dx, clientY, cursor.root, clientRect);
                delete clientRect.scrollLeft;
                this.root.scrollHoriz();
                return cursor
            };
            function offset(self) {
                var offset = self.jQ.removeClass("mq-cursor").offset();
                self.jQ.addClass("mq-cursor");
                return offset
            }

            _.writeLatex = function (latex) {
                var self = this;
                clearUpDownCache(self);
                self.show().deleteSelection();
                var all = Parser.all;
                var eof = Parser.eof;
                var block = latexMathParser.skip(eof).or(all.result(false)).parse(latex);
                if (block && !block.isEmpty()) {
                    block.children().adopt(self.parent, self.prev, self.next);
                    var html = block.join("html");
                    var jQ = MathElement.jQize(html);
                    jQ.insertBefore(self.jQ);
                    self.prev = block.lastChild;
                    block.finalizeInsert();
                    self.parent.bubble("redraw")
                }
                return this
            };
            _.write = _.insertCh = function (ch) {
                if ((ch == "^" || ch == "_") && !this.prev) {
                    return
                }
                if ((ch == "+" || ch == "=" || ch == "-" || ch == "<" || ch == ">") && (this.parent.parent.ctrlSeq === "^" || this.parent.parent.ctrlSeq === "_") && !this.next && this.prev) {
                    this.moveRight()
                }
                if (ch === "^" && this.prev instanceof SupSub && (this.prev.ctrlSeq === "^" || this.prev.prev.ctrlSeq === "^")) {
                    this.moveUp();
                    return
                }
                if (ch === "^" && this.next instanceof SupSub && (this.next.ctrlSeq === "^" || (this.next.next && this.next.next.ctrlSeq === "^"))) {
                    this.moveUp();
                    return
                }
                if (ch === "_" && this.prev instanceof SupSub && (this.prev.ctrlSeq === "_" || this.prev.prev.ctrlSeq === "_")) {
                    this.moveDown();
                    return
                }
                clearUpDownCache(this);
                this.show();
                var cmd;
                if (ch.match(/^[a-z]$/i)) {
                    cmd = Variable(ch)
                } else {
                    //符号键盘输入时，才转化公式符号
                    if ((window.symbolKeyboard == true || ch.includes("<") || ch.includes(">")) && (cmd = CharCmds[ch] || LatexCmds[ch])) {
                        cmd = cmd(ch)
                    } else {
                        cmd = VanillaSymbol(ch)
                    }
                }
                if (this.selection) {
                    this.prev = this.selection.first.prev;
                    this.next = this.selection.last.next;
                    cmd.replaces(this.selection);
                    delete this.selection
                }

                return this.insertNew(cmd)
            };
            _.insertNew = function (cmd) {
                cmd.createBefore(this);
                return this
            };
            _.insertCmd = function (latexCmd, replacedFragment) {
                clearUpDownCache(this);
                this.show();
                var cmd = LatexCmds[latexCmd];
                if (cmd) {
                    cmd = cmd(latexCmd);
                    if (replacedFragment) {
                        cmd.replaces(replacedFragment)
                    }
                    this.insertNew(cmd)
                } else {
                    cmd = TextBlock();
                    cmd.replaces(latexCmd);
                    cmd.firstChild.focus = function () {
                        delete this.focus;
                        return this
                    };
                    this.insertNew(cmd).insertAfter(cmd);
                    if (replacedFragment) {
                        replacedFragment.remove()
                    }
                }
                return this
            };
            _.unwrapGramp = function () {
                var gramp = this.parent.parent;
                var greatgramp = gramp.parent;
                var next = gramp.next;
                var cursor = this;
                var prev = gramp.prev;
                gramp.disown().eachChild(function (uncle) {
                    if (uncle.isEmpty()) {
                        return
                    }
                    uncle.children().adopt(greatgramp, prev, next).each(function (cousin) {
                        cousin.jQ.insertBefore(gramp.jQ.first())
                    });
                    prev = uncle.lastChild
                });
                if (!this.next) {
                    if (this.prev) {
                        this.next = this.prev.next
                    } else {
                        while (!this.next) {
                            this.parent = this.parent.next;
                            if (this.parent) {
                                this.next = this.parent.firstChild
                            } else {
                                this.next = gramp.next;
                                this.parent = greatgramp;
                                break
                            }
                        }
                    }
                }
                if (this.next) {
                    this.insertBefore(this.next)
                } else {
                    this.appendTo(greatgramp)
                }
                gramp.jQ.remove();
                if (gramp.prev) {
                    gramp.prev.respace()
                }
                if (gramp.next) {
                    gramp.next.respace()
                }
            };
            _.backspace = function () {
                clearUpDownCache(this);
                this.show();
                if (this.deleteSelection()) {
                } else {
                    if (this.prev) {
                        if (this.prev.isEmpty()) {
                            if (this.prev.ctrlSeq === "\\le ") {
                                var ins = LatexCmds["<"]("<")
                            } else {
                                if (this.prev.ctrlSeq === "\\ge ") {
                                    var ins = LatexCmds[">"](">")
                                }
                            }
                            this.prev = this.prev.remove().prev;
                            if (ins) {
                                this.insertNew(ins)
                            }
                        } else {
                            if (this.prev instanceof Bracket) {
                                return this.appendTo(this.prev.firstChild).deleteForward()
                            } else {
                                this.selectLeft()
                            }
                        }
                    } else {
                        if (this.parent !== this.root) {
                            if (this.parent.parent.isEmpty()) {
                                return this.insertAfter(this.parent.parent).backspace()
                            } else {
                                if (this.next instanceof Bracket) {
                                    return this.prependTo(this.next.firstChild).backspace()
                                } else {
                                    this.unwrapGramp()
                                }
                            }
                        }
                    }
                }
                if (this.prev) {
                    this.prev.respace()
                }
                if (this.next) {
                    this.next.respace()
                }
                this.parent.bubble("redraw");
                return this
            };
            _.deleteForward = function () {
                clearUpDownCache(this);
                this.show();
                if (this.deleteSelection()) {
                } else {
                    if (this.next) {
                        if (this.next.isEmpty()) {
                            this.next = this.next.remove().next
                        } else {
                            this.selectRight()
                        }
                    } else {
                        if (this.parent !== this.root) {
                            if (this.parent.parent.isEmpty()) {
                                return this.insertBefore(this.parent.parent).deleteForward()
                            } else {
                                this.unwrapGramp()
                            }
                        } else {
                            this.root.triggerSpecialEvent("delPressed")
                        }
                    }
                }
                if (this.prev) {
                    this.prev.respace()
                }
                if (this.next) {
                    this.next.respace()
                }
                this.parent.bubble("redraw");
                return this
            };
            _.selectFrom = function (anticursor) {
                var oneA = this, otherA = anticursor;
                loopThroughAncestors:do {
                    for (var oneI = this; oneI !== oneA.parent.parent; oneI = oneI.parent.parent) {
                        if (oneI.parent === otherA.parent) {
                            left = oneI;
                            right = otherA;
                            break loopThroughAncestors
                        }
                    }
                    for (var otherI = anticursor; otherI !== otherA.parent.parent; otherI = otherI.parent.parent) {
                        if (oneA.parent === otherI.parent) {
                            left = oneA;
                            right = otherI;
                            break loopThroughAncestors
                        }
                    }
                    if (oneA.parent.parent) {
                        oneA = oneA.parent.parent
                    }
                    if (otherA.parent.parent) {
                        otherA = otherA.parent.parent
                    }
                } while (oneA.parent.parent || otherA.parent.parent || oneA.parent === otherA.parent);
                pray("cursor and anticursor are in the same tree", oneA.parent.parent || otherA.parent.parent || oneA.parent === otherA.parent);
                var left, right, leftRight;
                if (left.next !== right) {
                    for (var next = left; next; next = next.next) {
                        if (next === right.prev) {
                            leftRight = true;
                            break
                        }
                    }
                    if (!leftRight) {
                        leftRight = right;
                        right = left;
                        left = leftRight
                    }
                }
                this.hide().selection = Selection(left.prev.next || left.parent.firstChild, right.next.prev || right.parent.lastChild);
                this.insertAfter(right.next.prev || right.parent.lastChild);
                this.root.selectionChanged()
            };
            _.selectLeft = function () {
                clearUpDownCache(this);
                if (this.selection) {
                    if (this.selection.first === this.next) {
                        if (this.prev) {
                            this.hopLeft().selection.extendLeft()
                        } else {
                            if (this.parent !== this.root) {
                                this.insertBefore(this.parent.parent).selection.levelUp()
                            }
                        }
                    } else {
                        this.hopLeft();
                        if (this.selection.first === this.selection.last) {
                            this.clearSelection().show();
                            return
                        }
                        this.selection.retractLeft()
                    }
                } else {
                    if (this.prev) {
                        this.hopLeft()
                    } else {
                        if (this.parent !== this.root) {
                            this.insertBefore(this.parent.parent)
                        } else {
                            return
                        }
                    }
                    this.hide().selection = Selection(this.next)
                }
                this.root.selectionChanged()
            };
            _.selectRight = function () {
                clearUpDownCache(this);
                if (this.selection) {
                    if (this.selection.last === this.prev) {
                        if (this.next) {
                            this.hopRight().selection.extendRight()
                        } else {
                            if (this.parent !== this.root) {
                                this.insertAfter(this.parent.parent).selection.levelUp()
                            }
                        }
                    } else {
                        this.hopRight();
                        if (this.selection.first === this.selection.last) {
                            this.clearSelection().show();
                            return
                        }
                        this.selection.retractRight()
                    }
                } else {
                    if (this.next) {
                        this.hopRight()
                    } else {
                        if (this.parent !== this.root) {
                            this.insertAfter(this.parent.parent)
                        } else {
                            return
                        }
                    }
                    this.hide().selection = Selection(this.prev)
                }
                this.root.selectionChanged()
            };
            function clearUpDownCache(self) {
                self.upDownCache = {}
            }

            _.prepareMove = function () {
                clearUpDownCache(this);
                return this.show().clearSelection()
            };
            _.prepareEdit = function () {
                clearUpDownCache(this);
                return this.show().deleteSelection()
            };
            _.clearSelection = function () {
                if (this.selection) {
                    this.selection.clear();
                    delete this.selection;
                    this.root.selectionChanged()
                }
                return this
            };
            _.deleteSelection = function () {
                if (!this.selection) {
                    return false
                }
                this.prev = this.selection.first.prev;
                this.next = this.selection.last.next;
                this.selection.remove();
                this.root.selectionChanged();
                return delete this.selection
            }
        });
        var Selection = P(MathFragment, function (_, _super) {
            _.init = function () {
                var frag = this;
                _super.init.apply(frag, arguments);
                frag.jQwrap(frag.jQ)
            };
            _.jQwrap = function (children) {
                this.jQ = children.wrapAll('<span class="mq-selection"></span>').parent()
            };
            _.adopt = function () {
                this.jQ.replaceWith(this.jQ = this.jQ.children());
                return _super.adopt.apply(this, arguments)
            };
            _.clear = function () {
                this.jQ.replaceWith(this.jQ.children());
                return this
            };
            _.levelUp = function () {
                var seln = this, gramp = seln.first = seln.last = seln.last.parent.parent;
                seln.clear().jQwrap(gramp.jQ);
                return seln
            };
            _.extendLeft = function () {
                this.first = this.first.prev;
                this.first.jQ.prependTo(this.jQ)
            };
            _.extendRight = function () {
                this.last = this.last.next;
                this.last.jQ.appendTo(this.jQ)
            };
            _.retractRight = function () {
                this.first.jQ.insertBefore(this.jQ);
                this.first = this.first.next
            };
            _.retractLeft = function () {
                this.last.jQ.insertAfter(this.jQ);
                this.last = this.last.prev
            }
        });
        $.fn.mathquill = function (cmd, latex) {
            switch (cmd) {
                case"focus":
                case"blur":
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                        if (block && block.textarea) {
                            block.textarea.children().trigger(cmd)
                        }
                    });
                case"onKey":
                case"onText":
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                        if (cursor) {
                            cursor.parent.bubble(cmd, latex, {preventDefault: noop});
                            if (block.blurred) {
                                cursor.hide().parent.blur()
                            }
                        }
                    });
                case"redraw":
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), rootBlock = blockId && MathElement[blockId];
                        if (rootBlock) {
                            (function postOrderRedraw(el) {
                                el.eachChild(postOrderRedraw);
                                if (el.redraw) {
                                    el.redraw()
                                }
                            }(rootBlock))
                        }
                    });
                case"revert":
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                        if (block && block.revert) {
                            block.revert()
                        }
                    });
                case"sliderLatex":
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                        if (block) {
                            cursor = block && block.cursor;
                            if (cursor) {
                                cursor.clearSelection()
                            }
                            block.renderSliderLatex(latex);
                            block.triggerSpecialEvent("render")
                        }
                    });
                case"latex":
                    if (arguments.length > 1) {
                        return this.each(function () {
                            var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                            if (block) {
                                cursor = block && block.cursor;
                                if (cursor) {
                                    cursor.clearSelection()
                                }
                                block.renderLatex(latex);
                                block.triggerSpecialEvent("render")
                            }
                        })
                    }
                    var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                    return block && block.latex();
                case"text":
                    var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                    return block && block.text();
                case"html":
                    return this.children(".mathquill-root-block").html().replace(/ ?mq-hasCursor|mq-hasCursor /, "").replace(/ class=(""|(?= |>))/g, "").replace(/<span class="?mq-cursor( mq-blink)?"?>.?<\/span>/i, "");
                case"write":
                    if (arguments.length > 1) {
                        return this.each(function () {
                            var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                            if (cursor) {
                                cursor.writeLatex(latex);
                                if (block.blurred) {
                                    cursor.hide().parent.blur()
                                }
                            }
                        })
                    }
                case"cmd":
                    if (arguments.length > 1) {
                        return this.each(function () {
                            var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                            if (cursor) {
                                if (/^\\[a-z]+$/i.test(latex)) {
                                    var selection = cursor.selection;
                                    if (selection) {
                                        cursor.prev = selection.first.prev;
                                        cursor.next = selection.last.next;
                                        delete cursor.selection
                                    }
                                    cursor.insertCmd(latex.slice(1), selection)
                                } else {
                                    cursor.insertCh(latex)
                                }
                                if (block.blurred) {
                                    cursor.hide().parent.blur()
                                }
                            }
                        })
                    }
                case"touchtap":
                    var touchstartTarget = arguments[1], x = arguments[2], y = arguments[3];
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                        if (cursor && touchstartTarget !== cursor.handle[0]) {
                            var wasBlurred = block.blurred;
                            block.textarea.children().focus();
                            cursor.seek($(touchstartTarget), x, y, cachedClientRectFnForNewCache(), true);
                            if (!wasBlurred) {
                                cursor.showHandle()
                            }
                        }
                    });
                case"ignoreNextMousedown":
                    var time = arguments[1];
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                        if (block) {
                            block.ignoreMousedownTimeout = setTimeout(function () {
                                block.ignoreMousedownTimeout = undefined
                            }, time)
                        }
                    });
                case"moveStart":
                    var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                    if (block && block.cursor) {
                        block.cursor.prependTo(block)
                    }
                    break;
                case"moveEnd":
                    var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId];
                    if (block && block.cursor) {
                        block.cursor.appendTo(block)
                    }
                    break;
                case"isAtStart":
                    var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                    if (cursor) {
                        return cursor.parent === cursor.root && !cursor.prev
                    }
                    break;
                case"isAtEnd":
                    var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                    if (cursor) {
                        return cursor.parent === cursor.root && !cursor.next
                    }
                    break;
                case"selection":
                    var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                    if (!cursor) {
                        return
                    }
                    return cursor.selection ? "$" + cursor.selection.latex() + "$" : "";
                case"clearSelection":
                    return this.each(function () {
                        var blockId = $(this).attr(mqBlockId), block = blockId && MathElement[blockId], cursor = block && block.cursor;
                        if (cursor) {
                            cursor.clearSelection();
                            if (block.blurred) {
                                cursor.hide().parent.blur()
                            }
                        }
                    });
                default:
                    var textbox = cmd === "textbox", editable = textbox || cmd === "editable", RootBlock = textbox ? RootTextBlock : RootMathBlock;
                    return this.each(function () {
                        var container = $(this), root = RootBlock();
                        createRoot(container, root, textbox, editable);
                        var cursor = root.cursor;
                        var textarea = setupTextarea(editable, container, root, cursor);
                        var textareaSpan = root.textarea;
                        root.editable = editable;
                        mouseEvents(container);
                        setupTouchHandle(editable, root, cursor);
                        if (!editable) {
                            return
                        }
                        rootCSSClasses(container, textbox);
                        focusBlurEvents(root, cursor, textarea);
                        desmosCustomEvents(container, root, cursor)
                    })
            }
        }
    }());
    define("mathquill", function () {
    });
    define("template!expression_item", ["underscore"], function (_) {
        return function (obj) {
            var __p = "";
            var print = function () {
                __p += Array.prototype.join.call(arguments, "")
            };
            with (obj || {}) {
                __p += "";
                if (renderShell) {
                    __p += "\n\n<div class=\"dcg-do-not-blur dcg-expressionitem dcg-shell\">\n  <div class='dcg-shell'></div>\n</div>\n\n"
                } else {
                    __p += '\n\n<div class="dcg-do-not-blur dcg-expressionitem">\n  <div class=\'dcg-fade-container\'>\n\n    <div class="dcg-fadeout-left"></div>\n\n    <span class="dcg-main">\n      <span class="dcg-transient-mathquill"></span>\n      <span class="dcg-template-mathquill"></span>\n    </span>\n\n    <span class="dcg-fadeout"></span>\n    <i class="dcg-icon-remove dcg-top-level-delete dcg-action-delete" handleEvent="true"></i>\n\n    <div class="dcg-slider-speed-container dcg-do-not-blur" handleEvent="true">\n      <span class="dcg-action-slower" >&laquo;</span>\n      <span class="dcg-variable-speed"></span>\n      <span class="dcg-action-faster">&raquo;</span>\n    </div>\n\n    <div class="dcg-template-bottom-container dcg-fixed-width-element">\n      <div class="dcg-template-bottom"></div>\n    </div>\n  </div> <span class="dcg-exp-actions">\n    <span class="dcg-graphic" handleEvent="true"></span>\n    <nobr>\n      <span class="dcg-action-delete dcg-delete-btn dcg-tooltip" handleEvent="true" tooltip="' + (t("Delete")) + '"><i class=\'dcg-icon-remove\'></i></span>\n      <span class="dcg-action-duplicate dcg-duplicate-btn dcg-tooltip" handleEvent="true" tooltip="' + (t("Duplicate")) + '"><i class=\'dcg-icon-duplicate\'></i></span>\n      <span class="dcg-action-createtable dcg-tooltip" tooltip="' + (t("Convert to Table")) + '" handleEvent="true">\n        <i class=\'dcg-icon-table\'></i>\n      </span>\n    </nobr>\n  </span>\n</div>\n\n'
                }
                __p += "\n"
            }
            return __p
        }
    });
    define("expressions/abstractitem_view", ["require", "pjs", "jquery", "underscore_view", "undoredo", "conditional_blur"], function (require) {
        var P = require("pjs");
        var $ = require("jquery");
        var UnderscoreView = require("underscore_view");
        var UndoRedo = require("undoredo");
        var conditionalBlur = require("conditional_blur");
        var AbstractItemView = P(UnderscoreView, function (view, _super) {
            view.init = function (model, listView) {
                _super.init.call(this);
                this.model = model;
                this.listView = listView;
                if (this.model.selected) {
                    this.model.renderShell = false
                }
                this.model.observe("index.itemview", this.renderIndex.bind(this));
                this.model.observe("selected.itemview", this.renderSelected.bind(this));
                this.model.observe("renderShell.itemview", this.rerender.bind(this));
                this.model.observe("renderShell.itemview", this.setMinWidth.bind(this));
                this.model.observe("folder.itemview", this.renderFolder.bind(this));
                this.model.observe("inCollapsedFolder.itemview", this.renderCollapsedFolder.bind(this))
            };
            view.onProjectorModeChange = function () {
            };
            view.destruct = function () {
                this.model.unobserve(".itemview");
                this.setProperty("transient", false)
            };
            view.getTemplateParams = function () {
                return {renderShell: this.model.renderShell, inCollapsedFolder: this.model.inCollapsedFolder}
            };
            view.setInitialAnimationHeight = function (height) {
                if (this.$templateBottomContainer.hasClass("dcg-do-animate")) {
                    return
                }
                this.$templateBottomContainer.css("height", height);
                var self = this;
                setTimeout(function () {
                    self.$templateBottomContainer.addClass("dcg-do-animate")
                })
            };
            view.animateHeightTimeout = null;
            view.clearHeightTimeout = null;
            view.animateHeightTo = function (height) {
                var self = this;
                clearTimeout(this.animateHeightTimeout);
                this.animateHeightTimeout = setTimeout(function () {
                    self.$templateBottomContainer.css("height", height);
                    self.$templateBottom.toggleClass("dcg-faded-in", (height > 0))
                }, 250);
                clearTimeout(this.clearHeightTimeout);
                this.clearHeightTimeout = setTimeout(function () {
                    self.$templateBottomContainer.css("height", "auto");
                    self.$templateBottomContainer.removeClass("dcg-do-animate")
                }, 550)
            };
            view.templateBottomItems = 0;
            view.addViewToBottom = function (view) {
                return;
                if (!this.$templateBottom) {
                    return
                }
                this.templateBottomItems++;
                if (!this.doAnimate || this.templateBottomItems > 1) {
                    this.$templateBottom.addClass("dcg-faded-in");
                    view.appendTo(this.$templateBottom);
                    return
                }
                this.setInitialAnimationHeight(0);
                view.appendTo(this.$templateBottom);
                this.animateHeightTo(view.$().height())
            };
            view.removeViewFromBottom = function (view) {
                if (!this.$templateBottom) {
                    return
                }
                this.templateBottomItems--;
                if (this.templateBottomItems > 0) {
                    view.remove();
                    return
                }
                if (!this.doAnimate) {
                    this.$templateBottom.removeClass("dcg-faded-in");
                    view.remove();
                    return
                }
                this.setInitialAnimationHeight(this.$templateBottom.height());
                view.remove();
                this.animateHeightTo(0)
            };
            view.renderIndex = function () {
                var index = this.model.index;
                this.$().attr("index", index);
                this.$(".dcg-variable-index").text(index + 1)
            };
            view.renderFolder = function () {
                this.$().toggleClass("dcg-inFolder", !!this.model.folder)
            };
            view.renderCollapsedFolder = function () {
                this.$().toggleClass("dcg-inCollapsedFolder", !!this.model.inCollapsedFolder);
                if (!this.model.inCollapsedFolder) {
                    this.$(".mathquill-rendered-math").mathquill("redraw")
                }
            };
            view.renderSelected = function () {
                if (this.model.selected) {
                    if (this.model.renderShell) {
                        this.model.setProperty("renderShell", false)
                    }
                }
                this.$().toggleClass("dcg-selected", !!this.model.selected)
            };
            view.setMinWidth = function () {
                var width = $(window).width();
                this.$(".dcg-fixed-width-element").css("width", width)
            };
            view.didCreateElement = function () {
                this.setMinWidth();
                this.$templateBottom = this.$(".dcg-template-bottom");
                this.$templateBottomContainer = this.$(".dcg-template-bottom-container")
            };
            view.didInsertElement = function () {
                _super.didInsertElement.call(this);
                var self = this;
                this.$().on("tap tapstart", function (evt) {
                    if (evt.type === "tap" && evt.device === "mouse") {
                        return
                    }
                    if (evt.type === "tapstart" && evt.device === "touch") {
                        return
                    }
                    self.onMouseSelect(evt)
                });
                this.$(".dcg-action-drag").on("tapstart", this.onDragPending.bind(this));
                this.$(".dcg-action-delete").on("tap", this.onDelete.bind(this));
                this.$().attr("expr-id", this.model.id);
                this.renderIndex();
                this.renderSelected();
                this.renderFolder();
                this.renderCollapsedFolder()
            };
            view.triggerDelete = function () {
            };
            view.triggerEnterPressed = function () {
            };
            view.triggerUpPressed = function () {
            };
            view.triggerDownPressed = function () {
            };
            view.triggerBackspacePressed = function () {
            };
            view.triggerDelPressed = function () {
            };
            view.onMouseSelect = function () {
            };
            view.sendTapToMathQuill = function (evt, mq) {
                if (evt.device === "mouse") {
                    evt.preventDefault()
                }
                if(!evt.device){
                    return;
                }
                if (evt.device === "mouse") {
                    if ($.contains(mq[0], evt.target)) {
                        return
                    }
                    var fakeEvent = $.event.fix(evt.originalEvent);
                    mq.triggerHandler(fakeEvent)
                } else {
                    var touch = evt.originalEvent.changedTouches[0];
                    mq.mathquill("touchtap", touch.target, touch.clientX, touch.clientY).mathquill("ignoreNextMousedown", 1000)
                }
            };
            view.onDelete = function () {
                this.triggerDelete()
            };
            view.convertTo = function (cls, state) {
                var obj = cls(state);
                var index = this.model.index;
                var list = this.model.list;
                var folder = this.model.folder;
                obj.setProperty("list", list);
                UndoRedo.oneTransaction(function () {
                    list.removeItemAt(index);
                    list.insertItemAt(index, obj);
                    if (folder) {
                        folder.addItem(obj)
                    }
                });
                return obj
            };
            view.getBounds = function () {
                var dom = this.$();
                var offset = dom.offset();
                if (!offset) {
                    return null
                }
                var top = offset.top;
                var height = dom.height();
                return {top: top, bottom: top + height}
            };
            view.allowDragDrop = function () {
                return true
            };
            view.onDragPending = function (evt) {
                conditionalBlur();
                if (!this.allowDragDrop()) {
                    return
                }
                var self = this;
                this.mouseMovedTo = null;
                var dragStartTimeout = setTimeout(function () {
                    $(document).off(".dragpending");
                    self.onDragStart(evt)
                }, 500);
                $(document).on("tapmove.dragpending", function (new_evt) {
                    self.mouseMovedTo = new_evt.touches[0];
                    var dx = evt.touches[0].x - self.mouseMovedTo.x;
                    var dy = evt.touches[0].y - self.mouseMovedTo.y;
                    if (Math.sqrt(dx * dx + dy * dy) > 3) {
                        clearTimeout(dragStartTimeout);
                        $(document).off(".dragpending");
                        self.onDragStart(evt)
                    }
                });
                $(document).on("tapend.dragpending", function (new_evt) {
                    clearTimeout(dragStartTimeout);
                    $(document).off(".dragpending")
                })
            };
            view.onDragStart = function (evt) {
                if (!this.allowDragDrop()) {
                    return
                }
                this.listView.dragdrop_expressions.start(evt, this);
                if (this.mouseMovedTo) {
                    this.listView.dragdrop_expressions.drag(this.mouseMovedTo.x, this.mouseMovedTo.y)
                }
            };
            view.hideContextMenu = function () {
                this.notifyPropertyChange("hideContextMenu")
            };
            view.processMissedKeyEvent = function (evt) {
            };
            view.addFocus = function (where) {
            };
            view.isFocused = function () {
                return false
            }
        });
        return AbstractItemView
    });
    define("expressions/expression_view", ["require", "jquery", "pjs", "config", "expressions/unresolved", "graphing/columnmode", "i18n", "conditional_blur", "mathquill", "keys", "undoredo", "lib/track_feature", "template!expression_item", "expressions/abstractitem_view"], function (require) {
        var $ = require("jquery");
        var P = require("pjs");
        var Config = require("config");
        var UnresolvedView = require("expressions/unresolved");
        var ExpressionObject = require("./expression");
        var COLUMNMODE = require("graphing/columnmode");
        var i18n = require("i18n");
        var conditionalBlur = require("conditional_blur");
        require("mathquill");
        var Keys = require("keys");
        var UndoRedo = require("undoredo");
        var Feature = require("lib/track_feature");
        var template = require("template!expression_item");
        var AbstractItemView = require("expressions/abstractitem_view");
        var ExpressionView = P(AbstractItemView, function (view, _super) {
            view.template = template;
            view.init = function (model, listView, toastView) {
                _super.init.call(this, model, listView);
                this.toastView = toastView;
                this.model.observe("formula.exprview", this.onFormulaChange.bind(this));
                this.model.observe("selected.exprview", this.onSelectedChange.bind(this));
                this.model.observe("latex.exprview", this.onLatexChange.bind(this));
                this.model.observe("dependent.exprview", this.renderDependent.bind(this));
                this.model.observe("isTableable.exprview", this.renderIsTableable.bind(this));
                this.model.observe("unresolved.exprview", this.renderUnresolved.bind(this));
                this.model.observe("loading.exprview", this.onLoadingChange.bind(this))
            };
            view.onLoadingChange = function () {
                if (!this.model.loading) {
                    var self = this;
                    setTimeout(function () {
                        self.setProperty("doAnimate", true)
                    })
                }
            };
            view.renderIsTableable = function () {
                this.$(".dcg-action-createtable").toggleClass("dcg-disabled", !this.model.isTableable)
            };
            view.destruct = function () {
                _super.destruct.call(this);
                this.model.unobserve(".exprview");
                if (this.iconView) {
                    this.iconView.remove();
                    this.iconView = null
                }
                if (this.sliderView) {
                    this.sliderView.remove();
                    this.sliderView = null
                }
                if (this.promptSliderView) {
                    this.promptSliderView.remove();
                    this.promptSliderView = null
                }
                if (this.domainView) {
                    this.domainView.remove();
                    this.domainView = null
                }
                if (this.evaluationView) {
                    this.evaluationView.remove();
                    this.evaluationView = null
                }
                if (this.unresolvedView) {
                    this.unresolvedView.remove();
                    this.unresolvedView = null
                }
            };
            view.onLatexChange = function () {
                var latex = this.model.latex;
                if (latex === '"' || latex === "'") {
                    this.listView.getSelectedView().addFocus();
                    return
                }
                this.listView.onLatexChange(latex);
                this.updateMathquill()
            };
            view.updateMathquill = function () {
                if (!this.mathquill) {
                    return
                }
                var latex = this.model.latex;
                if (latex !== undefined && this.mathquill.mathquill("latex") !== latex) {
                    this.mathquill.mathquill("latex", latex)
                }
            };
            view.updateTransientValue = function () {
                if (!this.$transientValue || !this.$transientValue.length) {
                    return
                }
                this.$transientValue[0].innerHTML = (this.model.slider.computeSnappedValue(this.model.slider.value).toString().replace("-", '<span class="unary-operator">\u2212</span>'))
            };
            view.createIconView = function () {
            };
            view.createSliderView = function () {
            };
            view.createPromptSliderView = function () {
            };
            view.createDomainView = function () {
            };
            view.createEvaluationView = function () {
            };
            view.onFormulaChange = function () {
                if (this.model.renderShell) {
                    return
                }
                var formula = this.model.formula;
                this.hideContextMenu();
                var showSlider = formula.is_slidable;
                if (this.sliderView && !showSlider) {
                    this.sliderView.slider.unobserve(".expressionView");
                    this.removeViewFromBottom(this.sliderView);
                    this.sliderView = null;
                    this.$().removeClass("dcg-hasSlider")
                } else {
                    if (!this.sliderView && showSlider) {
                    }
                }
                var promptCreateSlider = formula.variables.length > 0;
                if (this.promptSliderView && !promptCreateSlider) {
                    this.removeViewFromBottom(this.promptSliderView);
                    this.promptSliderView = null
                } else {
                    if (!this.promptSliderView && promptCreateSlider) {
                    }
                }
                var showDomain = formula.is_parametric;
                if (this.domainView && !showDomain) {
                    this.removeViewFromBottom(this.domainView);
                    this.domainView = null;
                    this.$().removeClass("dcg-hasDomain")
                } else {
                    if (!this.domainView && showDomain) {
                        this.domainView = this.createDomainView();
                        if (this.domainView) {
                            this.addViewToBottom(this.domainView);
                            this.$().addClass("dcg-hasDomain")
                        }
                    }
                }
                var showEvaluation = formula.is_evaluable;
                if (this.evaluationView && !showEvaluation) {
                    this.removeViewFromBottom(this.evaluationView);
                    this.evaluationView = null
                } else {
                    if (!this.evaluationView && showEvaluation) {
                        this.evaluationView = this.createEvaluationView();
                        if (this.evaluationView) {
                            this.addViewToBottom(this.evaluationView);
                            this.$().addClass(".dcg-hasEvaluation");
                            this.evaluationView.setProperty("dependentLabel", this.getDependentLabel())
                        }
                    }
                }
                if (this.promptSliderView) {
                    this.promptSliderView.setProperty("variables", formula.variables)
                }
                if (this.evaluationView) {
                    this.evaluationView.setProperty("evaluations", formula.zero_values)
                }
            };
            view.renderDependent = function () {
                if (this.sliderView) {
                    this.sliderView.setProperty("dependentLabel", this.getDependentLabel())
                }
                if (this.evaluationView) {
                    this.evaluationView.setProperty("dependentLabel", this.getDependentLabel())
                }
            };
            view.renderUnresolved = function () {
                var unresolved = this.model.unresolved;
                if (!unresolved && this.unresolvedView) {
                    this.unresolvedView.remove();
                    this.unresolvedView = null
                }
                if (unresolved && !this.unresolvedView) {
                    this.unresolvedView = UnresolvedView();
                    this.addViewToBottom(this.unresolvedView)
                }
            };
            view.didInsertElement = function () {
                _super.didInsertElement.call(this);
                if (this.model.renderShell) {
                    return
                }
                this.mathquill = this.$(".dcg-template-mathquill").mathquill("editable");
                this.$transientLhs = this.$(".dcg-transient-mathquill").mathquill("editable");
                this.$transientLhs.hide();
                this.$transientValue = $("<span>");
                this.mathquill.on("render upPressed downPressed enterPressed backspacePressed delPressed keydown focusin focus", this.onMathquillEvent.bind(this));
                this.$transientLhs.on("tapstart", this.onSelectTransient.bind(this));
                this.mathquill.mathquill("latex", this.model.latex || "");
                this.iconView = this.createIconView();
                if (this.iconView) {
                    this.iconView.replace(this.$(".template-expricon"))
                }
                this.$(".dcg-action-duplicate").on("tap", this.onDuplicateWithoutFocus.bind(this));
                this.$(".dcg-action-createtable").on("tap", this.onCreateTable.bind(this));
                this.$(".dcg-action-faster").on("tap", this.animateFaster.bind(this));
                this.$(".dcg-action-slower").on("tap", this.animateSlower.bind(this));
                this.renderIsTableable();
                this.onFormulaChange()
            };
            view.animateFaster = function () {
                if (this.sliderView) {
                    this.sliderView.animateFaster()
                }
            };
            view.animateSlower = function () {
                if (this.sliderView) {
                    this.sliderView.animateSlower()
                }
            };
            view.onSelectedChange = function () {
                if (!this.model.selected && this.mathquill) {
                    this.mathquill.mathquill("clearSelection").mathquill("blur")
                }
            };
            view.onSelectTransient = function () {
                this.stopTransient();
                this.mathquill.mathquill("focus")
            };
            view.onMathquillEvent = function (evt) {
                switch (evt.type) {
                    case"render":
                        this.model.setProperty("latex", this.mathquill.mathquill("latex"));
                        return;
                    case"focus":
                    case"focusin":
                        if (this.sliderView) {
                            this.sliderView.slider.setProperty("isPlaying", false)
                        }
                        this.model.setProperty("selected", true);
                        return;
                    case"upPressed":
                        this.triggerUpPressed();
                        return;
                    case"downPressed":
                        this.triggerDownPressed();
                        return;
                    case"enterPressed":
                        this.triggerEnterPressed();
                        return;
                    case"backspacePressed":
                        if (!this.model.isEmpty()) {
                            return
                        }
                        this.triggerBackspacePressed();
                        return;
                    case"delPressed":
                        if (!this.model.isEmpty()) {
                            return
                        }
                        this.triggerDelPressed();
                        return;
                    case"keydown":
                        if (Keys.lookup(evt) === Keys.ESCAPE) {
                            conditionalBlur()
                        }
                        return
                }
            };
            view.onDuplicate = function () {
                var obj = this.onDuplicateWithoutFocus();
                var view = this.listView.getItemView(obj.id);
                view.addFocus()
            };
            view.onDuplicateWithoutFocus = function () {
                var index = this.model.index;
                var state = this.model.getState();
                state.selected = false;
                delete state.id;
                var list = this.model.list;
                var folder = this.model.folder;
                var obj = ExpressionObject(state, list);
                UndoRedo.oneTransaction(function () {
                    list.insertItemAt(index + 1, obj);
                    if (folder) {
                        folder.addItem(obj)
                    }
                });
                return obj
            };
            view.onMouseSelect = function (evt) {
                if (this.listView.editListMode) {
                    return
                }
                if (evt.wasHandled()) {
                    return
                }
                evt.handle();
                this.model.setProperty("selected", true);
                this.sendTapToMathQuill(evt, this.mathquill)
            };
            view.getDependentLabel = function () {
                var dependent = this.model.dependent;
                if (!dependent) {
                    return ""
                }
                if (dependent.match(/(.*)_(.+)/)) {
                    dependent = dependent.replace(/(.*)_(.+)/, "$1_{$2}")
                }
                dependent = $("<span>" + dependent + "</span>").mathquill("editable").mathquill("html");
                dependent = ("<span class='mathquill-rendered-math'>" + dependent + "</span>");
                return dependent
            };
            var lhs = function (latex) {
                return latex.replace(RegExp("=[^=]+$"), "=")
            };
            view.startTransient = function () {
                this.setProperty("transient", true);
                this.updateTransientValue();
                this.$transientLhs.show();
                this.mathquill.hide();
                this.$transientLhs.mathquill("latex", lhs(this.model.latex));
                this.$transientLhs.children(".mathquill-root-block").append(this.$transientValue)
            };
            view.stopTransient = function () {
                this.setProperty("transient", false);
                this.$transientValue.remove();
                this.$transientLhs.hide();
                this.mathquill.show();
                this.updateMathquill()
            };
            view.updateTransient = function () {
                if (!this.$transientValue || !this.$transientValue.length) {
                    return
                }
                this.stopTransient()
            };
            view.isFocused = function () {
                return $(document.activeElement).closest(this.mathquill).length !== 0
            };
            view.addFocus = function (where) {
                if (Config.get("no_focus")) {
                    return
                }
                if (!this.mathquill) {
                    return
                }
                this.mathquill.mathquill("focus");
                if (where === "start") {
                    this.mathquill.mathquill("moveStart")
                } else {
                    if (where === "end") {
                        this.mathquill.mathquill("moveEnd")
                    }
                }
            };
            view.onCreateTable = function () {
            }
        });
        return ExpressionView
    });
    define("template!list", ["underscore"], function (_) {
        return function (obj) {
            var __p = "";
            var print = function () {
                __p += Array.prototype.join.call(arguments, "")
            };
            with (obj || {}) {
                __p += '<div class="dcg-exppanel-outer">\n\n  <div class="dcg-exppanel-container">\n      <div class="dcg-exppanel dcg-disable-horizontal-scroll-to-cursor">\n\n      <div class="dcg-expressionlist">\n        <span class="dcg-template-expressioneach"></span>\n        <div class="template-newexpression"></div>\n      </div>\n    </div>\n  </div>\n\n  <div class=\'dcg-show-expressions-tab\'>\n    <a\n      class=\'dcg-resize-list-btn dcg-action-showexpressions dcg-tooltip\'\n      tooltip="' + (t("Show List")) + "\"\n    >\n      <i class='dcg-icon-show'></i>\n    </a>\n  </div>\n</div>\n"
            }
            return __p
        }
    });
    define("expressions/list_view", ["require", "jquery", "underscore", "pjs", "config", "tipsy", "underscore_view", "touchtracking", "conditional_blur", "undoredo", "keys", "browser", "jquery.scrollvisible", "./new_expression", "./renderviewport", "./expression", "./expression_view", "template!list"], function (require) {
        var $ = require("jquery");
        var _ = require("underscore");
        var P = require("pjs");
        var Config = require("config");
        require("tipsy");
        var UnderscoreView = require("underscore_view");
        var touchtracking = require("touchtracking");
        var conditionalBlur = require("conditional_blur");
        var UndoRedo = require("undoredo");
        var Keys = require("keys");
        var Browser = require("browser");
        require("jquery.scrollvisible");
        var NewExpressionView = require("./new_expression");
        require("./renderviewport");
        var ExpressionObject = require("./expression");
        var ExpressionView = require("./expression_view");
        var template = require("template!list");
        var ExpressionListView = P(UnderscoreView, function (view, _super) {
            view.__itemViews = {};
            view.__latexChangeCallbacks = [];
            view.keypadView = null;
            view.isTransient = false;
            view.transientChildren = [];
            view.template = template;
            view.minWidth = 356;
            view.isTablet = Config.get("tablet");
            view.triggerClearGraph = function () {
            };
            view.getTemplateParams = function () {
                return {IS_TABLET: this.isTablet}
            };
            view.onLatexChange = function (latex) {
                _.each(this.__latexChangeCallbacks, function (cb) {
                    cb(latex)
                })
            };
            view.init = function (model, $root, toastView, graphSettings) {
                _super.init.call(this);
                this.$root = $root || $("body");
                this.toastView = toastView;
                this.graphSettings = graphSettings;
                this.model = model;
                this.model.triggerItemInserted = this.onItemInserted.bind(this);
                this.model.triggerItemRemoved = this.onItemRemoved.bind(this);
                this.model.triggerItemMoved = this.onItemMoved.bind(this);
                this.model.triggerSetState = this.onSetState.bind(this);
                this.observe("itemFocused", this.renderItemFocused.bind(this));
                this.observe("editListMode", this.renderEditListMode.bind(this));
                this.model.observe("selectedItem", this.ensureActiveChildIsVisible.bind(this));
                this.createAllItemViews()
            };
            view.computeTransient = function () {
                this.setProperty("transient", this.transientChildren.length > 0)
            };
            view.padLastExpression = function (padding) {
                var $lastExp = this.$(".dcg-expressionitem.dcg-new-expression");
                $lastExp.css("margin-bottom", +padding + "px")
            };
            view.unpadLastExpression = function () {
                var $lastExp = this.$(".dcg-expressionitem.dcg-new-expression");
                $lastExp.css("margin-bottom", "0")
            };
            view.padLastExpressionUntilTapEnd = function (padding) {
                var self = this;
                this.padLastExpression(padding);
                $(document).on("tap.animating-bottom", function () {
                    if (self.$(".dcg-exp-options-menu").length === 0) {
                        self.unpadLastExpression();
                        $(document).off("tap.animating-bottom")
                    }
                })
            };
            view.setMinWidth = function (newWidth) {
                if (!this.$().length) {
                    return
                }
                if (newWidth === this.minWidth) {
                    return
                }
                this.minWidth = newWidth;
                var newCss = {minWidth: newWidth};
                if (!this.itemFocused) {
                    newCss.maxWidth = newWidth
                }
                this.$exppanelContainer.css(newCss);
                _.each(this.__itemViews, function (view) {
                    view.setMinWidth()
                })
            };
            view.updateWidth = function () {
                if (!this.$().length) {
                    return
                }
                var exppanel = this.$exppanelContainer;
                var maxWidth = 0;
                if (exppanel.css("min-width") === "100%") {
                    return
                }
                var minWidth = this.minWidth;
                this.$(".dcg-disable-horizontal-scroll-to-cursor").scrollLeft(0);
                function includeWidth($element) {
                    var main = $element.find(".dcg-main");
                    if (!main.length) {
                        return
                    }
                    var width = main.outerWidth() + main.offset().left + 5;
                    if (width > maxWidth) {
                        maxWidth = width
                    }
                }

                var selected = this.getSelectedView();
                if (selected && (this.itemFocused || selected.model.isTable)) {
                    includeWidth(selected.$())
                }
                if (this.editListMode) {
                    this.$(".dcg-expressiontable").each(function () {
                        includeWidth($(this))
                    })
                }
                if (maxWidth < minWidth) {
                    maxWidth = minWidth
                }
            };
            view.onItemInserted = function (index, item) {
                if (this.newExpressionView) {
                    this.newExpressionView.setProperty("index", this.model.getItemCount() + 1)
                }
                if (this.$items) {
                    var view = this.createItemView(item);
                    if (view) {
                        if (index === 0) {
                            view.prependTo(this.$items)
                        } else {
                            if (index === this.model.getItemCount() - 1) {
                                view.appendTo(this.$items)
                            } else {
                                view.insertAfter(this.$items.children(":nth-child(" + index + ")"))
                            }
                        }
                        if (this.editListMode) {
                            view.$().css({transform: "scale(0,0)", opacity: 0});
                            setTimeout(function () {
                                view.$().css({transition: ".2s", opacity: 1, transform: ""})
                            }, 1);
                            setTimeout(function () {
                                view.$().css({transition: "none"})
                            }, 300)
                        }
                    }
                    var len = this.model.getItemCount();
                    for (var i = index; i < len; i++) {
                        this.model.getItemByIndex(i).setProperty("index", i)
                    }
                    this.updateWidth()
                }
            };
            view.onItemRemoved = function (index, item) {
                var item_id = String(item.id);
                item.unobserve(".listview");
                if (this.newExpressionView) {
                    this.newExpressionView.setProperty("index", this.model.getItemCount() + 1)
                }
                var view = this.__itemViews[item_id];
                if (view) {
                    view.remove();
                    delete this.__itemViews[item_id];
                    var len = this.model.getItemCount();
                    for (var i = index; i < len; i++) {
                        this.model.getItemByIndex(i).setProperty("index", i)
                    }
                }
                this.updateWidth()
            };
            view.onItemMoved = function (from, to) {
                var min_affected = Math.min(from, to);
                var max_affected = Math.max(from, to);
                for (var i = min_affected; i <= max_affected; i++) {
                    this.model.getItemByIndex(i).setProperty("index", i)
                }
                var view = this.getItemView(this.model.getItemByIndex(to).id);
                if (view) {
                    var $items = this.$items;
                    if (to === 0) {
                        $items.prepend(view.$())
                    } else {
                        if (to === this.model.getItemCount() - 1) {
                            $items.append(view.$())
                        } else {
                            var child_index = to + (to > from ? 1 : 0);
                            view.$().insertAfter($items.children(":nth-child(" + child_index + ")"))
                        }
                    }
                }
            };
            view.onSetState = function (list) {
                for (var id in this.__itemViews) {
                    if (this.__itemViews.hasOwnProperty(id)) {
                        this.__itemViews[id].remove()
                    }
                }
                this.__itemViews = {};
                if (this.newExpressionView) {
                    this.newExpressionView.setProperty("index", this.model.getItemCount() + 1)
                }
                this.createAllItemViews();
                this.appendAllItemViews()
            };
            view.renderItemFocused = function () {
                this.$root.toggleClass("dcg-ITEM-FOCUSED", !!this.itemFocused)
            };
            view.instantiateItemView = function (item) {
                if (item.isExpression) {
                    return ExpressionView(item, this)
                }
            };
            view.createItemView = function (item) {
                var view = this.instantiateItemView(item);
                var item_id = String(item.id);
                if (view) {
                    this.__itemViews[item_id] = view;
                    var self = this;
                    view.triggerDelete = function () {
                        self.onDelete(view)
                    };
                    view.triggerEnterPressed = function () {
                        self.onEnterPressed(view)
                    };
                    view.triggerUpPressed = function () {
                        self.onUpPressed(view)
                    };
                    view.triggerDownPressed = function () {
                        self.onDownPressed(view)
                    };
                    view.triggerBackspacePressed = function () {
                        self.onBackspacePressed(view)
                    };
                    view.triggerDelPressed = function () {
                        self.onDelPressed(view)
                    };
                    view.observe("transient", function (prop, view) {
                        self.transientChildren = _(self.transientChildren).without(view);
                        self.computeTransient()
                    })
                }
                return view
            };
            view.createAllItemViews = function () {
                var len = this.model.getItemCount();
                for (var i = 0; i < len; i++) {
                    var item = this.model.getItemByIndex(i);
                    this.createItemView(item)
                }
            };
            view.appendAllItemViews = function () {
                if (!this.$items) {
                    return
                }
                var len = this.model.getItemCount();
                for (var i = 0; i < len; i++) {
                    var item = this.model.getItemByIndex(i);
                    var view = this.getItemView(item.id);
                    view.appendTo(this.$items)
                }
                this.updateWidth()
            };
            view.getItemView = function (id) {
                return this.__itemViews[String(id)]
            };
            view.onDelete = function (view) {
                var self = this;
                var edit_main = view.$().find(".mathquill-editable");
                edit_main.mathquill("latex", "");
                setTimeout(function () {
                    getResult()
                }, 500)
            };
            view.onUpPressed = function (view) {
                return;
                if (view.model.index === 0) {
                    return
                }
                this.selectPrevExpression(view.model);
                this.getSelectedView().addFocus("end")
            };
            view.onDownPressed = function (view) {
                return;
                this.selectNextExpression(view.model);
                this.getSelectedView().addFocus("start")
            };
            view.onBackspacePressed = function (view) {
                return;
                var wasText = view.model.isText;
                var nextItem = this.model.getItemByIndex(view.model.index + 1);
                if (view.model.folder && (!nextItem || !nextItem.folder)) {
                    view.model.folder.removeItem(view.model);
                    return
                }
                this.upwardDeleteExpression(view.model);
                if (wasText && Browser.IS_IPAD && Browser.IS_IN_IFRAME) {
                    this.model.setSelected(null);
                    return
                }
                this.getSelectedView().addFocus("end")
            };
            view.onDelPressed = function (view) {
                return;
                this.downwardDeleteExpression(view.model);
                this.getSelectedView().addFocus("start")
            };
            view.onEnterPressed = function (view) {
                if (!Demo.onNeedEnter) {
                    return
                }
                if (view.model.isText && Browser.IS_IPAD && Browser.IS_IN_IFRAME) {
                    conditionalBlur();
                    this.model.setSelected(null);
                    return
                }
                var obj = ExpressionObject({selected: false}, this.model);
                var self = this;
                var insertIndex = view.model.index + 1;
                if (view.model.isFolder && view.model.collapsed) {
                    insertIndex += _(view.model.memberIds).keys().length
                }
                UndoRedo.oneTransaction(function () {
                    self.model.insertItemAt(insertIndex, obj);
                    if (view.model.isFolder && !view.model.collapsed) {
                        view.model.addItem(obj)
                    }
                    if (view.model.folder) {
                        view.model.folder.addItem(obj)
                    }
                });
                Demo.onEnterCallBack(1)
            };
            view.expressionsVisible = true;
            view.hideExpressions = function () {
                this.model.setSelected(null);
                conditionalBlur();
                this.setProperty("expressionsVisible", false)
            };
            view.showExpressions = function () {
                this.setProperty("expressionsVisible", true);
                conditionalBlur()
            };
            view.renderEditListMode = function () {
                var $root = this.$root;
                var self = this;
                if (this.editListMode) {
                    $root.addClass("dcg-EDIT-LIST-MODE");
                    this.model.setSelected(null);
                    this.model.stopAllSliders();
                    $(document).on("tapstart.edit-list-mode", function (evt) {
                        if ($(evt.target).closest(".dcg-exppanel").length === 0 && $(evt.target).closest(".dcg-options-menu").length === 0 && $(evt.target).closest(".dcg-expression-top-bar").length === 0) {
                            self.setProperty("editListMode", false)
                        }
                    })
                } else {
                    $root.removeClass("dcg-EDIT-LIST-MODE");
                    $(document).off(".edit-list-mode")
                }
            };
            view.handleFocusChange = function (focused) {
                var target = $(focused);
                var inMathquill = target.closest(".mathquill-rendered-math").length !== 0;
                var inEditableMathquill = target.closest(".mathquill-editable").length !== 0;
                var inMathquillWithMathField = target.closest(".mathquill-rendered-math:not(.mathquill-editable)").find(".mathquill-editable").length !== 0;
                var inMathInput = target.closest(".dcg-math-input").length !== 0;
                var inText = target.closest(".dcg-expressiontext").length !== 0;
                var inFolder = target.closest(".dcg-expressionfolder").length !== 0;
                if (!inEditableMathquill && inMathquill && inMathquillWithMathField) {
                    inMathquill = false;
                    inEditableMathquill = false;
                    inMathInput = false
                }
                if (!inMathInput && (inMathquill || inEditableMathquill || inText || inFolder)) {
                    this.setProperty("editListMode", false)
                }
                this.setProperty("itemFocused", inMathquill || inEditableMathquill);
                this.setProperty("needFakeKeypad", inMathquill || inEditableMathquill);
                this.setProperty("editDisabled", inMathquill && !inEditableMathquill)
            };
            view.onFocusIn = function (evt) {
                if (!this.expressionsVisible) {
                    this.showExpressions()
                }
                this.handleFocusChange(evt.target);
                clearTimeout(this.fakeKeypadTimeout)
            };
            view.onFocusOut = function () {
                clearTimeout(this.fakeKeypadTimeout);
                this.fakeKeypadTimeout = setTimeout(function () {
                    this.handleFocusChange(document.activeElement)
                }.bind(this), 0)
            };
            view.offset = function () {
                return this.$().offset()
            };
            view.setBottom = function (bottom) {
                if (!this.$().length) {
                    return
                }
                var oldBottom = parseFloat(this.$().css("bottom").slice(0, -2));
                if (!isFinite(oldBottom)) {
                    oldBottom = 0
                }
                this.$().css("bottom", bottom + "px");
                if (bottom === 0 && touchtracking.isTapActive()) {
                    this.padLastExpressionUntilTapEnd(oldBottom)
                }
            };
            view.didCreateElement = function () {
                var self = this;
                _super.didCreateElement.call(this);
                this.$().tipsy({fade: "fast", title: "tooltip", wait: 500, delegate: ".dcg-tooltip"});
                this.$exppanelContainer = this.$(".dcg-exppanel-container");
                this.$exppanel = this.$(".dcg-exppanel");
                this.$items = this.$(".dcg-template-expressioneach");
                this.appendAllItemViews();
                this.$exppanel.scroll(function (evt) {
                    this.$(".dcg-expression-top-bar").toggleClass("dcg-expressions-scrolled", $(evt.target).scrollTop() > 0)
                }.bind(this));
                this.$exppanel.on("tapstart", function (evt) {
                    if (evt.device === "mouse") {
                        return
                    }
                    if ($(evt.target).closest(".dcg-expressionitem").length === 0) {
                        conditionalBlur()
                    }
                });
                this.$exppanel.on("keypress", this.ensureActiveChildIsVisible.bind(this));
                this.$(".dcg-expression-top-bar").on("tapstart", function (evt) {
                    if (evt.wasHandled()) {
                        return
                    }
                    self.model.setSelected(null)
                });
                this.$().on("tap", ".dcg-action-clearall", function () {
                    self.triggerClearGraph();
                    self.toastView.show("Graph cleared.", function () {
                        self.setProperty("editListMode", true)
                    })
                });
                this.$().on("tap", ".dcg-action-undo", function () {
                    UndoRedo.undo()
                });
                this.$().on("tap", ".dcg-action-redo", function () {
                    UndoRedo.redo()
                });
                this.$().on("focusout", this.onFocusOut.bind(this));
                this.$().on("focusin", this.onFocusIn.bind(this));
                this.$(".dcg-action-toggle-edit").on("tap", function () {
                    self.setProperty("editListMode", !self.editListMode)
                });
                this.$(".dcg-action-hideexpressions").on("tap", this.hideExpressions.bind(this));
                this.$(".dcg-action-showexpressions").on("tap", this.showExpressions.bind(this));
                $(document.documentElement).on("keydown", this.handleKeyDown.bind(this));
                this.renderItemFocused();
                this.renderEditListMode();
                this.newExpressionView = NewExpressionView(this);
                this.newExpressionView.replace(this.$(".template-newexpression"));
                this.newExpressionView.setProperty("index", this.model.getItemCount() + 1);
                this.$().on("render", function (evt) {
                    self.updateWidth()
                });
                this.model.observe("selectedItem", function () {
                    self.updateWidth()
                });
                this.observe("editListMode itemFocused", function () {
                    self.updateWidth()
                });
                this.$().on("focusin", function () {
                    setTimeout(function () {
                        self.updateWidth()
                    }, 0)
                })
            };
            view.didInsertElement = function () {
                this.updateWidth();
                this.$exppanelContainer.addClass("dcg-do-animate")
            };
            view.getFirstVisibleItem = function () {
                var top = this.$exppanel.offset().top;
                var el = this.expressionAtPoint(0, top);
                if (!el) {
                    return this.model.getItemByIndex(0)
                }
                if (this.getItemView(el.id).$().offset().top < top - 2) {
                    el = this.model.getItemByIndex(el.index + 1)
                }
                return el
            };
            view.appendBlankExpression = function () {
                this.newExpressionView.newMath()
            };
            view.ensureActiveChildIsVisible = function () {
                if (!this.$().is(":visible")) {
                    return
                }
                if (this.model.selectedItem) {
                    var selectedView = this.getItemView(this.model.selectedItem.id);
                    if (selectedView) {
                        var self = this;
                        setTimeout(function () {
                            var active = $(document.activeElement);
                            var mathquill = active.closest(".mathquill-editable");
                            if (mathquill.length) {
                                self.$exppanel.scrollVisible(mathquill, 15, -50)
                            } else {
                                if (active.closest(".dcg-expressionitem").length) {
                                    self.$exppanel.scrollVisible(active, 10, -10)
                                } else {
                                    self.$exppanel.scrollVisible(selectedView.$(), 10, -10)
                                }
                            }
                        }, 1)
                    }
                }
            };
            view.handleKeyDown = function (evt) {
                if ($.contains(document.body, document.activeElement)) {
                    return
                }
                if ($(evt.target).closest(".dcg-exppanel").length) {
                    return
                }
                if (!$.contains(document.documentElement, evt.target)) {
                    return
                }
                var selected = this.getSelectedView();
                if (selected && selected.isFocused()) {
                    selected.processMissedKeyEvent(evt);
                    return
                }
                var key = Keys.lookup(evt);
                if (key === Keys.SPACEBAR) {
                    this.model.toggleAllSliders();
                    return
                }
                if (!selected) {
                    return
                }
                switch (key) {
                    case Keys.UP:
                        evt.preventDefault();
                        this.selectPrevExpression(selected.model);
                        break;
                    case Keys.DOWN:
                        evt.preventDefault();
                        this.selectNextExpression(selected.model, true);
                        break;
                    case Keys.ESCAPE:
                        evt.preventDefault();
                        this.model.setSelected(null);
                        break;
                    case Keys.RIGHT:
                    case Keys.TAB:
                        evt.preventDefault();
                        if (selected) {
                            if (selected.model.isTable) {
                                selected.addFocus("cell", 0, 0)
                            } else {
                                selected.addFocus("start")
                            }
                        }
                        break;
                    case Keys.LEFT:
                        evt.preventDefault();
                        if (selected) {
                            if (selected.model.isTable) {
                                selected.addFocus("cell", 0, selected.model.columns.length - 1)
                            } else {
                                selected.addFocus("end")
                            }
                        }
                        break;
                    case Keys.BACKSPACE:
                        evt.preventDefault();
                        clickHandler("key", "Backspace", "");
                        return;
                        if (selected) {
                            this.upwardDeleteExpression(selected.model)
                        }
                        break;
                    case Keys.DELETE:
                        evt.preventDefault();
                        if (selected) {
                            this.downwardDeleteExpression(selected.model)
                        }
                        break;
                    case Keys.ENTER:
                        evt.preventDefault();
                        if (selected) {
                            this.onEnterPressed(selected)
                        }
                        break;
                    default:
                        if (evt.metaKey || evt.ctrlKey || key === Keys.SHIFT || key === Keys.SPACEBAR) {
                            return
                        }
                        if (selected) {
                            if (selected.model.isTable) {
                            } else {
                                selected.addFocus("end")
                            }
                        }
                }
            };
            view.getSelectedView = function () {
                var selected = this.model.getSelected();
                if (selected) {
                    var view = this.getItemView(selected.id);
                    return view
                }
                return null
            };
            view.upwardDeleteExpression = function (expression) {
                var index = expression.index;
                var prev = this.model.getItemByIndex(this.findPrevSelectableIndex(index));
                var self = this;
                UndoRedo.oneTransaction(function () {
                    self.model.removeItemAt(index);
                    if (self.model.getItemCount() === 0) {
                        prev = ExpressionObject(undefined, self.model);
                        self.model.insertItemAt(0, prev)
                    }
                    if (!prev) {
                        prev = self.model.getItemByIndex(self.findNextSelectableIndex(index - 1))
                    }
                    if (prev) {
                        prev.setProperty("selected", true)
                    }
                })
            };
            view.findPrevSelectableIndex = function (index) {
                var item;
                do {
                    index--;
                    item = this.model.getItemByIndex(index)
                } while (item && item.inCollapsedFolder);
                return item ? index : undefined
            };
            view.findNextSelectableIndex = function (index) {
                var item;
                do {
                    index++;
                    item = this.model.getItemByIndex(index)
                } while (item && item.inCollapsedFolder);
                return item ? index : undefined
            };
            view.downwardDeleteExpression = function (expression) {
                var index = expression.index;
                var next = this.model.getItemByIndex(this.findNextSelectableIndex(index));
                var self = this;
                if (next) {
                    this.model.setSelected(next);
                    this.model.removeItemAt(index)
                } else {
                    if (this.model.getItemCount() > 1) {
                        this.model.setSelected(index - 1);
                        this.model.removeItemAt(index)
                    } else {
                        UndoRedo.oneTransaction(function () {
                            self.model.removeItemAt(0);
                            self.model.insertItemAt(0, ExpressionObject(undefined, self.model));
                            self.model.setSelected(0)
                        })
                    }
                }
            };
            view.selectPrevExpression = function (expression) {
                if (!expression) {
                    return
                }
                var index = expression.index;
                var prev = this.model.getItemByIndex(this.findPrevSelectableIndex(index));
                if (prev) {
                    prev.setProperty("selected", true)
                }
            };
            view.selectNextExpression = function (expression, dontCreateNew) {
                if (!expression) {
                    return
                }
                var index = expression.index;
                var next = this.model.getItemByIndex(this.findNextSelectableIndex(index));
                if (next) {
                    next.setProperty("selected", true)
                } else {
                    if (!dontCreateNew) {
                    }
                }
            };
            view._getVisibleViews = function () {
                var visibleViews = [];
                for (var i = 0; i < this.model.getItemCount(); i++) {
                    var exp = this.model.getItemByIndex(i);
                    var view = this.getItemView(exp.id);
                    if (view && view.$().is(":visible")) {
                        visibleViews.push(view)
                    }
                }
                return visibleViews
            };
            view.expressionAtPoint = function (x, y) {
                var visibleViews = this._getVisibleViews();
                var lo = 0;
                var hi = visibleViews.length - 1;
                while (lo <= hi) {
                    var mid = lo + Math.floor((hi - lo) / 2);
                    var view = visibleViews[mid];
                    var rect = view.getBounds();
                    if (rect.top > y) {
                        hi = mid - 1
                    } else {
                        if (rect.bottom < y) {
                            lo = mid + 1
                        } else {
                            return view.model
                        }
                    }
                }
                return null
            };
            view.expressionAbovePoint = function (x, y) {
                var visibleViews = this._getVisibleViews();
                var lo = 0;
                var hi = visibleViews.length - 1;
                var found = null;
                while (lo <= hi) {
                    var mid = lo + Math.floor((hi - lo) / 2);
                    var view = visibleViews[mid];
                    var rect = view.getBounds();
                    if (rect.top > y) {
                        hi = mid - 1
                    } else {
                        lo = mid + 1;
                        found = view.model
                    }
                }
                return found
            };
            view.getActiveMathquill = function () {
                return $(document.activeElement).closest(".mathquill-editable")
            };
            view.onProjectorModeChange = function () {
                for (var id in this.__itemViews) {
                    if (this.__itemViews.hasOwnProperty(id)) {
                        this.__itemViews[id].onProjectorModeChange()
                    }
                }
            }
        });
        return ExpressionListView
    });
    define("main/state_controller", ["require", "pjs", "undoredo", "expressions/colors", "jquery"], function (require) {
        var P = require("pjs");
        var UndoRedo = require("undoredo");
        var Colors = require("expressions/colors");
        var $ = require("jquery");
        var StateController = P(function (proto) {
            var BLANK_STATE = {
                graph: {viewport: {xmin: -10, xmax: 10, ymin: -10, ymax: 10}, showLabels: true, showGrid: true, showAxes: true, squareAxes: true, labelXMode: "", labelYMode: ""},
                expressions: {list: [{id: 1, latex: ""}]}
            };
            proto.init = function (grapher, expressionsModel, graphSettings) {
                this.grapher = grapher;
                this.expressionsModel = expressionsModel;
                this.graphSettings = graphSettings;
                this.isFirstSetState = true
            };
            proto.getState = function () {
                return {expressions: this.expressionsModel.getState()}
            };
            proto.setState = function (state) {
                this.graphSettings.setProperty("POIs", false);
                this.expressionsModel.setSelected(null);
                if (!this.isFirstSetState && (state === null) && this.expressionsModel.isEmpty()) {
                    return
                }
                var self = this;
                var manipulator = function (state) {
                    Colors.reset();
                    if (!state) {
                        state = BLANK_STATE
                    }
                    if (typeof state === "string") {
                        state = JSON.parse(state)
                    }
                    if ("expressions" in state) {
                        self.expressionsModel.setState({list: []})
                    }
                    if ("graph" in state) {
                        if (!("degreeMode" in state.graph)) {
                            state.graph.degreeMode = false
                        }
                    }
                    if ("expressions" in state) {
                        self.expressionsModel.setState(state.expressions)
                    }
                };
                if (this.isFirstSetState) {
                    manipulator(state);
                    this.isFirstSetState = false;
                    return
                }
                var curState = this.getState();
                UndoRedo.addTransaction({
                    type: UndoRedo.CAUSE_OF_CHANGE, undo: function () {
                        manipulator(curState)
                    }, redo: function () {
                        manipulator(state)
                    }, ensureChangeOccured: function () {
                        var newState = JSON.stringify(self.getState());
                        var oldState = JSON.stringify(curState);
                        return oldState === newState
                    }
                })
            };
            proto.setBlank = function () {
                this.setState(BLANK_STATE);
                UndoRedo.markAsSaved()
            };
            proto.setStateFromURL = function (url) {
                return $.getJSON(url).done(function (msg) {
                    this.setState(msg.state)
                }.bind(this))
            }
        });
        return StateController
    });
    define("template!toast", ["underscore"], function (_) {
        return function (obj) {
            var __p = "";
            var print = function () {
                __p += Array.prototype.join.call(arguments, "")
            };
            with (obj || {}) {
                __p += '<div class="toast-container">\n  <span class="toast">\n    <span class="dcg-msg dcg-variable-msg"></span>\n    <a class="dcg-action-toast-undo">' + (t("Undo")) + "</a>\n  </span>\n</div>"
            }
            return __p
        }
    });
    define("main/toast", ["require", "jquery", "pjs", "underscore_view", "undoredo", "template!toast"], function (require) {
        var $ = require("jquery");
        var P = require("pjs");
        var UnderscoreView = require("underscore_view");
        var UndoRedo = require("undoredo");
        var template = require("template!toast");
        var ToastView = P(UnderscoreView, function (toast, _super) {
            toast.template = template;
            toast.didCreateElement = function () {
                var self = this;
                UndoRedo.changesCallbacks.push(function () {
                    self.hide()
                });
                this.$(".dcg-action-toast-undo").on("tap", function () {
                    UndoRedo.undo();
                    if (self.callback) {
                        self.callback()
                    }
                    self.hide()
                });
                this.$().toggle(false)
            };
            toast.show = function (str, cb) {
                clearTimeout(this.hideTimeout);
                $(".toast-container").fadeOut("fast");
                this.$().fadeIn("fast");
                this.$(".dcg-variable-msg").text(str);
                this.callback = cb;
                var self = this;
                this.hideTimeout = setTimeout(function () {
                    self.hide()
                }, 6000)
            };
            toast.hide = function () {
                clearTimeout(this.hideTimeout);
                this.$().fadeOut("fast")
            }
        });
        return ToastView
    });
    define("main/calc_embed", ["require", "jquery", "underscore", "pjs", "config", "main/evaluator", "graphing/grapher", "main/graph_settings", "graphing/viewport", "expressions/list", "expressions/list_view", "main/focus", "undoredo", "main/state_controller", "browser", "main/toast"], function (require) {
        var $ = require("jquery");
        var _ = require("underscore");
        var P = require("pjs");
        var Config = require("config");
        var Evaluator = require("main/evaluator");
        var Grapher = require("graphing/grapher");
        var GraphSettings = require("main/graph_settings");
        var Viewport = require("graphing/viewport");
        var ExpressionList = require("expressions/list");
        var ExpressionListView = require("expressions/list_view");
        var Focus = require("main/focus");
        var UndoRedo = require("undoredo");
        var StateController = require("main/state_controller");
        var Browser = require("browser");
        var ToastView = require("main/toast");
        var Calc = P(function (proto) {
            proto.init = function (elt) {
                var containerClasses = ["dcg-container"];
                if (!Config.get("menus")) {
                    containerClasses.push("dcg-no-menus")
                }
                if (!Config.get("zoomButtons")) {
                    containerClasses.push("dcg-no-zoom")
                }
                var $embedContainer = $('<div class="' + containerClasses.join(" ") + '">');
                var $graphpaper = $('<div class="dcg-grapher">');
                var toastView = ToastView();
                var evaluator = Evaluator(Config.get("workerURL"));
                var graphSettings = GraphSettings();
                var keypadView;
                var expressionsModel = ExpressionList();
                var expressionsView;
                if (Config.get("noexpressions") || Config.get("expressionsCollapsed")) {
                    $embedContainer.addClass("dcg-fullscreen")
                }
                if (!Config.get("noexpressions")) {
                    expressionsView = ExpressionListView(expressionsModel, $embedContainer, toastView, graphSettings)
                }
                if (Browser.IS_IE9 && $graphpaper.width() === 0) {
                    var iframes = $(window.parent.document).find("iframe");
                    var thisFrame = _.find(iframes, function (iframe) {
                        var frameBody = $(iframe).contents().find("body[data-load-data]");
                        if (frameBody.length > 0) {
                            var seed = frameBody.data("load-data").seed;
                            return seed === $("body").data("load-data").seed
                        } else {
                            return false
                        }
                    });
                    if (thisFrame) {
                        $graphpaper.width($(thisFrame).width() - 300);
                        $graphpaper.height($(thisFrame).height())
                    }
                }
                if (Config.get("keypad") && expressionsView) {
                }
                if (Config.get("nographpaper")) {
                    $embedContainer.addClass("dcg-no-graphpaper")
                }
                $embedContainer.appendTo(elt);
                graphSettings.registerCallbacks({}, expressionsView, $embedContainer);
                graphSettings.observe("degreeMode", function () {
                    evaluator.setDegreeMode(graphSettings.degreeMode)
                });
                var stateController = StateController({}, expressionsModel, graphSettings);
                evaluator.triggerStatusChange = function (changes) {
                    expressionsModel.onChange(changes)
                };
                evaluator.triggerGraphComputed = function (id, graphData) {
                    expressionsModel.onGraphComputed(id, graphData)
                };
                evaluator.triggerRemove = function (id) {
                };
                evaluator.triggerUpdateIntersections = function (id, intersections) {
                };
                evaluator.triggerRender = function () {
                };
                evaluator.triggerRenderSlowly = function () {
                };
                expressionsModel.triggerAddExp = function (obj) {
                    if (!obj) {
                        return
                    }
                    if (obj.latex === "" && this.type !== "table") {
                    }
                    evaluator.addStatement(obj)
                };
                expressionsModel.triggerRemoveExp = function (id) {
                    evaluator.removeStatement(id)
                };
                expressionsModel.triggerRemoveExps = function (ids) {
                    evaluator.removeStatements(ids)
                };
                expressionsModel.observe("drawOrder", function () {
                });
                UndoRedo.oneTransactionWrapper = evaluator.batch.bind(evaluator);
                expressionsModel.batchEvaluation = evaluator.batch.bind(evaluator);
                if (expressionsView) {
                    expressionsView.triggerClearGraph = function () {
                        stateController.setBlank()
                    }
                }
                expressionsModel.triggerAddImage = function (image) {
                    if (image.imageObj.width && image.imageObj.height) {
                    } else {
                        $(image.imageObj).on("load.calc_load", function () {
                        })
                    }
                };
                expressionsModel.triggerRemoveImage = function (image) {
                    $(image.imageObj).off("load.calc_load")
                };
                expressionsModel.triggerRedrawImages = function () {
                };
                Focus.takeFocus = function () {
                    expressionsModel.setSelected(null)
                };
                if (expressionsView) {
                    expressionsView.appendTo($embedContainer)
                }
                $(document).bind("keydown", UndoRedo.handleKeydown.bind(UndoRedo));
                this.expressionsModel = expressionsModel;
                if (expressionsView) {
                    this.expressions = expressionsView
                }
                this.evaluator = evaluator;
                this.setState = stateController.setState.bind(stateController);
                this.setBlank = stateController.setBlank.bind(stateController);
                this.getState = stateController.getState.bind(stateController);
                this.setStateFromURL = stateController.setStateFromURL.bind(stateController);
                this.changedSinceSave = UndoRedo.changedSinceSave.bind(UndoRedo);
                this.setViewport = function (bounds) {
                };
                this.resize = function () {
                    layoutController.resize()
                };
                this.interceptTouch = function () {
                    var elts = $graphpaper;
                    if (expressionsView) {
                        elts = elts.add(expressionsView.$(".dcg-expression-top-bar"))
                    }
                    if (keypadView) {
                        elts = elts.add(keypadView.$())
                    }
                    elts.on("touchstart", function (evt) {
                        evt.preventDefault()
                    })
                };
                this.setOptions = function (options) {
                    var needsResize = false;
                    if (options.hasOwnProperty("solutions")) {
                        $embedContainer.toggleClass("dcg-no-solutions", !options.solutions)
                    }
                    if (options.hasOwnProperty("menus")) {
                        $embedContainer.toggleClass("dcg-no-menus", !options.menus);
                        needsResize = true
                    }
                    if (options.hasOwnProperty("graphpaper")) {
                        $embedContainer.toggleClass("dcg-no-graphpaper", !options.graphpaper);
                        needsResize = true
                    }
                    if (options.hasOwnProperty("zoomButtons")) {
                        $embedContainer.toggleClass("dcg-no-zoom", !options.zoomButtons)
                    }
                    if (options.hasOwnProperty("expressionsCollapsed") && expressionsView) {
                        if (options.expressionsCollapsed) {
                            expressionsView.hideExpressions()
                        } else {
                            expressionsView.showExpressions()
                        }
                    }
                    if (options.hasOwnProperty("keypad")) {
                        console.warn("Bad option {keypad: " + options.keypad + "}. The keypad can only be added or removed at load time, not at runtime.")
                    }
                    if (options.hasOwnProperty("expressions")) {
                        console.warn("Bad option {expressions: " + options.expressions + "}. The expressions can only be added or removed at load time, not at runtime.")
                    }
                    if (needsResize) {
                        layoutController.resize()
                    }
                };
                stateController.setBlank();
                if (Config.get("expressionsCollapsed")) {
                    this.setOptions({expressionsCollapsed: true})
                }
            }
        });
        return Calc
    });
    define("api/forwardmessages", ["require"], function (require) {
        var init = function (Calc) {
            function reply(event, data) {
                event.source.postMessage(JSON.stringify(data), event.origin)
            }

            var receiveMessage = function (event) {
                var eventData = JSON.parse(event.data);
                if (listeners.hasOwnProperty(eventData.type)) {
                    listeners[eventData.type](event, eventData.payload)
                } else {
                    console.warn("Unsupported API call [" + eventData.type + "].Only getState, setState, and setBlank are supported in the iframe API.")
                }
            };
            var listeners = {};
            listeners.setState = function (event, state) {
                Calc.setState(JSON.parse(state))
            };
            listeners.setBlank = function (event) {
                Calc.setBlank()
            };
            listeners.setOptions = function (event, options) {
                Calc.setOptions(options)
            };
            listeners.getState = function (event) {
                var state = Calc.getState();
                reply(event, {type: "getState", payload: JSON.stringify(state)})
            };
            window.addEventListener("message", receiveMessage, false);
            if (parent !== window) {
                parent.postMessage(JSON.stringify({type: "ready"}), "*")
            }
        };
        return init
    });
    if (!window.Desmos) {
        window.Desmos = {}
    }
    define("api/abstract_api", ["require", "pjs", "expressions/colors", "config", "./forwardmessages"], function (require) {
        var P = require("pjs");
        var Colors = require("expressions/colors");
        var Config = require("config");
        var ForwardMessages = require("./forwardmessages");

        function _parseExpression(expression) {
            var obj;
            if (typeof expression === "string") {
                obj = {latex: expression}
            } else {
                if (expression.headings !== undefined) {
                    obj = expression;
                    obj.headings = obj.headings.map(function (heading) {
                        return (typeof heading === "string") ? {latex: heading} : heading
                    })
                } else {
                    obj = expression
                }
            }
            return obj
        }

        function validatedOptions(options) {
            var out = {};
            if (!options) {
                return out
            }
            if (options.hasOwnProperty("keypad")) {
                out.keypad = options.keypad
            }
            if (options.hasOwnProperty("handwriting")) {
                out.handwriting = options.handwriting
            }
            if (options.hasOwnProperty("menus")) {
                out.menus = options.menus
            }
            if (options.hasOwnProperty("graphpaper")) {
                out.nographpaper = !options.graphpaper
            }
            if (options.hasOwnProperty("expressions")) {
                out.noexpressions = !options.expressions
            }
            if (options.hasOwnProperty("zoomButtons")) {
                out.zoomButtons = options.zoomButtons
            }
            if (options.hasOwnProperty("solutions")) {
                out.solutions = options.solutions
            }
            if (options.hasOwnProperty("expressionsCollapsed")) {
                out.expressionsCollapsed = options.expressionsCollapsed
            }
            if (options.hasOwnProperty("lockViewport")) {
                out.lockViewport = options.lockViewport
            }
            if (out.nographpaper && out.expressionsCollapsed) {
                out.expressionsCollapsed = false;
                console.warn("Desmos API initialized with bad options. graphpaper: false and expressionsCollapsed: true are incompatible. Proceeding with expressionsCollapsed: false.")
            }
            if (out.menus && out.zoomButtons) {
                out.zoomButtons = false;
                console.warn("Desmos API initialized with bad options. menus: true and zoomButtons: true are currently incompatible. Proceeding with zoomButtons: false.")
            }
            return out
        }

        function verifyPermissions() {
            var apiUser = Config.get("apiUser");
            if (Config.get("handwriting") && !apiUser.handwriting) {
                throw new Error("API user " + apiUser.user + " does not have handwriting enabled.")
            }
        }

        var AbstractAPI = P(function (proto) {
            proto.init = function (Calc, elt, options) {
                Config.use(validatedOptions(options), function () {
                    verifyPermissions();
                    this._calc = Calc(elt);
                    this._calc.interceptTouch();
                    if (Config.get("iframe")) {
                        ForwardMessages(this._calc)
                    }
                }.bind(this))
            };
            proto.setExpression = function (expression) {
                var expressions = this._calc.expressionsModel;
                var validatedState = {};
                var id = validatedState.id = expression.id.toString();
                if (!id) {
                    return
                }
                if (expression.hasOwnProperty("latex")) {
                    validatedState.latex = expression.latex.toString()
                }
                if (expression.hasOwnProperty("color")) {
                    validatedState.color = expression.color.toString()
                }
                if (expression.hasOwnProperty("style")) {
                    validatedState.style = expression.style.toString()
                }
                if (expression.hasOwnProperty("hidden")) {
                    validatedState.hidden = !!expression.hidden
                }
                if (expressions.getItemById(id)) {
                    expressions.updateItemById(id, validatedState)
                } else {
                    var obj = expressions.fromState(_parseExpression(validatedState));
                    expressions.addItem(obj)
                }
            };
            proto.setExpressions = function (expressions) {
                expressions.forEach(this.setExpression.bind(this))
            };
            proto.removeExpression = function (expression) {
                var expressions = this._calc.expressionsModel;
                var id = expression.id.toString();
                expressions.removeItemById(id)
            };
            proto.removeExpressions = function (expressions) {
                expressions.forEach(this.removeExpression.bind(this))
            };
            proto.setViewport = function (bounds) {
                if (bounds.length == 4 && bounds[1] > bounds[0] && bounds[3] > bounds[2]) {
                    this._calc.setViewport(bounds)
                } else {
                    console.warn("Invalid viewport.  Expected [xmin, xmax, ymin, ymax].  Got " + bounds)
                }
            };
            proto.resize = function () {
                this._calc.resize()
            };
            proto.setBlank = function () {
                return this._calc.setBlank.apply(this._calc, arguments)
            };
            proto.setState = function () {
                return this._calc.setState.apply(this._calc, arguments)
            };
            proto.getState = function () {
                return this._calc.getState.apply(this._calc, arguments)
            };
            proto.screenshot = function (opts) {
                opts = opts ? opts : {};
                return this._calc.grapher.screenshot(opts.width, opts.height)
            }
        });
        window.Desmos.Colors = {RED: Colors.RED, BLUE: Colors.BLUE, GREEN: Colors.GREEN, ORANGE: Colors.ORANGE, PURPLE: Colors.PURPLE, BLACK: Colors.BLACK, next: Colors.next};
        return AbstractAPI
    });
    define("api/calculator", ["require", "pjs", "underscore", "main/calc_embed", "./abstract_api", "underscore_model"], function (require) {
        var P = require("pjs");
        var _ = require("underscore");
        var Calc = require("main/calc_embed");
        var AbstractAPI = require("./abstract_api");
        var UnderscoreModel = require("underscore_model");
        var Calculator = P(AbstractAPI, function (proto, _super) {
            proto.init = function (elt, options) {
                _super.init.call(this, Calc, elt, options)
            };
            proto.setOptions = function () {
                return this._calc.setOptions.apply(this._calc, arguments)
            }
        });
        window.Desmos.Calculator = Calculator;
        return Calculator
    });
    var Desmos = window.Desmos || {};
    Desmos.require = require;
    Desmos.requirejs = requirejs;
    requirejs(["api/calculator", "jquery", "underscore"], function (calculator, $, _) {
        Desmos.$ = $;
        Desmos._ = _;
        $.noConflict(true);
        _.noConflict()
    }, undefined, true);
    define("toplevel/calculator_embed", function () {
    })
}());
