/**
 * Created by Administrator on 2017/5/22.
 *
 * 依赖：
 * 	monent
 * 	lodash
 * 	jquery
 *
 *
 */
//todo 异步处理
var ResStatusListener = function(rrtAPI){
	var publishingHomework = null;
	var fetchInterval = null;

	function refreshItem(homeworkItem,callback){
		var item = (_.remove(publishingHomework,{homework_id:homeworkItem.homework_id}))[0];
		item.res_status = homeworkItem.res_status;
		if(callback) callback(item);
	}

	function getResStatus(callback){
		if(publishingHomework && publishingHomework.length>0){
			var params = [];
			_.forEach(publishingHomework,function(homeworkItem){
				params.push('homework_id='+homeworkItem.homework_id)
			});
			rrtAPI.getHomeworkResStatus(params.join('&')).then(function(data){
				//data.items[0].res_status = 2;

				_.forEach(data.items,function(homeworkItem){
					switch (homeworkItem.res_status){
						case 1:
							//状态改变后，进行刷新 data-homework-id
							//  状态标志，重发按钮，公布答案
							refreshItem(homeworkItem,callback);
							break;
						case 2:
							refreshItem(homeworkItem,callback);
							break;
						default: //do nothing;
					}
				});
				console.info(_.pluck(publishingHomework,'homework_id').join(','));
				if(publishingHomework.length===0){
					publishingHomework = null;
					cancel();
				}
			});
		}else{
			cancel();
		}
	}

	function listenPublishingHomework(homeworkList){
		if(homeworkList && homeworkList.length>0){
			if(!publishingHomework) publishingHomework = [];
			_.forEach(homeworkList,function(homeworkItem){
				if(homeworkItem.res_status===0 && _.findIndex(publishingHomework,{homework_id:homeworkItem.homework_id})===-1){
					publishingHomework.push(homeworkItem);
				}
			});

			if(publishingHomework.length===0) {
				publishingHomework = null;
			}else{
				return true;
			}
		}
	}

	/**
	 *	对指定作业列表中的作业状态进行监听，当状态变动时调用回调，如果作业列表中存在重复作业，并不重复监听，进行增量添加监听列表
	 *
	 * @param homework 	需要监听状态的作业列表
	 * @param cb			当状态变动时的回调方法
	 */
	function startListen(homework,cb){
		if(!homework) return;
		var homeworkList = homework;
		if(!_.isArray(homework)){
			homeworkList = [homework];
		}
		//判断是否需要进行监听
		if(listenPublishingHomework(homeworkList)){
			if(fetchInterval) return;
			fetchInterval = window.setInterval(function(){
				console.info('fetchInterval action!');
				getResStatus(cb);
			},2000);
		}
	}

	function cancel(){
		if(fetchInterval){
			clearInterval(fetchInterval);
			fetchInterval = null;
		}
	}


	return {
		start:startListen,
		cancel:cancel
	};

};
try{
	if(module && module.exports)
		module.exports.default = ResStatusListener;
}catch(e){
	console.info('it is not common pattern');
}

