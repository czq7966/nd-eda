import CloudAtlas from '@sdp.nd/cloud-atlas-web-sdk'
import moment from 'moment'
import nativeApi from 'nativeApi'
import requestConfig from 'common/request/config'

var cloudAtlasInit = function () {
    const cloudEnv = ['development', 'test', 'preproduction'].includes(window.config.env) ? 'PRODUCT' : 'PRODUCT'
    var options = {
        appKey: window.config.cloudAppKey,
        appVer: window.config.cloudAppVer,
        env: cloudEnv
    };
    new CloudAtlas(options);
};
var cloudAtlasOpen = function () {
    window.setTimeout(function () {
        CloudAtlas.onOpen();
    }, 0);
};
var cloudAtlasClose = function () {
    window.setTimeout(function () {
        if (window.attachEvent) {
            window.attachEvent("onbeforeunload", function () {
                CloudAtlas.onClose();
            });
        } else {
            window.addEventListener("beforeunload", function () {
                CloudAtlas.onClose();
            }, true);
        }
    }, 0);
};
var cloudAtlasMobileClose = function () {
    window.setTimeout(function () {
        CloudAtlas.onClose();
    }, 200);
};
var cloudAtlasSignIn = function (user_id) {
    window.setTimeout(function () {
        CloudAtlas.onProfileSignIn(user_id);
    }, 0);
};
var cloudAtlasSignOff = function (user_id) {
    window.setTimeout(function () {
        CloudAtlas.onProfileSignOff();
    }, 0);
};
var cloudAtlasEvent = function (obj) {
    if(!('info' in obj)) {
        obj.info = {
            version: nativeApi.getPlatform(),
            time: moment().format('YYYY-MM-DD HH:mm'),
            user_id: requestConfig.userInfo.uid + ""
        }
    }

    window.setTimeout(function () {
        console.log('qwqw', obj)
        CloudAtlas.onEvent(obj);
    }, 0);
};

export default {
    cloudAtlasInit:cloudAtlasInit,
    cloudAtlasOpen:cloudAtlasOpen,
    cloudAtlasClose:cloudAtlasClose,
    cloudAtlasSignIn:cloudAtlasSignIn,
    cloudAtlasEvent:cloudAtlasEvent,
    cloudAtlasSignOff:cloudAtlasSignOff,
    cloudAtlasMobileClose:cloudAtlasMobileClose
}
