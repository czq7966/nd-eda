
let dev_host = 'esp-homework-mobile.dev.web.nd' // 开发环境
let debug_host = 'mini-homework-h5.debug.ndaeweb.com' // 测试环境
let debug_host2 = 'tiny-homework-h5.debug.ndaeweb.com' // 测试环境
let beta_host = 'mini-homework-h5.beta.101.com' // 预生产环境
let prod_host = 'mini-homework-h5.sdp.101.com' // 生产环境
let aws_host = 'esp-homework-mobile.aws.101.com' // aws环境
let awsca_host = 'esp-homework-mobile.awsca.101.com' // awsca环境
let wjt_host = 'esp-homework-mobile.wjt.101.com' // 网教通环境
let snwjt_host = 'esp-homework-mobile.sneduyun.com.cn' // 陕西网教通环境
let hk_host = 'esp-homework-mobile.hk.101.com' // 陕西网教通环境
let iraq_host = 'mini-homework-h5.iraq.101.com'
let ncet_xedu = 'xue.eduyun.cn'

let currentHost = window.location.href
if (currentHost.indexOf('localhost') >= 0) {
  require("../../filters/h5/test/config");
} else if (currentHost.indexOf(dev_host) >= 0) {
  require("../../filters/h5/development/config");
} else if (currentHost.indexOf(debug_host) >= 0 || currentHost.indexOf(debug_host2) >= 0) {
  require("../../filters/h5/test/config");
} else if (currentHost.indexOf(beta_host) >= 0 || currentHost.indexOf('esp-homework-mobile.beta.web.sdp.101.com') >= 0) {
  require("../../filters/h5/preproduction/config");
} else if (currentHost.indexOf(prod_host) >= 0 || currentHost.indexOf('esp-homework-mobile.edu.web.sdp.101.com') >= 0) {
  require("../../filters/h5/product/config");
} else if (currentHost.indexOf(aws_host) >= 0) {
  require("../../filters/h5/aws/config");
} else if (currentHost.indexOf(awsca_host) >= 0) {
  require("../../filters/h5/aws-california/config");
} else if (currentHost.indexOf(wjt_host) >= 0) {
  require("../../filters/h5/wjt/config");
} else if (currentHost.indexOf(snwjt_host) >= 0) {
  require("../../filters/h5/snwjt/config");
} else if (currentHost.indexOf(hk_host) >= 0) {
  require("../../filters/h5/hk/config");
} else if (currentHost.indexOf('192.168') >= 0) {
  require("../../filters/h5/preproduction/config");
} else if (currentHost.indexOf(iraq_host) >= 0) {
  require("../../filters/h5/pre-iraq-edu/config");
} else if (currentHost.indexOf(ncet_xedu) >= 0) {
  require("../../filters/h5/ncet-xedu/config");
}

